"""Invoke the frozen distribution's canonical Swift console entry point."""
import hashlib
from importlib import metadata
from pathlib import Path
import sys

VERSION = '4.4.2'
ENTRY = 'swift.cli.main:cli_main'
SOURCE_BYTES = 3264
SOURCE_SHA256 = 'd84a44f9911c01c9af83db19baf2068ad39a8ec926f6e2c58f6f69779bfdad68'


def resolve_cli():
    distribution = metadata.distribution('ms-swift')
    entries = [e for e in distribution.entry_points if e.group == 'console_scripts' and e.name == 'swift']
    if distribution.version != VERSION or len(entries) != 1 or entries[0].value != ENTRY:
        raise ValueError('Swift console metadata differs from the frozen reference')
    source = Path(distribution.locate_file('swift/cli/main.py')).resolve(strict=True)
    if source.stat().st_size != SOURCE_BYTES or hashlib.sha256(source.read_bytes()).hexdigest() != SOURCE_SHA256:
        raise ValueError('Swift console dispatcher source differs from the frozen reference')
    function = entries[0].load()
    if (getattr(function, '__module__', None) != 'swift.cli.main'
            or getattr(function, '__name__', None) != 'cli_main'
            or Path(sys.modules['swift.cli.main'].__file__).resolve(strict=True) != source):
        raise ValueError('Swift console dispatcher was loaded from a foreign provider')
    return function


def main():
    # Keep every original argument and environment variable for Swift's own
    # single-/multi-process dispatcher. No training flags are interpreted here.
    return resolve_cli()()


if __name__ == '__main__':
    raise SystemExit(main())
