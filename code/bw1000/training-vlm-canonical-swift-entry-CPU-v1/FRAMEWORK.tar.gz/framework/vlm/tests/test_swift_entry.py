"""Canonical dispatch preserves original flags and rejects foreign console metadata."""
import importlib.util
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

SOURCE = Path(__file__).resolve().parents[1]/'runtime/swift_entry.py'
spec = importlib.util.spec_from_file_location('shared_swift_entry', SOURCE)
entry = importlib.util.module_from_spec(spec)
spec.loader.exec_module(entry)


class SwiftEntryTest(unittest.TestCase):
    def test_original_training_arguments_are_left_to_the_canonical_dispatcher(self):
        argv = ['swift_entry.py', 'sft', '--max_steps', '25', '--lora_dropout', '0.05',
                '--gradient_accumulation_steps', '4', '--warmup_steps', '5']
        received = []
        def canonical():
            received.append(sys.argv.copy())
            return 17
        with patch.object(sys, 'argv', argv.copy()), patch.object(entry, 'resolve_cli', return_value=canonical):
            self.assertEqual(entry.main(), 17)
            self.assertEqual(sys.argv, argv)
        self.assertEqual(received, [argv])

    def test_foreign_or_duplicate_metadata_never_loads_an_entry(self):
        def forbidden():
            raise AssertionError('unapproved console code was loaded')
        good = SimpleNamespace(group='console_scripts', name='swift', value=entry.ENTRY, load=forbidden)
        bad = SimpleNamespace(group='console_scripts', name='swift', value='foreign:main', load=forbidden)
        for version, entries in [('4.4.1', [good]), ('4.4.2', []), ('4.4.2', [good, good]), ('4.4.2', [bad])]:
            distribution = SimpleNamespace(version=version, entry_points=entries)
            with self.subTest(version=version, entries=entries), patch.object(entry.metadata, 'distribution', return_value=distribution):
                with self.assertRaises(ValueError):
                    entry.resolve_cli()


if __name__ == '__main__':
    unittest.main()
