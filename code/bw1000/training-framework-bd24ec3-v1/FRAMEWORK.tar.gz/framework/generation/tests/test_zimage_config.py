from pathlib import Path

import yaml


def test_rl_example_defines_pinned_inputs_and_reward():
    path = Path(__file__).resolve().parents[1] / "configs/z-image-rl.yaml"
    config = yaml.safe_load(path.read_text(encoding="utf-8"))
    for field in ("model_sha", "preset_lora_sha"):
        digest = config[field]
        assert isinstance(digest, str) and len(digest) == 64
        assert all(character in "0123456789abcdef" for character in digest)
    assert config["preset_lora_path"].endswith("zimage_turbo_training_adapter_v1.safetensors")
    assert len(config["reward_target_rgb"]) == 3
    assert all(0 <= value <= 1 for value in config["reward_target_rgb"])
    assert config["rollouts_per_prompt"] >= 4
    assert config["sample_steps"] == 8
    assert config["gradient_checkpointing"] is False
    assert config["validate_turbo_regression"] is True
    assert config["regression_prompt"]


def test_training_example_explicitly_enables_its_regression_acceptance_check():
    path = Path(__file__).resolve().parents[1] / "configs/z-image-training.yaml"
    config = yaml.safe_load(path.read_text(encoding="utf-8"))
    assert config["validate_turbo_regression"] is True
    assert config["regression_prompt"]
    assert config["checkpoint_steps"] == [10, 20]
    assert config["resume_from_checkpoint"] is None
