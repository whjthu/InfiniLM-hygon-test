from __future__ import annotations

import copy
import datetime
import tempfile
import unittest
import zipfile
from pathlib import Path

try:
    import torch
except ModuleNotFoundError as error:
    if error.name != "torch":
        raise
    torch = None

if torch is not None:
    import numpy as np

    from genmlu.backends import sf3d_training as backend


def execute_payload(path: str) -> dict:
    Path(path).write_text("executed", encoding="utf-8")
    return {}


class MaliciousValue:
    def __init__(self, path: Path):
        self.path = str(path)

    def __reduce__(self):
        return execute_payload, (self.path,)


@unittest.skipIf(torch is None, "real CPU Torch is unavailable")
class RestrictedCheckpointLoadingTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.allowed_before = set(torch.serialization.get_safe_globals())
        self.addCleanup(self.assert_allowlist_restored)

    def assert_allowlist_restored(self):
        self.assertEqual(set(torch.serialization.get_safe_globals()), self.allowed_before)

    def fixture(self):
        model = torch.nn.Linear(3, 3)
        named = list(model.named_parameters())
        optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
        progress = backend._sf3d_initial_optimizer_progress(named, optimizer)
        for parameter in model.parameters():
            parameter.grad = torch.ones_like(parameter)
        optimizer.step()
        progress = backend._sf3d_advance_optimizer_progress(progress, named, optimizer)
        contract = backend._sf3d_contract(
            identity={key: "a" * 64 for key in backend._SF3D_IDENTITY_FIELDS},
            config_sha256="b" * 64, input_sha256="c" * 64,
            seed=19, warmup_steps=0, max_steps=2, batch_count=1, device_ids=[],
        )
        cache = [{
            "triplane_features": torch.ones(2, 3),
            "image_features": torch.ones(1, 3),
            "albedo": torch.ones(1, 3),
            "roughness": torch.ones(1), "metallic": torch.ones(1),
        }]
        payload = backend._sf3d_make_checkpoint(
            contract=contract, global_optimizer_step=1, named_parameters=named,
            optimizer=optimizer, optimizer_progress=progress, cached_batches=cache,
        )
        return payload, contract, named, optimizer

    def load_and_validate(self, path, contract, named, optimizer):
        payload = backend._sf3d_load_checkpoint(path, torch)
        return backend._sf3d_validate_checkpoint(
            payload, contract, named, optimizer,
            {"triplane_width": 3, "image_width": 3}, torch, native_rng=False,
        )

    def test_real_mt19937_round_trip_with_both_reconstruct_aliases(self):
        payload, contract, named, optimizer = self.fixture()
        self.assertEqual(payload["rng"]["numpy"][0], "MT19937")
        self.assertEqual(payload["rng"]["numpy"][1].dtype, np.dtype(np.uint32))
        original = self.root / "original.pt"
        torch.save(payload, original)
        for namespace in ("numpy.core", "numpy._core"):
            with self.subTest(namespace=namespace):
                path = self.root / (namespace + ".pt")
                # Rewrite only the producer's GLOBAL name, preserving real tensor storage.
                with zipfile.ZipFile(original) as source, zipfile.ZipFile(path, "w") as target:
                    for entry in source.infolist():
                        data = source.read(entry.filename)
                        if entry.filename.endswith("/data.pkl"):
                            aliases = [b"cnumpy.core.multiarray\n_reconstruct\n",
                                       b"cnumpy._core.multiarray\n_reconstruct\n"]
                            self.assertEqual(sum(data.count(alias) for alias in aliases), 1)
                            for alias in aliases:
                                data = data.replace(alias, (
                                    "c" + namespace + ".multiarray\n_reconstruct\n"
                                ).encode("ascii"))
                        target.writestr(entry, data)
                loaded = backend._sf3d_load_checkpoint(path, torch)
                self.assertEqual(backend._sf3d_type_tree_sha256(loaded),
                                 backend._sf3d_type_tree_sha256(payload))
                self.assertEqual(self.load_and_validate(path, contract, named, optimizer)["next"],
                                 {"global_optimizer_step": 2, "data_cursor": 0})
                self.assert_allowlist_restored()

    def test_malicious_reduce_is_not_executed(self):
        marker = self.root / "executed.txt"
        path = self.root / "malicious.pt"
        torch.save({"value": MaliciousValue(marker)}, path)
        with self.assertRaises(backend.SF3DCheckpointValidationError):
            backend._sf3d_load_checkpoint(path, torch)
        self.assertFalse(marker.exists())

    def test_unsupported_global_is_rejected(self):
        path = self.root / "global.pt"
        torch.save({"value": datetime.datetime(2026, 10, 10)}, path)
        with self.assertRaises(backend.SF3DCheckpointValidationError):
            backend._sf3d_load_checkpoint(path, torch)

    def test_unsupported_rng_dtypes_are_rejected(self):
        payload, contract, named, optimizer = self.fixture()
        for dtype in (np.int64, np.float64, object):
            with self.subTest(dtype=dtype):
                candidate = copy.deepcopy(payload)
                rng = list(candidate["rng"]["numpy"])
                rng[1] = rng[1].astype(dtype)
                candidate["rng"]["numpy"] = tuple(rng)
                if dtype is not object:
                    candidate["integrity_sha256"] = backend._sf3d_checkpoint_integrity({
                        key: value for key, value in candidate.items() if key != "integrity_sha256"
                    })
                path = self.root / "dtype.pt"
                torch.save(candidate, path)
                with self.assertRaises(backend.SF3DCheckpointValidationError):
                    self.load_and_validate(path, contract, named, optimizer)

    def test_missing_and_malformed_files_are_rejected(self):
        path = self.root / "missing.pt"
        with self.assertRaises(backend.SF3DCheckpointValidationError):
            backend._sf3d_load_checkpoint(path, torch)
        path.write_bytes(b"not a torch checkpoint")
        with self.assertRaises(backend.SF3DCheckpointValidationError):
            backend._sf3d_load_checkpoint(path, torch)
        torch.save([], path)
        with self.assertRaises(backend.SF3DCheckpointValidationError):
            backend._sf3d_load_checkpoint(path, torch)

    def test_missing_payload_fields_and_bad_integrity_are_rejected(self):
        payload, contract, named, optimizer = self.fixture()
        for field in ("metadata", "state", "rng", "integrity_sha256"):
            with self.subTest(field=field):
                candidate = copy.deepcopy(payload)
                del candidate[field]
                path = self.root / "incomplete.pt"
                torch.save(candidate, path)
                with self.assertRaises(backend.SF3DCheckpointValidationError):
                    self.load_and_validate(path, contract, named, optimizer)
        payload["state"]["material_heads"][named[0][0]].add_(1)
        path = self.root / "tampered.pt"
        torch.save(payload, path)
        with self.assertRaisesRegex(backend.SF3DCheckpointValidationError, "integrity mismatch"):
            self.load_and_validate(path, contract, named, optimizer)


if __name__ == "__main__":
    unittest.main()
