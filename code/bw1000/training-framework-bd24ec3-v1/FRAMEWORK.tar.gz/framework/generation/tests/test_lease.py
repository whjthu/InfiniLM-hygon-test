from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys

import pytest

from genmlu import lease


class FakeFcntl:
    LOCK_EX = 1
    LOCK_NB = 2
    LOCK_UN = 8

    def __init__(self, fail_on: int | None = None) -> None:
        self.fail_on = fail_on
        self.acquire_calls = 0
        self.unlock_calls = 0

    def flock(self, _fd: int, operation: int) -> None:
        if operation & self.LOCK_UN:
            self.unlock_calls += 1
            return
        self.acquire_calls += 1
        if self.fail_on == self.acquire_calls:
            raise BlockingIOError("locked")


def test_parse_cards_sorts_cards_for_a_stable_lock_order() -> None:
    assert lease.parse_cards("2,0,1") == (0, 1, 2)


def test_lease_location_requires_an_absolute_shared_root_and_physical_host(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="--lock-root"):
        lease.lease_location(None, "physical-a")
    with pytest.raises(ValueError, match="absolute"):
        lease.lease_location(Path("relative-locks"), "physical-a")
    with pytest.raises(ValueError, match="--lock-host"):
        lease.lease_location(tmp_path, None)
    assert lease.lease_location(tmp_path, "physical-a") == (tmp_path.resolve(), "physical-a")


def test_overlap_is_rejected_nonblocking_and_partially_acquired_cards_are_released(tmp_path: Path, monkeypatch) -> None:
    fake = FakeFcntl(fail_on=2)
    monkeypatch.setattr(lease, "_load_fcntl", lambda: fake)
    with pytest.raises(RuntimeError, match="card 2 is already leased"):
        with lease.acquire((1, 2), tmp_path, host="worker-a"):
            pass
    assert fake.acquire_calls == 2
    assert fake.unlock_calls == 1
    assert (tmp_path / "worker-a" / "card-1.lock").is_file()
    assert (tmp_path / "worker-a" / "card-2.lock").is_file()


def test_exception_in_lease_body_releases_every_card_and_hosts_are_isolated(tmp_path: Path, monkeypatch) -> None:
    fake = FakeFcntl()
    monkeypatch.setattr(lease, "_load_fcntl", lambda: fake)
    with pytest.raises(ValueError, match="backend failed"):
        with lease.acquire((1, 0), tmp_path, host="worker-a"):
            raise ValueError("backend failed")
    with lease.acquire((0,), tmp_path, host="worker-b"):
        pass
    assert fake.unlock_calls == 3
    assert (tmp_path / "worker-a" / "card-0.lock").is_file()
    assert (tmp_path / "worker-b" / "card-0.lock").is_file()


@pytest.mark.skipif(os.name == "nt", reason="fcntl leases require POSIX")
def test_real_process_holding_card_rejects_overlapping_lease(tmp_path: Path) -> None:
    program = """
from pathlib import Path
import sys
import time
from genmlu.lease import acquire

with acquire((0,), Path(sys.argv[1]), host="physical-a"):
    print("locked", flush=True)
    time.sleep(30)
"""
    process = subprocess.Popen(
        [sys.executable, "-c", program, str(tmp_path)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    try:
        assert process.stdout is not None
        assert process.stdout.readline().strip() == "locked"
        with pytest.raises(RuntimeError, match="card 0 is already leased"):
            with lease.acquire((0,), tmp_path, host="physical-a"):
                pass
    finally:
        process.terminate()
        process.wait(timeout=10)
