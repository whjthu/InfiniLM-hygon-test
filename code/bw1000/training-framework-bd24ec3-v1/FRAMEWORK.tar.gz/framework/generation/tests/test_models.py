from pathlib import Path

from genmlu.models import load_specs
from genmlu.cli import DEFAULT_MODELS


def test_packaged_registry_contains_all_supported_models() -> None:
    assert set(load_specs(DEFAULT_MODELS)) == {
        "sdxl-1.0", "z-image-turbo", "hunyuanvideo-1.5", "hy-motion-1.0",
        "trellis-2-4b", "trellis-shape-flow-1.3b", "vggt-1b", "stable-fast-3d",
    }


def test_custom_registry_file_is_supported(tmp_path: Path) -> None:
    custom = tmp_path / "models.yaml"
    custom.write_text("models: {}\n", encoding="utf-8")
    assert load_specs(custom) == {}
