from __future__ import annotations

import copy
import sys
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest

from genmlu import cli
from genmlu.backends import trellis2_generation as backend
from genmlu.manifest import merge_backend_result, new_manifest, sha256_path
from genmlu.models import ModelSpec
from genmlu.trellis_output_contract import DIAGNOSTIC_MULTIBOX, LATENT_ONLY, validate_output_contract


def _arrays() -> dict[str, np.ndarray]:
    return {
        "condition": np.array([[1.0, 2.0]], dtype=np.float32),
        "coords": np.array([[0, 1, 2, 3], [0, 2, 3, 4]], dtype=np.int32),
        "shape_latent": np.array([[3.0]], dtype=np.float32),
        "structure_latent": np.array([[[1.0]]], dtype=np.float32),
        "texture_latent": np.array([[4.0, 5.0, 6.0]], dtype=np.float32),
    }


def _capability(contract: str, artifact: Path) -> dict[str, object]:
    return {
        "schema": "trellis-output-capability-v1",
        "requested": contract,
        "produced": "latent_with_diagnostic_multibox" if contract == DIAGNOSTIC_MULTIBOX else LATENT_ONLY,
        "full_mesh_available": False,
        "formal_mesh_available": False,
        "textured_glb_available": False,
        "formal_output_contract": False,
        "primary_artifact": {"path": str(artifact), "sha256": sha256_path(artifact), "role": "latent"},
        "shape_decoder_executed": False,
        "texture_decoder_executed": False,
        "decoded_fields_artifact": None,
        "diagnostic_preview": contract == DIAGNOSTIC_MULTIBOX,
    }


def _result(contract: str, artifact: Path) -> dict[str, object]:
    return {
        "artifacts": [{"path": str(artifact), "sha256": sha256_path(artifact)}],
        "logs": [],
        "metrics": {},
        "stage_timings": {},
        "checks": {
            "finite_tensors": True,
            "main_forward_device": True,
            "formal_output_contract": False,
            "requested_output_contract_satisfied": True,
        },
        "output_capability": _capability(contract, artifact),
    }


@pytest.mark.parametrize("contract", [LATENT_ONLY, DIAGNOSTIC_MULTIBOX])
def test_bounded_contract_keeps_implicit_sparse_cap(contract: str) -> None:
    config = {"output_contract": contract}
    assert validate_output_contract(config) == contract
    assert "max_sparse_tokens" not in config
    assert validate_output_contract({**config, "max_sparse_tokens": 1024}) == contract


@pytest.mark.parametrize("value", [None, True, "LATENT_ONLY", "latent", "unknown", "full_mesh"])
def test_direct_backend_rejects_invalid_contract_before_mlu_setup(tmp_path: Path, monkeypatch, value) -> None:
    calls = []
    monkeypatch.setattr(backend, "require_mlu", lambda: calls.append("mlu"))
    config = {"output_contract": value}
    expected = ValueError
    with pytest.raises(expected):
        backend.run_trellis2_inference(tmp_path / "weights", config, tmp_path / "out", tmp_path / "source")
    assert calls == []


@pytest.mark.parametrize("value", [None, False, "diagnostic_Multibox", "full_mesh"])
def test_cli_load_and_dry_run_reject_invalid_contract_before_runtime(tmp_path: Path, monkeypatch, value) -> None:
    config = tmp_path / "run.yaml"
    rendered = "model: trellis-2-4b\n" if value is None else f"model: trellis-2-4b\noutput_contract: {value!r}\n"
    config.write_text(rendered, encoding="utf-8")
    expected = ValueError
    with pytest.raises(expected):
        cli.load_run_config(config, "trellis-2-4b")

    spec = ModelSpec("trellis-2-4b", "3d-generation", "trellis", "trellis-2-4b", "bfloat16", "not-included")
    monkeypatch.setattr(cli, "get_spec", lambda *_args: spec)
    monkeypatch.setattr(cli, "create_run_dir", lambda *_args: (_ for _ in ()).throw(AssertionError("run dir")))
    monkeypatch.setattr(cli, "inspect_runtime", lambda: (_ for _ in ()).throw(AssertionError("runtime")))
    args = SimpleNamespace(
        command="infer", models_config="models.yaml", model="trellis-2-4b", config=str(config),
        output_root=str(tmp_path / "outputs"), run_name="run-1", model_root=None, weights=None,
        source_root=None, dry_run=True, cards="not-parsed", lock_root=None, lock_host=None,
    )
    with pytest.raises(expected):
        cli.cmd_run(args)


def test_cpu_decode_rejects_diagnostic_multibox_before_mlu_setup(tmp_path: Path, monkeypatch) -> None:
    calls = []
    monkeypatch.setattr(backend, "require_mlu", lambda: calls.append("mlu"))
    with pytest.raises(ValueError, match="only supported with"):
        backend.run_trellis2_inference(
            tmp_path / "weights",
            {"output_contract": DIAGNOSTIC_MULTIBOX, "decode_cpu_fields": True},
            tmp_path / "out",
            tmp_path / "source",
        )
    assert calls == []


@pytest.mark.parametrize("resolution", [256, 1024])
def test_cpu_decode_rejects_grid_mismatch_before_runtime(tmp_path: Path, monkeypatch, resolution: int) -> None:
    config = {
        "output_contract": LATENT_ONLY,
        "decode_cpu_fields": True,
        "cpu_decode_resolution": resolution,
    }
    monkeypatch.setattr(
        backend, "require_mlu", lambda: (_ for _ in ()).throw(AssertionError("runtime"))
    )
    with pytest.raises(ValueError, match="requires cpu_decode_resolution=512"):
        backend.run_trellis2_inference(
            tmp_path / "weights", config, tmp_path / "out", tmp_path / "source"
        )
    path = tmp_path / "config.yaml"
    path.write_text(
        "output_contract: latent_only\ndecode_cpu_fields: true\n"
        f"cpu_decode_resolution: {resolution}\n", encoding="utf-8"
    )
    with pytest.raises(ValueError, match="requires cpu_decode_resolution=512"):
        cli.load_run_config(path, "trellis-2-4b")


@pytest.mark.parametrize(
    "extra",
    [
        {"decode_cpu_fields": "true"},
        {"cpu_decoder_source_root": ""},
        {"cpu_decode_max_points": True},
        {"cpu_decode_threads": 0},
        {"cpu_shape_decoder_sha256": "not-a-sha"},
    ],
)
def test_cpu_decode_config_rejects_invalid_values_during_load(tmp_path: Path, extra) -> None:
    config = tmp_path / "run.yaml"
    lines = ["model: trellis-2-4b", "output_contract: latent_only"]
    lines.extend(f"{name}: {value!r}" for name, value in extra.items())
    config.write_text("\n".join(lines) + "\n", encoding="utf-8")
    with pytest.raises(ValueError):
        cli.load_run_config(config, "trellis-2-4b")


def test_latent_only_never_calls_sidecar_and_keeps_npz_primary(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.delitem(sys.modules, "trimesh", raising=False)
    monkeypatch.setattr(
        backend,
        "_cpu_mesh_sidecar",
        lambda *_args: (_ for _ in ()).throw(AssertionError("sidecar")),
    )
    latent_path, artifacts, cpu_metrics, capability, semantic_sha, sidecar_seconds = (
        backend._write_output_artifacts(LATENT_ONLY, _arrays(), tmp_path)
    )
    assert latent_path.name == "trellis2-staged-latents.npz"
    assert [artifact["path"] for artifact in artifacts] == [str(latent_path)]
    assert cpu_metrics == {}
    assert sidecar_seconds is None
    assert capability["primary_artifact"]["path"] == str(latent_path)
    assert capability["diagnostic_preview"] is False
    assert "trimesh" not in sys.modules
    with np.load(latent_path) as saved:
        assert np.isfinite(saved["texture_latent"]).all()
    assert semantic_sha == backend.trellis_array_sha(_arrays())


def test_diagnostic_multibox_keeps_npz_primary_and_preserves_latent_semantics(tmp_path: Path, monkeypatch) -> None:
    calls = []

    def fake_sidecar(_coords, _features, output_dir):
        calls.append(True)
        glb = output_dir / "trellis2-diagnostic-multibox.glb"
        preview = output_dir / "trellis2-diagnostic-multibox-preview.png"
        glb.write_bytes(b"diagnostic glb")
        preview.write_bytes(b"diagnostic preview")
        return glb, preview, {"cpu_sidecar": True}

    monkeypatch.setattr(backend, "_cpu_mesh_sidecar", fake_sidecar)
    latent_path, artifacts, cpu_metrics, capability, semantic_sha, sidecar_seconds = (
        backend._write_output_artifacts(DIAGNOSTIC_MULTIBOX, _arrays(), tmp_path)
    )
    assert calls == [True]
    assert artifacts[0]["path"] == str(latent_path)
    assert all("staged-mesh" not in artifact["path"] for artifact in artifacts)
    assert capability["produced"] == "latent_with_diagnostic_multibox"
    assert capability["primary_artifact"]["role"] == "latent"
    assert capability["diagnostic_preview"] is True
    assert cpu_metrics == {"cpu_sidecar": True}
    assert sidecar_seconds is not None and sidecar_seconds >= 0.0
    assert semantic_sha == backend.trellis_array_sha(_arrays())


def test_diagnostic_artifacts_merge_before_the_formal_contract_fails(tmp_path: Path, monkeypatch) -> None:
    def fake_sidecar(_coords, _features, output_dir):
        glb = output_dir / "trellis2-diagnostic-multibox.glb"
        preview = output_dir / "trellis2-diagnostic-multibox-preview.png"
        glb.write_bytes(b"diagnostic glb")
        preview.write_bytes(b"diagnostic preview")
        return glb, preview, {"cpu_sidecar": True}

    monkeypatch.setattr(backend, "_cpu_mesh_sidecar", fake_sidecar)
    latent_path, artifacts, _metrics, capability, _sha, _seconds = backend._write_output_artifacts(
        DIAGNOSTIC_MULTIBOX, _arrays(), tmp_path
    )
    result = _result(DIAGNOSTIC_MULTIBOX, latent_path)
    result["artifacts"] = artifacts
    result["output_capability"] = capability
    value = new_manifest("infer", "trellis-2-4b", {"output_contract": DIAGNOSTIC_MULTIBOX}, {})
    merge_backend_result(value, result)
    assert value["artifacts"] == artifacts
    assert value["checks"]["formal_output_contract"] is False


def test_trellis_manifest_persists_only_validated_capability(tmp_path: Path) -> None:
    artifact = tmp_path / "latents.npz"
    artifact.write_bytes(b"real latent evidence")
    value = new_manifest("infer", "trellis-2-4b", {"output_contract": LATENT_ONLY}, {})
    result = _result(LATENT_ONLY, artifact)
    merge_backend_result(value, result)
    assert value["output_capability"] == result["output_capability"]
    assert value["artifacts"] == result["artifacts"]


@pytest.mark.parametrize("check_value", [None, True, "false"])
def test_trellis_manifest_requires_false_formal_check_not_a_metric(
    tmp_path: Path, check_value
) -> None:
    artifact = tmp_path / "latents.npz"
    artifact.write_bytes(b"real latent evidence")
    result = _result(LATENT_ONLY, artifact)
    result["metrics"]["formal_output_contract"] = False
    if check_value is None:
        result["checks"].pop("formal_output_contract")
    else:
        result["checks"]["formal_output_contract"] = check_value
    value = new_manifest("infer", "trellis-2-4b", {"output_contract": LATENT_ONLY}, {})
    with pytest.raises(ValueError, match="checks.formal_output_contract"):
        merge_backend_result(value, result)
    assert value.get("status") != "completed"


@pytest.mark.parametrize(
    "mutation", ["missing", "spoofed_path", "spoofed_primary", "wrong_contract", "formal_true"]
)
def test_trellis_manifest_rejects_missing_or_spoofed_capability(tmp_path: Path, mutation: str) -> None:
    artifact = tmp_path / "latents.npz"
    artifact.write_bytes(b"real latent evidence")
    result = _result(LATENT_ONLY, artifact)
    if mutation == "missing":
        result.pop("output_capability")
    elif mutation == "spoofed_path":
        result["output_capability"]["primary_artifact"]["path"] = str(tmp_path / "other.npz")
    elif mutation == "spoofed_primary":
        result["output_capability"]["primary_artifact"]["sha256"] = "0" * 64
    elif mutation == "wrong_contract":
        result["output_capability"]["requested"] = DIAGNOSTIC_MULTIBOX
    else:
        result["output_capability"]["formal_output_contract"] = True
    value = new_manifest("infer", "trellis-2-4b", {"output_contract": LATENT_ONLY}, {})
    with pytest.raises((ValueError, NotImplementedError)):
        merge_backend_result(value, result)
    assert value.get("status") != "completed"


def test_non_trellis_manifest_does_not_require_capability(tmp_path: Path) -> None:
    artifact = tmp_path / "image.png"
    artifact.write_bytes(b"image")
    value = new_manifest("infer", "sdxl-1.0", {}, {})
    merge_backend_result(value, {
        "artifacts": [{"path": str(artifact), "sha256": sha256_path(artifact)}],
        "logs": [], "metrics": {}, "stage_timings": {}, "checks": {},
    })
    assert value["status"] == "completed"
    assert "output_capability" not in value


def test_cli_accepts_bounded_trellis_latent_capability_and_releases_lease(
    tmp_path: Path, monkeypatch
) -> None:
    config = tmp_path / "run.yaml"
    config.write_text("model: trellis-2-4b\noutput_contract: latent_only\n", encoding="utf-8")
    artifact = tmp_path / "latents.npz"
    artifact.write_bytes(b"real latent evidence")
    written = []
    entered = False
    spec = ModelSpec("trellis-2-4b", "3d-generation", "trellis", "trellis-2-4b", "bfloat16", "not-included")

    @contextmanager
    def fake_acquire(*_args, **_kwargs):
        nonlocal entered
        entered = True
        try:
            yield tmp_path / "locks"
        finally:
            entered = False

    monkeypatch.setenv("MLU_VISIBLE_DEVICES", "0")
    monkeypatch.setattr(cli, "get_spec", lambda *_args: spec)
    monkeypatch.setattr(cli, "resolve_weights", lambda *_args: tmp_path / "weights")
    monkeypatch.setattr(cli, "create_run_dir", lambda *_args: tmp_path / "run")
    monkeypatch.setattr(cli, "lease_location", lambda *_args: (tmp_path / "locks", "physical-a"))
    monkeypatch.setattr(cli, "acquire", fake_acquire)
    monkeypatch.setattr(cli, "inspect_runtime", lambda: SimpleNamespace(torch_version=None))
    monkeypatch.setattr(cli, "run_backend", lambda *_args: _result(LATENT_ONLY, artifact))
    monkeypatch.setattr(cli, "write_manifest", lambda _path, manifest: written.append(copy.deepcopy(manifest)))
    args = SimpleNamespace(
        command="infer", models_config="models.yaml", model="trellis-2-4b", config=str(config),
        output_root=str(tmp_path / "outputs"), run_name="run-1", model_root=None, weights=None,
        source_root=None, dry_run=False, cards="0", lock_root=str(tmp_path / "locks"), lock_host="physical-a",
    )
    assert cli.cmd_run(args) == 0
    assert not entered
    final = written[-1]
    assert final["status"] == "completed"
    assert final["artifacts"] == [{"path": str(artifact), "sha256": sha256_path(artifact)}]
    assert final["output_capability"]["primary_artifact"]["path"] == str(artifact)
    assert final["output_capability"]["formal_output_contract"] is False
    assert final["checks"]["formal_output_contract"] is False
    assert "failed_checks" not in final["execution"]


def test_formal_output_contract_false_is_non_failing_only_for_trellis() -> None:
    checks = {"finite_tensors": True, "formal_output_contract": False}

    assert cli.failed_backend_checks("trellis-2-4b", checks) == []
    assert cli.failed_backend_checks("sdxl-1.0", checks) == ["formal_output_contract"]


def test_cli_native_texture_preflight_precedes_runtime(tmp_path: Path, monkeypatch) -> None:
    spec = ModelSpec("trellis-2-4b", "3d-generation", "trellis", "trellis-2-4b", "bfloat16", "not-included")
    config = {"output_contract": "full_mesh"}
    calls = []

    @contextmanager
    def acquire(*_args, **_kwargs):
        yield tmp_path

    def reject(*_args):
        calls.append("native_preflight")
        raise RuntimeError("native unavailable")

    monkeypatch.setattr(cli, "get_spec", lambda *_args: spec)
    monkeypatch.setattr(cli, "load_run_config", lambda *_args: config)
    monkeypatch.setattr(cli, "resolve_weights", lambda *_args: tmp_path)
    monkeypatch.setattr(cli, "create_run_dir", lambda *_args: tmp_path)
    monkeypatch.setattr(cli, "lease_location", lambda *_args: (tmp_path, "physical-a"))
    monkeypatch.setattr(cli, "configure_visible_cards", lambda *_args: None)
    monkeypatch.setattr(cli, "acquire", acquire)
    monkeypatch.setattr(cli, "write_manifest", lambda *_args: None)
    monkeypatch.setattr(backend, "preflight_cpu_texture_export", reject)
    monkeypatch.setattr(cli, "inspect_runtime", lambda: (_ for _ in ()).throw(AssertionError("runtime before preflight")))
    args = SimpleNamespace(command="infer", models_config="models.yaml", model="trellis-2-4b", config="run.yaml",
                           output_root=str(tmp_path), run_name="run", model_root=None, weights=None,
                           source_root=None, dry_run=False, cards="0", lock_root=None, lock_host=None)
    with pytest.raises(RuntimeError, match="native unavailable"):
        cli.cmd_run(args)
    assert calls == ["native_preflight"]
