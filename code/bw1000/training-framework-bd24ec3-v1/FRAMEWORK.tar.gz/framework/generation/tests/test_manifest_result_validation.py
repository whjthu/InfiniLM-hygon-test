from __future__ import annotations

from pathlib import Path

import pytest

from genmlu.manifest import merge_backend_result, new_manifest, sha256_path, write_manifest


def manifest() -> dict[str, object]:
    return new_manifest("infer", "sdxl-1.0", {}, {})


def result(entry: dict[str, object], logs: list[dict[str, object]] | None = None) -> dict[str, object]:
    return {
        "artifacts": [entry],
        "logs": [] if logs is None else logs,
        "metrics": {},
        "stage_timings": {},
        "checks": {},
    }


@pytest.mark.parametrize("kind", ("missing", "empty", "wrong_hash", "missing_hash"))
def test_invalid_artifact_never_marks_manifest_completed(tmp_path: Path, kind: str) -> None:
    artifact = tmp_path / "artifact.bin"
    if kind != "missing":
        artifact.write_bytes(b"" if kind == "empty" else b"artifact")
    entry: dict[str, object] = {"path": str(artifact), "sha256": sha256_path(artifact)}
    if kind == "wrong_hash":
        entry["sha256"] = "0" * 64
    elif kind == "missing_hash":
        entry.pop("sha256")
    value = manifest()
    with pytest.raises(ValueError):
        merge_backend_result(value, result(entry))
    assert value.get("status") != "completed"


def test_nonempty_hashed_artifact_and_optional_empty_logs_complete_manifest(tmp_path: Path) -> None:
    artifact = tmp_path / "artifact.bin"
    artifact.write_bytes(b"artifact")
    value = manifest()
    merge_backend_result(value, result({"path": str(artifact), "sha256": sha256_path(artifact)}))
    assert value["status"] == "completed"
    assert value["artifacts"] == [{"path": str(artifact), "sha256": sha256_path(artifact)}]


def test_declared_log_must_be_nonempty_and_hash_verified(tmp_path: Path) -> None:
    artifact = tmp_path / "artifact.bin"
    artifact.write_bytes(b"artifact")
    log = tmp_path / "backend.log"
    log.write_bytes(b"")
    value = manifest()
    with pytest.raises(ValueError, match="logs\\[0\\] is missing or empty"):
        merge_backend_result(
            value,
            result(
                {"path": str(artifact), "sha256": sha256_path(artifact)},
                [{"path": str(log), "sha256": sha256_path(log)}],
            ),
        )
    assert value.get("status") != "completed"


def test_failed_atomic_replace_removes_the_temporary_manifest(tmp_path: Path, monkeypatch) -> None:
    target = tmp_path / "manifest.json"
    before = set(tmp_path.iterdir())

    def failed_replace(_source: Path, _target: Path) -> None:
        raise OSError("replace failed")

    monkeypatch.setattr(Path, "replace", failed_replace)
    with pytest.raises(OSError, match="replace failed"):
        write_manifest(target, {"status": "running"})
    assert set(tmp_path.iterdir()) == before


def test_observations_must_be_a_mapping(tmp_path: Path) -> None:
    artifact = tmp_path / "artifact.bin"
    artifact.write_bytes(b"artifact")
    value = result({"path": str(artifact), "sha256": sha256_path(artifact)})
    value["observations"] = False
    with pytest.raises(ValueError, match="observations must be a mapping"):
        merge_backend_result(manifest(), value)
