from __future__ import annotations

import importlib.util
import inspect
import sys
import threading
import time
import types
from concurrent.futures import Future, ThreadPoolExecutor
from pathlib import Path

import pytest


class FakeTensor:
    def __init__(self, values: list[int], delay: float = 0.0) -> None:
        self.values = list(values)
        self.delay = delay

    def detach(self) -> "FakeTensor":
        return self

    def cpu(self) -> "FakeTensor":
        return self

    def clone(self) -> "FakeTensor":
        return FakeTensor(self.values, self.delay)


@pytest.fixture
def sf3d(monkeypatch):
    """Load the staged backend with tiny local stubs, not the delivery checkout."""
    timing_failures: list[BaseException] = []
    failure_profiles: list[dict[str, object]] = []

    packages = {
        "genmlu": types.ModuleType("genmlu"),
        "genmlu.backends": types.ModuleType("genmlu.backends"),
        "genmlu.manifest": types.ModuleType("genmlu.manifest"),
        "genmlu.runtime": types.ModuleType("genmlu.runtime"),
        "sf3d": types.ModuleType("sf3d"),
        "sf3d.models": types.ModuleType("sf3d.models"),
        "sf3d.models.mesh": types.ModuleType("sf3d.models.mesh"),
    }
    packages["genmlu.manifest"].sha256_path = lambda _path: "unused"
    packages["genmlu.runtime"].autocast_bf16 = lambda: None
    packages["genmlu.runtime"].memory_stats = lambda: {}
    packages["genmlu.runtime"].require_mlu = lambda: None
    packages["genmlu.runtime"].synchronize = lambda: None
    packages["genmlu"].__path__ = []
    packages["genmlu.backends"].__path__ = []
    for name, module in packages.items():
        monkeypatch.setitem(sys.modules, name, module)

    source_root = Path(__file__).parents[1] / "src/genmlu"
    timing_spec = importlib.util.spec_from_file_location(
        "genmlu.sidecar_timing", source_root / "sidecar_timing.py"
    )
    assert timing_spec and timing_spec.loader
    timing_module = importlib.util.module_from_spec(timing_spec)
    monkeypatch.setitem(sys.modules, timing_spec.name, timing_module)
    timing_spec.loader.exec_module(timing_module)

    path = source_root / "backends/sf3d_reconstruction.py"
    spec = importlib.util.spec_from_file_location(
        "genmlu.backends.sf3d_dual_candidate", path
    )
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    monkeypatch.setitem(sys.modules, spec.name, module)
    spec.loader.exec_module(module)

    def capture_failure(trace, _path, exc) -> None:
        timing_failures.append(exc)
        failure_profiles.append(
            trace.finish(status="failed", error=f"{type(exc).__name__}: {exc}")
        )

    module.record_sidecar_failure = capture_failure
    module._test_timing_failures = timing_failures
    module._test_failure_profiles = failure_profiles
    return module


def _install_mesh(module, unwrap) -> None:
    class Mesh:
        def __init__(self, vertices, faces) -> None:
            self.v_pos = vertices
            self.t_pos_idx = faces
            self.v_tex = FakeTensor([42])

        def unwrap_uv(self) -> None:
            unwrap(self)

    sys.modules["sf3d.models.mesh"].Mesh = Mesh


def test_dual_workers_allow_real_uv_concurrency_and_finish_submission_order(sf3d) -> None:
    slow_started = threading.Event()
    release_slow = threading.Event()
    worker_threads: list[int] = []

    def unwrap(mesh) -> None:
        worker_threads.append(threading.get_ident())
        if mesh.v_pos.values[0] == 1:
            slow_started.set()
            assert release_slow.wait(timeout=2)

    _install_mesh(sf3d, unwrap)
    with ThreadPoolExecutor(max_workers=2) as executor:
        slow = sf3d._start_dual_worker_cpu_mesh_sidecar(
            executor, types.SimpleNamespace(v_pos=FakeTensor([1]), t_pos_idx=FakeTensor([1])),
            FakeTensor([10]), {}, 64, Path("slow.glb"),
        )
        assert slow_started.wait(timeout=2)
        fast = sf3d._start_dual_worker_cpu_mesh_sidecar(
            executor, types.SimpleNamespace(v_pos=FakeTensor([2]), t_pos_idx=FakeTensor([2])),
            FakeTensor([20]), {}, 64, Path("fast.glb"),
        )
        fast["future"].result(timeout=2)
        assert not slow["future"].done(), "the second job completed before the first"
        release_slow.set()
        slow["future"].result(timeout=2)

    assert len(set(worker_threads)) == 2
    assert all(thread_id != threading.get_ident() for thread_id in worker_threads)


def test_dual_submission_clones_cpu_and_mlu_snapshots_before_worker_runs(sf3d) -> None:
    entered = threading.Event()
    release = threading.Event()

    def unwrap(_mesh) -> None:
        entered.set()
        assert release.wait(timeout=2)

    _install_mesh(sf3d, unwrap)
    vertices = FakeTensor([1])
    faces = FakeTensor([2])
    scene_codes = FakeTensor([3])
    global_dict = {"decoder_roughness": FakeTensor([4])}
    with ThreadPoolExecutor(max_workers=1) as executor:
        pending = sf3d._start_dual_worker_cpu_mesh_sidecar(
            executor,
            types.SimpleNamespace(v_pos=vertices, t_pos_idx=faces),
            scene_codes,
            global_dict,
            64,
            Path("snapshot.glb"),
        )
        assert entered.wait(timeout=2)
        vertices.values[0] = 99
        faces.values[0] = 98
        scene_codes.values[0] = 97
        global_dict["decoder_roughness"].values[0] = 96
        release.set()
        prepared_mesh, _ = pending["future"].result(timeout=2)

    assert prepared_mesh.v_pos.values == [1]
    assert prepared_mesh.t_pos_idx.values == [2]
    assert pending["scene_codes"].values == [3]
    assert pending["global_dict"]["decoder_roughness"].values == [4]


def test_pre_inference_drain_caps_unfinished_samples_and_releases_snapshots(sf3d) -> None:
    first = {"sample": "first", "snapshot": FakeTensor([1])}
    second = {"sample": "second", "snapshot": FakeTensor([2])}
    pending = [first, second]
    completed: list[str] = []

    def finish(item) -> None:
        # The oldest no longer counts as unfinished while it is finalized.
        assert len(pending) == 1
        completed.append(item["sample"])

    sf3d._drain_dual_sidecars_before_inference(pending, finish)

    assert completed == ["first"]
    assert len(pending) == 1
    assert pending[0]["sample"] == "second"
    assert first == {}

    pending.append({"sample": "third", "snapshot": FakeTensor([3])})
    assert len(pending) == 2


def test_pre_inference_drain_failure_releases_oldest_and_does_not_admit_next(sf3d) -> None:
    first = {"sample": "first", "snapshot": FakeTensor([1])}
    second = {"sample": "second", "snapshot": FakeTensor([2])}
    pending = [first, second]

    with pytest.raises(RuntimeError, match="owner bake failed"):
        sf3d._drain_dual_sidecars_before_inference(
            pending,
            lambda _item: (_ for _ in ()).throw(RuntimeError("owner bake failed")),
        )

    assert first == {}
    assert [item["sample"] for item in pending] == ["second"]


def test_dual_worker_limits_live_uv_jobs_to_two(sf3d) -> None:
    entered = threading.Event()
    release = threading.Event()
    state = {"active": 0, "maximum": 0}
    lock = threading.Lock()

    def unwrap(_mesh) -> None:
        with lock:
            state["active"] += 1
            state["maximum"] = max(state["maximum"], state["active"])
            if state["active"] == 2:
                entered.set()
        assert release.wait(timeout=2)
        with lock:
            state["active"] -= 1

    _install_mesh(sf3d, unwrap)
    with ThreadPoolExecutor(max_workers=2) as executor:
        pending = [
            sf3d._start_dual_worker_cpu_mesh_sidecar(
                executor,
                types.SimpleNamespace(v_pos=FakeTensor([index]), t_pos_idx=FakeTensor([index])),
                FakeTensor([index]), {}, 64, Path(f"live-{index}.glb"),
            )
            for index in range(3)
        ]
        assert entered.wait(timeout=2)
        assert state["active"] == 2
        release.set()
        for item in pending:
            item["future"].result(timeout=2)

    assert state["maximum"] == 2


def test_owner_performs_baker_calls_after_worker_uv_and_preserves_failure(sf3d) -> None:
    worker_done = threading.Event()
    baker_threads: list[int] = []

    def unwrap(_mesh) -> None:
        worker_done.set()

    _install_mesh(sf3d, unwrap)

    class Baker:
        def rasterize(self, *_args):
            baker_threads.append(threading.get_ident())
            return "raster"

        def get_mask(self, _raster):
            baker_threads.append(threading.get_ident())
            return "mask"

        def interpolate(self, *_args):
            baker_threads.append(threading.get_ident())
            return {"mask": "sampled"}

    model = types.SimpleNamespace(baker=Baker())
    sf3d._finish_cpu_mesh_sidecar = lambda *_args: {"artifact": "owner-finished"}
    with ThreadPoolExecutor(max_workers=2) as executor:
        pending = sf3d._start_dual_worker_cpu_mesh_sidecar(
            executor, types.SimpleNamespace(v_pos=FakeTensor([1]), t_pos_idx=FakeTensor([2])),
            FakeTensor([3]), {}, 64, Path("owner.glb"),
        )
        assert worker_done.wait(timeout=2)
        result = sf3d._finish_dual_worker_cpu_mesh_sidecar(object(), model, pending)

    assert result["artifact"] == "owner-finished"
    assert baker_threads == [threading.get_ident()] * 3

    with ThreadPoolExecutor(max_workers=1) as executor:
        failing = sf3d._start_dual_worker_cpu_mesh_sidecar(
            executor, types.SimpleNamespace(v_pos=FakeTensor([1]), t_pos_idx=FakeTensor([2])),
            FakeTensor([3]), {}, 64, Path("failure.glb"),
        )
        failing["future"] = executor.submit(lambda: (_ for _ in ()).throw(RuntimeError("uv failed")))
        with pytest.raises(RuntimeError, match="uv failed"):
            sf3d._finish_dual_worker_cpu_mesh_sidecar(object(), model, failing)

    assert isinstance(sf3d._test_timing_failures[-1], RuntimeError)


def test_dual_worker_reports_uv_and_owner_bake_timing(sf3d) -> None:
    def unwrap(_mesh) -> None:
        time.sleep(0.02)

    _install_mesh(sf3d, unwrap)
    trace = sf3d.SidecarTiming()
    mesh, unwrap_seconds = sf3d._prepare_cpu_mesh_uv_sidecar(
        FakeTensor([1]), FakeTensor([2]), trace
    )

    class Baker:
        def rasterize(self, *_args):
            time.sleep(0.02)
            return "raster"

        def get_mask(self, _raster):
            return "mask"

        def interpolate(self, *_args):
            return {"mask": "sampled"}

    _mask, _positions, bake_seconds = sf3d._owner_bake_cpu_mesh_sidecar(
        Baker(), mesh, 64, trace
    )
    profile = trace.finish(status="completed")

    assert unwrap_seconds >= 0.015
    assert bake_seconds >= 0.015
    assert [(phase["name"], phase["execution"]) for phase in profile["phases"]] == [
        ("uv_unwrap", "cpu"),
        ("rasterize_and_interpolate", "cpu"),
    ]


def test_real_sidecar_timing_separates_ready_queue_wait_from_owner_bake(sf3d) -> None:
    class Clock:
        value = 0.0

        def __call__(self) -> float:
            return self.value

    clock = Clock()
    trace = sf3d.SidecarTiming(clock=clock, memory_reader=lambda: {})
    clock.value = 1.0
    trace.mark("mesh_transfer_and_construct", "mixed")
    clock.value = 2.0
    trace.mark("uv_unwrap", "cpu")

    class Baker:
        def rasterize(self, *_args):
            clock.value = 15.0
            return "raster"

        def get_mask(self, _raster):
            return "mask"

        def interpolate(self, *_args):
            return {"mask": "sampled"}

    future: Future[tuple[object, float]] = Future()
    mesh = types.SimpleNamespace(
        v_pos=FakeTensor([1]), t_pos_idx=FakeTensor([2]), v_tex=FakeTensor([3])
    )
    future.set_result((mesh, 1.0))
    clock.value = 12.0
    pending = {
        "future": future,
        "trace": trace,
        "sidecar_started": 0.0,
        "scene_codes": FakeTensor([4]),
        "global_dict": {},
        "bake_resolution": 64,
        "output_path": Path("timing.glb"),
    }
    sf3d._finish_cpu_mesh_sidecar = lambda *_args: {"artifact": "timing"}
    result = sf3d._finish_dual_worker_cpu_mesh_sidecar(
        object(), types.SimpleNamespace(baker=Baker()), pending
    )
    phases = result["sidecar_profile"]["phases"]

    assert [phase["name"] for phase in phases] == [
        "mesh_transfer_and_construct",
        "uv_unwrap",
        "uv_ready_queue_wait",
        "rasterize_and_interpolate",
    ]
    assert phases[2]["seconds"] == 10.0
    assert phases[3]["seconds"] == 3.0


def test_failed_uv_does_not_enter_ready_wait_or_owner_bake(sf3d) -> None:
    future: Future[tuple[object, float]] = Future()
    future.set_exception(RuntimeError("uv failed"))
    trace = sf3d.SidecarTiming(memory_reader=lambda: {})
    trace.mark("mesh_transfer_and_construct", "mixed")
    baker_called = False

    class Baker:
        def rasterize(self, *_args):
            nonlocal baker_called
            baker_called = True
            raise AssertionError("baker must not run")

    pending = {
        "future": future,
        "trace": trace,
        "sidecar_started": 0.0,
        "scene_codes": FakeTensor([4]),
        "global_dict": {},
        "bake_resolution": 64,
        "output_path": Path("failure.glb"),
    }
    with pytest.raises(RuntimeError, match="uv failed"):
        sf3d._finish_dual_worker_cpu_mesh_sidecar(
            object(), types.SimpleNamespace(baker=Baker()), pending
        )

    assert not baker_called
    assert [phase["name"] for phase in sf3d._test_failure_profiles[-1]["phases"]] == [
        "mesh_transfer_and_construct"
    ]


def test_dual_path_caps_in_flight_work_drains_warmup_and_joins_on_failure(sf3d) -> None:
    source = inspect.getsource(sf3d.run_sf3d_inference)

    assert 'cpu_sidecar_workers = int(config.get("cpu_sidecar_workers", 1))' in source
    assert "ThreadPoolExecutor(max_workers=2) if dual_worker_sidecar else None" in source
    assert "_drain_dual_sidecars_before_inference(" in source
    assert "_finish_oldest_dual_sidecar(" in source
    assert "while pending_dual_sidecars:" in source
    assert "pending[\"future\"].cancel()" in source
    assert "dual_executor.shutdown(wait=True, cancel_futures=True)" in source
    assert source.index("_drain_dual_sidecars_before_inference(") < source.index(
        "batch = batches[repeat_index % len(batches)]"
    )
    assert "if len(pending_dual_sidecars) == 2:" not in source
    assert source.index("while pending_dual_sidecars:") < source.index(
        "measurement_started = perf_counter()"
    )


def test_worker_payload_excludes_baker_mlu_and_export_work(sf3d) -> None:
    source = inspect.getsource(sf3d._prepare_cpu_mesh_uv_sidecar)

    assert "unwrap_uv()" in source
    assert "baker" not in source
    assert "rasterize" not in source
    assert "export" not in source
    assert ".to(\"mlu\")" not in source
