import errno
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
from contextlib import contextmanager

import pytest

import genmlu.benchctl as benchctl
from genmlu.benchctl import (
    CardState,
    CnmonProcess,
    RunInterrupted,
    acquire_lease,
    create_lease,
    exclusive_file_lock,
    lease_path,
    normalized_command,
    parse_cnmon_info,
    parse_cnmon_processes,
    release_lease,
    remove_lease,
    sample_preflight,
    without_process_ids,
)


@pytest.mark.skipif(os.name == "nt", reason="requires POSIX flock")
def test_exclusive_file_lock_retries_only_transient_contention(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import fcntl

    attempts = 0
    operations: list[int] = []
    sleeps: list[float] = []

    def flock(_fd: int, operation: int) -> None:
        nonlocal attempts
        operations.append(operation)
        if operation == fcntl.LOCK_UN:
            return
        attempts += 1
        if attempts < 3:
            raise BlockingIOError(errno.EAGAIN, "busy")

    monkeypatch.setattr(fcntl, "flock", flock)
    with exclusive_file_lock(
        tmp_path / "host.lock",
        timeout_seconds=1.0,
        retry_interval_seconds=0.1,
        clock=lambda: 0.0,
        sleeper=sleeps.append,
    ):
        pass
    assert attempts == 3
    assert sleeps == [0.1, 0.1]
    assert operations[:-1] == [fcntl.LOCK_EX | fcntl.LOCK_NB] * 3
    assert operations[-1] == fcntl.LOCK_UN


@pytest.mark.skipif(os.name == "nt", reason="requires POSIX flock")
def test_exclusive_file_lock_permanent_contention_times_out(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import fcntl

    times = iter((0.0, 0.0, 0.2))
    sleeps: list[float] = []

    def flock(_fd: int, operation: int) -> None:
        assert operation == fcntl.LOCK_EX | fcntl.LOCK_NB
        raise BlockingIOError(errno.EWOULDBLOCK, "busy")

    monkeypatch.setattr(fcntl, "flock", flock)
    with pytest.raises(TimeoutError, match="timed out acquiring lock"):
        with exclusive_file_lock(
            tmp_path / "host.lock",
            timeout_seconds=0.1,
            retry_interval_seconds=0.05,
            clock=lambda: next(times),
            sleeper=sleeps.append,
        ):
            pytest.fail("contended lock must not be entered")
    assert sleeps == [0.05]


@pytest.mark.skipif(os.name == "nt", reason="requires POSIX flock")
@pytest.mark.parametrize("error_number", [errno.EACCES, errno.EPERM, errno.EIO])
def test_exclusive_file_lock_does_not_retry_non_contention_errors(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, error_number: int
) -> None:
    import fcntl

    sleeps: list[float] = []
    attempts = 0

    def flock(_fd: int, _operation: int) -> None:
        nonlocal attempts
        attempts += 1
        raise OSError(error_number, "lock failure")

    monkeypatch.setattr(fcntl, "flock", flock)
    with pytest.raises(OSError) as captured:
        with exclusive_file_lock(tmp_path / "host.lock", sleeper=sleeps.append):
            pytest.fail("failed lock must not be entered")
    assert captured.value.errno == error_number
    assert attempts == 1
    assert sleeps == []


@pytest.mark.skipif(os.name == "nt", reason="requires POSIX flock")
def test_exclusive_file_lock_closes_fd_and_propagates_signal(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import fcntl

    descriptors: list[int] = []

    def flock(fd: int, _operation: int) -> None:
        descriptors.append(fd)
        raise RunInterrupted(signal.SIGTERM)

    monkeypatch.setattr(fcntl, "flock", flock)
    with pytest.raises(RunInterrupted):
        with exclusive_file_lock(tmp_path / "host.lock"):
            pytest.fail("interrupted lock must not be entered")
    assert len(descriptors) == 1
    with pytest.raises(OSError) as captured:
        os.fstat(descriptors[0])
    assert captured.value.errno == errno.EBADF


@pytest.mark.skipif(os.name == "nt", reason="requires POSIX flock")
def test_afs_lock_serializes_two_cpu_processes() -> None:
    afs_root = os.environ.get("BENCHCTL_AFS_LOCK_TEST_ROOT")
    if not afs_root:
        pytest.skip("set BENCHCTL_AFS_LOCK_TEST_ROOT to an isolated AFS test directory")
    root = Path(afs_root).resolve(strict=True)
    script = """
import sys, time
from pathlib import Path
from genmlu.benchctl import exclusive_file_lock
lock, events, label, delay = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3], float(sys.argv[4])
with exclusive_file_lock(lock, timeout_seconds=3.0):
    with events.open('a', encoding='utf-8') as stream:
        stream.write(label + '-enter\\n')
        stream.flush()
    time.sleep(delay)
    with events.open('a', encoding='utf-8') as stream:
        stream.write(label + '-exit\\n')
        stream.flush()
"""
    environment = os.environ.copy()
    source_root = str(Path(__file__).resolve().parents[1] / "src")
    environment["PYTHONPATH"] = source_root + os.pathsep + environment.get("PYTHONPATH", "")
    with tempfile.TemporaryDirectory(prefix="benchctl-flock-", dir=root) as directory:
        test_root = Path(directory)
        lock = test_root / "host.lock"
        events = test_root / "events.log"
        first = subprocess.Popen(
            [sys.executable, "-c", script, str(lock), str(events), "first", "0.5"],
            env=environment,
        )
        deadline = time.monotonic() + 5.0
        while time.monotonic() < deadline:
            if events.is_file() and "first-enter" in events.read_text(encoding="utf-8"):
                break
            time.sleep(0.01)
        else:
            first.kill()
            first.wait(timeout=5)
            pytest.fail("first AFS lock process did not acquire its isolated lock")
        second = subprocess.Popen(
            [sys.executable, "-c", script, str(lock), str(events), "second", "0"],
            env=environment,
        )
        assert first.wait(timeout=5) == 0
        assert second.wait(timeout=5) == 0
        assert events.read_text(encoding="utf-8").splitlines() == [
            "first-enter",
            "first-exit",
            "second-enter",
            "second-exit",
        ]


def test_parse_cnmon_info_for_selected_cards() -> None:
    text = """
Card 0
    MLU Average                     : 0 %
    Physical Memory Usage
        Used                            : 0 MiB
Card 1
    MLU Average                     : 12 %
    Physical Memory Usage
        Used                            : 8192 MiB
"""
    states = parse_cnmon_info(text, (0, 1, 2))
    assert states == (CardState(0, 0, 0), CardState(1, 12, 8192), CardState(2, None, None))
    assert states[0].idle
    assert not states[1].idle


def test_lease_is_exclusive_and_removable(tmp_path: Path) -> None:
    path = lease_path(tmp_path, "generative-mlu", "mlu-10000", (0, 1))
    create_lease(path, {"run_id": "one"})
    assert path.is_file()
    with pytest.raises(RuntimeError, match="already exists"):
        create_lease(path, {"run_id": "two"})
    remove_lease(path)
    assert not path.exists()


def test_normalized_command_removes_separator() -> None:
    assert normalized_command(("--", "/bin/true")) == ["/bin/true"]
    with pytest.raises(ValueError):
        normalized_command(("--",))


def test_own_controller_process_is_not_a_conflict() -> None:
    processes = ("12 Ss python3 -m genmlu.benchctl run", "13 Ss vllm serve model")
    assert without_process_ids(processes, {12}) == ("13 Ss vllm serve model",)


def test_parse_cnmon_processes_uses_real_card_and_pid_columns() -> None:
    text = """
| Processes:                                                                   |
|  Card  MI  PID     Command Line                             MLU Memory Usage |
|==============================================================================|
|  0     /   4123    python train.py --cards 0                  8192 MiB       |
|  3     /   4999    python reward.py                           1024 MiB       |
"""
    assert parse_cnmon_processes(text) == (
        CnmonProcess(0, 4123, "python train.py --cards 0", 8192),
        CnmonProcess(3, 4999, "python reward.py", 1024),
    )


def test_parse_cnmon_processes_accepts_terminal_escaped_rows() -> None:
    text = "\n".join((
        "|  Card  MI  PID     Command Line                             MLU Memory Usage |",
        "\x1b[32m|  0     /   1884973 /torch/venv3/pytorch/bin/python       0 KiB |\x1b[0m",
    ))
    assert parse_cnmon_processes(text) == (
        CnmonProcess(0, 1884973, "/torch/venv3/pytorch/bin/python", 0),
    )


@pytest.mark.parametrize(
    ("row", "expected_mib"),
    [
        ("|  0     /   1336782 /torch/venv3/pytorch/bin/python                     0 KiB |", 0),
        ("|  0     /   1336782 python train.py                                1025 KiB |", 2),
        ("|  0     /   1336782 python train.py                                 1.1 MiB |", 2),
        ("|  0     /   1336782 python train.py                                   1 GiB |", 1024),
    ],
)
def test_parse_cnmon_processes_accepts_units_with_conservative_mib_ceiling(row: str, expected_mib: int) -> None:
    text = "\n".join(("|  Card  MI  PID     Command Line                             MLU Memory Usage |", row))
    process, = parse_cnmon_processes(text)
    assert process.pid == 1336782
    assert process.used_mib == expected_mib


@pytest.mark.parametrize("memory", ("NaN MiB", "-1 MiB", "1 TiB", "1.2.3 MiB"))
def test_parse_cnmon_processes_rejects_unknown_or_invalid_memory_units(memory: str) -> None:
    text = "\n".join(("|  Card  MI  PID     Command Line                             MLU Memory Usage |",
                      f"|  0     /   1336782 python train.py                         {memory} |"))
    with pytest.raises(RuntimeError, match="process row"):
        parse_cnmon_processes(text)


def test_parse_cnmon_processes_accepts_verified_empty_table() -> None:
    text = """
|  Card  MI  PID     Command Line                             MLU Memory Usage |
|==============================================================================|
|  No running processes found                                                  |
"""
    assert parse_cnmon_processes(text) == ()
    with pytest.raises(RuntimeError, match="unable to parse"):
        parse_cnmon_processes("CNMON output changed")


def test_parse_cnmon_processes_rejects_one_malformed_pid_row() -> None:
    text = """
|  Card  MI  PID     Command Line                             MLU Memory Usage |
|  0     /   101     python valid.py                            100 MiB        |
|  1     /   PID?    python malformed.py                        ??? MiB        |
+------------------------------------------------------------------------------+
"""
    with pytest.raises(RuntimeError, match="process row"):
        parse_cnmon_processes(text)


def test_preflight_only_flags_selected_card_real_pids() -> None:
    info = """
Card 0
  MLU Average : 0 %
  Physical Memory Usage
    Used : 0 MiB
Card 1
  MLU Average : 0 %
  Physical Memory Usage
    Used : 0 MiB
"""
    process_table = """
|  Card  MI  PID     Command Line                             MLU Memory Usage |
|  0     /   101     python owned.py                            100 MiB        |
|  1     /   202     python unrelated.py                        100 MiB        |
"""

    def runner(command: tuple[str, ...], timeout: int) -> str:
        del timeout
        return info if command == ("cnmon", "info") else process_table

    result = sample_preflight((0,), runner=runner, owned_pids=frozenset({101}), host="test")
    assert result.ready
    assert result.foreign_accelerator_processes == ()


def test_preflight_blocks_foreign_zero_kib_process_on_selected_card() -> None:
    info = """
Card 0
  MLU Average : 0 %
  Physical Memory Usage
    Used : 0 MiB
"""
    process_table = """
|  Card  MI  PID     Command Line                             MLU Memory Usage |
|  0     /   1336782 /torch/venv3/pytorch/bin/python                     0 KiB |
"""

    def runner(command: tuple[str, ...], timeout: int) -> str:
        del timeout
        return info if command == ("cnmon", "info") else process_table

    result = sample_preflight((0,), runner=runner, host="test")
    assert not result.ready
    assert result.foreign_accelerator_processes == (
        "card=0 pid=1336782 memory_mib=0 command=/torch/venv3/pytorch/bin/python",
    )
    owned = sample_preflight((0,), runner=runner, host="test", owned_pids=frozenset({1336782}))
    assert owned.ready
    assert owned.foreign_accelerator_processes == ()


def test_cross_project_overlap_is_blocked_and_owner_release_is_token_safe(tmp_path: Path) -> None:
    first = acquire_lease(
        tmp_path,
        "project-a",
        "mlu-10000",
        (0, 1),
        {"cards": [0, 1], "lease_id": "owner-a"},
    )
    with pytest.raises(RuntimeError, match="overlapping lease"):
        acquire_lease(
            tmp_path,
            "project-b",
            "mlu-10000",
            (1, 2),
            {"cards": [1, 2], "lease_id": "owner-b"},
        )
    first.path.write_text('{"cards": [0, 1], "lease_id": "replacement"}\n', encoding="utf-8")
    assert not release_lease(first)
    assert first.path.is_file()


@pytest.mark.parametrize(
    ("field", "replacement"),
    [("host", "other-host"), ("cards", [0, 2]), ("pid", 9999)],
)
def test_release_requires_exact_original_owner_identity(
    tmp_path: Path, field: str, replacement: object
) -> None:
    payload = {
        "cards": [0, 1],
        "lease_id": "owner-a",
        "host": "node-a",
        "pid": 1234,
    }
    handle = acquire_lease(tmp_path, "project-a", "mlu-10000", (0, 1), payload)
    changed = dict(payload)
    changed[field] = replacement
    handle.path.write_text(json.dumps(changed) + "\n", encoding="utf-8")
    assert not release_lease(handle)
    assert json.loads(handle.path.read_text(encoding="utf-8"))[field] == replacement


def test_acquire_rollback_does_not_delete_replaced_identity(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    target = lease_path(tmp_path, "project-a", "mlu-10000", (0,))
    calls = 0

    @contextmanager
    def lock_then_fail(_path: Path):
        nonlocal calls
        calls += 1
        try:
            yield
        finally:
            if calls == 1:
                replacement = {
                    "cards": [0],
                    "lease_id": "owner-a",
                    "host": "replacement-host",
                    "pid": 9999,
                }
                target.write_text(json.dumps(replacement) + "\n", encoding="utf-8")
                raise OSError(errno.EIO, "unlock failed")

    monkeypatch.setattr(benchctl, "exclusive_file_lock", lock_then_fail)
    with pytest.raises(OSError, match="unlock failed"):
        acquire_lease(
            tmp_path,
            "project-a",
            "mlu-10000",
            (0,),
            {
                "cards": [0],
                "lease_id": "owner-a",
                "host": "original-host",
                "pid": 1234,
            },
        )
    assert json.loads(target.read_text(encoding="utf-8"))["host"] == "replacement-host"


@pytest.mark.skipif(os.name == "nt", reason="requires POSIX flock")
def test_acquire_lock_error_does_not_touch_any_lease(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import fcntl

    existing = lease_path(tmp_path, "project-a", "mlu-10000", (7,))
    existing.parent.mkdir(parents=True)
    evidence = '{"cards": [7], "lease_id": "existing"}\n'
    existing.write_text(evidence, encoding="utf-8")

    def flock(_fd: int, _operation: int) -> None:
        raise OSError(errno.EIO, "AFS lock I/O error")

    monkeypatch.setattr(fcntl, "flock", flock)
    with pytest.raises(OSError) as captured:
        acquire_lease(
            tmp_path,
            "project-b",
            "mlu-10000",
            (0,),
            {"cards": [0], "lease_id": "new"},
        )
    assert captured.value.errno == errno.EIO
    assert existing.read_text(encoding="utf-8") == evidence
    assert not lease_path(tmp_path, "project-b", "mlu-10000", (0,)).exists()


def test_unknown_lease_blocks_and_is_never_auto_deleted(tmp_path: Path) -> None:
    unknown = lease_path(tmp_path, "old-project", "mlu-10000", (7,))
    unknown.parent.mkdir(parents=True)
    unknown.write_text("not-json\n", encoding="utf-8")
    with pytest.raises(RuntimeError, match="unknown lease blocks"):
        acquire_lease(
            tmp_path,
            "new-project",
            "mlu-10000",
            (0,),
            {"cards": [0], "lease_id": "new"},
        )
    assert unknown.read_text(encoding="utf-8") == "not-json\n"
