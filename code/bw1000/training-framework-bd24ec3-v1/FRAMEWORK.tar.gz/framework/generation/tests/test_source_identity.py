import json
import subprocess
from pathlib import Path

import pytest

from genmlu.source_identity import config_digest, package_digest, source_identity


def make_package(tmp_path: Path) -> Path:
    package = tmp_path / "generation" / "src" / "genmlu"
    package.mkdir(parents=True)
    (package / "__init__.py").write_text("VALUE = 1\n", encoding="utf-8")
    return package


def test_digest_tracks_content_and_names_but_ignores_bytecode(tmp_path):
    package = make_package(tmp_path)
    first = package_digest(package)
    (package / "unused.pyc").write_bytes(b"cache")
    assert package_digest(package) == first
    (package / "__init__.py").write_bytes(b"VALUE = 1\r\n")
    assert package_digest(package) == first
    (package / "__init__.py").rename(package / "module.py")
    assert package_digest(package) != first


def test_archive_records_content_without_inventing_git_identity(tmp_path):
    identity = source_identity(make_package(tmp_path))
    assert identity["origin"] == "package-content"
    assert identity["commit"] is None
    assert identity["dirty"] is None


def test_built_identity_is_checked_against_installed_sources(tmp_path):
    package = make_package(tmp_path)
    build = source_identity(package)
    build.update(commit="1" * 40, tree="2" * 40, dirty=False)
    (package / "_build_identity.json").write_text(json.dumps(build), encoding="utf-8")
    assert source_identity(package)["commit"] == "1" * 40
    (package / "__init__.py").write_text("VALUE = 2\n", encoding="utf-8")
    with pytest.raises(ValueError, match="build identity"):
        source_identity(package)


def test_git_failure_does_not_invent_clean_state(tmp_path, monkeypatch):
    package = make_package(tmp_path)
    (tmp_path / ".git").mkdir()

    def unavailable(*args, **kwargs):
        raise subprocess.TimeoutExpired("git", 10)

    monkeypatch.setattr(subprocess, "run", unavailable)
    assert source_identity(package)["dirty"] is None


def test_configuration_digest_is_canonical_and_rejects_nan():
    assert config_digest({"a": 1, "b": 2}) == config_digest({"b": 2, "a": 1})
    assert config_digest({"a": 1}) != config_digest({"a": 2})
    with pytest.raises(ValueError):
        config_digest({"a": float("nan")})
