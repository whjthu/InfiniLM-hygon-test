from contextlib import nullcontext

import torch

from genmlu.backends import vggt_training


class FakeAggregator:
    def __init__(self) -> None:
        self.calls = 0

    def __call__(self, images: torch.Tensor):
        self.calls += 1
        return [images * 2, None], 7


class FakeModel:
    def __init__(self) -> None:
        self.aggregator = FakeAggregator()


def test_feature_cache_keeps_fixed_batches_and_detaches_aggregator_tokens(monkeypatch) -> None:
    monkeypatch.setattr(vggt_training, "require_mlu", lambda: torch)
    monkeypatch.setattr(vggt_training, "autocast_bf16", nullcontext)
    monkeypatch.setattr(vggt_training, "synchronize", lambda: None)
    monkeypatch.setattr(vggt_training, "_device_batch", lambda batch: batch)
    model = FakeModel()
    images = torch.ones((1, 2, 3, 4, 4), requires_grad=True)
    cached = vggt_training._cache_frozen_aggregator_features(model, [{"images": images, "ids": [0, 1]}])
    assert model.aggregator.calls == 1
    assert cached[0]["batch"]["ids"] == [0, 1]
    assert cached[0]["patch_start_index"] == 7
    assert cached[0]["tokens"][0].requires_grad is False
    assert torch.equal(cached[0]["tokens"][0], images.detach() * 2)
    assert cached[0]["tokens"][1] is None
