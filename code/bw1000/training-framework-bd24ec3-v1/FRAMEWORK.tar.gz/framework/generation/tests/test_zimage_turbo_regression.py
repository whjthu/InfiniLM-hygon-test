from __future__ import annotations

import sys
from contextlib import contextmanager
from pathlib import Path
from types import ModuleType, SimpleNamespace

import pytest
import torch

from genmlu import cli
from genmlu.backends import zimage_flow_grpo as flow_grpo
from genmlu.backends import zimage_training as training
from genmlu.models import ModelSpec


class _TinyDit:
    def __init__(self) -> None:
        self._parameter = SimpleNamespace(device=SimpleNamespace(type="mlu"))

    def parameters(self):
        yield self._parameter

    def eval(self) -> None:
        pass

    def train(self) -> None:
        pass


class _TinyModel(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.adapter = torch.nn.Parameter(torch.tensor(1.0))
        self.pipe = SimpleNamespace(
            dit=_TinyDit(),
            scheduler=SimpleNamespace(set_timesteps=lambda *_args, **_kwargs: None),
        )

    def forward(self, _data: object) -> torch.Tensor:
        return self.adapter.square()

    def trainable_modules(self) -> list[torch.nn.Parameter]:
        return [self.adapter]


class _TorchRuntime:
    def __init__(self) -> None:
        self.mlu = SimpleNamespace(reset_peak_memory_stats=lambda: None)

    def __getattr__(self, name: str):
        return getattr(torch, name)


def _install_dataset(monkeypatch) -> None:
    class Dataset:
        def __init__(self, **_kwargs) -> None:
            pass

        @staticmethod
        def default_image_operator(**_kwargs):
            return lambda value: value

        def __len__(self) -> int:
            return 1

        def __getitem__(self, _index: int) -> dict[str, object]:
            return {}

    diffsynth = ModuleType("diffsynth")
    diffsynth.__path__ = []
    core = ModuleType("diffsynth.core")
    core.UnifiedDataset = Dataset
    monkeypatch.setitem(sys.modules, "diffsynth", diffsynth)
    monkeypatch.setitem(sys.modules, "diffsynth.core", core)


def _recording_image(events: list[str]):
    def image(_model, _prompt: str, _seed: int, _size: int, path: Path) -> None:
        events.append(f"image:{path.name}")
        path.write_bytes(b"image")

    return image


def _install_training_boundary(monkeypatch, events: list[str]) -> None:
    _install_dataset(monkeypatch)
    model = _TinyModel()
    original_train_step = training._train_step

    def train_step(*args, **kwargs):
        events.append("update")
        return original_train_step(*args, **kwargs)

    monkeypatch.setattr(training, "require_mlu", _TorchRuntime)
    monkeypatch.setattr(training, "synchronize", lambda: None)
    monkeypatch.setattr(training, "memory_stats", lambda: {})
    monkeypatch.setattr(training, "local_model_paths", lambda _weights: "[]")
    monkeypatch.setattr(training, "_training_module_class", lambda _root: lambda **_kwargs: model)
    monkeypatch.setattr(training, "_train_step", train_step)
    monkeypatch.setattr(training, "_dataset_resume_evidence", lambda *_args: ({}, ["sample-0"]))
    monkeypatch.setattr(training, "_build_resume_contract", lambda **_kwargs: ({"identity": {}}, {}))
    monkeypatch.setattr(training.z_resume, "scheduler_spec", lambda _scheduler: {"fixture": 1})
    monkeypatch.setattr(training.z_resume, "restore_scheduler", lambda *_args: None)
    monkeypatch.setattr(training.z_resume.common, "capture_rng", lambda _devices: {})
    monkeypatch.setattr(training.z_resume.common, "_restore_rng", lambda *_args: None)
    monkeypatch.setattr(training.z_resume.common, "initial_optimizer_progress", lambda *_args: {})
    monkeypatch.setattr(training.z_resume.common, "advance_optimizer_progress", lambda progress, *_args: progress)
    monkeypatch.setattr(training.z_resume, "make_payload", lambda **_kwargs: {})
    monkeypatch.setattr(
        training.z_resume,
        "save_atomic",
        lambda path, _payload: (path.parent.mkdir(parents=True, exist_ok=True), path.write_bytes(b"checkpoint")),
    )
    monkeypatch.setattr(training, "_turbo_image", _recording_image(events))
    monkeypatch.setattr(
        training,
        "_save_lora",
        lambda path, _model: path.write_bytes(b"final adapter"),
    )
    monkeypatch.setattr(
        training,
        "_image_regression",
        lambda _before, _after: {"pixel_mae": 1.0, "output_std": 0.0, "passed": False},
    )


def _install_flow_boundary(monkeypatch, events: list[str]) -> None:
    class Scheduler:
        def __init__(self, *_args, **_kwargs) -> None:
            pass

    diffsynth = ModuleType("diffsynth")
    diffusion = ModuleType("diffsynth.diffusion")
    diffsynth.__path__ = []
    diffusion.__path__ = []
    flow_match = ModuleType("diffsynth.diffusion.flow_match")
    flow_match.FlowMatchSDEScheduler = Scheduler
    monkeypatch.setitem(sys.modules, "diffsynth", diffsynth)
    monkeypatch.setitem(sys.modules, "diffsynth.diffusion", diffusion)
    monkeypatch.setitem(sys.modules, "diffsynth.diffusion.flow_match", flow_match)

    model = _TinyModel()

    def update(model, *_args, **_kwargs):
        events.append("update")
        with torch.no_grad():
            model.adapter.add_(1.0)
        return {
            "loss": 1.0,
            "ratio": 1.0,
            "approx_kl": 0.0,
            "grad_norm": 1.0,
            "log_prob_mae": 0.0,
            "log_prob_p99": 0.0,
            "finite_gradients": True,
        }

    monkeypatch.setattr(flow_grpo, "require_mlu", _TorchRuntime)
    monkeypatch.setattr(flow_grpo, "synchronize", lambda: None)
    monkeypatch.setattr(flow_grpo, "memory_stats", lambda: {})
    monkeypatch.setattr(flow_grpo, "_build_model", lambda *_args: model)
    monkeypatch.setattr(flow_grpo, "_encode_prompt", lambda *_args: object())
    monkeypatch.setattr(flow_grpo, "_sample_group", lambda *_args: {"images": []})
    monkeypatch.setattr(
        flow_grpo,
        "image_prompt_reward",
        lambda *_args: torch.tensor([0.0, 1.0, 2.0, 3.0]),
    )
    monkeypatch.setattr(flow_grpo, "_train_transition", update)
    monkeypatch.setattr(flow_grpo, "_write_trajectory", lambda *_args: [])
    monkeypatch.setattr(
        flow_grpo,
        "_build_resume_contract",
        lambda **_kwargs: ({"identity": {}}, {}, {}),
    )
    monkeypatch.setattr(flow_grpo.z_resume.common, "initial_optimizer_progress", lambda *_args: {})
    monkeypatch.setattr(
        flow_grpo.z_resume.common,
        "advance_optimizer_progress",
        lambda progress, *_args: progress,
    )
    monkeypatch.setattr(flow_grpo.z_resume, "make_payload", lambda **_kwargs: {})
    monkeypatch.setattr(
        flow_grpo.z_resume,
        "save_atomic",
        lambda path, _payload: (
            path.parent.mkdir(parents=True, exist_ok=True),
            path.write_bytes(b"checkpoint"),
        ),
    )
    monkeypatch.setattr(training, "_turbo_image", _recording_image(events))
    monkeypatch.setattr(
        flow_grpo,
        "_save_lora",
        lambda path, _model: path.write_bytes(b"final adapter"),
    )
    monkeypatch.setattr(
        flow_grpo,
        "_image_regression",
        lambda _before, _after: {"pixel_mae": 1.0, "output_std": 0.0, "passed": False},
    )


def _assert_cli_rejects_regression_failure(
    tmp_path: Path, monkeypatch, result: dict[str, object]
) -> None:
    written: list[dict[str, object]] = []
    cli_result = dict(result)
    cli_result.pop("measurement_window", None)

    @contextmanager
    def acquire(*_args, **_kwargs):
        yield tmp_path / "locks"

    monkeypatch.setenv("MLU_VISIBLE_DEVICES", "0")
    monkeypatch.setattr(
        cli,
        "get_spec",
        lambda *_args: ModelSpec(
            "z-image", "image", "diffusers", "z-image", "bfloat16", "grpo"
        ),
    )
    monkeypatch.setattr(cli, "load_run_config", lambda *_args: {})
    monkeypatch.setattr(cli, "resolve_weights", lambda *_args: tmp_path / "weights")
    monkeypatch.setattr(cli, "create_run_dir", lambda *_args: tmp_path / "run")
    monkeypatch.setattr(
        cli,
        "new_manifest",
        lambda *_args: {"checks": {}, "provenance": {}, "execution": {}},
    )
    monkeypatch.setattr(
        cli, "write_manifest", lambda _path, manifest: written.append(dict(manifest))
    )
    monkeypatch.setattr(cli, "parse_cards", lambda _value: (0,))
    monkeypatch.setattr(cli, "acquire", acquire)
    monkeypatch.setattr(
        cli,
        "inspect_runtime",
        lambda: SimpleNamespace(
            torch_version=None, mlu_available=False, mlu_count=0, device_name=None
        ),
    )
    monkeypatch.setattr(cli, "run_backend", lambda *_args: cli_result)
    args = SimpleNamespace(
        command="rl", models_config="models.yaml", model="z-image", config="run.yaml",
        output_root=str(tmp_path / "outputs"), run_name="run-1", model_root=None, weights=None,
        source_root=None,
        dry_run=False,
        cards="0",
        lock_root=str(tmp_path / "locks"),
        lock_host="host",
    )
    with pytest.raises(RuntimeError, match="turbo_8step_regression"):
        cli.cmd_run(args)
    assert written[-1]["execution"]["failed_checks"] == ["turbo_8step_regression"]


def test_training_backend_off_skips_images_and_reports_none(tmp_path: Path, monkeypatch) -> None:
    events: list[str] = []
    _install_training_boundary(monkeypatch, events)
    adapter = tmp_path / "adapter.safetensors"
    adapter.write_bytes(b"preset adapter")

    result = training.run_zimage_training(
        tmp_path / "weights",
        {
            "dataset_root": str(tmp_path / "dataset"),
            "dataset_metadata": str(tmp_path / "metadata.csv"),
            "preset_lora_path": str(adapter),
            "lora_target_modules": "adapter",
            "max_steps": 1,
        },
        tmp_path / "training-off",
        tmp_path / "source",
    )

    assert events == ["update"]
    assert result["checks"]["turbo_8step_regression"] is None
    assert result["metrics"]["turbo_8step_pixel_mae"] is None
    assert result["metrics"]["turbo_8step_output_std"] is None


def test_training_backend_enabled_wraps_the_actual_update(tmp_path: Path, monkeypatch) -> None:
    events: list[str] = []
    _install_training_boundary(monkeypatch, events)
    adapter = tmp_path / "adapter.safetensors"
    adapter.write_bytes(b"preset adapter")

    result = training.run_zimage_training(
        tmp_path / "weights",
        {
            "dataset_root": str(tmp_path / "dataset"),
            "dataset_metadata": str(tmp_path / "metadata.csv"),
            "preset_lora_path": str(adapter),
            "lora_target_modules": "adapter",
            "max_steps": 1,
            "validate_turbo_regression": True,
            "regression_prompt": "fixture",
        },
        tmp_path / "training-on",
        tmp_path / "source",
    )

    assert events == ["image:turbo-before.png", "update", "image:turbo-after.png"]
    assert result["checks"]["turbo_8step_regression"] is False


def test_flow_backend_off_skips_images_and_reports_none(tmp_path: Path, monkeypatch) -> None:
    events: list[str] = []
    _install_flow_boundary(monkeypatch, events)

    result = flow_grpo.run_zimage_flow_grpo(
        tmp_path / "weights",
        {
            "prompt": "fixture",
            "preset_lora_path": str(tmp_path / "adapter.safetensors"),
            "lora_target_modules": "adapter",
            "model_sha": "a" * 64,
            "preset_lora_sha": "b" * 64,
            "max_steps": 1,
            "checkpoint_steps": [1],
        },
        tmp_path / "flow-off",
        tmp_path / "source",
    )

    assert events == ["update"]
    assert result["checks"]["turbo_8step_regression"] is None
    assert result["metrics"]["turbo_8step_pixel_mae"] is None
    assert result["metrics"]["turbo_8step_output_std"] is None


def test_flow_backend_enabled_wraps_update_and_cli_rejects_failure(
    tmp_path: Path, monkeypatch
) -> None:
    events: list[str] = []
    _install_flow_boundary(monkeypatch, events)

    result = flow_grpo.run_zimage_flow_grpo(
        tmp_path / "weights",
        {
            "prompt": "fixture",
            "preset_lora_path": str(tmp_path / "adapter.safetensors"),
            "lora_target_modules": "adapter",
            "model_sha": "a" * 64,
            "preset_lora_sha": "b" * 64,
            "max_steps": 1,
            "checkpoint_steps": [1],
            "size": 384,
            "validate_turbo_regression": True,
        },
        tmp_path / "flow-on",
        tmp_path / "source",
    )

    assert events == ["image:turbo-before.png", "update", "image:turbo-after.png"]
    assert result["checks"]["turbo_8step_regression"] is False
    _assert_cli_rejects_regression_failure(tmp_path, monkeypatch, result)


def test_turbo_regression_default_is_off_without_requiring_a_prompt(tmp_path: Path) -> None:
    calls: list[tuple[object, ...]] = []
    options = training.turbo_regression_options({})
    rendered = training.render_turbo_regression_image(
        options,
        object(),
        tmp_path / "before.png",
        image_fn=lambda *args: calls.append(args),
    )

    assert options is None
    assert rendered is False
    assert calls == []
    assert training.turbo_regression_metrics(None) == {
        "turbo_8step_pixel_mae": None,
        "turbo_8step_output_std": None,
    }
    assert training.turbo_regression_check(None) is None


def test_turbo_regression_enabled_preserves_comparison_failure(tmp_path: Path) -> None:
    image = pytest.importorskip("PIL.Image")

    class Model:
        phase = 0

    def image_fn(model: Model, _prompt: str, _seed: int, _size: int, path: Path) -> None:
        image.new("RGB", (2, 2), color=(255 * model.phase,) * 3).save(path)
        model.phase += 1

    options = training.turbo_regression_options(
        {"validate_turbo_regression": True, "regression_prompt": "fixture"}
    )
    model = Model()
    before = tmp_path / "before.png"
    after = tmp_path / "after.png"
    assert training.render_turbo_regression_image(options, model, before, image_fn=image_fn)
    assert training.render_turbo_regression_image(options, model, after, image_fn=image_fn)
    result = training._image_regression(before, after)

    assert model.phase == 2
    assert training.turbo_regression_check(result) is False
    assert result["pixel_mae"] > 0.35
    assert result["output_std"] == 0.0


@pytest.mark.parametrize(
    "config",
    [
        {"validate_turbo_regression": "true"},
        {"validate_turbo_regression": True},
        {
            "validate_turbo_regression": True,
            "regression_prompt": "fixture",
            "regression_size": 0,
        },
    ],
)
def test_turbo_regression_rejects_invalid_enabled_configuration(
    config: dict[str, object],
) -> None:
    with pytest.raises(ValueError):
        training.turbo_regression_options(config)


def test_resume_identity_marks_the_explicit_regression_contract() -> None:
    default = flow_grpo._resume_effective_config({})
    explicit_off = flow_grpo._resume_effective_config(
        {"validate_turbo_regression": False}
    )
    enabled = flow_grpo._resume_effective_config(
        {"validate_turbo_regression": True, "regression_prompt": "fixture"}
    )

    assert default == explicit_off
    assert default["validate_turbo_regression"] is False
    assert default["turbo_regression_contract"] == "explicit-opt-in-v1"
    assert enabled["validate_turbo_regression"] is True
    assert enabled != default


def test_rl_regression_defaults_preserve_the_rollout_prompt_and_size() -> None:
    options = training.turbo_regression_options(
        {"validate_turbo_regression": True},
        default_prompt="rollout fixture",
        default_size=384,
    )

    assert options == {"prompt": "rollout fixture", "seed": 20260901, "size": 384}
