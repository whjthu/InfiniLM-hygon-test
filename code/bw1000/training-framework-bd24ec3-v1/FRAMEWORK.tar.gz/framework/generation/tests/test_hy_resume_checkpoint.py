from __future__ import annotations

import copy
import errno
import importlib.util
import os
import random
from pathlib import Path

import numpy as np
import pytest
import torch


ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = Path(os.environ.get("HY_CHECKPOINT_REPO", ROOT))
MODULE_PATH = REPO_ROOT / "src" / "genmlu" / "hy_resume_checkpoint.py"
SPEC = importlib.util.spec_from_file_location("hy_resume_checkpoint", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
resume = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(resume)


class TinyPolicy(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.input = torch.nn.Linear(3, 4)
        self.output = torch.nn.Linear(4, 2)
        self.unused = torch.nn.Parameter(torch.ones(2))
        self.register_buffer("scale", torch.tensor([0.75, 1.25]))

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        return self.output(torch.tanh(self.input(value))) * self.scale


def make_contract(**identity_overrides: str) -> dict:
    identity = {
        key: ("0123456789abcdef"[index] * 64)
        for index, key in enumerate(sorted(resume.IDENTITY_FIELDS))
    }
    identity.update(identity_overrides)
    return resume.build_contract(
        identity=identity,
        seed=1701,
        warmup_steps=2,
        max_steps=8,
        group_size=4,
        sample_order=["sample-a", "sample-b", "sample-c"],
        device_ids=[],
    )


def make_policy(seed: int = 91) -> tuple[TinyPolicy, torch.optim.AdamW]:
    torch.manual_seed(seed)
    model = TinyPolicy()
    model.train()
    model.output.eval()
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=3e-3, betas=(0.8, 0.95), eps=1e-7, weight_decay=0.02
    )
    return model, optimizer


def train_step(model: TinyPolicy, optimizer: torch.optim.AdamW) -> dict:
    optimizer.zero_grad(set_to_none=True)
    python_scale = 0.5 + random.random()
    numpy_shift = float(np.random.uniform(-0.1, 0.1))
    inputs = torch.randn(5, 3) * python_scale + numpy_shift
    targets = torch.randn(5, 2)
    output = model(inputs)
    loss = (output - targets).square().mean()
    loss.backward()
    gradients = {
        name: parameter.grad.detach().clone() if parameter.grad is not None else None
        for name, parameter in model.named_parameters()
    }
    optimizer.step()
    return {
        "loss": loss.detach().clone(),
        "gradients": gradients,
        "model": {name: value.detach().clone() for name, value in model.named_parameters()},
        "optimizer": resume.cpu_tree(optimizer.state_dict()),
        "rng": resume.capture_rng([]),
    }


def initialized_boundary(step: int = 4):
    random.seed(404)
    np.random.seed(405)
    torch.manual_seed(406)
    model, optimizer = make_policy()
    progress = resume.initial_optimizer_progress(model, optimizer)
    for _ in range(step):
        train_step(model, optimizer)
        progress = resume.advance_optimizer_progress(progress, model, optimizer)
    anchor = {
        name: parameter.detach().cpu().clone() - 0.125
        for name, parameter in model.named_parameters()
        if parameter.requires_grad
    }
    contract = make_contract()
    payload = resume.make_payload(
        contract=contract,
        global_step=step,
        model=model,
        optimizer=optimizer,
        optimizer_progress=progress,
        anchor=anchor,
    )
    return model, optimizer, progress, anchor, contract, payload


def live_fingerprint(model: TinyPolicy, optimizer: torch.optim.AdamW) -> str:
    return resume.tree_sha256(
        {
            "parameters": resume.cpu_tree(dict(model.named_parameters())),
            "buffers": resume.cpu_tree(dict(model.named_buffers())),
            "modes": {name: module.training for name, module in model.named_modules()},
            "optimizer": resume.cpu_tree(optimizer.state_dict()),
            "rng": resume.capture_rng([]),
        }
    )


def resign(payload: dict) -> None:
    payload["integrity_sha256"] = resume.tree_sha256(
        {key: value for key, value in payload.items() if key != "integrity_sha256"}
    )


def assert_exact(left, right) -> None:
    assert resume.tree_sha256(left) == resume.tree_sha256(right)


def test_fresh_restore_matches_continuous_next_step_exactly() -> None:
    model, optimizer, _progress, _anchor, contract, payload = initialized_boundary()
    continuous = train_step(model, optimizer)

    fresh_model, fresh_optimizer = make_policy(seed=999)
    restored_anchor, restored_progress, checked = resume.restore_checkpoint(
        payload, contract, fresh_model, fresh_optimizer, payload["anchor"]
    )
    assert checked["next"] == {
        "global_step": 5,
        "measured_step": 3,
        "sample_cursor": 1,
        "sample_id": "sample-b",
        "rollout_seeds": [6701, 6702, 6703, 6704],
    }
    resume.assert_restored_boundary(
        payload,
        contract,
        fresh_model,
        fresh_optimizer,
        restored_anchor,
        restored_progress,
    )
    restored = train_step(fresh_model, fresh_optimizer)

    assert_exact(continuous, restored)
    assert not getattr(fresh_model, "_hy_resume_poisoned", False)


@pytest.mark.parametrize(
    "corruption",
    [
        "identity_sha",
        "config_identity",
        "cursor",
        "missing_rng",
        "optimizer_data",
        "optimizer_hyperparameters",
        "anchor",
        "legacy",
    ],
)
def test_invalid_checkpoint_is_rejected_before_mutation(corruption: str) -> None:
    _model, _optimizer, _progress, _anchor, contract, payload = initialized_boundary()
    candidate = copy.deepcopy(payload)
    expected_contract = copy.deepcopy(contract)

    if corruption == "identity_sha":
        candidate["metadata"]["contract"]["identity"]["model"] = "0" * 64
        resign(candidate)
    elif corruption == "config_identity":
        expected_contract["identity"]["config"] = "9" * 64
    elif corruption == "cursor":
        candidate["metadata"]["next_sample_cursor"] = 0
        resign(candidate)
    elif corruption == "missing_rng":
        del candidate["rng"]["numpy"]
        resign(candidate)
    elif corruption == "optimizer_data":
        first_state = next(iter(candidate["state"]["optimizer"]["state"].values()))
        del first_state["exp_avg"]
        resign(candidate)
    elif corruption == "anchor":
        first_anchor = next(iter(candidate["anchor"].values()))
        first_anchor.reshape(-1)[0] += 1
        resign(candidate)
    elif corruption == "legacy":
        candidate = {
            "step": 4,
            "adapter": candidate["state"]["trainable"],
            "optimizer": candidate["state"]["optimizer"],
        }

    fresh_model, fresh_optimizer = make_policy(seed=701)
    if corruption == "optimizer_hyperparameters":
        fresh_optimizer.param_groups[0]["lr"] = 4e-3
    before = live_fingerprint(fresh_model, fresh_optimizer)
    with pytest.raises(resume.CheckpointValidationError):
        resume.restore_checkpoint(
            candidate,
            expected_contract,
            fresh_model,
            fresh_optimizer,
            payload["anchor"],
        )
    after = live_fingerprint(fresh_model, fresh_optimizer)
    assert before == after
    assert not getattr(fresh_model, "_hy_resume_poisoned", False)


def test_atomic_write_failure_preserves_existing_checkpoint(tmp_path: Path) -> None:
    _model, _optimizer, _progress, _anchor, _contract, payload = initialized_boundary()
    target = tmp_path / "state.pt"
    target.write_bytes(b"accepted-checkpoint")

    def fail_after_write(_payload, handle) -> None:
        handle.write(b"incomplete-new-checkpoint")
        raise OSError("injected write failure")

    with pytest.raises(OSError, match="injected write failure"):
        resume.save_atomic(target, payload, save_fn=fail_after_write)

    assert target.read_bytes() == b"accepted-checkpoint"
    assert list(tmp_path.glob("*.partial")) == []
    assert list(tmp_path.glob(".*.partial")) == []


def test_directory_sync_propagates_posix_open_failure(
    tmp_path: Path,
) -> None:
    expected = OSError(errno.EACCES, "injected directory open failure")

    def fail_open(*_args, **_kwargs):
        raise expected

    with pytest.raises(OSError) as caught:
        resume._sync_replaced_directory(
            tmp_path, platform_name="posix", open_directory=fail_open
        )

    assert caught.value is expected


@pytest.mark.parametrize(
    "error_number", sorted(resume._UNSUPPORTED_DIRECTORY_FSYNC_ERRNOS)
)
def test_directory_sync_allows_each_unsupported_errno(
    tmp_path: Path, error_number: int
) -> None:
    closed: list[int] = []

    def unsupported_fsync(_fd: int) -> None:
        raise OSError(error_number, "directory fsync unsupported")

    resume._sync_replaced_directory(
        tmp_path,
        platform_name="posix",
        open_directory=lambda *_args: 73,
        fsync_fd=unsupported_fsync,
        close_fd=closed.append,
    )
    assert closed == [73]


@pytest.mark.parametrize(
    "error_number",
    [
        errno.EACCES,
        errno.EBADF,
        errno.EIO,
        errno.ENOSPC,
        getattr(errno, "EDQUOT", 122),
    ],
)
def test_directory_sync_propagates_other_fsync_errnos(
    tmp_path: Path, error_number: int
) -> None:
    expected = OSError(error_number, "injected directory fsync failure")
    closed: list[int] = []

    def fail_fsync(_fd: int) -> None:
        raise expected

    with pytest.raises(OSError) as caught:
        resume._sync_replaced_directory(
            tmp_path,
            platform_name="posix",
            open_directory=lambda *_args: 73,
            fsync_fd=fail_fsync,
            close_fd=closed.append,
        )

    assert caught.value is expected
    assert closed == [73]


def test_directory_sync_preserves_fsync_error_when_close_also_fails(
    tmp_path: Path,
) -> None:
    fsync_error = OSError(errno.EIO, "injected directory fsync failure")
    close_error = OSError(errno.EBADF, "injected directory close failure")
    close_calls: list[int] = []

    def fail_fsync(_fd: int) -> None:
        raise fsync_error

    def fail_close(fd: int) -> None:
        close_calls.append(fd)
        raise close_error

    with pytest.raises(OSError) as caught:
        resume._sync_replaced_directory(
            tmp_path,
            platform_name="posix",
            open_directory=lambda *_args: 73,
            fsync_fd=fail_fsync,
            close_fd=fail_close,
        )

    assert caught.value is fsync_error
    assert caught.value.__cause__ is close_error
    assert close_calls == [73]


def test_directory_sync_closes_after_non_oserror_fsync_failure(tmp_path: Path) -> None:
    fsync_error = SystemExit("injected directory fsync termination")
    close_calls: list[int] = []

    def fail_fsync(_fd: int) -> None:
        raise fsync_error

    with pytest.raises(SystemExit) as caught:
        resume._sync_replaced_directory(
            tmp_path,
            platform_name="posix",
            open_directory=lambda *_args: 73,
            fsync_fd=fail_fsync,
            close_fd=close_calls.append,
        )

    assert caught.value is fsync_error
    assert close_calls == [73]


def test_directory_sync_preserves_non_oserror_when_close_also_fails(
    tmp_path: Path,
) -> None:
    fsync_error = KeyboardInterrupt("injected directory fsync interruption")
    close_error = OSError(errno.EBADF, "injected directory close failure")
    close_calls: list[int] = []

    def fail_fsync(_fd: int) -> None:
        raise fsync_error

    def fail_close(fd: int) -> None:
        close_calls.append(fd)
        raise close_error

    with pytest.raises(KeyboardInterrupt) as caught:
        resume._sync_replaced_directory(
            tmp_path,
            platform_name="posix",
            open_directory=lambda *_args: 73,
            fsync_fd=fail_fsync,
            close_fd=fail_close,
        )

    assert caught.value is fsync_error
    assert caught.value.__cause__ is close_error
    assert close_calls == [73]


def test_directory_sync_propagates_close_failure_after_success(tmp_path: Path) -> None:
    close_error = OSError(errno.EIO, "injected directory close failure")
    synchronized: list[int] = []
    close_calls: list[int] = []

    def fail_close(fd: int) -> None:
        close_calls.append(fd)
        raise close_error

    with pytest.raises(OSError) as caught:
        resume._sync_replaced_directory(
            tmp_path,
            platform_name="posix",
            open_directory=lambda *_args: 73,
            fsync_fd=synchronized.append,
            close_fd=fail_close,
        )

    assert caught.value is close_error
    assert synchronized == [73]
    assert close_calls == [73]


def test_directory_sync_skips_windows_directory_handles(
    tmp_path: Path,
) -> None:
    opened = False

    def fail_open(*_args, **_kwargs):
        nonlocal opened
        opened = True
        raise AssertionError("Windows compatibility path must not open the directory")

    resume._sync_replaced_directory(
        tmp_path, platform_name="nt", open_directory=fail_open
    )
    assert not opened


def test_save_atomic_file_fsync_failure_precedes_replace(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    target = tmp_path / "state.pt"
    target.write_bytes(b"accepted-checkpoint")
    expected = OSError(errno.EIO, "injected file fsync failure")
    events: list[str] = []

    def save_bytes(_payload, handle) -> None:
        events.append("save")
        handle.write(b"new-checkpoint")

    def fail_file_fsync(_fd: int) -> None:
        events.append("file-fsync")
        raise expected

    def unexpected_replace(*_args) -> None:
        events.append("replace")

    monkeypatch.setattr(resume.os, "fsync", fail_file_fsync)
    monkeypatch.setattr(resume.os, "replace", unexpected_replace)

    with pytest.raises(OSError) as caught:
        resume.save_atomic(target, {}, save_fn=save_bytes)

    assert caught.value is expected
    assert events == ["save", "file-fsync"]
    assert target.read_bytes() == b"accepted-checkpoint"


def test_save_atomic_replace_failure_follows_file_fsync(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    target = tmp_path / "state.pt"
    target.write_bytes(b"accepted-checkpoint")
    expected = OSError(errno.EIO, "injected replace failure")
    events: list[str] = []
    real_fsync = resume.os.fsync

    def save_bytes(_payload, handle) -> None:
        events.append("save")
        handle.write(b"new-checkpoint")

    def sync_file(fd: int) -> None:
        events.append("file-fsync")
        real_fsync(fd)

    def fail_replace(*_args) -> None:
        events.append("replace")
        raise expected

    monkeypatch.setattr(resume.os, "fsync", sync_file)
    monkeypatch.setattr(resume.os, "replace", fail_replace)

    with pytest.raises(OSError) as caught:
        resume.save_atomic(target, {}, save_fn=save_bytes)

    assert caught.value is expected
    assert events == ["save", "file-fsync", "replace"]
    assert target.read_bytes() == b"accepted-checkpoint"


@pytest.mark.skipif(os.name == "nt", reason="Windows does not expose directory fsync")
def test_save_atomic_directory_fsync_failure_keeps_replaced_target(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    target = tmp_path / "state.pt"
    target.write_bytes(b"accepted-checkpoint")
    expected = OSError(errno.EIO, "injected directory fsync failure")
    events: list[str] = []
    real_fsync = resume.os.fsync
    real_replace = resume.os.replace

    def save_bytes(_payload, handle) -> None:
        events.append("save")
        handle.write(b"new-checkpoint")

    def sync_in_order(fd: int) -> None:
        if "replace" not in events:
            events.append("file-fsync")
            real_fsync(fd)
            return
        events.append("directory-fsync")
        raise expected

    def replace_in_order(source, destination) -> None:
        events.append("replace")
        real_replace(source, destination)

    monkeypatch.setattr(resume.os, "fsync", sync_in_order)
    monkeypatch.setattr(resume.os, "replace", replace_in_order)

    with pytest.raises(OSError) as caught:
        resume.save_atomic(target, {}, save_fn=save_bytes)

    assert caught.value is expected
    assert events == ["save", "file-fsync", "replace", "directory-fsync"]
    assert target.read_bytes() == b"new-checkpoint"


@pytest.mark.skipif(os.name == "nt", reason="Windows does not expose directory fsync")
def test_save_atomic_orders_file_sync_replace_and_directory_sync(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    target = tmp_path / "state.pt"
    events: list[str] = []
    real_fsync = resume.os.fsync
    real_replace = resume.os.replace

    def save_bytes(_payload, handle) -> None:
        events.append("save")
        handle.write(b"new-checkpoint")

    def sync_in_order(fd: int) -> None:
        events.append("file-fsync" if "replace" not in events else "directory-fsync")
        real_fsync(fd)

    def replace_in_order(source, destination) -> None:
        events.append("replace")
        real_replace(source, destination)

    monkeypatch.setattr(resume.os, "fsync", sync_in_order)
    monkeypatch.setattr(resume.os, "replace", replace_in_order)

    resume.save_atomic(target, {}, save_fn=save_bytes)

    assert events == ["save", "file-fsync", "replace", "directory-fsync"]
    assert target.read_bytes() == b"new-checkpoint"


def test_atomic_roundtrip_and_completed_schedule_coordinate(tmp_path: Path) -> None:
    model, optimizer, progress, _anchor, contract, _payload = initialized_boundary()
    for _ in range(6):
        train_step(model, optimizer)
        progress = resume.advance_optimizer_progress(progress, model, optimizer)
    anchor = {
        name: parameter.detach().cpu().clone()
        for name, parameter in model.named_parameters()
        if parameter.requires_grad
    }
    payload = resume.make_payload(
        contract=contract,
        global_step=10,
        model=model,
        optimizer=optimizer,
        optimizer_progress=progress,
        anchor=anchor,
    )
    path = tmp_path / "state.pt"
    resume.save_atomic(path, payload)
    loaded = resume.load_checkpoint(path)
    checked = resume.validate_checkpoint(
        loaded, contract, model, optimizer, native_rng=False
    )
    assert checked["next"] is None
    assert loaded["metadata"]["measured_step"] == 8
    assert loaded["metadata"]["global_step"] == 10


def test_boundary_metadata_keeps_global_and_measured_coordinates() -> None:
    contract = resume.build_contract(
        identity={key: "a" * 64 for key in resume.IDENTITY_FIELDS},
        seed=1701,
        warmup_steps=5,
        max_steps=20,
        group_size=4,
        sample_order=["sample-a", "sample-b", "sample-c"],
        device_ids=[],
    )
    at_global_ten = resume.boundary_metadata(contract, 10)
    at_global_twenty = resume.boundary_metadata(contract, 20)
    assert at_global_ten["global_step"] == 10
    assert at_global_ten["measured_step"] == 5
    assert at_global_twenty["global_step"] == 20
    assert at_global_twenty["measured_step"] == 15
