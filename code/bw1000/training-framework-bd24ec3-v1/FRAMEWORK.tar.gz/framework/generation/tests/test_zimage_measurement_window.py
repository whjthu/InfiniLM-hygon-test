from __future__ import annotations

import inspect

from genmlu.backends import zimage_flow_grpo as zimage


def test_window_covers_remaining_updates_and_final_artifacts() -> None:
    source = inspect.getsource(zimage.run_zimage_flow_grpo)
    loop = source.index("for global_step in range(completed_global_step + 1, max_steps + 1):")
    start = source.index("measurement_started = time.perf_counter()")
    rollout = source.index("rollout = _sample_group(")
    final_save = source.index("_save_lora(final_adapter, model)")
    regression = source.index("regression = _image_regression(pre_image, post_image)")
    window = source.index('result["measurement_window"] = {')

    assert loop < start < rollout < final_save < regression < window
    assert "if global_step > warmup_steps and measurement_started is None:" in source
    assert 'measured = [item for item in metrics if int(item["global_step"]) > warmup_steps]' in source
    assert '"work_units": len(measured)' in source
    assert '"unit": "policy_updates"' in source


def test_invalid_warmup_is_rejected_before_training_and_recovery_is_unqualified() -> None:
    source = inspect.getsource(zimage.run_zimage_flow_grpo)
    assert source.index("if warmup_steps < 0 or warmup_steps >= max_steps:") < source.index(
        "training_started = time.perf_counter()"
    )
    assert 'if config.get("validate_recovery", False) is False:' in source
    assert source.count('result["measurement_window"] = {') == 1
