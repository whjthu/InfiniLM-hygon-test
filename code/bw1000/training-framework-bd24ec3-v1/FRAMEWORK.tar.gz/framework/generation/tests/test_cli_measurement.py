from __future__ import annotations

import copy
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace

import pytest

from genmlu import cli
from genmlu.measurement import consume_backend_window, stamp_completed_measurement
from genmlu.models import ModelSpec


class Clock:
    def __init__(self, value: float = 100.0) -> None:
        self.value = value

    def __call__(self) -> float:
        return self.value

    def advance(self, seconds: float) -> None:
        self.value += seconds


def _result(path: Path, window: dict | None) -> dict:
    path.write_bytes(b"artifact")
    result = {
        "artifacts": [{"path": str(path), "sha256": cli.sha256_path(path)}],
        "logs": [],
        "metrics": {},
        "stage_timings": {},
        "checks": {},
    }
    if window is not None:
        result["measurement_window"] = window
    return result


def _args(tmp_path: Path) -> SimpleNamespace:
    return SimpleNamespace(
        command="infer", models_config="models.yaml", model="sdxl-1.0", config="run.yaml",
        output_root=str(tmp_path / "outputs"), run_name="run-1", model_root=None, weights=None,
        source_root=None, dry_run=False, cards="0", lock_root=str(tmp_path / "locks"), lock_host="host-a",
    )


def _install_cli(monkeypatch, tmp_path: Path, result: dict, clock: Clock, recovery: bool = False):
    written = []
    spec = ModelSpec("sdxl-1.0", "image", "diffusers", "sdxl-1.0", "bfloat16", "ddpo")
    monkeypatch.delenv("MLU_VISIBLE_DEVICES", raising=False)

    @contextmanager
    def acquire(*_args, **_kwargs):
        yield tmp_path / "locks"

    def backend(*_args, **_kwargs):
        clock.advance(1.0)
        if "measurement_window" in result:
            result["measurement_window"]["start_monotonic"] = clock()
        clock.advance(9.0)
        return result

    monkeypatch.setattr(cli, "get_spec", lambda *_args: spec)
    monkeypatch.setattr(cli, "load_run_config", lambda *_args: {"validate_recovery": recovery})
    monkeypatch.setattr(cli, "resolve_weights", lambda *_args: tmp_path / "weights")
    monkeypatch.setattr(cli, "create_run_dir", lambda *_args: tmp_path / "run")
    monkeypatch.setattr(cli, "new_manifest", lambda *_args: {"checks": {}, "provenance": {}, "execution": {}, "metrics": {}})
    monkeypatch.setattr(cli, "parse_cards", lambda _value: (0,))
    monkeypatch.setattr(cli, "acquire", acquire)
    monkeypatch.setattr(cli, "inspect_runtime", lambda: SimpleNamespace(torch_version=None))
    monkeypatch.setattr(cli, "run_backend", backend)
    monkeypatch.setattr(cli, "perf_counter", clock)

    def write_manifest(_path, manifest):
        written.append(copy.deepcopy(manifest))
        if manifest.get("status") == "completed" and "measurement_qualification" not in manifest["metrics"]:
            clock.advance(1.0)

    monkeypatch.setattr(cli, "write_manifest", write_manifest)
    return written


def test_cli_measurement_includes_backend_tail_rehash_and_completed_write(tmp_path, monkeypatch) -> None:
    clock = Clock()
    result = _result(tmp_path / "artifact.bin", {"start_monotonic": 0.0, "work_units": 3, "unit": "optimizer_steps"})
    written = _install_cli(monkeypatch, tmp_path, result, clock)
    merged = []
    real_merge = cli.merge_backend_result

    def slow_merge(manifest, backend_result):
        assert "measurement_window" not in backend_result
        merged.append(backend_result)
        clock.advance(4.0)
        real_merge(manifest, backend_result)

    def delayed_completed_write(_path, manifest):
        written.append(copy.deepcopy(manifest))
        if manifest.get("status") == "completed" and "measurement_qualification" not in manifest["metrics"]:
            clock.advance(5.0)

    monkeypatch.setattr(cli, "merge_backend_result", slow_merge)
    monkeypatch.setattr(cli, "write_manifest", delayed_completed_write)

    assert cli.cmd_run(_args(tmp_path)) == 0
    metrics = written[-1]["metrics"]
    assert len(merged) == 1
    assert metrics["measurement_qualification"] == "QUALIFIED"
    assert metrics["measurement_work_units"] == 3.0
    assert metrics["measurement_duration_seconds"] == 18.0
    assert metrics["measurement_rate_per_second"] == pytest.approx(3.0 / 18.0)
    assert metrics["outer_end_to_end_seconds"] == 19.0
    assert metrics["measurement_final_metadata_stamp_excluded"] is True


def test_cli_preserves_actual_resumed_work_units(tmp_path, monkeypatch) -> None:
    clock = Clock()
    result = _result(tmp_path / "artifact.bin", {"start_monotonic": 0.0, "work_units": 5, "unit": "policy_updates"})
    written = _install_cli(monkeypatch, tmp_path, result, clock)

    assert cli.cmd_run(_args(tmp_path)) == 0
    metrics = written[-1]["metrics"]
    assert metrics["measurement_work_units"] == 5.0
    assert metrics["measurement_unit"] == "policy_updates"


def test_cli_qualifies_reconstruction_work_units(tmp_path, monkeypatch) -> None:
    clock = Clock()
    result = _result(
        tmp_path / "artifact.bin",
        {"start_monotonic": 0.0, "work_units": 2, "unit": "reconstructions"},
    )
    written = _install_cli(monkeypatch, tmp_path, result, clock)

    assert cli.cmd_run(_args(tmp_path)) == 0
    metrics = written[-1]["metrics"]
    assert metrics["measurement_qualification"] == "QUALIFIED"
    assert metrics["measurement_work_units"] == 2.0
    assert metrics["measurement_unit"] == "reconstructions"


def test_cli_excludes_recovery_enabled_runs_from_measurement_qualification(tmp_path, monkeypatch) -> None:
    clock = Clock()
    result = _result(tmp_path / "artifact.bin", None)
    written = _install_cli(monkeypatch, tmp_path, result, clock, recovery=True)

    assert cli.cmd_run(_args(tmp_path)) == 0
    metrics = written[-1]["metrics"]
    assert metrics["measurement_qualification"] == "UNAVAILABLE"
    assert metrics["measurement_unavailable_reason"] == "recovery_validation_enabled"
    assert metrics["measurement_duration_seconds"] is None


@pytest.mark.parametrize(
    "window",
    [
        {"start_monotonic": 9.0, "work_units": 1, "unit": "optimizer_steps"},
        {"start_monotonic": 11.0, "work_units": 0, "unit": "optimizer_steps"},
        {"start_monotonic": 11.0, "work_units": True, "unit": "optimizer_steps"},
        {"start_monotonic": 11.0, "work_units": float("nan"), "unit": "optimizer_steps"},
        {"start_monotonic": 11.0, "work_units": 1, "unit": "frames"},
    ],
)
def test_invalid_backend_window_fails_qualification(window) -> None:
    with pytest.raises(ValueError):
        consume_backend_window(
            {"measurement_window": window}, recovery_enabled=False, t0=10.0, t1=12.0
        )


def test_completed_measurement_requires_strict_t1_before_t3() -> None:
    window = consume_backend_window(
        {"measurement_window": {"start_monotonic": 11.0, "work_units": 1, "unit": "optimizer_steps"}},
        recovery_enabled=False,
        t0=10.0,
        t1=12.0,
    )
    with pytest.raises(ValueError, match="clock ordering"):
        stamp_completed_measurement({}, window, recovery_enabled=False, t0=10.0, t1=12.0, t3=12.0)


def test_completed_write_failure_marks_failed_without_remerging_artifacts(tmp_path, monkeypatch) -> None:
    clock = Clock()
    result = _result(tmp_path / "artifact.bin", {"start_monotonic": 0.0, "work_units": 2, "unit": "optimizer_steps"})
    written = _install_cli(monkeypatch, tmp_path, result, clock)
    merged = 0
    real_merge = cli.merge_backend_result

    def counted_merge(manifest, backend_result):
        nonlocal merged
        merged += 1
        real_merge(manifest, backend_result)

    def fail_completed_write(_path, manifest):
        written.append(copy.deepcopy(manifest))
        if manifest.get("status") == "completed":
            raise OSError("completed write failed")

    monkeypatch.setattr(cli, "merge_backend_result", counted_merge)
    monkeypatch.setattr(cli, "write_manifest", fail_completed_write)

    with pytest.raises(OSError, match="completed write failed"):
        cli.cmd_run(_args(tmp_path))
    assert merged == 1
    assert written[-1]["status"] == "failed"
    assert written[-1]["metrics"]["measurement_qualification"] == "FAILED"


def test_measurement_stamp_write_failure_marks_failed_without_remerging_artifacts(tmp_path, monkeypatch) -> None:
    clock = Clock()
    result = _result(tmp_path / "artifact.bin", {"start_monotonic": 0.0, "work_units": 2, "unit": "optimizer_steps"})
    written = _install_cli(monkeypatch, tmp_path, result, clock)
    merged = 0
    real_merge = cli.merge_backend_result

    def counted_merge(manifest, backend_result):
        nonlocal merged
        merged += 1
        real_merge(manifest, backend_result)

    def fail_measurement_stamp(_path, manifest):
        written.append(copy.deepcopy(manifest))
        if manifest.get("status") != "completed":
            return
        if "measurement_qualification" in manifest["metrics"]:
            raise OSError("measurement stamp write failed")
        clock.advance(1.0)

    monkeypatch.setattr(cli, "merge_backend_result", counted_merge)
    monkeypatch.setattr(cli, "write_manifest", fail_measurement_stamp)

    with pytest.raises(OSError, match="measurement stamp write failed"):
        cli.cmd_run(_args(tmp_path))
    assert merged == 1
    assert written[-1]["status"] == "failed"
    assert written[-1]["metrics"]["measurement_qualification"] == "FAILED"
