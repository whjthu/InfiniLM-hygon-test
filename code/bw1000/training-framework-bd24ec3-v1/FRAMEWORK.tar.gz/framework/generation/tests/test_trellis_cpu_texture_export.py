"""CPU logic tests; native bundle qualification is a separate device-free run."""
from __future__ import annotations

import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import numpy as np

from genmlu import trellis_cpu_texture_export as export
from genmlu.trellis_output_contract import validate_output_contract
from genmlu.trellis_sparse_support import write_proof


def configuration(root: Path) -> dict:
    files = {}
    for package, module in (("uv_unwrapper", "unwrap"), ("texture_baker", "baker")):
        for name in ("__init__.py", module + ".py", "_C.test.so"):
            path = root / package / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(b"unit-test-identity-only")
            files[f"{package}/{name}"] = export.sha(path)
    return export.settings({
        "texture_size": 32, "chunk_size": 7, "padding_pixels": 1,
        "dependencies": {"root": str(root.resolve()), "files": files,
                         "versions": {"python": "unit-test", "torch": "unit-test", "numpy": "unit-test", "Pillow": "unit-test"}},
    })


def fields() -> dict[str, np.ndarray]:
    c = np.array([[0, 255 + (i & 1), 255 + ((i >> 1) & 1), 255 + ((i >> 2) & 1)] for i in range(8)], np.int32)
    v = (np.array([[255.7, 255.7, 255.7], [256.2, 255.7, 255.8], [255.8, 256.2, 255.7], [255.8, 255.8, 256.2]], np.float32) / 512 - 0.5)
    f = np.array([[0, 2, 1], [0, 1, 3], [1, 2, 3], [2, 0, 3]], np.int32)
    attrs = np.array([[i / 8, (7-i) / 8, (i % 3) / 3, 0.2 + i / 20, 0.7 - i / 20, 0.3 + i / 16] for i in range(8)], np.float32)
    return {"coords": c, "vertices": v, "faces": f, "shape_fields": np.zeros((8, 7), np.float32), "material_attrs": attrs}


def nonmanifold_fields() -> dict[str, np.ndarray]:
    a = fields()
    a["vertices"] = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1],
                              [0, -1, 0], [2, 2, 2], [99, 99, 99]], np.float32) / 4096
    a["faces"] = np.array([[0, 1, 2], [1, 0, 3], [0, 1, 4], [2, 1, 3]], np.int32)
    return a


def fixture_uv(size: int = 32) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    triangles, records = [], []
    for face, (x, y) in enumerate(((2, 2), (18, 2), (2, 18), (18, 18))):
        # Here y is an image row. Face corners are in the native bottom-up UV convention.
        triangles.extend([[x / size, 1-y / size], [(x+10) / size, 1-y / size], [x / size, 1-(y+10) / size]])
        for dy in range(11):
            for dx in range(11-dy):
                records.append(((y+dy)*size+x+dx, face, [1-(dx+dy)/10, dx/10, dy/10]))
    records.sort()
    evidence = {"pixels": np.array([r[0] for r in records], np.int64),
                "face_ids": np.array([r[1] for r in records], np.int64),
                "barycentric": np.array([r[2] for r in records], np.float32)}
    return np.array(triangles, np.float32), evidence


def evidence_for_uv(uv: np.ndarray, size: int, max_work: int = 1_000_000) -> dict[str, np.ndarray]:
    owner = export.interior_coverage(uv, size, max_work)
    pixels = np.flatnonzero(owner >= 0).astype(np.int64)
    face_ids = owner[pixels].astype(np.int64)
    points = np.stack(((pixels % size) / size, 1 - (pixels // size) / size), axis=1)
    tri = uv.reshape(-1, 3, 2).astype(np.float64)[face_ids]
    ab, ac, relative = tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0], points - tri[:, 0]
    determinant = ab[:, 0] * ac[:, 1] - ab[:, 1] * ac[:, 0]
    b = (relative[:, 0] * ac[:, 1] - relative[:, 1] * ac[:, 0]) / determinant
    c = (ab[:, 0] * relative[:, 1] - ab[:, 1] * relative[:, 0]) / determinant
    barycentric = np.stack((1 - b - c, b, c), axis=1).astype(np.float32)
    return {"pixels": pixels, "face_ids": face_ids,
            "barycentric": np.ascontiguousarray(barycentric)}


class TextureExportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.config = configuration(self.root / "deps")

    def tearDown(self):
        self.temp.cleanup()

    def product(self, a=None):
        a = fields() if a is None else a
        uv, evidence = fixture_uv()
        world, n, _ = export.corner_geometry(a["vertices"], a["faces"])
        pos, mask = export.correspondence(uv, world, evidence, self.config)
        images = export.textures(a, pos, evidence, mask, self.config)
        glb = self.root / "model.glb"
        glb.write_bytes(export.encode_glb(world, n, uv, images))
        mapping = glb.with_suffix(".correspondence.npz")
        np.savez_compressed(mapping, **evidence)
        return a, uv, evidence, glb, mapping, images

    def report(self, a=None, decode_input=None):
        a, _, _, glb, mapping, _ = self.product(a)
        decoded = self.root / "fields.npz"
        np.savez_compressed(decoded, **a)
        decode_report = self.root / "trellis2-cpu-decode-report.json"
        d = {"schema": "genmlu-trellis-cpu-decode-v1", "source_revision": export.TRELLIS_REFERENCE,
             "source_clean": True, "source_sha256": {"decoder": "a"*64, "geometry": "b"*64},
             "output": {"path": str(decoded), "sha256": export.sha(decoded)}, "runtime": {"device": "cpu"},
             "decoders": {r: {"requested_geometry_resolution": 512} for r in ("shape", "material")}}
        if decode_input is not None:
            d["input"] = {"path": str(decode_input.resolve()), "sha256": export.sha(decode_input)}
        decode_report.write_bytes(export.canonical(d))
        r = {"schema": export.SCHEMA, "policy": export.POLICY, "config": self.config,
             "exporter_sha256": export.sha(Path(export.__file__)), "dependency_identity": export.dependency_identity(self.config),
             "input": {"path": str(decoded), "sha256": export.sha(decoded)},
             "decode_report": {"path": str(decode_report), "sha256": export.sha(decode_report)},
             "decoder_source": {"revision": d["source_revision"], "files": d["source_sha256"]},
             "output": {"path": str(glb), "sha256": export.sha(glb)},
             "correspondence": {"path": str(mapping), "sha256": export.sha(mapping)},
             "product": export.verify_product(glb, mapping, a, self.config),
             "runtime": {"device": "cpu", "native_preflight_executed": True, "peak_rss_bytes": 1024, "seconds": 1.0}}
        r["payload_sha256"] = export.json_sha(r)
        path = glb.with_suffix(".report.json")
        path.write_bytes(export.canonical(r))
        return path, glb, decoded, r

    def full_mesh_manifest_result(self):
        coords = np.array([[0, 0, 0, index] for index in range(8)], np.int32)
        support_arrays = {
            "native": coords.copy(), "retained": coords.copy(),
            "selection": np.arange(len(coords), dtype=np.int64),
            **{name: coords.copy() for name in (
                "shape_input", "shape_output", "texture_input", "texture_output")},
        }
        support_path = self.root / "trellis2-sparse-support.npz"
        sparse_support = write_proof(support_path, support_arrays, full_mesh=True)
        latent_path = self.root / "trellis2-staged-latents.npz"
        np.savez_compressed(
            latent_path, condition=np.zeros((1, 1, 1), np.float32), coords=coords,
            shape_latent=np.zeros((len(coords), 32), np.float32),
            structure_latent=np.zeros((1, 1, 1, 1, 1), np.float32),
            texture_latent=np.zeros((len(coords), 32), np.float32),
        )
        sparse_support["latent"] = {"path": str(latent_path), "sha256": export.sha(latent_path)}
        path, _, _, report = self.report(decode_input=latent_path)
        config = {"output_contract": "full_mesh", "decode_cpu_fields": True,
                  "max_sparse_tokens": 8, "cpu_decode_resolution": 512,
                  "cpu_texture_export": self.config}
        artifacts = [report[key] for key in ("input", "output", "correspondence", "decode_report")]
        artifacts.extend(({"path": str(path), "sha256": export.sha(path)},
                          sparse_support["proof"], sparse_support["latent"]))
        result = {
            "artifacts": artifacts, "logs": [], "metrics": {}, "stage_timings": {},
            "checks": {"formal_output_contract": True}, "sparse_support": sparse_support,
            "cpu_decoder_source_identity": {
                "clean": True, "revision": export.TRELLIS_REFERENCE,
                "source_sha256": report["decoder_source"]["files"],
            },
            "cpu_texture_export_report": {"path": str(path), "sha256": export.sha(path)},
            "output_capability": {
                "schema": "trellis-output-capability-v1", "requested": "full_mesh",
                "produced": "textured_glb", "full_mesh_available": True,
                "formal_mesh_available": True, "textured_glb_available": True,
                "formal_output_contract": True, "shape_decoder_executed": True,
                "texture_decoder_executed": True, "diagnostic_preview": False,
                "primary_artifact": {**report["output"], "role": "textured_glb"},
                "decoded_fields_artifact": {
                    **report["input"], "role": "decoded_fields_and_geometry"},
            },
        }
        return config, result, report

    def test_config_identity_and_hard_bounds(self):
        for change in ({"texture_size": True}, {"texture_size": 31}, {"max_bytes": 1}, {"chunk_size": 0}, {"island_padding": float("nan")}, {"uv_layout": "automatic"}, {"uv_layout": "face_tiles"}, {"unknown": 1}):
            with self.subTest(change=change), self.assertRaises(ValueError):
                export.settings({**self.config, **change})
        export.dependency_identity(self.config)
        (self.root / "deps/uv_unwrapper/unwrap.py").write_bytes(b"changed")
        with self.assertRaisesRegex(ValueError, "inventory/SHA"):
            export.dependency_identity(self.config)

    def test_rejects_extra_native_and_escaping_dependency_paths(self):
        (self.root / "deps/uv_unwrapper/extra.py").write_bytes(b"extra")
        with self.assertRaises(ValueError):
            export.dependency_identity(self.config)
        c = copy.deepcopy(self.config)
        c["dependencies"]["files"]["../escape.py"] = "0" * 64
        with self.assertRaises(ValueError):
            export.settings(c)

    def test_full_contract_requires_explicit_identity_and_512(self):
        base = {"output_contract": "full_mesh", "max_sparse_tokens": 8,
                "decode_cpu_fields": True, "cpu_decode_resolution": 512,
                "cpu_texture_export": self.config}
        self.assertEqual(validate_output_contract(base), "full_mesh")
        for change in ({"decode_cpu_fields": False}, {"cpu_decode_resolution": 256}, {"cpu_decode_resolution": 1024}, {"cpu_texture_export": {}}, {"output_contract": "latent_only"}):
            with self.subTest(change=change), self.assertRaises(ValueError):
                validate_output_contract({**base, **change})

    def test_full_contract_requires_explicit_bounded_sparse_cap(self):
        base = {"output_contract": "full_mesh", "decode_cpu_fields": True,
                "cpu_decode_resolution": 512, "cpu_texture_export": self.config}
        with self.assertRaisesRegex(ValueError, "explicit max_sparse_tokens"):
            validate_output_contract(base)
        for limit in (8, 16, 32768):
            with self.subTest(limit=limit):
                self.assertEqual(validate_output_contract({**base, "max_sparse_tokens": limit}), "full_mesh")
        for limit in (7, 32769, True, False, None, "1024", 1024.0):
            with self.subTest(limit=limit), self.assertRaisesRegex(ValueError, "max_sparse_tokens"):
                validate_output_contract({**base, "max_sparse_tokens": limit})

    def test_missing_sparse_cap_rejected_before_backend_or_cli_runtime(self):
        from genmlu import cli
        from genmlu.backends import trellis2_generation as backend

        config = {"output_contract": "full_mesh", "decode_cpu_fields": True,
                  "cpu_decode_resolution": 512, "cpu_texture_export": self.config}
        with patch.object(backend, "require_mlu") as mlu, patch.object(backend, "preflight_cpu_texture_export") as preflight:
            with self.assertRaisesRegex(ValueError, "explicit max_sparse_tokens"):
                backend.run_trellis2_inference(self.root, config, self.root / "run", self.root)
        mlu.assert_not_called()
        preflight.assert_not_called()
        config_path = self.root / "missing-cap.json"
        config_path.write_bytes(export.canonical(config))
        with self.assertRaisesRegex(ValueError, "explicit max_sparse_tokens"):
            cli.load_run_config(config_path, "trellis-2-4b")

    def test_correct_eight_corners_and_centers(self):
        coords = np.array([[0, i & 1, (i >> 1) & 1, (i >> 2) & 1] for i in range(8)], np.int32)
        attrs = np.repeat(np.arange(8, dtype=np.float32)[:, None], 6, 1)
        sampler = export.SparseSampler(coords, attrs, 2)
        np.testing.assert_array_equal(sampler.sample(coords[:, 1:].astype(np.float32)+0.5, 3), attrs)
        np.testing.assert_array_equal(sampler.sample(np.array([[1, 1, 1]], np.float32), 1), np.full((1, 6), 3.5, np.float32))
        one = np.zeros_like(attrs)
        one[7] = 1
        np.testing.assert_array_equal(export.SparseSampler(coords, one, 2).sample(np.ones((1, 3), np.float32), 1), np.full((1, 6), 0.125, np.float32))

    def test_sparse_missing_neighbor_renormalization_and_bounds(self):
        coords = np.array([[0, 0, 0, 0]], np.int32)
        attrs = np.arange(6, dtype=np.float32)[None]
        sampler = export.SparseSampler(coords, attrs, 2)
        for point in ([0, 0, 0], [1, 1, 1], [-0.25, 0.5, 0.5]):
            np.testing.assert_array_equal(sampler.sample(np.array([point], np.float32), 1), attrs)
        for point in ([2, 2, 2], [-1, 0, 0], [float("nan"), 0, 0]):
            with self.assertRaises(ValueError):
                sampler.sample(np.array([point], np.float32), 1)
        with self.assertRaises(ValueError):
            export.SparseSampler(np.repeat(coords, 2, 0), np.repeat(attrs, 2, 0), 2)

    def test_permutation_chunking_and_distinct_material_rows(self):
        a = fields()
        q = np.random.default_rng(7).uniform(255.6, 256.4, (19, 3)).astype(np.float32)
        reference = export.SparseSampler(a["coords"], a["material_attrs"]).sample(q, 1)
        order = np.array([7, 0, 3, 1, 6, 2, 5, 4])
        np.testing.assert_array_equal(reference, export.SparseSampler(a["coords"][order], a["material_attrs"][order]).sample(q, 19))
        self.assertFalse(np.array_equal(reference, export.SparseSampler(a["coords"], a["material_attrs"][order]).sample(q, 7)))

    def test_geometry_uv_pbr_glb_roundtrip(self):
        a, uv, evidence, glb, mapping, images = self.product()
        self.assertNotEqual(len(a["coords"]), len(a["vertices"]))
        result = export.verify_product(glb, mapping, a, self.config)
        self.assertEqual(result["faces"], 4)
        self.assertEqual(result["vertices"], 12)
        self.assertGreater(result["covered_texels"], 0)
        arrays, actual = export.read_glb(glb, self.config)
        np.testing.assert_array_equal(arrays[0], export.rotate(a["vertices"][a["faces"]].reshape(-1, 3)))
        np.testing.assert_array_equal(arrays[2][:, 1], 1-uv[:, 1])
        np.testing.assert_array_equal(actual[0], images[0])
        np.testing.assert_array_equal(actual[1], images[1])
        self.assertTrue(np.all(actual[1][:, :, 0] == 0))
        self.assertTrue(np.any(actual[1][:, :, 1] != actual[1][:, :, 2]))
        self.assertTrue(np.any(actual[0][:, :, 3] != 255))
        self.assertIn(0, evidence["face_ids"])

    def test_wrong_material_or_geometry_fails_actual_product_check(self):
        a, _, _, glb, mapping, _ = self.product()
        bad = {**a, "material_attrs": a["material_attrs"][::-1].copy()}
        with self.assertRaisesRegex(ValueError, "material correspondence"):
            export.verify_product(glb, mapping, bad, self.config)
        a["vertices"][0, 0] += 0.0001
        with self.assertRaisesRegex(ValueError, "geometry/normals"):
            export.verify_product(glb, mapping, a, self.config)

    def test_raster_uv_ownership_missing_pixels_and_overlap(self):
        a, uv, evidence, _, _, _ = self.product()
        world = a["vertices"][a["faces"]].reshape(-1, 3)
        bad = {k: v.copy() for k, v in evidence.items()}
        bad["face_ids"][3] = 3
        with self.assertRaises(ValueError):
            export.correspondence(uv, world, bad, self.config)
        bad = {k: v[evidence["face_ids"] != 0] for k, v in evidence.items()}
        with self.assertRaisesRegex(ValueError, "omits"):
            export.correspondence(uv, world, bad, self.config)
        uv[3:6] = uv[:3]
        with self.assertRaisesRegex(ValueError, "overlapping"):
            export.interior_coverage(uv, 32, 100000)

    def test_face_tile_layout_variable_counts_padding_and_capacity(self):
        for face_count in (1, 2, 5, 17):
            with self.subTest(face_count=face_count):
                uv = export.face_tile_uv(face_count, 128, 4)
                self.assertEqual(uv.shape, (3 * face_count, 2))
                export.validate_uv(uv, face_count)
                owner = export.interior_coverage(uv, 128, 1_000_000)
                self.assertEqual(set(owner[owner >= 0]), set(range(face_count)))
        layout = export.face_tile_geometry(1254, 1024, 4)
        self.assertEqual(layout, {"grid": 36, "pitch": 28, "margin": 8,
                                  "inset": 5, "side": 18})
        first = export.face_tile_uv(1254, 1024, 4)[:3] * np.float32(1024)
        np.testing.assert_array_equal(first[:, 0], [13, 31, 13])
        np.testing.assert_array_equal(1024 - first[:, 1], [13, 13, 31])
        owner = export.interior_coverage(
            export.face_tile_uv(1254, 1024, 4), 1024, 2_000_000)
        counts = np.bincount(owner[owner >= 0], minlength=1254)
        np.testing.assert_array_equal(counts, np.full(1254, 136, np.int64))
        with self.assertRaisesRegex(ValueError, "padding_pixels 4"):
            export.face_tile_uv(4, 128, 3)
        with patch.object(export.np, "arange") as arange, patch.object(export.np, "empty") as empty:
            with self.assertRaisesRegex(ValueError, "insufficient"):
                export.face_tile_uv(1254, 128, 4)
        arange.assert_not_called()
        empty.assert_not_called()

    def test_face_tiles_uv_glb_roundtrip_and_product_coverage(self):
        a = fields()
        config = export.settings({**self.config, "uv_layout": "face_tiles", "padding_pixels": 4})
        uv = export.face_tile_uv(len(a["faces"]), config["texture_size"], config["padding_pixels"])
        evidence = evidence_for_uv(uv, config["texture_size"])
        world, normal, _ = export.corner_geometry(a["vertices"], a["faces"])
        positions, mask = export.correspondence(uv, world, evidence, config)
        images = export.textures(a, positions, evidence, mask, config)
        glb = self.root / "face-tiles.glb"
        glb.write_bytes(export.encode_glb(world, normal, uv, images))
        mapping = glb.with_suffix(".correspondence.npz")
        np.savez_compressed(mapping, **evidence)
        arrays, _ = export.read_glb(glb, config)
        roundtrip = arrays[2].copy()
        roundtrip[:, 1] = 1 - roundtrip[:, 1]
        np.testing.assert_array_equal(roundtrip, uv)
        product = export.verify_product(glb, mapping, a, config)
        self.assertEqual(product["interior_covered_faces"], len(a["faces"]))
        self.assertGreater(product["minimum_face_interior_texels"], 0)
        self.assertEqual(product["uv_implementation"]["layout"], "face_tiles")
        self.assertEqual(product["uv_implementation"]["version"], "face-tiles-v1")
        self.assertEqual({key: product["uv_implementation"][key]
                          for key in ("grid", "pitch", "margin", "inset", "side")},
                         export.face_tile_geometry(len(a["faces"]), 32, 4))
        self.assertIs(product["uv_implementation"]["official_unwrap"], False)

    def test_all_face_interior_gate_precedes_baker_and_survives_glb_reparse(self):
        a = fields()
        uv, _ = fixture_uv()
        uv[-3:] = np.array([[0.9, 0.9], [0.9001, 0.9], [0.9, 0.9001]], np.float32)

        class Tensor:
            def __init__(self, data):
                self.data, self.device = data, SimpleNamespace(type="cpu")

            def to(self, *, device):
                self.device = SimpleNamespace(type=device)
                return self

            def detach(self):
                return self

            def numpy(self):
                return self.data

        unwrap = lambda *_args, **_kwargs: (Tensor(uv), Tensor(np.arange(12).reshape(-1, 3)))
        baker = SimpleNamespace(rasterize=Mock())
        with self.assertRaisesRegex(ValueError, "every face"):
            export.native_pipeline(a, self.config, SimpleNamespace(from_numpy=Tensor), unwrap, baker)
        baker.rasterize.assert_not_called()

        tiled_config = export.settings({**self.config, "uv_layout": "face_tiles",
                                        "padding_pixels": 4})
        tiled_unwrap = Mock(side_effect=AssertionError("face_tiles called native unwrap"))
        tiled_baker = SimpleNamespace(rasterize=Mock())
        with patch.object(export, "face_tile_uv", return_value=uv), \
                self.assertRaisesRegex(ValueError, "every face"):
            export.native_pipeline(a, tiled_config, SimpleNamespace(from_numpy=Tensor),
                                   tiled_unwrap, tiled_baker)
        tiled_unwrap.assert_not_called()
        tiled_baker.rasterize.assert_not_called()

        world, normal, _ = export.corner_geometry(a["vertices"], a["faces"])
        _, _, evidence, _, mapping, images = self.product(a)
        glb = self.root / "missing-face-interior.glb"
        glb.write_bytes(export.encode_glb(world, normal, uv, images))
        with self.assertRaisesRegex(ValueError, "every face"):
            export.verify_product(glb, mapping, a, self.config)

    def test_zero_area_uv_and_bad_geometry_rejected(self):
        a = fields()
        with self.assertRaisesRegex(ValueError, "degenerate UV"):
            export.validate_uv(np.zeros((12, 2), np.float32), 4)
        a["faces"][0] = [0, 0, 1]
        with self.assertRaisesRegex(ValueError, "degenerate geometry"):
            export.corner_geometry(a["vertices"], a["faces"])

    def test_nonmanifold_corner_geometry_preserves_faces_and_reports_original_edges(self):
        a = nonmanifold_fields()
        before = {k: v.copy() for k, v in a.items()}
        world, normal, original = export.corner_geometry(a["vertices"], a["faces"])
        np.testing.assert_array_equal(world, a["vertices"][a["faces"]].reshape(-1, 3))
        self.assertEqual(world.shape, (12, 3))
        self.assertEqual(original, {"vertices": 7, "faces": 4, "referenced_vertices": 5,
                                   "unreferenced_vertices": 2, "boundary_edges": 5,
                                   "nonmanifold_edges": 1, "maximum_edge_incidence": 3,
                                   "degenerate_faces": 0})
        np.testing.assert_allclose(np.linalg.norm(normal, axis=1), 1, rtol=0, atol=1e-7)
        np.testing.assert_array_equal(normal[:3], np.tile([0, 0, 1], (3, 1)))
        np.testing.assert_array_equal(normal[6:9], np.tile([0, 0, -1], (3, 1)))
        for key in a:
            np.testing.assert_array_equal(a[key], before[key])
        self.assertIs(export.POLICY["watertight_claimed"], False)

    def test_corner_normals_follow_winding_not_shared_vertex_average(self):
        a = nonmanifold_fields()
        world, normal, _ = export.corner_geometry(a["vertices"], a["faces"])
        reversed_world, reversed_normal, _ = export.corner_geometry(a["vertices"], a["faces"][:, ::-1])
        np.testing.assert_array_equal(reversed_world.reshape(-1, 3, 3), world.reshape(-1, 3, 3)[:, ::-1])
        np.testing.assert_array_equal(reversed_normal, -normal)
        a["vertices"][-2:] = [[1e20, -1e20, 3], [-7, 8, -9]]
        actual_world, actual_normal, _ = export.corner_geometry(a["vertices"], a["faces"])
        np.testing.assert_array_equal(actual_world, world)
        np.testing.assert_array_equal(actual_normal, normal)

    def test_corner_geometry_keeps_invalid_geometry_rejections(self):
        for mutation in ("repeated", "collinear", "nan", "infinite", "negative", "outside"):
            a = nonmanifold_fields()
            if mutation == "repeated":
                a["faces"][0, 1] = a["faces"][0, 0]
            elif mutation == "collinear":
                a["vertices"][2] = a["vertices"][1] * 2
            elif mutation in {"nan", "infinite"}:
                a["vertices"][0, 0] = np.nan if mutation == "nan" else np.inf
            else:
                a["faces"][0, 0] = -1 if mutation == "negative" else len(a["vertices"])
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                export.corner_geometry(a["vertices"], a["faces"])

    def test_native_interface_receives_isolated_corners_and_original_world(self):
        a = nonmanifold_fields()
        before = {key: value.copy() for key, value in a.items()}
        uv, evidence = fixture_uv()
        world, normal, _ = export.corner_geometry(a["vertices"], a["faces"])
        expected_faces = np.arange(len(world), dtype=np.int64).reshape(-1, 3)
        positions, mask = export.correspondence(uv, world, evidence, self.config)
        raster = np.zeros((32, 32, 4), np.float32)
        raster[:, :, 3] = -1
        raster.reshape(-1, 4)[evidence["pixels"], :3] = evidence["barycentric"]
        raster.reshape(-1, 4)[evidence["pixels"], 3] = evidence["face_ids"]
        interpolated = np.zeros((32, 32, 3), np.float32)
        interpolated[mask] = positions

        class Tensor:
            def __init__(self, data):
                self.assert_writable = data.flags.writeable
                self.data, self.device = data, SimpleNamespace(type="cpu")

            def to(self, *, device):
                assert device == "cpu"
                return self

            def detach(self):
                return self

            def numpy(self):
                return self.data

        def unwrap(v, n, f, *, island_padding):
            self.assertTrue(v.assert_writable and n.assert_writable and f.assert_writable)
            np.testing.assert_array_equal(v.data, world)
            np.testing.assert_array_equal(n.data, normal)
            np.testing.assert_array_equal(f.data, expected_faces)
            self.assertEqual(len(np.unique(f.data)), 3 * len(a["faces"]))
            return Tensor(uv), Tensor(expected_faces)

        def interpolate(v, rast, f):
            self.assertTrue(v.assert_writable and f.assert_writable)
            np.testing.assert_array_equal(v.data, world)
            np.testing.assert_array_equal(f.data, expected_faces)
            return Tensor(interpolated)

        baker = SimpleNamespace(rasterize=lambda *args: Tensor(raster),
                                get_mask=lambda *args: Tensor(mask), interpolate=interpolate)
        actual_uv, actual_evidence = export.native_pipeline(a, self.config, SimpleNamespace(from_numpy=Tensor), unwrap, baker)
        np.testing.assert_array_equal(actual_uv, uv)
        for key in evidence:
            np.testing.assert_array_equal(actual_evidence[key], evidence[key])
        for key in a:
            np.testing.assert_array_equal(a[key], before[key])

    def test_face_tiles_pipeline_skips_unwrapper_uses_baker_and_preserves_sources(self):
        a = fields()
        before = {key: value.copy() for key, value in a.items()}
        config = export.settings({**self.config, "uv_layout": "face_tiles",
                                  "padding_pixels": 4})
        uv = export.face_tile_uv(len(a["faces"]), 32, 4)
        evidence = evidence_for_uv(uv, 32)
        world, _, _ = export.corner_geometry(a["vertices"], a["faces"])
        positions, mask = export.correspondence(uv, world, evidence, config)
        raster = np.zeros((32, 32, 4), np.float32)
        raster[:, :, 3] = -1
        raster.reshape(-1, 4)[evidence["pixels"], :3] = evidence["barycentric"]
        raster.reshape(-1, 4)[evidence["pixels"], 3] = evidence["face_ids"]
        interpolated = np.zeros((32, 32, 3), np.float32)
        interpolated[mask] = positions

        class Tensor:
            def __init__(self, data):
                self.data, self.device = data, SimpleNamespace(type="cpu")
                self.writable = data.flags.writeable

            def to(self, *, device):
                self.device = SimpleNamespace(type=device)
                return self

            def detach(self):
                return self

            def numpy(self):
                return self.data

        expected_faces = np.arange(len(world), dtype=np.int32).reshape(-1, 3)

        def rasterize(actual_uv, actual_faces, size):
            self.assertTrue(actual_uv.writable and actual_faces.writable)
            np.testing.assert_array_equal(actual_uv.data, uv)
            np.testing.assert_array_equal(actual_faces.data, expected_faces)
            self.assertEqual(size, 32)
            return Tensor(raster)

        def interpolate(actual_world, _raster, actual_faces):
            self.assertTrue(actual_world.writable and actual_faces.writable)
            np.testing.assert_array_equal(actual_world.data, world)
            np.testing.assert_array_equal(actual_faces.data, expected_faces)
            return Tensor(interpolated)

        unwrapper = Mock(side_effect=AssertionError("face_tiles called native unwrap"))
        baker = SimpleNamespace(rasterize=rasterize, get_mask=lambda *_: Tensor(mask),
                                interpolate=interpolate)
        actual_uv, actual_evidence = export.native_pipeline(
            a, config, SimpleNamespace(from_numpy=Tensor), unwrapper, baker)
        unwrapper.assert_not_called()
        np.testing.assert_array_equal(actual_uv, uv)
        for key in evidence:
            np.testing.assert_array_equal(actual_evidence[key], evidence[key])
        for key in a:
            np.testing.assert_array_equal(a[key], before[key])

    def test_nonmanifold_glb_parent_checks_triangles_material_and_topology_report(self):
        path, glb, decoded, report = self.report(nonmanifold_fields())
        accepted = export.validate_export(path, export.sha(path), self.config, glb, decoded)
        self.assertEqual(accepted["product"]["original_geometry"]["nonmanifold_edges"], 1)
        self.assertEqual(accepted["product"]["vertices"], 12)
        for key, value in (("nonmanifold_edges", 0), ("boundary_edges", 0), ("unreferenced_vertices", 0)):
            bad = copy.deepcopy(report)
            bad["product"]["original_geometry"][key] = value
            bad["payload_sha256"] = export.json_sha({k: v for k, v in bad.items() if k != "payload_sha256"})
            path.write_bytes(export.canonical(bad))
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, "actual GLB/report product"):
                export.validate_export(path, export.sha(path), self.config, glb, decoded)

    def test_nonmanifold_export_does_not_hide_reordered_or_reversed_triangles(self):
        a, uv, _, glb, mapping, images = self.product(nonmanifold_fields())
        world, normal, _ = export.corner_geometry(a["vertices"], a["faces"])
        for order in (np.arange(12).reshape(-1, 3)[::-1].reshape(-1),
                      np.arange(12).reshape(-1, 3)[:, ::-1].reshape(-1)):
            glb.write_bytes(export.encode_glb(world[order], normal[order], uv, images))
            with self.assertRaisesRegex(ValueError, "geometry/normals"):
                export.verify_product(glb, mapping, a, self.config)

    @unittest.skipUnless(os.environ.get("TRELLIS_CPU_TEXTURE_DECODED_NPZ"), "external decoded NPZ not supplied")
    def test_external_decoded_corner_geometry_numpy_only(self):
        path = Path(os.environ["TRELLIS_CPU_TEXTURE_DECODED_NPZ"])
        digest = os.environ["TRELLIS_CPU_TEXTURE_DECODED_SHA256"]
        a = export.load_fields(path, digest, self.config)
        world, normal, original = export.corner_geometry(a["vertices"], a["faces"])
        np.testing.assert_array_equal(world.reshape(-1, 3, 3), a["vertices"][a["faces"]])
        expected = np.cross(world.reshape(-1, 3, 3)[:, 1].astype(np.float64) - world.reshape(-1, 3, 3)[:, 0],
                            world.reshape(-1, 3, 3)[:, 2].astype(np.float64) - world.reshape(-1, 3, 3)[:, 0])
        expected /= np.linalg.norm(expected, axis=1)[:, None]
        np.testing.assert_allclose(normal.reshape(-1, 3, 3), np.repeat(expected[:, None], 3, axis=1), rtol=0, atol=1e-7)
        self.assertEqual(original["faces"], len(a["faces"]))
        self.assertEqual(original["unreferenced_vertices"], len(a["vertices"]) - len(np.unique(a["faces"])))
        self.assertEqual(export.sha(path), digest)

    def test_padding_does_not_wrap_or_change_surface(self):
        values = np.zeros((5, 5, 4), np.uint8)
        values[0, 0] = 77
        mask = np.zeros((5, 5), bool)
        mask[0, 0] = True
        padded = export.pad_texture(values, mask, 1)
        np.testing.assert_array_equal(padded[mask], values[mask])
        self.assertEqual(int(padded[-1].sum()), 0)
        self.assertEqual(int(padded[:, -1].sum()), 0)
        self.assertTrue(np.all(padded[1, 0] == 77))

    def test_glb_rejects_truncation_and_vertex_color_only(self):
        _, _, _, glb, _, _ = self.product()
        original = glb.read_bytes()
        for bad in (original[:-1], original.replace(b'TEXCOORD_0', b'COLOR_0000')):
            glb.write_bytes(bad)
            with self.assertRaises(ValueError):
                export.read_glb(glb, self.config)

    def test_report_binds_actual_artifacts_source_config_and_pixels(self):
        path, glb, decoded, r = self.report()
        export.validate_export(path, export.sha(path), self.config, glb, decoded)
        original = path.read_bytes()
        for field, value in (("exporter_sha256", "0"*64), ("product", {"faces": 4}), ("policy", {})):
            bad = copy.deepcopy(r)
            bad[field] = value
            bad["payload_sha256"] = export.json_sha({k: v for k, v in bad.items() if k != "payload_sha256"})
            path.write_bytes(export.canonical(bad))
            with self.subTest(field=field), self.assertRaises(ValueError):
                export.validate_export(path, export.sha(path), self.config, glb, decoded)
        path.write_bytes(original)
        glb.write_bytes(glb.read_bytes() + b"changed")
        with self.assertRaisesRegex(ValueError, "SHA/path"):
            export.validate_export(path, export.sha(path), self.config, glb, decoded)

    def test_npz_strict_schema_finite_grid_and_sha(self):
        for mutation in ("nan", "duplicate", "batch", "outside", "channels"):
            a = fields()
            if mutation == "nan":
                a["material_attrs"][0, 0] = np.nan
            elif mutation == "duplicate":
                a["coords"][0] = a["coords"][1]
            elif mutation == "batch":
                a["coords"][0, 0] = 1
            elif mutation == "outside":
                a["coords"][0, 1] = 512
            else:
                a["material_attrs"] = a["material_attrs"][:, :5]
            path = self.root / "bad.npz"
            np.savez_compressed(path, **a)
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                export.load_fields(path, export.sha(path), self.config)
        with self.assertRaisesRegex(ValueError, "SHA"):
            export.load_fields(path, "0"*64, self.config)

    def test_cost_guard_does_not_relax_validation(self):
        uv, _ = fixture_uv()
        with self.assertRaisesRegex(ValueError, "max_raster_work"):
            export.interior_coverage(uv, 32, 1)

    def test_atomic_output_does_not_replace_existing_file(self):
        path = self.root / "artifact"
        export.atomic_bytes(path, b"first")
        with self.assertRaises(ValueError):
            export.atomic_bytes(path, b"second")
        self.assertEqual(path.read_bytes(), b"first")

    def test_find_spec_is_not_native_readiness(self):
        with patch.dict("os.environ", {"TORCH_DEVICE_BACKEND_AUTOLOAD": "1"}):
            with self.assertRaisesRegex(ValueError, "autoload"):
                export.load_native(self.config)

    def test_parent_preflight_rejects_failure_before_mlu(self):
        from genmlu.backends import trellis2_generation as backend
        config = {"output_contract": "full_mesh", "decode_cpu_fields": True,
                  "max_sparse_tokens": 8, "cpu_decode_resolution": 512,
                  "cpu_texture_export": self.config}
        with patch.object(backend, "require_mlu") as mlu, patch.object(backend, "_run_cpu_texture_child", side_effect=RuntimeError("native unavailable")):
            with self.assertRaisesRegex(RuntimeError, "native unavailable"):
                backend.run_trellis2_inference(self.root, config, self.root / "run", self.root)
        mlu.assert_not_called()

    def test_child_environment_identity_failure_and_duplicate_records(self):
        from genmlu.backends import trellis2_generation as backend
        expected = {"schema": export.SCHEMA, "native_preflight_executed": True,
                    "dependency_identity": export.dependency_identity(self.config),
                    "exporter_sha256": export.sha(Path(export.__file__))}
        line = export.PREFIX + json.dumps(expected)
        with patch.object(backend.subprocess, "run", return_value=SimpleNamespace(returncode=0, stdout=line, stderr="")) as run:
            backend._run_cpu_texture_child(self.root / "config", self.root, self.config, preflight=True)
            env = run.call_args.kwargs["env"]
            self.assertEqual(env["TORCH_DEVICE_BACKEND_AUTOLOAD"], "0")
            self.assertTrue(all(env[k] == "" for k in ("CUDA_VISIBLE_DEVICES", "MLU_VISIBLE_DEVICES", "CNRT_VISIBLE_DEVICES")))
        for response in (SimpleNamespace(returncode=1, stdout="", stderr="native error"),
                         SimpleNamespace(returncode=0, stdout=line+"\n"+line, stderr=""),
                         SimpleNamespace(returncode=0, stdout=export.PREFIX+'{"native_preflight_executed":false}', stderr="")):
            with patch.object(backend.subprocess, "run", return_value=response), self.assertRaises(RuntimeError):
                backend._run_cpu_texture_child(self.root / "config", self.root, self.config, preflight=True)

    def test_manifest_requires_actual_product_and_verified_report(self):
        from genmlu.manifest import merge_backend_result, new_manifest
        config, result, r = self.full_mesh_manifest_result()
        value = new_manifest("infer", "trellis-2-4b", config, {})
        merge_backend_result(value, result)
        self.assertEqual(value["output_capability"]["primary_artifact"]["role"], "textured_glb")
        self.assertIn("cpu_texture_export_report", value["provenance"])
        for mutation in ("missing_report", "wrong_sha", "false_capability", "false_check", "missing_correspondence"):
            bad = copy.deepcopy(result)
            if mutation == "missing_report":
                del bad["cpu_texture_export_report"]
            elif mutation == "wrong_sha":
                bad["cpu_texture_export_report"]["sha256"] = "0"*64
            elif mutation == "false_capability":
                bad["output_capability"]["textured_glb_available"] = False
            elif mutation == "false_check":
                bad["checks"]["formal_output_contract"] = False
            else:
                bad["artifacts"] = [a for a in bad["artifacts"] if a != r["correspondence"]]
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                merge_backend_result(new_manifest("infer", "trellis-2-4b", config, {}), bad)

    def test_full_mesh_manifest_rejects_missing_sparse_support(self):
        from genmlu.manifest import merge_backend_result, new_manifest
        config, result, _ = self.full_mesh_manifest_result()
        del result["sparse_support"]
        with self.assertRaisesRegex(ValueError, "sparse support evidence"):
            merge_backend_result(new_manifest("infer", "trellis-2-4b", config, {}), result)

    def test_full_mesh_manifest_rejects_swapped_decode_input(self):
        from genmlu.manifest import merge_backend_result, new_manifest
        config, result, report = self.full_mesh_manifest_result()
        original_latent = Path(result["sparse_support"]["latent"]["path"])
        swapped_latent = self.root / "swapped-staged-latents.npz"
        swapped_latent.write_bytes(original_latent.read_bytes())
        result["artifacts"].append({"path": str(swapped_latent),
                                    "sha256": export.sha(swapped_latent)})

        decode_path = Path(report["decode_report"]["path"])
        decode = json.loads(decode_path.read_text(encoding="utf-8"))
        decode["input"] = {"path": str(swapped_latent.resolve()),
                           "sha256": export.sha(swapped_latent)}
        decode_path.write_bytes(export.canonical(decode))

        export_path = Path(result["cpu_texture_export_report"]["path"])
        exported = json.loads(export_path.read_text(encoding="utf-8"))
        exported["decode_report"]["sha256"] = export.sha(decode_path)
        exported["payload_sha256"] = export.json_sha(
            {key: value for key, value in exported.items() if key != "payload_sha256"})
        export_path.write_bytes(export.canonical(exported))
        for artifact in result["artifacts"]:
            if Path(artifact["path"]) in {decode_path, export_path}:
                artifact["sha256"] = export.sha(Path(artifact["path"]))
        result["cpu_texture_export_report"]["sha256"] = export.sha(export_path)

        with self.assertRaisesRegex(ValueError, "native-support latent"):
            merge_backend_result(new_manifest("infer", "trellis-2-4b", config, {}), result)

    def test_export_atomic_workflow_with_native_interface_stub(self):
        path, _, decoded, r = self.report()
        output = self.root / "exported.glb"
        uv, evidence = fixture_uv()
        identity = export.dependency_identity(self.config)
        with patch.object(export, "preflight", return_value=(None, None, None, identity)), patch.object(export, "native_pipeline", return_value=(uv, evidence)), patch.object(export, "peak_rss", return_value=1024):
            result = export.export(decoded, r["input"]["sha256"], Path(r["decode_report"]["path"]), r["decode_report"]["sha256"], output, self.config)
        report = export.validate_export(result, export.sha(result), self.config, output, decoded)
        self.assertEqual(report["product"]["faces"], 4)
        self.assertEqual(export.sha(decoded), r["input"]["sha256"])

    def test_linux_peak_rss_uses_own_vmhwm_not_inherited_resource(self):
        resource = SimpleNamespace(RUSAGE_SELF=0, getrusage=Mock(return_value=SimpleNamespace(ru_maxrss=8 * 1024**2)))
        with patch.object(export.sys, "platform", "linux"), patch.dict(sys.modules, {"resource": resource}), \
                patch.object(Path, "read_text", return_value="Name:\tpython\nVmHWM:\t  12345 kB\nVmRSS:\t100 kB\n") as read:
            self.assertEqual(export.peak_rss(), 12345 * 1024)
            read.assert_called_once_with(encoding="ascii")
        resource.getrusage.assert_not_called()

    def test_linux_peak_rss_rejects_bad_proc_without_resource_fallback(self):
        resource = SimpleNamespace(RUSAGE_SELF=0, getrusage=Mock(return_value=SimpleNamespace(ru_maxrss=1)))
        cases = ("", "VmRSS: 123 kB\n", "VmHWM: 123 kB\nVmHWM: 124 kB\n",
                 "VmHWM: 0 kB\n", "VmHWM: -1 kB\n", "VmHWM: +1 kB\n",
                 "VmHWM: 1.5 kB\n", "VmHWM: NaN kB\n", "VmHWM: inf kB\n",
                 "VmHWM: 123 KB\n", "VmHWM: 123 B\n", "VmHWM: 123\n",
                 "VmHWM: 123 kB extra\n", "VmHWM: 1_024 kB\n")
        with patch.object(export.sys, "platform", "linux"), patch.dict(sys.modules, {"resource": resource}):
            for content in cases:
                with self.subTest(content=content), patch.object(Path, "read_text", return_value=content):
                    self.assertIsNone(export.peak_rss())
            for error in (FileNotFoundError(), PermissionError(), UnicodeError()):
                with self.subTest(error=type(error).__name__), patch.object(Path, "read_text", side_effect=error):
                    self.assertIsNone(export.peak_rss())
        resource.getrusage.assert_not_called()

    def test_peak_rss_platform_fallback_is_explicit_and_positive(self):
        resource = SimpleNamespace(RUSAGE_SELF=0, getrusage=Mock(return_value=SimpleNamespace(ru_maxrss=12345)))
        with patch.dict(sys.modules, {"resource": resource}):
            with patch.object(export.sys, "platform", "darwin"):
                self.assertEqual(export.peak_rss(), 12345)
                resource.getrusage.return_value.ru_maxrss = 0
                self.assertIsNone(export.peak_rss())
            resource.getrusage.reset_mock()
            with patch.object(export.sys, "platform", "win32"):
                self.assertIsNone(export.peak_rss())
            resource.getrusage.assert_not_called()

    def test_export_rss_gate_still_rejects_missing_and_over_budget(self):
        _, _, decoded, r = self.report()
        uv, evidence = fixture_uv()
        identity = export.dependency_identity(self.config)
        self.assertEqual(export.DEFAULTS["max_bytes"], 2 * 1024**3)
        for index, rss in enumerate((None, self.config["max_bytes"] + 1)):
            output = self.root / f"rss-rejected-{index}.glb"
            with patch.object(export, "preflight", return_value=(None, None, None, identity)), \
                    patch.object(export, "native_pipeline", return_value=(uv, evidence)), \
                    patch.object(export, "peak_rss", return_value=rss):
                with self.assertRaisesRegex(ValueError, "CPU peak RSS"):
                    export.export(decoded, r["input"]["sha256"], Path(r["decode_report"]["path"]), r["decode_report"]["sha256"], output, self.config)
            self.assertFalse(output.with_suffix(".report.json").exists())

    @unittest.skipUnless(sys.platform == "linux", "Linux fork/exec RSS accounting required")
    def test_linux_real_fork_exec_peak_rss_excludes_parent_ballast(self):
        # A fresh single-threaded helper forces fork/exec without loading Torch.
        script = r'''
import json, os, resource, subprocess, sys
child = """
import json, os, resource
from pathlib import Path
from genmlu.trellis_cpu_texture_export import peak_rss
def proc_hwm():
    row = next(line for line in Path('/proc/self/status').read_text().splitlines() if line.startswith('VmHWM:'))
    return int(row.split()[1]) * 1024
before = proc_hwm()
own = peak_rss()
after = proc_hwm()
print(json.dumps({'pid': os.getpid(), 'own': own, 'proc_before': before, 'proc_after': after,
                  'lifetime': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024}))
"""
ballast = bytearray(128 * 1024**2)
for offset in range(0, len(ballast), 4096):
    ballast[offset] = 1
completed = subprocess.run([sys.executable, '-B', '-c', child], preexec_fn=lambda: None,
                           cwd=os.getcwd(), capture_output=True, text=True, check=True, timeout=30)
result = json.loads(completed.stdout)
result['parent_pid'] = os.getpid()
result['parent_lifetime'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
print(json.dumps(result))
'''
        environment = {**os.environ, "TORCH_DEVICE_BACKEND_AUTOLOAD": "0", "CUDA_VISIBLE_DEVICES": "",
                       "MLU_VISIBLE_DEVICES": "", "CNRT_VISIBLE_DEVICES": "", "PYTHONDONTWRITEBYTECODE": "1",
                       "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"}
        environment["PYTHONPATH"] = str(Path(export.__file__).resolve().parents[1]) + os.pathsep + os.environ.get("PYTHONPATH", "")
        completed = subprocess.run([sys.executable, "-B", "-c", script], env=environment,
                                   capture_output=True, text=True, check=True, timeout=45)
        result = json.loads(completed.stdout)
        self.assertNotEqual(result["pid"], result["parent_pid"])
        self.assertGreaterEqual(result["parent_lifetime"], 128 * 1024**2)
        self.assertGreaterEqual(result["lifetime"], 128 * 1024**2)
        self.assertIs(type(result["own"]), int)
        self.assertGreater(result["own"], 0)
        self.assertLessEqual(result["proc_before"], result["own"])
        self.assertLessEqual(result["own"], result["proc_after"])
        self.assertLess(result["own"], result["lifetime"] - 64 * 1024**2)

    @unittest.skipUnless(importlib.util.find_spec("trimesh"), "independent GLB reader unavailable")
    def test_independent_trimesh_load(self):
        import trimesh
        _, _, _, glb, _, _ = self.product()
        scene = trimesh.load(glb, process=False)
        mesh = next(iter(scene.geometry.values()))
        self.assertEqual(len(mesh.faces), 4)
        self.assertEqual(mesh.visual.kind, "texture")
        self.assertIsNotNone(mesh.visual.material.baseColorTexture)
        self.assertIsNotNone(mesh.visual.material.metallicRoughnessTexture)

    @unittest.skipUnless(os.environ.get("TRELLIS_CPU_TEXTURE_CONFIG"), "external native CPU identity config not supplied")
    def test_real_native_bundle_preflight(self):
        environment = {**os.environ, "TORCH_DEVICE_BACKEND_AUTOLOAD": "0", "CUDA_VISIBLE_DEVICES": "",
                       "MLU_VISIBLE_DEVICES": "", "CNRT_VISIBLE_DEVICES": "", "PYTHONDONTWRITEBYTECODE": "1"}
        completed = subprocess.run([sys.executable, "-B", "-m", "genmlu.trellis_cpu_texture_export", "--preflight",
                                    "--config", os.environ["TRELLIS_CPU_TEXTURE_CONFIG"]],
                                   env=environment, capture_output=True, text=True, timeout=1800)
        self.assertEqual(completed.returncode, 0, completed.stderr)
        records = [line[len(export.PREFIX):] for line in completed.stdout.splitlines() if line.startswith(export.PREFIX)]
        self.assertEqual(len(records), 1)
        self.assertIs(json.loads(records[0])["native_preflight_executed"], True)


if __name__ == "__main__":
    unittest.main()
