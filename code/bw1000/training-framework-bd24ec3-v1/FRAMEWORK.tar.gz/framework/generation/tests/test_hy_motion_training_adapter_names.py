import unittest

from genmlu.backends.hy_motion_training import _adapter_parameter_name


class HYMotionTrainingAdapterNameTest(unittest.TestCase):
    def test_checkpoint_wrapper_name_is_canonical(self) -> None:
        self.assertEqual(
            _adapter_parameter_name(
                "double_blocks.0._checkpoint_wrapped_module.motion_mlp.fc1.lora_A"
            ),
            "double_blocks.0.motion_mlp.fc1.lora_A",
        )


if __name__ == "__main__":
    unittest.main()
