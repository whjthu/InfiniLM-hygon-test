from genmlu.runtime import MEMORY_LIMIT_BYTES, within_memory_limit


def test_frozen_memory_limit_uses_decimal_bytes_at_the_boundary() -> None:
    assert MEMORY_LIMIT_BYTES == 75_000_000_000
    assert within_memory_limit(74_999_999_999)
    assert within_memory_limit(75_000_000_000)
    assert not within_memory_limit(75_000_000_001)
