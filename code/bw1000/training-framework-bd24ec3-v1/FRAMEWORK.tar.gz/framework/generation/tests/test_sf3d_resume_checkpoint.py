from __future__ import annotations

import copy
import importlib
import inspect
import random
import sys

import numpy as np
import pytest
import torch

from genmlu import hy_resume_checkpoint as common
from genmlu.backends import sf3d_training as backend


class TinyMaterialHeads(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.albedo = torch.nn.Linear(3, 3)
        self.roughness = torch.nn.Linear(3, 1)
        self.metallic = torch.nn.Linear(3, 1)


def make_model(seed: int) -> tuple[TinyMaterialHeads, torch.optim.AdamW, list[tuple[str, torch.Tensor]]]:
    torch.manual_seed(seed)
    model = TinyMaterialHeads()
    named = list(model.named_parameters())
    return model, torch.optim.AdamW([parameter for _, parameter in named], lr=2e-3), named


def make_contract() -> dict:
    return backend._sf3d_contract(
        identity={key: "a" * 64 for key in backend._SF3D_IDENTITY_FIELDS},
        config_sha256="b" * 64,
        input_sha256="c" * 64,
        seed=19,
        warmup_steps=2,
        max_steps=8,
        batch_count=2,
        device_ids=[],
    )


def make_cache(seed: int, *, triplane_offset: float = 0.0) -> list[dict[str, torch.Tensor]]:
    generator = torch.Generator().manual_seed(seed)
    return [
        {
            "triplane_features": torch.randn(4, 3, generator=generator) + triplane_offset,
            "image_features": torch.randn(4, 3, generator=generator),
            "albedo": torch.randn(1, 3, generator=generator),
            "roughness": torch.randn(1, generator=generator),
            "metallic": torch.randn(1, generator=generator),
        }
        for _ in range(2)
    ]


def cache_fingerprint(cache: list[dict[str, torch.Tensor]]) -> str:
    return common.tree_sha256(backend._sf3d_capture_cached_batches(cache))


def cache_feature_spec() -> dict[str, int]:
    return {"triplane_width": 3, "image_width": 3}


def optimizer_progress(
    named: list[tuple[str, torch.Tensor]], optimizer: torch.optim.AdamW
) -> dict[str, int]:
    return {
        name: int(optimizer.state[parameter].get("step", 0).item())
        if hasattr(optimizer.state[parameter].get("step", 0), "item")
        else int(optimizer.state[parameter].get("step", 0))
        for name, parameter in named
    }


def update(
    model: TinyMaterialHeads, optimizer: torch.optim.AdamW, cache: list[dict[str, torch.Tensor]], global_step: int
) -> dict:
    optimizer.zero_grad(set_to_none=True)
    batch = cache[(global_step - 1) % len(cache)]
    inputs = (
        batch["triplane_features"]
        + 0.1 * batch["image_features"]
        + torch.randn(4, 3) * (0.5 + random.random())
        + float(np.random.uniform(-0.1, 0.1))
    )
    albedo = model.albedo(inputs)
    roughness = model.roughness(inputs)
    metallic = model.metallic(inputs)
    loss = (
        (albedo - batch["albedo"]).square().mean()
        + (roughness - batch["roughness"]).square().mean()
        + (metallic - batch["metallic"]).square().mean()
    )
    loss.backward()
    optimizer.step()
    return {
        "loss": loss.detach().clone(),
        "state": backend._sf3d_capture_state(
            list(model.named_parameters()), optimizer,
            optimizer_progress(list(model.named_parameters()), optimizer), cache,
        ),
        "rng": common.capture_rng([]),
    }


def update_albedo_only(
    model: TinyMaterialHeads, optimizer: torch.optim.AdamW, cache: list[dict[str, torch.Tensor]], global_step: int,
) -> None:
    optimizer.zero_grad(set_to_none=True)
    batch = cache[(global_step - 1) % len(cache)]
    loss = (model.albedo(batch["triplane_features"]) - batch["albedo"]).square().mean()
    loss.backward()
    optimizer.step()


def fingerprint(
    named: list[tuple[str, torch.Tensor]], optimizer: torch.optim.AdamW, cache: list[dict[str, torch.Tensor]]
) -> str:
    return common.tree_sha256(
        {
            "state": backend._sf3d_capture_state(
                named, optimizer, optimizer_progress(named, optimizer), cache
            ),
            "rng": common.capture_rng([]),
        }
    )


def checkpoint_at_boundary() -> tuple[
    TinyMaterialHeads, torch.optim.AdamW, list[tuple[str, torch.Tensor]], list[dict[str, torch.Tensor]], dict, dict
]:
    random.seed(7)
    np.random.seed(8)
    model, optimizer, named = make_model(9)
    cache = make_cache(10)
    for global_step in range(1, 6):
        update(model, optimizer, cache, global_step)
    contract = make_contract()
    payload = backend._sf3d_make_checkpoint(
        contract=contract, global_optimizer_step=5, named_parameters=named, optimizer=optimizer,
        optimizer_progress=optimizer_progress(named, optimizer),
        cached_batches=cache,
    )
    return model, optimizer, named, cache, contract, payload


def resign(payload: dict) -> None:
    payload["integrity_sha256"] = backend._sf3d_checkpoint_integrity(
        {key: value for key, value in payload.items() if key != "integrity_sha256"}
    )


def test_fresh_process_restore_matches_the_next_update_exactly() -> None:
    source, source_optimizer, _source_named, source_cache, contract, payload = checkpoint_at_boundary()
    continuous = [
        update(source, source_optimizer, source_cache, global_step)
        for global_step in (6, 7)
    ]

    fresh, fresh_optimizer, fresh_named = make_model(99)
    checked, fresh_cache, restored_progress = backend._sf3d_restore_checkpoint(
        payload, contract, fresh_named, fresh_optimizer, cache_feature_spec(), torch
    )
    backend._sf3d_assert_restored_boundary(
        payload, contract, fresh_named, fresh_optimizer, restored_progress, fresh_cache, torch
    )
    assert checked["next"] == {"global_optimizer_step": 6, "data_cursor": 1}

    resumed = [
        update(fresh, fresh_optimizer, fresh_cache, global_step)
        for global_step in (6, 7)
    ]
    assert common.tree_sha256(continuous) == common.tree_sha256(resumed)


def test_external_checkpoint_file_round_trip_restores_the_next_update(tmp_path) -> None:
    source, source_optimizer, _source_named, source_cache, contract, payload = checkpoint_at_boundary()
    checkpoint = tmp_path / "checkpoint-3.pt"
    common.save_atomic(checkpoint, payload)
    loaded = backend._sf3d_load_checkpoint(checkpoint, torch)
    continuous = update(source, source_optimizer, source_cache, 6)

    fresh, fresh_optimizer, fresh_named = make_model(100)
    _checked, fresh_cache, _progress = backend._sf3d_restore_checkpoint(
        loaded, contract, fresh_named, fresh_optimizer, cache_feature_spec(), torch
    )
    assert common.tree_sha256(continuous) == common.tree_sha256(
        update(fresh, fresh_optimizer, fresh_cache, 6)
    )


@pytest.mark.parametrize("representation", ("transposed-head", "python-v2", "numpy-int64"))
def test_representation_changing_head_or_rng_is_rejected_before_apply(representation: str) -> None:
    _source, _source_optimizer, _source_named, _source_cache, contract, payload = checkpoint_at_boundary()
    candidate = copy.deepcopy(payload)
    if representation == "transposed-head":
        candidate["state"]["material_heads"]["albedo.weight"] = (
            candidate["state"]["material_heads"]["albedo.weight"].t()
        )
    elif representation == "python-v2":
        _version, keys, gaussian = candidate["rng"]["python"]
        candidate["rng"]["python"] = (
            2,
            tuple(value if value < (1 << 31) else value - (1 << 32) for value in keys),
            gaussian,
        )
    else:
        algorithm, keys, position, has_gauss, cached_gaussian = candidate["rng"]["numpy"]
        candidate["rng"]["numpy"] = (
            algorithm,
            keys.astype(np.int64),
            position,
            has_gauss,
            cached_gaussian,
        )
    resign(candidate)

    fresh, fresh_optimizer, fresh_named = make_model(100)
    fresh_cache = make_cache(101)
    before = fingerprint(fresh_named, fresh_optimizer, fresh_cache)
    with pytest.raises(backend.SF3DCheckpointValidationError, match="roundtrip hash mismatch"):
        backend._sf3d_restore_checkpoint(
            candidate, contract, fresh_named, fresh_optimizer, cache_feature_spec(), torch
        )
    assert fingerprint(fresh_named, fresh_optimizer, fresh_cache) == before


def test_generated_checkpoint_with_inactive_parameters_restores_active_placements_only() -> None:
    source, source_optimizer, source_named = make_model(111)
    source_cache = make_cache(112)
    progress = backend._sf3d_initial_optimizer_progress(source_named, source_optimizer)
    for global_step in range(1, 6):
        update_albedo_only(source, source_optimizer, source_cache, global_step)
        progress = backend._sf3d_advance_optimizer_progress(progress, source_named, source_optimizer)
    payload = backend._sf3d_make_checkpoint(
        contract=make_contract(),
        global_optimizer_step=5,
        named_parameters=source_named,
        optimizer=source_optimizer,
        optimizer_progress=progress,
        cached_batches=source_cache,
    )
    active_names = {name for name, count in progress.items() if count > 0}
    assert active_names == {"albedo.weight", "albedo.bias"}
    assert len(payload["state"]["optimizer"]["state"]) == len(active_names)
    assert len(payload["state"]["optimizer_placements"]) == len(active_names)

    fresh, fresh_optimizer, fresh_named = make_model(113)
    checked, restored_cache, restored_progress = backend._sf3d_restore_checkpoint(
        payload, make_contract(), fresh_named, fresh_optimizer, cache_feature_spec(), torch
    )
    assert checked["next"] == {"global_optimizer_step": 6, "data_cursor": 1}
    assert restored_progress == progress
    backend._sf3d_assert_restored_boundary(
        payload, make_contract(), fresh_named, fresh_optimizer, restored_progress, restored_cache, torch
    )


def test_checkpoint_cursor_uses_global_step_and_preserves_warmup() -> None:
    metadata = backend._sf3d_checkpoint_metadata(make_contract(), 5)
    assert metadata["completed_measured_steps"] == 3
    assert metadata["next_global_optimizer_step"] == 6
    assert metadata["next_data_cursor"] == 1
    assert "checkpoint = save_checkpoint(step)" in inspect.getsource(backend.run_sf3d_training)


def test_imported_sf3d_modules_must_resolve_inside_the_requested_source_tree(tmp_path, monkeypatch) -> None:
    package = tmp_path / "source" / "sf3d"
    package.mkdir(parents=True)
    system = package / "system.py"
    system.write_text("class SF3D: pass\n", encoding="utf-8")
    monkeypatch.syspath_prepend(str(tmp_path / "source"))
    monkeypatch.delitem(sys.modules, "sf3d", raising=False)
    monkeypatch.delitem(sys.modules, "sf3d.system", raising=False)
    importlib.invalidate_caches()
    package_module = importlib.import_module("sf3d")
    importlib.import_module("sf3d.system")

    assert package_module.__file__ is None
    baseline = backend._sf3d_imported_package_sha256(tmp_path / "source")
    extra_namespace_location = package / "extra"
    extra_namespace_location.mkdir()
    monkeypatch.setattr(package_module, "__path__", [str(package), str(extra_namespace_location)])
    assert backend._sf3d_imported_package_sha256(tmp_path / "source") != baseline

    escaped = tmp_path / "escaped"
    escaped.mkdir()
    monkeypatch.setattr(package_module, "__path__", [str(package), str(escaped)])
    with pytest.raises(RuntimeError, match="escapes"):
        backend._sf3d_imported_package_sha256(tmp_path / "source")


def test_resume_identity_pins_the_shared_helper_and_input_order(tmp_path) -> None:
    first = tmp_path / "first.png"
    second = tmp_path / "second.png"
    first.write_bytes(b"first")
    second.write_bytes(b"second")
    assert backend._sf3d_paths_sha256([first, second], include_paths=False) != backend._sf3d_paths_sha256(
        [second, first], include_paths=False
    )
    assert '"resume_common": _sf3d_source_sha256(resume_common, "shared resume helper")' in inspect.getsource(
        backend._sf3d_resume_identity
    )


def test_saved_cache_replaces_changed_regenerated_features_before_the_next_update() -> None:
    source, source_optimizer, _source_named, source_cache, contract, payload = checkpoint_at_boundary()
    continuous = update(source, source_optimizer, source_cache, 6)
    regenerated = make_cache(10, triplane_offset=100.0)
    regenerated_before = cache_fingerprint(regenerated)
    saved_cache = cache_fingerprint(payload["state"]["cached_batches"])
    assert regenerated_before != saved_cache

    wrong, wrong_optimizer, wrong_named = make_model(102)
    backend._sf3d_restore_checkpoint(
        payload, contract, wrong_named, wrong_optimizer, cache_feature_spec(), torch
    )
    wrong_update = update(wrong, wrong_optimizer, regenerated, 6)

    fresh, fresh_optimizer, fresh_named = make_model(102)
    _checked, resumed_cache, _progress = backend._sf3d_restore_checkpoint(
        payload, contract, fresh_named, fresh_optimizer, cache_feature_spec(), torch
    )

    assert cache_fingerprint(resumed_cache) == saved_cache
    assert common.tree_sha256(wrong_update) != common.tree_sha256(continuous)
    assert common.tree_sha256(continuous) == common.tree_sha256(
        update(fresh, fresh_optimizer, resumed_cache, 6)
    )


def test_cache_size_limit_fails_closed_before_mutating_live_state(monkeypatch) -> None:
    _source, _source_optimizer, _source_named, _source_cache, contract, payload = checkpoint_at_boundary()
    fresh, fresh_optimizer, fresh_named = make_model(103)
    fresh_cache = make_cache(104)
    before = fingerprint(fresh_named, fresh_optimizer, fresh_cache)
    original_limit = backend._SF3D_MAX_CHECKPOINT_CACHE_BYTES
    monkeypatch.setattr(backend, "_SF3D_MAX_CHECKPOINT_CACHE_BYTES", 1)

    with pytest.raises(backend.SF3DCheckpointValidationError, match="size limit"):
        backend._sf3d_restore_checkpoint(
            payload, contract, fresh_named, fresh_optimizer, cache_feature_spec(), torch
        )

    monkeypatch.setattr(backend, "_SF3D_MAX_CHECKPOINT_CACHE_BYTES", original_limit)
    assert fingerprint(fresh_named, fresh_optimizer, fresh_cache) == before


@pytest.mark.parametrize("triplane_dtype,image_dtype", [
    (torch.float32, torch.float32),
    (torch.float32, torch.bfloat16),
    (torch.bfloat16, torch.float32),
    (torch.bfloat16, torch.bfloat16),
])
def test_supported_feature_dtype_combinations_restore(
    triplane_dtype: torch.dtype, image_dtype: torch.dtype,
) -> None:
    _source, _source_optimizer, _source_named, _source_cache, contract, payload = checkpoint_at_boundary()
    candidate = copy.deepcopy(payload)
    for batch in candidate["state"]["cached_batches"]:
        batch["triplane_features"] = batch["triplane_features"].to(triplane_dtype)
        batch["image_features"] = batch["image_features"].to(image_dtype)
    resign(candidate)

    fresh, fresh_optimizer, fresh_named = make_model(103)
    _checked, restored, _progress = backend._sf3d_restore_checkpoint(
        candidate, contract, fresh_named, fresh_optimizer, cache_feature_spec(), torch
    )
    assert [batch["triplane_features"].dtype for batch in restored] == [triplane_dtype] * 2
    assert [batch["image_features"].dtype for batch in restored] == [image_dtype] * 2


def test_external_completed_checkpoint_is_rejected_before_apply_but_internal_recovery_is_allowed() -> None:
    source, source_optimizer, source_named, source_cache, contract, _payload = checkpoint_at_boundary()
    for global_step in range(6, 11):
        update(source, source_optimizer, source_cache, global_step)
    completed = backend._sf3d_make_checkpoint(
        contract=contract,
        global_optimizer_step=10,
        named_parameters=source_named,
        optimizer=source_optimizer,
        optimizer_progress=optimizer_progress(source_named, source_optimizer),
        cached_batches=source_cache,
    )
    continuous = update(source, source_optimizer, source_cache, 11)

    external, external_optimizer, external_named = make_model(104)
    external_cache = make_cache(105)
    before = fingerprint(external_named, external_optimizer, external_cache)
    with pytest.raises(backend.SF3DCheckpointValidationError, match="already completed"):
        backend._sf3d_restore_checkpoint(
            completed, contract, external_named, external_optimizer, cache_feature_spec(), torch
        )
    assert fingerprint(external_named, external_optimizer, external_cache) == before

    internal, internal_optimizer, internal_named = make_model(106)
    _checked, restored_cache, _progress = backend._sf3d_restore_checkpoint(
        completed, contract, internal_named, internal_optimizer, cache_feature_spec(), torch,
        completion_policy="internal",
    )
    assert common.tree_sha256(continuous) == common.tree_sha256(
        update(internal, internal_optimizer, restored_cache, 11)
    )


def test_unexpected_apply_failure_is_fatal_only_after_preflight(monkeypatch) -> None:
    _source, _source_optimizer, _source_named, _source_cache, contract, payload = checkpoint_at_boundary()
    fresh, fresh_optimizer, fresh_named = make_model(107)

    def fail_load_state_dict(_state: dict) -> None:
        raise RuntimeError("injected live apply failure")

    monkeypatch.setattr(fresh_optimizer, "load_state_dict", fail_load_state_dict)
    with pytest.raises(backend.SF3DResumeApplyFatal, match="terminate this worker"):
        backend._sf3d_restore_checkpoint(
            payload, contract, fresh_named, fresh_optimizer, cache_feature_spec(), torch
        )


def test_final_boundary_failure_is_fatal_after_live_apply(monkeypatch) -> None:
    _source, _source_optimizer, _source_named, _source_cache, contract, payload = checkpoint_at_boundary()
    fresh, fresh_optimizer, fresh_named = make_model(114)

    def fail_boundary(*_args: object, **_kwargs: object) -> None:
        raise backend.SF3DCheckpointValidationError("injected restored boundary mismatch")

    monkeypatch.setattr(backend, "_sf3d_assert_restored_boundary", fail_boundary)
    with pytest.raises(backend.SF3DResumeApplyFatal, match="terminate this worker"):
        backend._sf3d_restore_checkpoint(
            payload, contract, fresh_named, fresh_optimizer, cache_feature_spec(), torch
        )


def test_optimizer_ids_and_placement_keys_are_canonical_before_apply() -> None:
    _source, _source_optimizer, _source_named, _source_cache, contract, payload = checkpoint_at_boundary()
    variants: list[tuple[str, callable]] = [
        (
            "group-id-order",
            lambda candidate: candidate["state"]["optimizer"]["param_groups"][0]["params"].reverse(),
        ),
        (
            "slot-bool-id",
            lambda candidate: candidate["state"]["optimizer"]["state"].__setitem__(
                False, candidate["state"]["optimizer"]["state"].pop(0)
            ),
        ),
        (
            "placement-bool-id",
            lambda candidate: candidate["state"]["optimizer_placements"].__setitem__(
                False, candidate["state"]["optimizer_placements"].pop(0)
            ),
        ),
        (
            "slot-int-key",
            lambda candidate: candidate["state"]["optimizer"]["state"][0].__setitem__(
                0, candidate["state"]["optimizer"]["state"][0].pop("step")
            ),
        ),
        (
            "placement-int-key",
            lambda candidate: candidate["state"]["optimizer_placements"][0].__setitem__(
                0, candidate["state"]["optimizer_placements"][0].pop("step")
            ),
        ),
        (
            "progress-bool",
            lambda candidate: candidate["state"]["optimizer_progress"].__setitem__(
                next(iter(candidate["state"]["optimizer_progress"])), True
            ),
        ),
    ]
    for _name, mutate in variants:
        candidate = copy.deepcopy(payload)
        mutate(candidate)
        try:
            resign(candidate)
        except backend.SF3DCheckpointValidationError:
            # Non-exact bool keys cannot be represented by the canonical hash.
            pass
        fresh, fresh_optimizer, fresh_named = make_model(107)
        fresh_cache = make_cache(108)
        before = fingerprint(fresh_named, fresh_optimizer, fresh_cache)
        with pytest.raises(backend.SF3DCheckpointValidationError):
            backend._sf3d_restore_checkpoint(
                candidate, contract, fresh_named, fresh_optimizer, cache_feature_spec(), torch
            )
        assert fingerprint(fresh_named, fresh_optimizer, fresh_cache) == before


class _DictSubclass(dict):
    pass


class _ListSubclass(list):
    pass


class _TupleSubclass(tuple):
    pass


def _set_path(candidate: dict, path: tuple[object, ...], value: object) -> None:
    parent: object = candidate
    for key in path[:-1]:
        parent = parent[key]  # type: ignore[index]
    parent[path[-1]] = value  # type: ignore[index]


_MALFORMED_PATHS = (
    ("metadata",),
    ("state",),
    ("rng",),
    ("integrity_sha256",),
    ("metadata", "contract"),
    ("metadata", "contract", "identity"),
    ("state", "material_heads"),
    ("state", "material_heads", "albedo.weight"),
    ("state", "optimizer"),
    ("state", "optimizer", "state"),
    ("state", "optimizer", "state", 0),
    ("state", "optimizer_placements"),
    ("state", "optimizer_placements", 0),
    ("state", "optimizer_parameter_names"),
    ("state", "optimizer_parameter_names", 0),
    ("state", "optimizer_progress"),
    ("state", "cached_batches"),
    ("state", "cached_batches", 0),
    ("state", "cached_batches", 0, "triplane_features"),
    ("state", "cached_batches", 1, "image_features"),
)


def _malformed_value(kind: str) -> object:
    if kind == "object":
        return object()
    if kind == "dict":
        return _DictSubclass()
    if kind == "list":
        return _ListSubclass()
    if kind == "tuple":
        return _TupleSubclass()
    if kind == "parameter":
        return torch.nn.Parameter(torch.zeros(1), requires_grad=False)
    if kind == "object-array":
        return np.array([object()], dtype=object)
    raise AssertionError(kind)


@pytest.mark.parametrize("path", _MALFORMED_PATHS, ids=lambda path: "-".join(map(str, path)))
@pytest.mark.parametrize("kind", ("object", "dict", "list", "tuple", "parameter", "object-array"))
def test_canonical_tree_gate_rejects_120_malformed_values_before_apply(
    path: tuple[object, ...], kind: str,
) -> None:
    _source, _source_optimizer, _source_named, _source_cache, contract, payload = checkpoint_at_boundary()
    candidate = copy.deepcopy(payload)
    _set_path(candidate, path, _malformed_value(kind))
    fresh, fresh_optimizer, fresh_named = make_model(109)
    fresh_cache = make_cache(110)
    before = fingerprint(fresh_named, fresh_optimizer, fresh_cache)
    with pytest.raises(backend.SF3DCheckpointValidationError):
        backend._sf3d_restore_checkpoint(
            candidate, contract, fresh_named, fresh_optimizer, cache_feature_spec(), torch
        )
    assert fingerprint(fresh_named, fresh_optimizer, fresh_cache) == before


@pytest.mark.parametrize("corruption", [
    "identity", "config", "inputs", "cursor", "optimizer", "optimizer_names", "optimizer_impl",
    "optimizer_progress", "optimizer_step_bool", "cache_second_width", "cache_triplane_dtype",
    "cache_image_dtype", "legacy",
])
def test_invalid_checkpoint_fails_closed_before_model_optimizer_or_rng_mutation(corruption: str) -> None:
    _source, _source_optimizer, _source_named, _source_cache, contract, payload = checkpoint_at_boundary()
    candidate = copy.deepcopy(payload)
    if corruption == "identity":
        candidate["metadata"]["contract"]["identity"]["weights"] = "d" * 64
        resign(candidate)
    elif corruption == "config":
        candidate["metadata"]["contract"]["config_sha256"] = "d" * 64
        resign(candidate)
    elif corruption == "inputs":
        candidate["metadata"]["contract"]["input_sha256"] = "d" * 64
        resign(candidate)
    elif corruption == "cursor":
        candidate["metadata"]["next_data_cursor"] = 0
        resign(candidate)
    elif corruption == "optimizer":
        slots = next(iter(candidate["state"]["optimizer"]["state"].values()))
        del slots["exp_avg"]
        resign(candidate)
    elif corruption == "optimizer_names":
        candidate["state"]["optimizer_parameter_names"][0].reverse()
        resign(candidate)
    elif corruption == "optimizer_impl":
        candidate["state"]["optimizer_implementation"]["torch_version"] = "other"
        resign(candidate)
    elif corruption == "optimizer_progress":
        name = next(iter(candidate["state"]["optimizer_progress"]))
        candidate["state"]["optimizer_progress"][name] += 1
        resign(candidate)
    elif corruption == "optimizer_step_bool":
        slots = next(iter(candidate["state"]["optimizer"]["state"].values()))
        slots["step"] = torch.tensor(True)
        resign(candidate)
    elif corruption == "cache_second_width":
        candidate["state"]["cached_batches"][1]["triplane_features"] = torch.zeros(4, 4)
        resign(candidate)
    elif corruption == "cache_triplane_dtype":
        candidate["state"]["cached_batches"][1]["triplane_features"] = (
            candidate["state"]["cached_batches"][1]["triplane_features"].to(torch.float64)
        )
        resign(candidate)
    elif corruption == "cache_image_dtype":
        candidate["state"]["cached_batches"][1]["image_features"] = (
            candidate["state"]["cached_batches"][1]["image_features"].to(torch.float64)
        )
        resign(candidate)
    else:
        candidate = {"step": 5, "material_heads": payload["state"]["material_heads"]}

    fresh, fresh_optimizer, fresh_named = make_model(101)
    fresh_cache = make_cache(103)
    before = fingerprint(fresh_named, fresh_optimizer, fresh_cache)
    with pytest.raises(backend.SF3DCheckpointValidationError):
        backend._sf3d_restore_checkpoint(
            candidate, contract, fresh_named, fresh_optimizer, cache_feature_spec(), torch
        )
    assert fingerprint(fresh_named, fresh_optimizer, fresh_cache) == before


def test_resume_preflight_precedes_output_mutation() -> None:
    source = inspect.getsource(backend.run_sf3d_training)
    assert source.index("if resume_path is not None:") < source.index("output_dir.mkdir(parents=True, exist_ok=True)")
    assert source.index("if resume_path is not None:") < source.index("images = [Image.open")
    assert source.index("if resume_path is not None:") < source.index("batch = _prepare_batch")
    assert "resume_from_checkpoint must be a non-empty external checkpoint path" in inspect.getsource(
        backend._sf3d_resume_checkpoint_path
    )
