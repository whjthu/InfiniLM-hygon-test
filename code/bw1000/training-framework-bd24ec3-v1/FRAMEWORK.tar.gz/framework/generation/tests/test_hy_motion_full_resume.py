from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import textwrap
from typing import Any

import numpy as np
import pytest
import torch
import yaml

from genmlu.backends import hy_motion_training as training


class TinyFullFlow(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.linear = torch.nn.Linear(3, 2)
        self.register_buffer("scale", torch.tensor(0.75))

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        return self.linear(value) * self.scale


def make_model(seed: int) -> tuple[TinyFullFlow, torch.optim.AdamW]:
    torch.manual_seed(seed)
    model = TinyFullFlow()
    return model, torch.optim.AdamW(model.parameters(), lr=2e-3, weight_decay=0.01)


def contract(total_global_steps: int = 10) -> dict[str, Any]:
    return training._build_hy_motion_full_resume_contract(
        identity={key: "a" * 64 for key in training.HY_MOTION_FULL_RESUME_IDENTITY_FIELDS},
        seed=1701,
        total_global_steps=total_global_steps,
        sample_count=3,
        shuffle_by_epoch=True,
        device_ids=[],
    )


def train_step(
    model: TinyFullFlow,
    optimizer: torch.optim.AdamW,
    progress: dict[str, int],
    global_step: int,
) -> tuple[dict[str, int], dict[str, object]]:
    samples = [
        {"sample_id": "a", "value": 0.25},
        {"sample_id": "b", "value": 0.5},
        {"sample_id": "c", "value": 0.75},
    ]
    sample, epoch, cursor = training._hy_motion_sample_for_step(
        samples, 1701, global_step, True
    )
    optimizer.zero_grad(set_to_none=True)
    input_value = torch.randn(2, 3)
    target = torch.tensor(
        float(sample["value"]) + random.random() + float(np.random.random())
    )
    loss = (model(input_value).mean() - target).square()
    loss.backward()
    optimizer.step()
    progress = training.hy_resume.advance_optimizer_progress(progress, model, optimizer)
    return progress, {
        "sample_id": sample["sample_id"],
        "epoch": epoch,
        "cursor": cursor,
        "loss": loss.detach().clone(),
        "state": training.hy_resume.cpu_tree(optimizer.state_dict()),
        "model": training.hy_resume.cpu_tree(model.state_dict()),
    }


def resign(payload: dict[str, object]) -> None:
    payload["integrity_sha256"] = training.hy_resume.tree_sha256(
        {key: value for key, value in payload.items() if key != "integrity_sha256"}
    )


def test_fresh_object_restore_matches_continuation_and_data_cursor() -> None:
    random.seed(1701)
    np.random.seed(1701)
    model, optimizer = make_model(1701)
    progress = training.hy_resume.initial_optimizer_progress(model, optimizer)
    for global_step in range(1, 5):
        progress, _ = train_step(model, optimizer, progress, global_step)
    payload = training._make_hy_motion_full_resume_payload(
        contract=contract(),
        global_step=4,
        model=model,
        optimizer=optimizer,
        optimizer_progress=progress,
    )
    continuous_progress, continuous = train_step(model, optimizer, progress, 5)

    fresh, fresh_optimizer = make_model(999)
    restored_progress, checked = training._restore_hy_motion_full_resume_payload(
        payload, contract(), fresh, fresh_optimizer
    )
    assert checked["metadata"]["next_global_step"] == 5
    assert checked["metadata"]["next_data_epoch"] == 1
    assert checked["metadata"]["next_data_cursor"] == 1
    training._assert_hy_motion_full_restored_boundary(
        payload, contract(), fresh, fresh_optimizer, restored_progress
    )
    resumed_progress, resumed = train_step(fresh, fresh_optimizer, restored_progress, 5)

    assert continuous["sample_id"] == resumed["sample_id"]
    assert continuous["epoch"] == resumed["epoch"] == 1
    assert continuous["cursor"] == resumed["cursor"] == 1
    assert training.hy_resume.tree_sha256(continuous) == training.hy_resume.tree_sha256(resumed)
    assert continuous_progress == resumed_progress


def test_filesystem_checkpoint_roundtrip_in_fresh_interpreter(tmp_path: Path) -> None:
    random.seed(1701)
    np.random.seed(1701)
    model, optimizer = make_model(1701)
    progress = training.hy_resume.initial_optimizer_progress(model, optimizer)
    for global_step in range(1, 5):
        progress, _ = train_step(model, optimizer, progress, global_step)
    checkpoint = tmp_path / "checkpoint-4" / "state.pt"
    payload = training._make_hy_motion_full_resume_payload(
        contract=contract(),
        global_step=4,
        model=model,
        optimizer=optimizer,
        optimizer_progress=progress,
    )
    training.hy_resume.save_atomic(checkpoint, payload)
    loaded = training.hy_resume.load_checkpoint(checkpoint)
    assert loaded["metadata"] == payload["metadata"]

    continuous_progress, continuous = train_step(model, optimizer, progress, 5)
    expected_digest = training.hy_resume.tree_sha256({
        "progress": continuous_progress,
        "record": continuous,
    })
    program = textwrap.dedent(
        """
        import json
        from pathlib import Path
        import random
        import sys

        import numpy as np
        import torch

        from genmlu.backends import hy_motion_training as training

        class TinyFullFlow(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.linear = torch.nn.Linear(3, 2)
                self.register_buffer("scale", torch.tensor(0.75))

            def forward(self, value):
                return self.linear(value) * self.scale

        def make_model(seed):
            torch.manual_seed(seed)
            model = TinyFullFlow()
            return model, torch.optim.AdamW(model.parameters(), lr=2e-3, weight_decay=0.01)

        def contract():
            return training._build_hy_motion_full_resume_contract(
                identity={key: "a" * 64 for key in training.HY_MOTION_FULL_RESUME_IDENTITY_FIELDS},
                seed=1701,
                total_global_steps=10,
                sample_count=3,
                shuffle_by_epoch=True,
                device_ids=[],
            )

        random.seed(999)
        np.random.seed(999)
        model, optimizer = make_model(999)
        payload = training.hy_resume.load_checkpoint(Path(sys.argv[1]))
        progress, checked = training._restore_hy_motion_full_resume_payload(
            payload, contract(), model, optimizer
        )
        samples = [
            {"sample_id": "a", "value": 0.25},
            {"sample_id": "b", "value": 0.5},
            {"sample_id": "c", "value": 0.75},
        ]
        sample, epoch, cursor = training._hy_motion_sample_for_step(samples, 1701, 5, True)
        optimizer.zero_grad(set_to_none=True)
        input_value = torch.randn(2, 3)
        target = torch.tensor(float(sample["value"]) + random.random() + float(np.random.random()))
        loss = (model(input_value).mean() - target).square()
        loss.backward()
        optimizer.step()
        progress = training.hy_resume.advance_optimizer_progress(progress, model, optimizer)
        record = {
            "sample_id": sample["sample_id"],
            "epoch": epoch,
            "cursor": cursor,
            "loss": loss.detach().clone(),
            "state": training.hy_resume.cpu_tree(optimizer.state_dict()),
            "model": training.hy_resume.cpu_tree(model.state_dict()),
        }
        print(json.dumps({
            "digest": training.hy_resume.tree_sha256({"progress": progress, "record": record}),
            "next_global_step": checked["metadata"]["next_global_step"],
            "next_data_epoch": checked["metadata"]["next_data_epoch"],
            "next_data_cursor": checked["metadata"]["next_data_cursor"],
        }, sort_keys=True))
        """
    )
    environment = dict(os.environ)
    source_root = Path(__file__).parents[1] / "src"
    environment["PYTHONPATH"] = str(source_root) + os.pathsep + environment.get("PYTHONPATH", "")
    completed = subprocess.run(
        [sys.executable, "-c", program, str(checkpoint)],
        check=True,
        capture_output=True,
        text=True,
        env=environment,
    )
    observed = json.loads(completed.stdout)
    assert observed == {
        "digest": expected_digest,
        "next_global_step": 5,
        "next_data_epoch": 1,
        "next_data_cursor": 1,
    }


def test_full_training_rejects_multicard_before_mlu_runtime(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    weights = tmp_path / "weights"
    source = tmp_path / "source"
    output = tmp_path / "output"
    weights.mkdir()
    source.mkdir()

    def forbidden_runtime() -> None:
        pytest.fail("multi-card Full training reached the MLU runtime")

    monkeypatch.setattr(training, "require_mlu", forbidden_runtime)
    with pytest.raises(RuntimeError, match="requires exactly one card"):
        training.run_hy_motion_training(
            weights,
            {"training_cache": "unused.pt", "cards": [0, 1]},
            output,
            source,
        )
    assert not output.exists()


@pytest.mark.parametrize("corruption", ["identity", "schedule", "cursor", "legacy"])
def test_invalid_full_checkpoint_is_rejected_before_mutation(corruption: str) -> None:
    random.seed(1701)
    np.random.seed(1701)
    model, optimizer = make_model(1701)
    progress = training.hy_resume.initial_optimizer_progress(model, optimizer)
    for global_step in range(1, 3):
        progress, _ = train_step(model, optimizer, progress, global_step)
    payload = training._make_hy_motion_full_resume_payload(
        contract=contract(),
        global_step=2,
        model=model,
        optimizer=optimizer,
        optimizer_progress=progress,
    )
    candidate: dict[str, Any] = copy.deepcopy(payload)
    expected_contract = contract()
    if corruption == "identity":
        expected_contract["identity"] = dict(expected_contract["identity"])
        expected_contract["identity"]["data"] = "b" * 64
    elif corruption == "schedule":
        expected_contract = contract(total_global_steps=11)
    elif corruption == "cursor":
        candidate["metadata"]["next_data_cursor"] = 0
        resign(candidate)
    else:
        candidate = {"step": 2, "adapter": payload["state"]["trainable"]}

    fresh, fresh_optimizer = make_model(999)
    before = training.hy_resume.tree_sha256({
        "model": training.hy_resume.cpu_tree(fresh.state_dict()),
        "optimizer": training.hy_resume.cpu_tree(fresh_optimizer.state_dict()),
        "rng": training.hy_resume.capture_rng([]),
    })
    with pytest.raises(training.hy_resume.CheckpointValidationError):
        training._restore_hy_motion_full_resume_payload(
            candidate, expected_contract, fresh, fresh_optimizer
        )
    after = training.hy_resume.tree_sha256({
        "model": training.hy_resume.cpu_tree(fresh.state_dict()),
        "optimizer": training.hy_resume.cpu_tree(fresh_optimizer.state_dict()),
        "rng": training.hy_resume.capture_rng([]),
    })
    assert before == after
    assert not getattr(fresh, "_hy_motion_full_resume_poisoned", False)


def test_hy_motion_training_config_declares_optional_external_resume() -> None:
    config_path = Path(__file__).parents[1] / "configs" / "hy-motion-training.yaml"
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    assert config["resume_from_checkpoint"] is None
