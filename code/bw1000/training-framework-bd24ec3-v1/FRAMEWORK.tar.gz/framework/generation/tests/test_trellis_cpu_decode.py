from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import subprocess
from types import SimpleNamespace
import sys

import numpy as np
import pytest
import torch

from genmlu import trellis_cpu_decode as decoder
from genmlu.backends import trellis2_generation as backend
from genmlu.manifest import merge_backend_result, new_manifest, sha256_path
from genmlu.trellis_output_contract import LATENT_ONLY


def _write_latents(path: Path, coords: np.ndarray) -> str:
    count = len(coords)
    np.savez_compressed(
        path,
        coords=coords,
        shape_latent=np.zeros((count, 32), dtype=np.float32),
        texture_latent=np.ones((count, 32), dtype=np.float32),
    )
    return sha256_path(path)


def test_tensor_hash_accepts_scalar_storage() -> None:
    assert decoder._tensor_sha256(torch.tensor(3, dtype=torch.int64))
    assert decoder._tensor_sha256(torch.tensor(2, dtype=torch.bfloat16))


@pytest.mark.parametrize(
    ("coords", "message"),
    [
        (np.array([[0.0, 1.0, 2.0, 3.0]], dtype=np.float32), "integer before"),
        (np.array([[0, 1, 2, 3], [0, 1, 2, 3]], dtype=np.int32), "unique"),
        (np.array([[1, 1, 2, 3]], dtype=np.int32), "single-batch"),
        (np.array([[0, -1, 2, 3]], dtype=np.int32), "outside"),
        (np.array([[0, 8, 2, 3]], dtype=np.int32), "outside"),
        (np.array([[0, 2**32 + 1, 2, 3]], dtype=np.int64), "outside"),
    ],
)
def test_latent_coordinates_are_rejected_before_silent_cast_or_truncation(
    tmp_path: Path, coords: np.ndarray, message: str
) -> None:
    path = tmp_path / "latents.npz"
    digest = _write_latents(path, coords)
    with pytest.raises(RuntimeError, match=message):
        decoder._load_latents(path, digest, max_points=4, resolution=8)


def test_latent_point_bound_rejects_without_truncation(tmp_path: Path) -> None:
    path = tmp_path / "latents.npz"
    coords = np.array([[0, index, 0, 0] for index in range(3)], dtype=np.int32)
    digest = _write_latents(path, coords)
    with pytest.raises(RuntimeError, match="truncation is forbidden"):
        decoder._load_latents(path, digest, max_points=2, resolution=8)


def test_cpu_coordinate_lookup_keeps_order_and_rejects_invalid_neighbors() -> None:
    lookup = decoder.CPUCoordinateLookup()
    coords = torch.tensor([[0, 1, 0, 0], [0, 0, 0, 0]], dtype=torch.int32)
    lookup.hashmap_insert_3d_idx_as_val_cuda(None, None, coords, 2, 2, 2)
    queries = torch.tensor(
        [[0, 0, 0, 0], [0, 1, 0, 0], [0, -1, 0, 0], [1, 0, 0, 0]],
        dtype=torch.int32,
    )
    assert lookup.hashmap_lookup_3d_cuda(None, None, queries, 2, 2, 2).tolist() == [
        1,
        0,
        decoder.MISSING_COORDINATE,
        decoder.MISSING_COORDINATE,
    ]


def test_geometry_accepts_none_split_without_substitution(monkeypatch, tmp_path: Path) -> None:
    observed = []

    def converter(coords, dual_vertices, flags, split_weight, **kwargs):
        observed.append((split_weight, kwargs))
        return dual_vertices.clone(), torch.tensor([[0, 1, 2]], dtype=torch.int64)

    monkeypatch.setattr(decoder, "_load_official_geometry", lambda _root: converter)
    coordinates = torch.tensor([[0, 0, 0], [0, 0, 1], [0, 1, 1]], dtype=torch.int32)
    vertices, faces = decoder._geometry(
        tmp_path,
        coordinates,
        torch.full((3, 3), 0.5),
        torch.zeros((3, 3), dtype=torch.bool),
        None,
        resolution=4,
        max_points=8,
    )

    assert observed[0][0] is None
    assert observed[0][1]["train"] is False
    assert vertices.shape == (3, 3)
    assert faces.tolist() == [[0, 1, 2]]


def _valid_output(path: Path) -> None:
    np.savez_compressed(
        path,
        coords=np.array([[0, 1, 2, 3], [0, 2, 2, 3]], dtype=np.int32),
        shape_fields=np.zeros((2, 7), dtype=np.float32),
        material_attrs=np.ones((2, 6), dtype=np.float32),
        vertices=np.zeros((3, 3), dtype=np.float32),
        faces=np.array([[0, 1, 2]], dtype=np.int64),
    )


def _report(root: Path, input_path: Path, output_path: Path) -> dict[str, object]:
    stage = {
        "guided_coords_sha256": "a" * 64,
        "input_coords_sha256": "a" * 64,
        "raw_guide_sha256": "b" * 64,
        "output": {
            "channels": 4,
            "coords_sha256": "e" * 64,
            "dtype": "torch.float16",
            "features_sha256": "f" * 64,
            "rows": 2,
        },
    }
    weights_root = root.parent / "weights"
    decoder_record = lambda role, count: {
        "checkpoint_resolution": 256 if role == "shape" else None,
        "config_sha256": sha256_path(
            weights_root
            / "ckpts"
            / ("shape_dec_next_dc_f16c32_fp16.json" if role == "shape" else "tex_dec_next_dc_f16c32_fp16.json")
        ),
        "expected_weights_sha256": None,
        "precision_parameter_counts": {"fp16_torso": 1, "fp32_norm": 1, "fp32_head": 1},
        "requested_geometry_resolution": 8,
        "strict_key_count": count,
        "weights_sha256": "d" * 64,
        "output": {
            "channels": 7 if role == "shape" else 6,
            "coords_sha256": "e" * 64,
            "dtype": "torch.float32",
            "features_sha256": "f" * 64,
            "rows": 2,
        },
        "stages": [copy.deepcopy(stage) for _ in range(4)],
    }
    sidecar = Path(backend.__file__).resolve().parents[1] / "trellis_cpu_decode.py"
    return {
        "schema": "genmlu-trellis-cpu-decode-v1",
        "source_revision": backend.PINNED_TRELLIS2_REVISION,
        "source_clean": True,
        "source_sha256": {
            "decoder": sha256_path(root / "trellis2/models/sc_vaes/sparse_unet_vae.py"),
            "geometry": sha256_path(root / "o-voxel/o_voxel/convert/flexible_dual_grid.py"),
        },
        "sidecar_sha256": sha256_path(sidecar),
        "input": {"path": str(input_path.resolve()), "sha256": sha256_path(input_path)},
        "output": {
            "path": str(output_path.resolve()),
            "sha256": sha256_path(output_path),
            "keys": sorted(backend.CPU_DECODE_KEYS),
        },
        "decoders": {
            "shape": decoder_record("shape", 292),
            "material": decoder_record("material", 284),
        },
        "geometry": {"faces": 1, "vertices": 3},
        "runtime": {
            "device": "cpu",
            "peak_rss_bytes": 123,
            "threads": 4,
            "torch_device_backend_autoload": "0",
        },
        "timings": {
            "cpu_shape_decoder_load_seconds": 1.0,
            "cpu_shape_decoder_forward_seconds": 2.0,
            "cpu_material_decoder_load_seconds": 1.0,
            "cpu_material_decoder_forward_seconds": 2.0,
            "cpu_geometry_seconds": 0.5,
        },
    }


def _source_fixture(root: Path) -> None:
    decoder_path = root / "trellis2/models/sc_vaes/sparse_unet_vae.py"
    geometry_path = root / "o-voxel/o_voxel/convert/flexible_dual_grid.py"
    decoder_path.parent.mkdir(parents=True)
    geometry_path.parent.mkdir(parents=True)
    decoder_path.write_text("decoder\n", encoding="utf-8")
    geometry_path.write_text("geometry\n", encoding="utf-8")
    weights = root.parent / "weights" / "ckpts"
    weights.mkdir(parents=True)
    (weights / "shape_dec_next_dc_f16c32_fp16.json").write_text("{}\n", encoding="utf-8")
    (weights / "tex_dec_next_dc_f16c32_fp16.json").write_text("{}\n", encoding="utf-8")


def test_parent_revalidates_child_paths_hash_and_npz(tmp_path: Path) -> None:
    source = tmp_path / "source"
    output_dir = tmp_path / "output"
    output_dir.mkdir()
    _source_fixture(source)
    input_path = output_dir / "latents.npz"
    _write_latents(input_path, np.array([[0, 1, 2, 3]], dtype=np.int32))
    output_path = output_dir / "trellis2-decoded-fields-geometry.npz"
    _valid_output(output_path)
    report = _report(source, input_path, output_path)

    validated, counts = backend._validated_cpu_decode_report(
        report,
        input_path=input_path,
        input_sha256=sha256_path(input_path),
        output_path=output_path,
        output_dir=output_dir,
        source_root=source,
        weights_root=tmp_path / "weights",
        config={},
        max_points=10,
        resolution=8,
    )

    assert validated is report
    assert counts == {"cpu_decoded_points": 2, "cpu_geometry_vertices": 3, "cpu_geometry_faces": 1}
    escaped = copy.deepcopy(report)
    escaped["output"]["path"] = str((tmp_path / "escaped.npz").resolve())
    with pytest.raises(RuntimeError, match="path or fields"):
        backend._validated_cpu_decode_report(
            escaped,
            input_path=input_path,
            input_sha256=sha256_path(input_path),
            output_path=output_path,
            output_dir=output_dir,
            source_root=source,
            weights_root=tmp_path / "weights",
            config={},
            max_points=10,
            resolution=8,
        )


def test_launcher_forces_cpu_child_and_uses_explicit_clean_source(tmp_path: Path, monkeypatch) -> None:
    output_dir = tmp_path / "output"
    output_dir.mkdir()
    input_path = output_dir / "latents.npz"
    input_path.write_bytes(b"latents")
    source = tmp_path / "clean-source"
    observed = {}
    report = {"placeholder": True}

    def fake_run(command, **kwargs):
        observed["command"] = command
        observed["kwargs"] = kwargs
        return SimpleNamespace(
            returncode=0,
            stdout=backend.CPU_DECODE_RESULT_PREFIX + json.dumps(report) + "\n",
            stderr="",
        )

    monkeypatch.setattr(backend.subprocess, "run", fake_run)
    monkeypatch.setattr(
        backend,
        "_validated_cpu_decode_report",
        lambda value, **_kwargs: (value, {"cpu_decoded_points": 1}),
    )

    path, returned, counts = backend._run_cpu_decoder_sidecar(
        input_path=input_path,
        output_dir=output_dir,
        source_root=source,
        weights=tmp_path / "weights",
        config={"cpu_decode_max_points": 9, "cpu_decode_resolution": 512},
    )

    assert path == output_dir / "trellis2-decoded-fields-geometry.npz"
    assert returned == report and counts == {"cpu_decoded_points": 1}
    assert observed["command"][1:3] == ["-m", "genmlu.trellis_cpu_decode"]
    assert observed["command"][observed["command"].index("--source-root") + 1] == str(source)
    assert observed["command"][observed["command"].index("--resolution") + 1] == "512"
    assert observed["kwargs"]["env"]["TORCH_DEVICE_BACKEND_AUTOLOAD"] == "0"
    assert observed["kwargs"]["env"]["MLU_VISIBLE_DEVICES"] == ""


def test_manifest_accepts_verified_cpu_fields_without_claiming_formal_mesh(tmp_path: Path) -> None:
    latent = tmp_path / "latents.npz"
    decoded = tmp_path / "decoded.npz"
    latent.write_bytes(b"latent")
    decoded.write_bytes(b"decoded")
    config = {
        "output_contract": LATENT_ONLY,
        "decode_cpu_fields": True,
        "cpu_decode_resolution": 512,
    }
    capability = {
        "schema": "trellis-output-capability-v1",
        "requested": LATENT_ONLY,
        "produced": LATENT_ONLY,
        "full_mesh_available": False,
        "formal_mesh_available": False,
        "textured_glb_available": False,
        "formal_output_contract": False,
        "primary_artifact": {"path": str(latent), "sha256": sha256_path(latent), "role": "latent"},
        "shape_decoder_executed": True,
        "texture_decoder_executed": True,
        "decoded_fields_artifact": {
            "path": str(decoded),
            "sha256": sha256_path(decoded),
            "role": "decoded_fields_and_geometry",
        },
        "diagnostic_preview": False,
    }
    result = {
        "artifacts": [
            {"path": str(latent), "sha256": sha256_path(latent)},
            {"path": str(decoded), "sha256": sha256_path(decoded)},
        ],
        "logs": [],
        "metrics": {},
        "stage_timings": {},
        "checks": {"formal_output_contract": False},
        "output_capability": capability,
        "cpu_decoder_source_identity": {
            "clean": True,
            "revision": decoder.PINNED_TRELLIS2_REVISION,
            "source_sha256": {"decoder": "a" * 64, "geometry": "b" * 64},
        },
    }
    manifest = new_manifest("infer", "trellis-2-4b", config, {})

    merge_backend_result(manifest, result)

    assert manifest["output_capability"] == capability
    assert manifest["provenance"]["cpu_decoder_source_identity"]["clean"] is True


def test_pinned_official_decoder_loader_contract_when_source_is_available() -> None:
    source_root = os.environ.get("TRELLIS2_CLEAN_SOURCE_ROOT")
    if not source_root:
        pytest.skip("set TRELLIS2_CLEAN_SOURCE_ROOT to the clean pinned checkout")
    code = r'''
import os
import sys
from pathlib import Path

import torch
from genmlu import trellis_cpu_decode as decoder

root = Path(sys.argv[1])
decoder._verify_source(root)
Decoder, _sp, path = decoder._load_official_decoder(root)
model = Decoder(
    out_channels=2,
    model_channels=[4],
    latent_channels=2,
    num_blocks=[1],
    block_type=["SparseConvNeXtBlock3d"],
    up_block_type=[],
    block_args=[{"use_checkpoint": False}],
    use_fp16=True,
    pred_subdiv=False,
).cpu().eval()
assert Decoder.__module__ == "trellis2.models.sc_vaes.sparse_unet_vae"
assert path.resolve() == (root / "trellis2/models/sc_vaes/sparse_unet_vae.py").resolve()
assert model.from_latent.weight.device.type == "cpu"
assert model.from_latent.weight.dtype == torch.float32
assert model.output_layer.weight.dtype == torch.float32
assert model.blocks[0][0].conv.weight.dtype == torch.float16
assert model.blocks[0][0].mlp[0].weight.dtype == torch.float16
assert model.blocks[0][0].norm.weight.dtype == torch.float32
assert "trellis2.models.sc_vaes.fdg_vae" not in sys.modules
'''
    environment = dict(os.environ)
    environment["TORCH_DEVICE_BACKEND_AUTOLOAD"] = "0"
    completed = subprocess.run(
        [sys.executable, "-c", code, source_root],
        check=False,
        capture_output=True,
        text=True,
        env=environment,
    )
    assert completed.returncode == 0, completed.stderr


@pytest.mark.parametrize(
    ("axis", "coords"),
    [
        (0, [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]]),
        (1, [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]]),
        (2, [[0, 0, 0], [0, 1, 0], [1, 1, 0], [1, 0, 0]]),
    ],
)
@pytest.mark.parametrize("split_weight", [None, torch.tensor([[2.0], [1.0], [2.0], [1.0]])])
def test_pinned_official_geometry_all_axes_and_optional_split_when_source_is_available(
    axis: int, coords: list[list[int]], split_weight: torch.Tensor | None
) -> None:
    source_root = os.environ.get("TRELLIS2_CLEAN_SOURCE_ROOT")
    if not source_root:
        pytest.skip("set TRELLIS2_CLEAN_SOURCE_ROOT to the clean pinned checkout")
    coordinates = torch.tensor(coords, dtype=torch.int32)
    offsets = torch.full((4, 3), 0.5)
    flags = torch.zeros((4, 3), dtype=torch.bool)
    flags[0, axis] = True

    vertices, faces = decoder._geometry(
        Path(source_root),
        coordinates,
        offsets,
        flags,
        split_weight,
        resolution=4,
        max_points=16,
    )

    torch.testing.assert_close(vertices, (coordinates.float() + offsets) / 4 - 0.5, rtol=0, atol=0)
    assert faces.tolist() == [[0, 1, 2], [0, 2, 3]]
