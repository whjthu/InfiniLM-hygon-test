from __future__ import annotations

import json
import struct

import numpy as np
import pytest
from PIL import Image

from genmlu.backends.sf3d_reconstruction import _lossless_texture_image


def test_texture_pixels_are_preserved_and_marked_for_lossless_export() -> None:
    pixels = np.arange(96, dtype=np.uint8).reshape(4, 8, 3)
    image = _lossless_texture_image(pixels)
    assert image.format == "PNG"
    assert image.mode == "RGB"
    np.testing.assert_array_equal(np.asarray(image), pixels)


def test_embedded_glb_texture_matches_standalone_png(tmp_path) -> None:
    trimesh = pytest.importorskip("trimesh")
    pixels = np.arange(96, dtype=np.uint8).reshape(4, 8, 3)
    image = _lossless_texture_image(pixels)
    mesh = trimesh.Trimesh(
        vertices=np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0]], dtype=np.float32),
        faces=np.array([[0, 1, 2]], dtype=np.int64),
        visual=trimesh.visual.texture.TextureVisuals(
            uv=np.array([[0, 0], [1, 0], [0, 1]], dtype=np.float32),
            material=trimesh.visual.material.PBRMaterial(baseColorTexture=image),
        ),
        process=False,
    )
    glb = tmp_path / "mesh.glb"
    png = tmp_path / "mesh-texture.png"
    mesh.export(glb, include_normals=True)
    image.save(png, format="PNG")
    with glb.open("rb") as handle:
        magic, version, length, json_length, json_type = struct.unpack("<4sIIII", handle.read(20))
        assert (magic, version, length) == (b"glTF", 2, glb.stat().st_size)
        assert json_type == 0x4E4F534A
        document = json.loads(handle.read(json_length))
    assert document["images"][0]["mimeType"] == "image/png"
    restored = trimesh.load(glb, force="mesh", process=False)
    embedded = np.asarray(restored.visual.material.baseColorTexture.convert("RGB"))
    with Image.open(png) as standalone:
        np.testing.assert_array_equal(embedded, np.asarray(standalone.convert("RGB")))
    np.testing.assert_array_equal(embedded, pixels)
