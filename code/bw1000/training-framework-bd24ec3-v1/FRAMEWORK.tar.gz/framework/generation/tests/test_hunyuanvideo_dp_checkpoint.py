"""Actual pinned native Muon CPU state tests; not hardware qualification."""
from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import random
import sys
import tempfile
import unittest
from unittest import mock

try:
    import torch
except ImportError:
    torch = None

SOURCE_SHA = "11862efb0b26bf308d313e4e18c7fcc0dd6934a275c640862ad7769b0bdfaccd"


def actual_muon():
    path = os.environ.get("HUNYUANVIDEO_MUON_SOURCE")
    if not path:
        raise unittest.SkipTest("HUNYUANVIDEO_MUON_SOURCE is unavailable")
    source = Path(path)
    if hashlib.sha256(source.read_bytes()).hexdigest() != SOURCE_SHA:
        raise AssertionError("external native Muon fixture SHA mismatch")
    name = "hunyuan_native_muon_fixture"
    spec = importlib.util.spec_from_file_location(name, source)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def make_model(seed=123):
    torch.manual_seed(seed)

    class Tiny(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.matrix = torch.nn.Parameter(torch.randn(2, 2))
            self.cube = torch.nn.Parameter(torch.randn(2, 2, 2))
            self.unused_matrix = torch.nn.Parameter(torch.randn(2, 2))
            self.bias = torch.nn.Parameter(torch.randn(2))
            self.unused_bias = torch.nn.Parameter(torch.randn(2))
            self.register_buffer("constant", torch.ones(1))

    return Tiny()


def manual_step(model, optimizer, counts, value=0.1, all_used=False):
    optimizer.zero_grad(set_to_none=True)
    for name, p in model.named_parameters():
        if all_used or not name.startswith("unused"):
            p.grad = torch.full_like(p, value)
            counts[name] += 1
    optimizer.step()


@unittest.skipIf(torch is None, "CPU Torch is unavailable")
class NativeReplicatedCheckpointTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.muon = actual_muon()
        from genmlu import hunyuanvideo_distributed_checkpoint as checkpoint
        cls.cp = checkpoint

    def setUp(self):
        self.model = make_model()
        self.optimizer = self.muon.get_muon_optimizer(self.model)
        self.contract = self.cp.build_contract(identity={key: "a" * 64 for key in self.cp.native.IDENTITY_FIELDS},
            model=self.model, optimizer=self.optimizer, seed=42, warmup_steps=0, max_steps=21, devices=["cpu", "cpu"])
        self.counts = self.cp.native.common.initial_optimizer_progress(self.model, self.optimizer)
        manual_step(self.model, self.optimizer, self.counts)
        self.payloads = [self.cp.capture_rank(contract=self.contract, model=self.model, optimizer=self.optimizer,
                                             rank=rank, step=1, gradient_counts=self.counts) for rank in (0, 1)]

    def resign(self, payload):
        payload["integrity_sha256"] = self.cp.native.tree_sha256(
            {key: value for key, value in payload.items() if key != "integrity_sha256"})

    def assert_rejected_without_mutation(self, mutate):
        payload = copy.deepcopy(self.payloads[0])
        mutate(payload)
        self.resign(payload)
        before = self.cp.native.tree_sha256(self.cp.native.capture_model_state(self.model, self.optimizer))
        with self.assertRaises(self.cp.Error):
            self.cp.validate_rank(payload, self.contract, self.model, self.optimizer, 0, native_rng=False)
        self.assertEqual(before, self.cp.native.tree_sha256(self.cp.native.capture_model_state(self.model, self.optimizer)))

    def test_every_muon_state_including_unused_and_flattened(self):
        slots = self.payloads[0]["state"]["optimizer"]["state"]
        names = self.payloads[0]["state"]["optimizer_parameter_names"][0]
        ids = self.payloads[0]["state"]["optimizer"]["param_groups"][0]["params"]
        by_name = dict(zip(names, ids))
        self.assertEqual(slots[by_name["cube"]]["momentum_buffer"].shape, (2, 4))
        self.assertEqual(slots[by_name["cube"]]["momentum_buffer"].dtype, torch.float32)
        self.assertTrue(torch.equal(slots[by_name["unused_matrix"]]["momentum_buffer"], torch.zeros(2, 2)))
        self.assertEqual(slots[by_name["unused_bias"]], {"use_muon": False})
        self.assertEqual(slots[by_name["bias"]]["step"], self.counts["bias"])
        self.assertEqual(self.cp.replica_sha(self.payloads[0]), self.cp.replica_sha(self.payloads[1]))

    def test_wrong_rank_world_and_ownership_reject(self):
        for rank in (True, -1, 2):
            with self.subTest(rank=rank), self.assertRaises(self.cp.Error):
                self.cp.validate_rank(self.payloads[0], self.contract, self.model, self.optimizer, rank, native_rng=False)
        self.assert_rejected_without_mutation(lambda p: p["metadata"].update(rank=1))
        for change in ({"world_size": 3}, {"world_size": True}, {"sp": 2}, {"ownership": "index-mod-world"}):
            contract = copy.deepcopy(self.contract) | change
            with self.subTest(change=change), self.assertRaises(self.cp.Error):
                self.cp.validate_rank(self.payloads[0], contract, self.model, self.optimizer, 0, native_rng=False)

    def test_missing_momentum_state_shape_dtype_and_nonfinite_reject(self):
        for mutation in (
            lambda p: p["state"]["optimizer"]["state"].pop(0),
            lambda p: p["state"]["optimizer"]["state"][0].pop("momentum_buffer"),
            lambda p: p["state"]["optimizer"]["state"][0].update(momentum_buffer=torch.zeros(4)),
            lambda p: p["state"]["optimizer"]["state"][0].update(momentum_buffer=torch.zeros(2, 2, dtype=torch.float64)),
            lambda p: p["state"]["optimizer"]["state"][0].update(momentum_buffer=torch.full((2, 2), float("nan"))),
        ):
            with self.subTest(mutation=mutation):
                self.assert_rejected_without_mutation(mutation)

    def test_branch_names_parameter_ids_and_placements_reject(self):
        for mutation in (
            lambda p: p["state"]["optimizer"]["state"][0].update(use_muon=False),
            lambda p: p["state"]["optimizer_parameter_names"][0].reverse(),
            lambda p: p["state"]["optimizer"]["param_groups"][0]["params"].reverse(),
            lambda p: p["state"]["optimizer"]["param_groups"][0]["params"].__setitem__(0, 9999),
            lambda p: p["state"]["optimizer"]["param_groups"][0]["params"].__setitem__(1, 0),
            lambda p: p["state"]["optimizer_placements"][0].update(momentum_buffer="mlu:1"),
        ):
            with self.subTest(mutation=mutation):
                self.assert_rejected_without_mutation(mutation)

    def test_consumed_adamw_and_unused_explicit_counts(self):
        for mutation in (
            lambda p: p["gradient_counts"].update(bias=0),
            lambda p: p["gradient_counts"].update(unused_bias=1),
            lambda p: p["gradient_counts"].update(matrix=True),
            lambda p: p["gradient_counts"].update(matrix=2),
            lambda p: p["gradient_counts"].pop("matrix"),
        ):
            with self.subTest(mutation=mutation):
                self.assert_rejected_without_mutation(mutation)

    def test_duplicate_group_names_and_unknown_hyperparameters(self):
        contract = copy.deepcopy(self.contract)
        contract["topology"]["groups"][0]["parameters"][1]["name"] = "matrix"
        with self.assertRaises(self.cp.Error):
            self.cp.validate_contract(contract)
        self.assert_rejected_without_mutation(lambda p: p["state"]["optimizer"]["param_groups"][0].update(extra=True))

    def test_dtensor_model_and_saved_tensor_refused(self):
        with mock.patch.object(self.cp.native, "_is_dtensor", side_effect=lambda value: value is self.model.matrix):
            with self.assertRaises(self.cp.Error):
                self.cp.topology(self.model, self.optimizer)
        tensor = self.payloads[0]["state"]["optimizer"]["state"][0]["momentum_buffer"]
        with mock.patch.object(self.cp.native, "_is_dtensor", side_effect=lambda value: value is tensor):
            with self.assertRaises(self.cp.Error):
                self.cp.validate_rank(self.payloads[0], self.contract, self.model, self.optimizer, 0, native_rng=False)

    def write_pair(self, directory, payloads=None):
        receipts = []
        for rank, payload in enumerate(payloads or self.payloads):
            path = directory / f"rank-{rank}.pt"
            self.cp.native.save_atomic(path, payload)
            receipts.append({"rank": rank, "sha256": self.cp.native.file_sha256(path),
                             "replica_sha256": self.cp.replica_sha(payload)})
        return receipts

    def test_commit_roundtrip_is_safe_and_json_stable(self):
        with tempfile.TemporaryDirectory() as root:
            directory = Path(root)
            receipts = self.write_pair(directory)
            self.cp.publish_commit(directory, receipts, self.contract, 1, writer_rank=0)
            manifest, loaded = self.cp.load_committed(directory)
            self.assertEqual(manifest["contract"], self.contract)
            self.assertEqual(loaded[1]["integrity_sha256"], self.payloads[1]["integrity_sha256"])
            self.cp.validate_rank(loaded[1], self.contract, self.model, self.optimizer, 1, native_rng=False)

    def test_missing_rank_no_marker_and_nonzero_writer_refused(self):
        with tempfile.TemporaryDirectory() as root:
            directory = Path(root)
            with self.assertRaises(self.cp.Error):
                self.cp.load_committed(directory)
            receipts = self.write_pair(directory)
            with self.assertRaises(self.cp.Error):
                self.cp.publish_commit(directory, receipts, self.contract, 1, writer_rank=1)
            (directory / "rank-1.pt").unlink()
            with self.assertRaises(self.cp.Error):
                self.cp.publish_commit(directory, receipts, self.contract, 1, writer_rank=0)
            self.assertFalse((directory / "COMMITTED.json").exists())

    def test_divergent_replica_duplicate_and_swapped_receipts_refused(self):
        for kind in ("divergence", "duplicate", "swap"):
            with self.subTest(kind=kind), tempfile.TemporaryDirectory() as root:
                payloads = copy.deepcopy(self.payloads)
                if kind == "divergence":
                    payloads[1]["state"]["optimizer"]["state"][0]["momentum_buffer"].add_(1)
                    self.resign(payloads[1])
                directory = Path(root)
                receipts = self.write_pair(directory, payloads)
                if kind == "duplicate":
                    receipts[1] = receipts[0]
                if kind == "swap":
                    receipts.reverse()
                with self.assertRaises(self.cp.Error):
                    self.cp.publish_commit(directory, receipts, self.contract, 1, writer_rank=0)
                self.assertFalse((directory / "COMMITTED.json").exists())

    def test_restore_next_rng_and_optimizer_update_exact(self):
        import numpy as np
        payload = self.payloads[1]
        self.cp.restore_rank_rng(payload, self.contract, 1)
        value = random.random() + float(np.random.rand()) + float(torch.rand(()))
        manual_step(self.model, self.optimizer, self.counts, value=value)
        expected = self.cp.native.tree_sha256(self.cp.native.capture_model_state(self.model, self.optimizer))
        fresh = make_model(999)
        optimizer = self.muon.get_muon_optimizer(fresh)
        self.cp.validate_rank(payload, self.contract, fresh, optimizer, 1, native_rng=False)
        self.cp.apply_rank_state(payload, fresh, optimizer)
        self.cp.restore_rank_rng(payload, self.contract, 1)
        replay = random.random() + float(np.random.rand()) + float(torch.rand(()))
        self.assertEqual(replay, value)
        manual_step(fresh, optimizer, dict(payload["gradient_counts"]), value=replay)
        self.assertEqual(expected, self.cp.native.tree_sha256(self.cp.native.capture_model_state(fresh, optimizer)))

    def test_shared_flow_sampling_keeps_the_original_expression_and_rng(self):
        from genmlu.backends import hunyuanvideo_training as native

        class CpuDeviceShim:
            def __getattr__(self, name):
                return getattr(torch, name)

            def randn(self, *args, **kwargs):
                assert kwargs["device"] == "mlu"
                return torch.randn(*args, **(kwargs | {"device": "cpu"}))

        latents = torch.arange(16, dtype=torch.float32).reshape(1, 2, 2, 2, 2) / 16
        cond = torch.zeros(1, 3, 2, 2, 2)
        torch.manual_seed(999)
        noise = torch.randn_like(latents)
        unit = torch.sigmoid(torch.randn((latents.shape[0],), device="cpu"))
        shifted = 3.0 * unit / (1.0 + (3.0 - 1.0) * unit)
        timestep = shifted * 1000
        scale = timestep.view(-1, 1, 1, 1, 1) / 1000
        expected = (torch.cat(((1.0 - scale) * latents + scale * noise, cond), dim=1), timestep, noise - latents)
        expected_rng = torch.get_rng_state().clone()
        torch.manual_seed(999)
        actual = native.sample_native_flow_inputs(CpuDeviceShim(), {"latents": latents, "cond": cond}, {})
        self.assertTrue(all(torch.equal(a, b) for a, b in zip(actual, expected)))
        self.assertTrue(torch.equal(expected_rng, torch.get_rng_state()))


if __name__ == "__main__":
    unittest.main()
