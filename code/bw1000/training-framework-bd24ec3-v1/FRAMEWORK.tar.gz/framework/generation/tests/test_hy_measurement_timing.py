from __future__ import annotations

import inspect
from pathlib import Path

import pytest

from genmlu.backends import hy_motion_motionrft as motionrft
from genmlu.manifest import merge_backend_result, new_manifest, sha256_path


def test_zero_update_resume_reports_only_nonempty_summary_log(tmp_path: Path) -> None:
    step_log = tmp_path / "steps.ndjson"
    step_log.touch()
    summary = tmp_path / "summary.json"
    summary.write_text('{"resume": true}', encoding="utf-8")
    assert motionrft._result_logs(step_log, "step-sha", summary, "summary-sha", 0) == [
        {"path": str(summary), "sha256": "summary-sha"}
    ]
    with pytest.raises(RuntimeError, match="without a step log"):
        motionrft._result_logs(step_log, "step-sha", summary, "summary-sha", 1)
    step_log.write_text('{"global_step": 25}\n', encoding="utf-8")
    assert len(motionrft._result_logs(step_log, "step-sha", summary, "summary-sha", 1)) == 2
    assert len(motionrft._result_logs(step_log, "step-sha", summary, "summary-sha", 0)) == 2


def test_zero_update_resume_manifest_accepts_summary_without_empty_step_log(tmp_path: Path) -> None:
    step_log = tmp_path / "steps.ndjson"
    step_log.touch()
    summary = tmp_path / "summary.json"
    summary.write_text('{"resume": {"boundary_validated": true}}', encoding="utf-8")
    adapter = tmp_path / "adapter-final.safetensors"
    adapter.write_bytes(b"adapter")
    value = new_manifest("rl", "hy-motion-1.0", {}, {})
    merge_backend_result(value, {
        "artifacts": [{"path": str(adapter), "sha256": sha256_path(adapter)}],
        "logs": motionrft._result_logs(
            step_log, sha256_path(step_log), summary, sha256_path(summary), 0
        ),
        "metrics": {"executed_steps": 0},
        "stage_timings": {},
        "checks": {"resume_boundary": True},
    })
    assert value["status"] == "completed"
    assert len(value["logs"]) == 1
    assert value["logs"][0]["path"] == str(summary)


def test_full_measurement_ends_after_mandatory_final_writes_and_hashes() -> None:
    source = inspect.getsource(motionrft.run_hy_motion_motionrft)

    assert source.index("training_ended = perf_counter()") < source.index(
        "checkpoint_final_sha = sha256_path(checkpoint)"
    )
    assert source.index("checkpoint_final_sha = sha256_path(checkpoint)") < source.index(
        "summary_path.write_text"
    )
    assert source.index("summary_path.write_text") < source.index(
        "summary_sha = sha256_path(summary_path)"
    )
    assert source.index("summary_sha = sha256_path(summary_path)") < source.index(
        "step_log_sha = sha256_path(step_log)"
    )
    assert source.index("step_log_sha = sha256_path(step_log)") < source.index(
        "full_measurement_ended = perf_counter()"
    )
    assert source.index("resume_validation_seconds = perf_counter() - resume_started") < source.index(
        "training_started = perf_counter()"
    )
    assert source.index("full_measurement_ended = perf_counter()") < source.index(
        '"resume_validation_seconds": resume_validation_seconds'
    )


def test_measurement_samples_count_only_resumed_process_records() -> None:
    resumed_remaining_records = [{"global_step": step} for step in (8, 9, 10)]

    assert motionrft._measurement_samples_per_second(
        resumed_remaining_records, group_size=4, wall_seconds=2.0
    ) == 6.0
    assert (
        motionrft._measurement_samples_per_second(
            [], group_size=4, wall_seconds=2.0
        )
        is None
    )
    assert motionrft._measurement_samples_per_second(
        resumed_remaining_records, group_size=4, wall_seconds=0.0
    ) is None
