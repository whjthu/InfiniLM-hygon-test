from __future__ import annotations

import copy
import importlib
import os
import random
import sys
from pathlib import Path

import numpy as np
import pytest

from genmlu import hunyuanvideo_resume_checkpoint as checkpoint
from genmlu.backends.hunyuanvideo_training import _invocation_counts


def _actual_muon_factory():
    source_root = os.environ.get("HUNYUANVIDEO_SOURCE")
    if not source_root:
        pytest.skip("HUNYUANVIDEO_SOURCE is required for the real Muon checkpoint test")
    source = Path(source_root)
    if not (source / "hyvideo" / "optim" / "muon.py").is_file():
        pytest.skip("HUNYUANVIDEO_SOURCE does not contain hyvideo.optim.muon")
    sys.path.insert(0, str(source))
    try:
        return importlib.import_module("hyvideo.optim.muon").get_muon_optimizer
    finally:
        sys.path.pop(0)


def _identity() -> dict[str, str]:
    return {field: "a" * 64 for field in checkpoint.IDENTITY_FIELDS}


def _contract() -> dict[str, object]:
    return checkpoint.build_contract(
        identity=_identity(),
        seed=17,
        warmup_steps=5,
        max_steps=20,
        cache_sha256="b" * 64,
        device_ids=[],
    )


def _make_model_and_optimizer():
    torch = pytest.importorskip("torch")
    get_muon_optimizer = _actual_muon_factory()

    class TinyNativeModel(torch.nn.Module):
        def __init__(self) -> None:
            super().__init__()
            self.muon_matrix = torch.nn.Parameter(torch.randn(2, 3))
            self.muon_rank3 = torch.nn.Parameter(torch.randn(2, 2, 2))
            self.muon_unused = torch.nn.Parameter(torch.randn(2, 2))
            self.adam_bias = torch.nn.Parameter(torch.randn(2))
            self.adam_unused = torch.nn.Parameter(torch.randn(2))

    model = TinyNativeModel()
    optimizer = get_muon_optimizer(model, lr=1e-3, weight_decay=1e-2)
    return torch, model, optimizer


def _step(torch, model, optimizer) -> tuple[float, float, float, float]:
    optimizer.zero_grad(set_to_none=True)
    sample = torch.randn(2, 3)
    host = random.random()
    numpy_value = float(np.random.random())
    loss = (
        (model.muon_matrix * sample).sum()
        + model.muon_rank3.square().mean()
        + model.adam_bias.square().sum()
        + host * 0.01
        + numpy_value * 0.01
    )
    loss.backward()
    optimizer.step()
    return float(loss.detach()), host, numpy_value, float(sample.sum())


def _resign(payload: dict[str, object]) -> None:
    unsigned = {key: value for key, value in payload.items() if key != "integrity_sha256"}
    payload["integrity_sha256"] = checkpoint.tree_sha256(unsigned)


def test_real_muon_full_state_roundtrip_and_next_step(tmp_path: Path) -> None:
    random.seed(17)
    np.random.seed(17)
    torch, model, optimizer = _make_model_and_optimizer()
    torch.manual_seed(17)
    for _ in range(10):
        _step(torch, model, optimizer)

    payload = checkpoint.make_payload(
        contract=_contract(), global_step=10, model=model, optimizer=optimizer
    )
    rank3_buffer = optimizer.state[model.muon_rank3]["momentum_buffer"]
    assert tuple(rank3_buffer.shape) == (2, 4)
    assert optimizer.state[model.muon_rank3]["use_muon"] is True
    assert "momentum_buffer" in optimizer.state[model.muon_unused]
    assert optimizer.state[model.adam_bias]["use_muon"] is False
    assert optimizer.state[model.adam_bias]["step"].__class__ is int
    assert set(optimizer.state[model.adam_unused]) == {"use_muon"}

    destination = tmp_path / "checkpoint-10" / "state.pt"
    checkpoint.save_atomic(destination, payload)
    payload = checkpoint.load_checkpoint(destination)
    payload_sha = checkpoint.tree_sha256(payload)
    continuous = _step(torch, model, optimizer)
    continuous_state = checkpoint.tree_sha256(checkpoint.capture_model_state(model, optimizer))

    random.seed(999)
    np.random.seed(999)
    torch.manual_seed(999)
    _, restored_model, restored_optimizer = _make_model_and_optimizer()
    checked = checkpoint.restore_checkpoint(payload, _contract(), restored_model, restored_optimizer)
    checkpoint.assert_restored_boundary(payload, _contract(), restored_model, restored_optimizer)
    resumed = _step(torch, restored_model, restored_optimizer)
    resumed_state = checkpoint.tree_sha256(
        checkpoint.capture_model_state(restored_model, restored_optimizer)
    )

    assert checked["metadata"]["global_optimizer_step"] == 10
    assert continuous == resumed
    assert continuous_state == resumed_state
    assert checkpoint.tree_sha256(payload) == payload_sha

    random.seed(333)
    np.random.seed(333)
    torch.manual_seed(333)
    _, second_model, second_optimizer = _make_model_and_optimizer()
    checkpoint.restore_checkpoint(payload, _contract(), second_model, second_optimizer)
    checkpoint.assert_restored_boundary(payload, _contract(), second_model, second_optimizer)


def test_real_muon_rejects_corruption_without_model_mutation() -> None:
    random.seed(17)
    np.random.seed(17)
    torch, model, optimizer = _make_model_and_optimizer()
    torch.manual_seed(17)
    for _ in range(10):
        _step(torch, model, optimizer)
    payload = checkpoint.make_payload(
        contract=_contract(), global_step=10, model=model, optimizer=optimizer
    )
    before = checkpoint.tree_sha256(checkpoint.capture_model_state(model, optimizer))
    corrupt = copy.deepcopy(payload)
    rank3_id = next(
        saved_id
        for saved_id, names in zip(
            corrupt["state"]["optimizer"]["param_groups"][0]["params"],
            corrupt["state"]["optimizer_parameter_names"][0],
        )
        if names == "muon_rank3"
    )
    corrupt["state"]["optimizer"]["state"][rank3_id]["momentum_buffer"] = torch.zeros(8)
    _resign(corrupt)

    with pytest.raises(checkpoint.CheckpointValidationError):
        checkpoint.validate_checkpoint(corrupt, _contract(), model, optimizer, native_rng=False)
    assert checkpoint.tree_sha256(checkpoint.capture_model_state(model, optimizer)) == before

    wrong_branch = copy.deepcopy(payload)
    wrong_branch["state"]["optimizer"]["state"][rank3_id]["use_muon"] = False
    _resign(wrong_branch)
    with pytest.raises(checkpoint.CheckpointValidationError, match="branch"):
        checkpoint.validate_checkpoint(wrong_branch, _contract(), model, optimizer, native_rng=False)
    assert checkpoint.tree_sha256(checkpoint.capture_model_state(model, optimizer)) == before

    dependency_drift = _contract()
    dependency_drift["identity"]["dependencies"] = "c" * 64
    with pytest.raises(checkpoint.CheckpointValidationError, match="identity"):
        checkpoint.validate_checkpoint(payload, dependency_drift, model, optimizer, native_rng=False)
    assert checkpoint.tree_sha256(checkpoint.capture_model_state(model, optimizer)) == before


def test_global_step_metadata_rejects_legacy_measured_step_contract() -> None:
    contract = _contract()
    metadata = checkpoint.boundary_metadata(contract, 10)
    assert metadata["completed_warmup_steps"] == 5
    assert metadata["completed_measured_steps"] == 5
    assert checkpoint.next_coordinate(metadata) == {
        "global_optimizer_step": 11,
        "measured_step": 6,
        "cache_cursor": 0,
    }
    assert checkpoint.next_coordinate(checkpoint.boundary_metadata(contract, 25)) is None

    legacy = copy.deepcopy(contract)
    legacy["checkpoint_step_basis"] = "measured-step"
    with pytest.raises(checkpoint.CheckpointValidationError, match="legacy"):
        checkpoint.validate_contract(legacy)


def test_resume_invocation_counts_do_not_report_the_full_fresh_schedule() -> None:
    assert _invocation_counts(10, 5, 25) == {
        "executed_global_steps": 15,
        "executed_warmup_steps": 0,
        "executed_measured_steps": 15,
        "first_global_step": 11,
    }
    assert _invocation_counts(20, 5, 25) == {
        "executed_global_steps": 5,
        "executed_warmup_steps": 0,
        "executed_measured_steps": 5,
        "first_global_step": 21,
    }
