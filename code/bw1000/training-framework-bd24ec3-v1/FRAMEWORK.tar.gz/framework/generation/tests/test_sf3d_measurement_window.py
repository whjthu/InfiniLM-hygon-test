from __future__ import annotations

import inspect

from genmlu.backends import sf3d_reconstruction as sf3d


def test_benchmark_window_starts_after_warmup_and_ends_after_export_tail() -> None:
    source = inspect.getsource(sf3d.run_sf3d_inference)

    warmup_slice = source.index("measured_runs = runs[warmup_steps:] if benchmark_mode else runs")
    tail_sidecar = source.rindex("if pending_sidecar is not None:")
    artifact_hashes = source.index("artifact_shas = [sha256_path")
    step_log = source.index('with step_log.open("w", encoding="utf-8")')
    window = source.index('result["measurement_window"] = {')

    assert tail_sidecar < artifact_hashes < step_log < window
    assert warmup_slice < window
    assert "if repeat_index == (warmup_steps if benchmark_mode else 0):" in source
    assert '"work_units": len(measured_runs)' in source
    assert '"unit": "reconstructions"' in source


def test_only_non_recovery_benchmark_runs_emit_reconstruction_windows() -> None:
    source = inspect.getsource(sf3d.run_sf3d_inference)

    assert "benchmark_mode = measure_steps > 0" in source
    assert 'if benchmark_mode and config.get("validate_recovery", False) is False:' in source
    assert source.count('result["measurement_window"] = {') == 1
