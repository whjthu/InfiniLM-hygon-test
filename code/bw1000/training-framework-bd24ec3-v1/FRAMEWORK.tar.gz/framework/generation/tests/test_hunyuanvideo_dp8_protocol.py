"""Stdlib transaction/collective gates with primitive fakes, not tensor or MLU proof."""
import ast
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
from typing import Any, Callable
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1] / "src/genmlu"


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def extract(path, names, namespace):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in names:
            exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), "exec"), namespace)
        elif isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id in names
                                                for target in node.targets):
            exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), "exec"), namespace)
    return namespace


NATIVE = extract(ROOT / "hunyuanvideo_resume_checkpoint.py", {"IDENTITY_FIELDS", "_MUON_GROUP_FIELDS"}, {})
CP = extract(ROOT / "hunyuanvideo_distributed_checkpoint.py",
    {"SCHEMA", "DP8_SCHEMA", "MUON_SOURCE_SHA256", "validate_contract", "rank_metadata", "replica_sha",
     "write_json_atomic", "_read_rank", "publish_commit", "load_committed"},
    {"Any": Any, "Path": Path, "json": json, "hashlib": hashlib, "io": io, "os": os,
     "tempfile": tempfile, "require": require, "native": SimpleNamespace(**NATIVE, tree_sha256=digest)})


def contract(world=8):
    return {"schema": CP["SCHEMA"] if world == 2 else CP["DP8_SCHEMA"], "world_size": world,
        "sp": 1, "ownership": "replicated-plain-tensor", "identity": {key: "a" * 64 for key in NATIVE["IDENTITY_FIELDS"]},
        "seed": 42, "warmup_steps": 0, "max_steps": 21, "devices": ["cpu"] * world,
        "topology": {"implementation": {"module": "fixture", "qualname": "Muon",
            "source_sha256": CP["MUON_SOURCE_SHA256"]}, "groups": [{"hyperparameters":
            {key: 0 for key in NATIVE["_MUON_GROUP_FIELDS"] - {"params"}}, "parameters": [{"name": "weight",
            "shape": [2, 2], "dtype": "torch.float32", "use_muon": True, "replicas": list(range(world))}]}]}}


def resign(payload):
    payload["integrity_sha256"] = digest({key: value for key, value in payload.items() if key != "integrity_sha256"})


class PrimitiveTransactionTests(unittest.TestCase):
    def setUp(self):
        self.loads = []

        def safe_load(handle, *, map_location, weights_only):
            self.assertEqual((map_location, weights_only), ("cpu", True))
            self.loads.append(True)
            return json.loads(handle.read())

        self.patch = mock.patch.dict("sys.modules", {"torch": SimpleNamespace(load=safe_load)})
        self.patch.start()
        self.addCleanup(self.patch.stop)

    def write_ranks(self, root, plan, mutation=None):
        receipts = []
        for rank in range(plan["world_size"]):
            payload = {"metadata": CP["rank_metadata"](plan, rank, 10), "state": {"weight": [1, 2],
                "optimizer": {"momentum": [3, 4]}, "optimizer_placements": {"momentum": plan["devices"][rank]}},
                "rng": {"rank_stream": rank}, "gradient_counts": {"weight": 10}}
            if mutation:
                mutation(rank, payload)
            resign(payload)
            data = json.dumps(payload, sort_keys=True).encode()
            (root / f"rank-{rank}.pt").write_bytes(data)
            receipts.append({"rank": rank, "sha256": hashlib.sha256(data).hexdigest(),
                             "replica_sha256": CP["replica_sha"](payload)})
        return receipts

    def test_dp2_schema_and_eight_receipt_roundtrip(self):
        for world in (2, 8):
            with self.subTest(world=world), tempfile.TemporaryDirectory() as temporary:
                root, plan = Path(temporary), contract(world)
                receipts = self.write_ranks(root, plan)
                CP["publish_commit"](root, receipts, plan, 10, writer_rank=0)
                manifest, payloads = CP["load_committed"](root)
                self.assertEqual(manifest, {"schema": plan["schema"], "contract": plan, "global_step": 10, "ranks": receipts})
                self.assertEqual([p["metadata"]["rank"] for p in payloads], list(range(world)))
                self.assertEqual([p["rng"]["rank_stream"] for p in payloads], list(range(world)))
                self.assertTrue(all(p["metadata"]["cache_cursor"] == 0 and
                                    p["metadata"]["next_global_step"] == 11 for p in payloads))

    def test_missing_duplicate_swapped_divergent_or_wrong_step_never_commit(self):
        for kind in ("missing", "duplicate", "swap", "divergent", "step", "writer"):
            with self.subTest(kind=kind), tempfile.TemporaryDirectory() as temporary:
                root, plan = Path(temporary), contract()
                def mutate(rank, payload):
                    if rank == 7 and kind == "divergent":
                        payload["state"]["optimizer"]["momentum"][0] = 99
                    if rank == 7 and kind == "step":
                        payload["metadata"]["global_step"] = 11
                receipts = self.write_ranks(root, plan, mutate)
                if kind == "missing":
                    (root / "rank-7.pt").unlink()
                elif kind == "duplicate":
                    receipts[7] = receipts[0]
                elif kind == "swap":
                    receipts[6], receipts[7] = receipts[7], receipts[6]
                with self.assertRaises(ValueError):
                    CP["publish_commit"](root, receipts, plan, 10, writer_rank=7 if kind == "writer" else 0)
                self.assertFalse((root / "COMMITTED.json").exists())

    def test_corruption_missing_receipt_and_cross_schema_reject(self):
        for kind in ("bytes", "missing", "schema", "world", "replicas", "devices", "seed"):
            with self.subTest(kind=kind), tempfile.TemporaryDirectory() as temporary:
                root, plan = Path(temporary), contract()
                receipts = self.write_ranks(root, plan)
                CP["publish_commit"](root, receipts, plan, 10, writer_rank=0)
                marker = root / "COMMITTED.json"
                manifest = json.loads(marker.read_text())
                if kind == "bytes":
                    (root / "rank-7.pt").write_bytes(b"changed")
                elif kind == "missing":
                    manifest["ranks"].pop()
                elif kind == "schema":
                    manifest["schema"] = CP["SCHEMA"]
                elif kind == "world":
                    manifest["contract"]["world_size"] = 2
                elif kind == "replicas":
                    manifest["contract"]["topology"]["groups"][0]["parameters"][0]["replicas"] = [0, 1]
                elif kind == "devices":
                    manifest["contract"]["devices"] = ["mlu:0"] * 8
                elif kind == "seed":
                    manifest["contract"]["seed"] = 2**32 - 7
                marker.write_text(json.dumps(manifest))
                with self.assertRaises(ValueError):
                    CP["load_committed"](root)


class FakeTensor:
    def __init__(self, values):
        self.values = list(values)

    def cpu(self):
        return self

    def item(self):
        return self.values[0]

    def tolist(self):
        return self.values

    def __setitem__(self, key, value):
        self.values[key] = value.values


class CollectiveGateTests(unittest.TestCase):
    def namespace(self):
        return extract(ROOT / "backends/hunyuanvideo_data_parallel.py",
            {"exchange_json", "collective_action", "agree", "average_gradients"},
            {"Any": Any, "Callable": Callable, "json": json, "checkpoint": SimpleNamespace(require=require,
             native=SimpleNamespace(_is_dtensor=lambda p: False, _parameter_names=lambda model, opt: [["weight"]],
                                    tree_sha256=digest))})

    def test_exchange_requires_all_ordered_unique_ranks_and_agree_checks_rank7(self):
        ns = self.namespace()
        for world in (2, 8):
            for kind in ("valid", "duplicate", "swapped", "disagree"):
                with self.subTest(world=world, kind=kind):
                    envelopes = [{"rank": rank, "value": "same"} for rank in range(world)]
                    if kind == "duplicate":
                        envelopes[-1]["rank"] = 0
                    elif kind == "swapped":
                        envelopes[-1], envelopes[-2] = envelopes[-2], envelopes[-1]
                    elif kind == "disagree":
                        envelopes[-1]["value"] = "different"
                    encoded = [json.dumps(value).encode() for value in envelopes]
                    calls = []
                    def gather(outputs, local):
                        for output, data in zip(outputs, encoded):
                            output.values = [len(data)] if not calls else list(data) + [0] * (max(map(len, encoded)) - len(data))
                        calls.append(True)
                    fake = SimpleNamespace(int32="int32", tensor=lambda values, **kw: FakeTensor(values),
                        empty_like=lambda value: FakeTensor([0] * len(value.values)),
                        zeros=lambda length, **kw: FakeTensor([0] * length), distributed=SimpleNamespace(
                        is_initialized=lambda: True, get_world_size=lambda: world, get_rank=lambda: 0, all_gather=gather))
                    if kind == "valid":
                        ns["agree"](fake, "cpu", "same", "fixture")
                    else:
                        with self.assertRaises(ValueError):
                            ns["agree"](fake, "cpu", "same", "fixture")

    def test_gradient_mean_and_one_rank_missing_gradient_fail_before_reduce(self):
        for world in (2, 8):
            for missing in (False, True):
                with self.subTest(world=world, missing=missing):
                    ns, reductions = self.namespace(), []
                    grad = SimpleNamespace(value=1.0, layout="strided", dtype="float32", shape=(1,), device="cpu")
                    grad.div_ = lambda divisor: setattr(grad, "value", grad.value / divisor)
                    parameter = SimpleNamespace(grad=grad, dtype="float32", shape=(1,), device="cpu")
                    def exchange(torch, value, device):
                        peers = [copy.deepcopy(value) for _ in range(world)]
                        if missing and type(value) is dict and "error" in value:
                            peers[-1]["error"] = "unused trainable parameter"
                        return peers
                    ns["exchange_json"] = exchange
                    def reduce(value, op):
                        reductions.append(op)
                        value.value = sum(range(1, world + 1))
                    fake = SimpleNamespace(strided="strided", isfinite=lambda value: SimpleNamespace(all=lambda: True),
                        distributed=SimpleNamespace(get_world_size=lambda: world, all_reduce=reduce,
                                                    ReduceOp=SimpleNamespace(SUM="sum")))
                    optimizer = SimpleNamespace(param_groups=[{"params": [parameter]}])
                    if missing:
                        with self.assertRaises(RuntimeError):
                            ns["average_gradients"](fake, None, optimizer, "cpu")
                        self.assertEqual(reductions, [])
                        self.assertEqual(grad.value, 1.0)
                    else:
                        ns["average_gradients"](fake, None, optimizer, "cpu")
                        self.assertEqual(grad.value, (world + 1) / 2)
                        self.assertEqual(reductions, ["sum"])

    def test_any_rank_parameter_order_disagreement_prevents_reduction(self):
        ns, reductions = self.namespace(), []
        grad = SimpleNamespace(layout="strided", dtype="float32", shape=(1,), device="cpu")
        parameter = SimpleNamespace(grad=grad, dtype="float32", shape=(1,), device="cpu")
        def exchange(torch, value, device):
            peers = [value for _ in range(8)]
            if isinstance(value, str):
                peers[7] = "different-parameter-order"
            return peers
        ns["exchange_json"] = exchange
        fake = SimpleNamespace(strided="strided", isfinite=lambda value: SimpleNamespace(all=lambda: True),
            distributed=SimpleNamespace(get_world_size=lambda: 8,
                all_reduce=lambda *args, **kwargs: reductions.append(True), ReduceOp=SimpleNamespace(SUM="sum")))
        with self.assertRaises(ValueError):
            ns["average_gradients"](fake, None, SimpleNamespace(param_groups=[{"params": [parameter]}]), "cpu")
        self.assertEqual(reductions, [])


if __name__ == "__main__":
    unittest.main()
