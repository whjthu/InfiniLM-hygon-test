"""Single-rank admission must precede runtime and output side effects."""
import ast
import os
from pathlib import Path
from typing import Any
import unittest


SOURCE = Path(__file__).resolve().parents[1] / "src/genmlu/backends/hunyuanvideo_training.py"
TREE = ast.parse(SOURCE.read_text(encoding="utf-8"))
NODE = next(node for node in TREE.body if isinstance(node, ast.FunctionDef)
            and node.name == "validate_single_rank_launch")
NAMESPACE = {"os": os, "Any": Any}
exec(compile(ast.Module(body=[NODE], type_ignores=[]), str(SOURCE), "exec"), NAMESPACE)
validate = NAMESPACE["validate_single_rank_launch"]


class LaunchAdmissionTests(unittest.TestCase):
    def test_standalone_and_single_rank_launcher_accept(self):
        validate({}, {})
        validate({"cards": [7]}, {})
        validate({"cards": [0], "rank": 0, "world_size": 1, "local_rank": 0},
                 {"RANK": "0", "WORLD_SIZE": "1", "LOCAL_RANK": "0", "LOCAL_WORLD_SIZE": "1"})

    def test_distributed_environment_rejects_each_conflict(self):
        for name, bad in (("WORLD_SIZE", "2"), ("RANK", "1"),
                          ("LOCAL_RANK", "1"), ("LOCAL_WORLD_SIZE", "2")):
            with self.subTest(name=name), self.assertRaises(RuntimeError):
                validate({}, {name: bad})

    def test_malformed_launcher_and_config_values_reject(self):
        for name in ("RANK", "WORLD_SIZE", "LOCAL_RANK", "LOCAL_WORLD_SIZE"):
            for value in ("", "true", "1.0", "-1", " 1", "01", "\uff11", None, 1):
                with self.subTest(name=name, value=value), self.assertRaises(RuntimeError):
                    validate({}, {name: value})
        for config in ({"cards": []}, {"cards": [0, 1]}, {"cards": "0"},
                       {"cards": [True]}, {"cards": [-1]}, {"cards": ["0"]},
                       {"world_size": True}, {"world_size": "1"},
                       {"world_size": 2}, {"rank": 1}, {"local_rank": 1}):
            with self.subTest(config=config), self.assertRaises(RuntimeError):
                validate(config, {})

    def test_admission_is_the_first_backend_action(self):
        function = next(node for node in TREE.body if isinstance(node, ast.FunctionDef)
                        and node.name == "run_hunyuanvideo_training")
        first = function.body[0]
        self.assertIsInstance(first, ast.Expr)
        self.assertIsInstance(first.value, ast.Call)
        self.assertEqual(first.value.func.id, "validate_single_rank_launch")


if __name__ == "__main__":
    unittest.main()
