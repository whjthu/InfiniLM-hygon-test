from __future__ import annotations

import sys
from types import ModuleType

import pytest
import torch
from torch import nn
from torch.nn import functional as F

from genmlu import trellis_sparse_cpu_adapter as adapter
from genmlu.sparse_submanifold_conv3d import sparse_submanifold_conv3d


class SparseValue:
    def __init__(self, feats, coords, marker):
        self.feats = feats
        self.coords = coords
        self.marker = marker

    def replace(self, feats):
        return SparseValue(feats, self.coords, self.marker)


def _dense_reference(features, coordinates, weight, bias):
    dense = features.new_zeros((2, features.shape[1], 2, 2, 2))
    for feature, coordinate in zip(features, coordinates):
        batch, depth, height, width = map(int, coordinate)
        dense[batch, :, depth, height, width] = feature
    output = F.conv3d(dense, weight.permute(0, 4, 1, 2, 3), bias, padding=1)
    return torch.stack([
        output[int(batch), :, int(depth), int(height), int(width)]
        for batch, depth, height, width in coordinates
    ])


def test_sparse_submanifold_conv_matches_dense_interleaved_batches() -> None:
    coords = torch.tensor(
        [[1, 0, 0, 0], [0, 0, 0, 0], [1, 0, 1, 0], [0, 0, 0, 1]],
        dtype=torch.int32,
    )
    features = torch.tensor([[7.0, 3.0], [1.0, 2.0], [11.0, 5.0], [4.0, 6.0]])
    weight = torch.arange(2 * 3 * 3 * 3 * 2, dtype=torch.float32).reshape(2, 3, 3, 3, 2)
    bias = torch.tensor([0.5, -1.5])

    actual = sparse_submanifold_conv3d(features, coords, weight, bias)

    torch.testing.assert_close(actual, _dense_reference(features, coords, weight, bias))


def test_sparse_submanifold_conv_rejects_duplicates_and_even_kernels() -> None:
    with pytest.raises(ValueError, match="duplicate"):
        sparse_submanifold_conv3d(
            torch.ones(2, 1),
            torch.tensor([[0, 0, 0, 0], [0, 0, 0, 0]]),
            torch.ones(1, 1, 1, 1, 1),
        )
    with pytest.raises(ValueError, match="odd"):
        sparse_submanifold_conv3d(
            torch.ones(1, 1), torch.zeros(1, 4, dtype=torch.int32), torch.ones(1, 2, 3, 3, 1)
        )


def test_adapter_preserves_sparse_metadata_and_flex_gemm_layout() -> None:
    module = nn.Module()
    adapter.sparse_conv3d_init(module, 1, 1, 3, bias=False)
    with torch.no_grad():
        module.weight.fill_(1.0)
    marker = object()
    value = SparseValue(
        torch.tensor([[2.0], [3.0]]),
        torch.tensor([[0, 0, 0, 0], [0, 0, 0, 1]], dtype=torch.int32),
        marker,
    )

    output = adapter.sparse_conv3d_forward(module, value)

    assert tuple(module.weight.shape) == (1, 3, 3, 3, 1)
    assert output.coords is value.coords
    assert output.marker is marker
    torch.testing.assert_close(output.feats, torch.tensor([[5.0], [5.0]]))


@pytest.mark.parametrize("kwargs", [{"stride": 2}, {"dilation": 2}, {"padding": 1}])
def test_adapter_rejects_non_submanifold_contract(kwargs) -> None:
    with pytest.raises(NotImplementedError):
        adapter.sparse_conv3d_init(nn.Module(), 1, 1, 3, **kwargs)


def test_adapter_install_rejects_preinitialized_foreign_backend(monkeypatch) -> None:
    trellis2 = ModuleType("trellis2")
    modules = ModuleType("trellis2.modules")
    sparse = ModuleType("trellis2.modules.sparse")
    config = ModuleType("trellis2.modules.sparse.config")
    config.CONV = "flex_gemm"
    conv_package = ModuleType("trellis2.modules.sparse.conv")
    conv = ModuleType("trellis2.modules.sparse.conv.conv")
    conv._backends = {"flex_gemm": object()}
    trellis2.modules = modules
    modules.sparse = sparse
    sparse.config = config
    sparse.conv = conv_package
    conv_package.conv = conv
    for name, module in {
        "trellis2": trellis2,
        "trellis2.modules": modules,
        "trellis2.modules.sparse": sparse,
        "trellis2.modules.sparse.config": config,
        "trellis2.modules.sparse.conv": conv_package,
        "trellis2.modules.sparse.conv.conv": conv,
    }.items():
        monkeypatch.setitem(sys.modules, name, module)

    with pytest.raises(RuntimeError, match="initialized before"):
        adapter.install_trellis_cpu_sparse_conv_adapter()
