"""CPU contract tests; fake tensor checks are not native MLU qualification."""

import base64
import copy
import importlib.util
import json
import math
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

from genmlu import sdxl_training_resume_checkpoint as checkpoint


PIN = "a" * 64
PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aX1cAAAAASUVORK5CYII="
)


class FakeTruth:
    def __init__(self, value):
        self.value = value

    def all(self):
        return self.value


class FakeTensor:
    def __init__(self, value=1.0, shape=(2,), dtype="float32"):
        self.value, self.shape, self.dtype = value, shape, dtype
        self.device = types.SimpleNamespace(type="cpu")
        self.layout = "strided"

    def clone(self):
        return copy.deepcopy(self)

    def stride(self):
        return (1,) * len(self.shape)

    def numel(self):
        return math.prod(self.shape)

    def item(self):
        return self.value

    def __ge__(self, value):
        return FakeTruth(self.value >= value)


class FakeGenerator:
    def __init__(self):
        self.state = FakeTensor(0, (4,), "uint8")

    def get_state(self):
        return self.state.clone()

    def set_state(self, state):
        checkpoint.require(type(state) is FakeTensor and state.dtype == "uint8", "bad generator state")
        self.state = state.clone()


class FakeBatchSampler:
    def __init__(self, sampler, batch_size, drop_last):
        self.sampler, self.batch_size, self.drop_last = sampler, batch_size, drop_last

    def __iter__(self):
        return iter([[index] for index in self.sampler])

    def __len__(self):
        return len(self.sampler)


def fake_torch():
    result = types.ModuleType("torch")
    result.Tensor, result.Generator = FakeTensor, FakeGenerator
    result.float32, result.float64, result.uint8, result.strided = "float32", "float64", "uint8", "strided"
    result.isfinite = lambda tensor: FakeTruth(math.isfinite(tensor.value))
    result.utils = types.SimpleNamespace(data=types.SimpleNamespace(BatchSampler=FakeBatchSampler))
    return result


class FakeDataset:
    def __init__(self, rows):
        self.rows = rows

    def cast_column(self, _column, image):
        assert image.decode is False
        return self

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        return self.rows[index]

    def add_column(self, name, values):
        return FakeDataset([dict(row, **{name: value}) for row, value in zip(self.rows, values)])


def real_rows(root):
    """Use actual metadata rows and file bytes, not a partial data contract."""
    metadata = [{"file_name": f"sample-{index}.png", "text": f"fixture caption {index}"} for index in range(3)]
    for row in metadata:
        (root / row["file_name"]).write_bytes(PNG)
    (root / "metadata.jsonl").write_text("".join(json.dumps(row) + "\n" for row in metadata), encoding="utf-8")
    rows = [json.loads(line) for line in (root / "metadata.jsonl").read_text(encoding="utf-8").splitlines()]
    dataset = FakeDataset([{"image": {"path": str(root / row["file_name"]), "bytes": None}, "text": row["text"]} for row in rows])
    datasets = types.ModuleType("datasets")
    datasets.Image = lambda **kwargs: types.SimpleNamespace(**kwargs)
    with patch.dict(sys.modules, {"datasets": datasets}):
        return checkpoint.bind_dataset(dataset, "image", "text", root)


def contract(data):
    plan = {
        "seed": 20260911, "max_train_steps": 25, "genmlu_measurement_warmup_steps": 5,
        "mixed_precision": "bf16", "gradient_accumulation_steps": 1, "train_batch_size": 1,
        "dataloader_num_workers": 0, "center_crop": True, "random_flip": False,
        "train_text_encoder": False, "use_8bit_adam": False, "validation_prompt": None,
        "lr_scheduler": "constant", "lr_warmup_steps": 0, "genmlu_full_checkpoint": True,
        "learning_rate": 1e-4, "rank": 4, "resolution": 512, "genmlu_runtime_image_id": "sha256:" + PIN,
        "checkpointing_steps": 10, "checkpoints_total_limit": 5, "genmlu_checkpoint_steps": "11,21,25",
    }
    imports = {name: {"origin": f"/fixture/{name}/__init__.py", "sha256": PIN, "version": "fixture"}
               for name in ("torch", "numpy", "accelerate", "diffusers", "peft", "transformers", "datasets", "torchvision", "torch_mlu")}
    return {
        "plan": plan, "weights_sha256": PIN, "data": data, "diffusers_revision": checkpoint.DIFFUSERS_REVISION,
        "source_sha256": PIN, "helper_sha256": PIN, "backend_sha256": PIN, "imports": imports,
        "parameters": [{"name": "lora.weight", "dtype": "torch.float32", "shape": [2]}], "buffers": [],
        "optimizer": {"module": "torch.optim.adamw", "class": "AdamW", "source_sha256": PIN},
        "scheduler": {"module": "torch.optim.lr_scheduler", "class": "LambdaLR", "source_sha256": PIN},
        "lora_policy": {"unet": {"r": {"default": 4}, "scaling": {"default": 1.0}}}, "mlu": True,
    }


def write_checkpoint(root, identity):
    directory = root / "checkpoint-10"
    directory.mkdir()
    for name in checkpoint.FILES:
        (directory / name).write_bytes(b"fixture-" + name.encode())
    document = {"schema": checkpoint.SCHEMA, "boundary": "after-complete-optimizer-scheduler-update", "step": 10,
                "next_step": 11, "contract": identity, "state_sha256": PIN,
                "files": {name: {"bytes": (directory / name).stat().st_size, "sha256": checkpoint.file_sha(directory / name)}
                          for name in checkpoint.FILES}}
    rewrite_manifest(directory, document)
    return directory, document


def rewrite_manifest(directory, document):
    document.pop("integrity_sha256", None)
    document["integrity_sha256"] = checkpoint.json_sha(document)
    (directory / checkpoint.MANIFEST).write_text(json.dumps(document), encoding="utf-8")


class NativeDeviceTests(unittest.TestCase):
    def test_unspecified_ordinal_resolves_only_to_the_single_current_mlu(self):
        def device(kind, ordinal=None):
            return types.SimpleNamespace(type=kind, index=ordinal)

        sdk = types.SimpleNamespace(device_count=lambda: 1, current_device=lambda: 0)
        torch = types.SimpleNamespace(mlu=sdk, device=device)
        for ordinal in (None, 0):
            resolved = checkpoint.native_training_device(types.SimpleNamespace(device=device("mlu", ordinal)), torch)
            self.assertEqual((resolved.type, resolved.index), ("mlu", 0))
        for kind, ordinal, count, current in (("cpu", None, 1, 0), ("mlu", 1, 1, 0),
                                             ("mlu", None, 2, 0), ("mlu", None, 1, 1)):
            sdk.device_count = lambda: count
            sdk.current_device = lambda: current
            with self.subTest(kind=kind, ordinal=ordinal, count=count, current=current):
                with self.assertRaises(checkpoint.CheckpointError):
                    checkpoint.native_training_device(types.SimpleNamespace(device=device(kind, ordinal)), torch)


class ContractTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.dataset, self.data = real_rows(self.root)
        self.identity = contract(self.data)

    def test_actual_metadata_rows_and_exact_plan_identity(self):
        checkpoint.validate_contract(self.identity, expected=copy.deepcopy(self.identity))
        self.assertEqual([row["genmlu_sample_id"] for row in self.dataset.rows], [0, 1, 2])
        self.assertEqual(self.data["records"][0]["sha256"], checkpoint.file_sha(self.root / "sample-0.png"))
        for key, value in (("seed", 2), ("max_train_steps", 26), ("genmlu_measurement_warmup_steps", 0),
                           ("genmlu_runtime_image_id", "sha256:" + "b" * 64)):
            changed = copy.deepcopy(self.identity)
            changed["plan"][key] = value
            with self.subTest(key=key), self.assertRaises(checkpoint.CheckpointError):
                checkpoint.validate_contract(changed, expected=self.identity)
        for key in ("source_sha256", "helper_sha256", "backend_sha256", "weights_sha256"):
            changed = copy.deepcopy(self.identity)
            changed[key] = "b" * 64
            with self.subTest(key=key), self.assertRaises(checkpoint.CheckpointError):
                checkpoint.validate_contract(changed, expected=self.identity)

    def test_semantic_contract_corruption_not_hidden_by_rehash(self):
        for mutate in (
            lambda value: value["plan"].update(train_batch_size=True),
            lambda value: value["plan"].update(dataloader_num_workers=2),
            lambda value: value["plan"].update(learning_rate=float("inf")),
            lambda value: value["data"]["records"][1].update(id=0),
            lambda value: value["data"]["records"][1].update(path="../escape.png"),
            lambda value: value["data"]["records"][1].update(path="sample-0.png"),
            lambda value: value["imports"].pop("torch_mlu"),
            lambda value: value["optimizer"].update(**{"class": "SGD"}),
        ):
            changed = copy.deepcopy(self.identity)
            mutate(changed)
            changed["data"]["ordered_sha256"] = checkpoint.json_sha(changed["data"]["records"])
            with self.subTest(mutation=mutate), self.assertRaises(checkpoint.CheckpointError):
                checkpoint.validate_contract(changed)

    def test_complete_manifest_checks_actual_files_without_loading_pickle(self):
        directory, document = write_checkpoint(self.root, self.identity)
        self.assertEqual(checkpoint.preflight(directory), document)
        (directory / "optimizer.bin").write_bytes(b"changed")
        with self.assertRaisesRegex(checkpoint.CheckpointError, "integrity mismatch"):
            checkpoint.preflight(directory)

    def test_missing_boundary_and_semantic_manifest_fail_closed(self):
        directory, original = write_checkpoint(self.root, self.identity)
        for field, value in (("next_step", 12), ("step", True), ("boundary", "before-update")):
            changed = copy.deepcopy(original)
            changed[field] = value
            rewrite_manifest(directory, changed)
            with self.subTest(field=field), self.assertRaises(checkpoint.CheckpointError):
                checkpoint.preflight(directory)
        rewrite_manifest(directory, original)
        (directory / "random_states_0.pkl").unlink()
        with self.assertRaises(checkpoint.CheckpointError):
            checkpoint.preflight(directory)
        (directory / checkpoint.MANIFEST).unlink()
        with self.assertRaises(checkpoint.CheckpointError):
            checkpoint.preflight(directory)

    def test_real_row_cursor_counts_consumption_not_prefetch(self):
        torch = fake_torch()
        original = FakeBatchSampler([2, 0, 1], 1, False)
        sampler = checkpoint.make_batch_sampler(original, FakeGenerator(), torch)
        iterator = iter(sampler)
        self.assertEqual(next(iterator), [2])
        self.assertEqual(next(iterator), [0])
        self.assertEqual(sampler.consumed, 0)
        sampler.consume([2])
        saved = sampler.state_dict()
        restored = checkpoint.make_batch_sampler(original, FakeGenerator(), torch)
        restored.load_state_dict(saved)
        self.assertEqual(list(restored), [[0], [1]])
        self.assertEqual(self.data["records"][next(iter(restored))[0]]["path"], "sample-0.png")
        with self.assertRaises(checkpoint.CheckpointError):
            restored.consume([1])
        with self.assertRaises(checkpoint.CheckpointError):
            restored.set_epoch(1)
        restored.consume([0])
        restored.consume([1])
        with self.assertRaises(checkpoint.CheckpointError):
            restored.consume([])
        restored.set_epoch(1)
        self.assertEqual(list(restored), [[2], [0], [1]])

    def test_checkpoint10_and20_have_exact_next_sample_without_warm_updates(self):
        for step in (10, 20):
            generator = FakeGenerator()
            sampler = checkpoint.make_batch_sampler(FakeBatchSampler([2, 0, 1], 1, False), generator, fake_torch())
            saved = {"epoch": step // 3, "consumed": step % 3, "order": [2, 0, 1], "generator": generator.get_state()}
            sampler.load_state_dict(saved)
            checkpoint.validate_cursor(saved, len(self.data["records"]))
            self.assertEqual(saved["epoch"] * 3 + saved["consumed"], step)
            self.assertEqual(next(iter(sampler)), [[2, 0, 1][step % 3]])
            for field, value in (("order", [2, 0, 0]), ("consumed", 4), ("epoch", True)):
                changed = copy.deepcopy(saved)
                changed[field] = value
                with self.subTest(step=step, field=field), self.assertRaises(checkpoint.CheckpointError):
                    sampler.load_state_dict(changed)


def state_fixture(step=10):
    session = checkpoint.NativeCheckpointSession.__new__(checkpoint.NativeCheckpointSession)
    session.named = [("lora.weight", FakeTensor())]
    session.counts = {"lora.weight": 0}
    session.sampler = [0, 1, 2]
    session.mlu = True
    group = {"params": [0], "lr": 1e-4, "betas": (0.9, 0.999), "eps": 1e-8,
             "weight_decay": 0.01, "amsgrad": False, "foreach": None, "maximize": False,
             "capturable": False, "differentiable": False, "fused": None}
    live = {
        "parameters": {"lora.weight": FakeTensor()}, "buffers": {}, "adapter": {"unet.lora.weight": FakeTensor()},
        "optimizer": {"state": {}, "param_groups": [group]}, "optimizer_names": [["lora.weight"]],
        "optimizer_placements": {0: {}}, "parameter_update_counts": {"lora.weight": 0},
        "scheduler": {"last_epoch": 0, "_step_count": 1, "base_lrs": [1e-4], "_last_lr": [1e-4],
                      "lr_lambdas": [None], "_get_lr_called_within_step": False},
        "accelerator_step": 0, "rng": {"fake": True},
        "data": {"epoch": 0, "consumed": 0, "order": None, "generator": FakeTensor(0, (4,), "uint8")},
    }
    session.capture_state = lambda: copy.deepcopy(live)
    state = copy.deepcopy(live)
    state["optimizer"]["state"][0] = {"step": FakeTensor(step, ()), "exp_avg": FakeTensor(), "exp_avg_sq": FakeTensor()}
    state["optimizer_placements"][0] = {"step": "cpu", "exp_avg": "cpu", "exp_avg_sq": "cpu"}
    state["parameter_update_counts"]["lora.weight"] = step
    state["scheduler"].update(last_epoch=step, _step_count=step + 1)
    state["accelerator_step"] = step
    state["data"].update(epoch=step // 3, consumed=step % 3, order=[2, 0, 1])
    return session, state


class StatePolicyTests(unittest.TestCase):
    def test_mlu_rng_uses_private_clone_and_rejects_alias_or_sdk_failure(self):
        import random
        import numpy as np

        torch = fake_torch()
        tensor = FakeTensor(7, (4,), "uint8")
        tensor.ndim = 1
        tensor.cpu = lambda: tensor
        state = {"python": random.getstate(), "numpy": np.random.get_state(),
                 "torch_cpu": FakeGenerator().get_state(), "mlu": [tensor]}
        live = types.SimpleNamespace()
        probe = types.SimpleNamespace(set_state=lambda value: None, get_state=lambda: tensor)
        live.clone_state = lambda: probe
        torch.mlu = types.SimpleNamespace(default_generators=[live])
        torch.equal = lambda left, right: left.value == right.value
        with patch.dict(sys.modules, {"torch": torch}):
            checkpoint.validate_rng(state, True)
            live.clone_state = lambda: live
            with self.assertRaisesRegex(checkpoint.CheckpointError, "aliases"):
                checkpoint.validate_rng(state, True)
            def unavailable():
                raise RuntimeError("no private SDK clone API")
            live.clone_state = unavailable
            with self.assertRaisesRegex(checkpoint.CheckpointError, "independently"):
                checkpoint.validate_rng(state, True)

    def test_safe_global_membership_ignores_order_but_not_aliases_or_duplicates(self):
        baseline = [FakeTensor, (FakeTensor, "numpy.core.multiarray._reconstruct"),
                    (FakeTensor, "numpy._core.multiarray._reconstruct")]
        self.assertCountEqual(list(reversed(baseline)), baseline)
        for changed in (
            baseline + [FakeTensor],
            baseline + [unsafe_reduce_target],
            baseline[:-1] + [(FakeTensor, "unapproved.alias")],
            baseline[:-1],
        ):
            with self.subTest(changed=changed), self.assertRaises(AssertionError):
                self.assertCountEqual(changed, baseline)

    def test_complete_adamw_scheduler_cursor_are_validated_without_apply(self):
        session, state = state_fixture()
        before = copy.deepcopy(session.counts)
        with patch.dict(sys.modules, {"torch": fake_torch()}), patch.object(checkpoint, "validate_rng") as rng:
            session.validate_state(state, 10)
        rng.assert_called_once_with(state["rng"], True)
        self.assertEqual(session.counts, before)

    def test_adamw_unknown_missing_nonfinite_and_policy_state_rejected(self):
        for mutate in (
            lambda value: value["optimizer_names"][0].__setitem__(0, "wrong.name"),
            lambda value: value["optimizer"]["state"].clear(),
            lambda value: value["optimizer"]["state"][0].update(max_exp_avg_sq=FakeTensor()),
            lambda value: value["optimizer"]["state"][0].update(step=FakeTensor(9, ())),
            lambda value: value["optimizer"]["state"][0].update(exp_avg=FakeTensor(float("nan"))),
            lambda value: value["optimizer"]["state"][0].update(exp_avg_sq=FakeTensor(-1.0)),
            lambda value: value["optimizer"]["param_groups"][0].update(lr=2e-4),
            lambda value: value["optimizer"]["param_groups"][0].update(amsgrad=True),
            lambda value: value["optimizer"]["param_groups"][0].update(amsgrad=0),
            lambda value: value["optimizer"]["param_groups"][0].update(betas=[0.9, 0.999]),
            lambda value: value["optimizer_placements"][0].update(exp_avg="cuda:0"),
            lambda value: value["parameter_update_counts"].update(**{"lora.weight": True}),
        ):
            session, state = state_fixture()
            mutate(state)
            with self.subTest(mutation=mutate), patch.dict(sys.modules, {"torch": fake_torch()}), \
                    patch.object(checkpoint, "validate_rng"), self.assertRaises(checkpoint.CheckpointError):
                session.validate_state(state, 10)
            self.assertEqual(session.counts, {"lora.weight": 0})

    def test_scheduler_rng_and_rehashed_cursor_fail_before_mutation(self):
        for mutate in (
            lambda value: value["scheduler"].update(last_epoch=9),
            lambda value: value["scheduler"].update(_step_count=True),
            lambda value: value["scheduler"].update(_get_lr_called_within_step=True),
            lambda value: value["data"].update(consumed=2),
            lambda value: value["data"].update(order=[2, 0, 0]),
            lambda value: value["data"].update(generator="missing"),
            lambda value: value["parameters"].update(**{"lora.weight": FakeTensor(float("inf"))}),
        ):
            session, state = state_fixture()
            mutate(state)
            with self.subTest(mutation=mutate), patch.dict(sys.modules, {"torch": fake_torch()}), \
                    patch.object(checkpoint, "validate_rng"), self.assertRaises(checkpoint.CheckpointError):
                session.validate_state(state, 10)
        session, state = state_fixture()
        with patch.dict(sys.modules, {"torch": fake_torch()}), \
                patch.object(checkpoint, "validate_rng", side_effect=checkpoint.CheckpointError("bad RNG")), \
                self.assertRaisesRegex(checkpoint.CheckpointError, "bad RNG"):
            session.validate_state(state, 10)

    def test_restricted_loader_exact_aliases_and_restoration_on_error(self):
        import numpy as np

        torch = fake_torch()
        entries, calls, active = [], [], []

        class ScopedGlobals:
            def __init__(self, values):
                self.values = values

            def __enter__(self):
                entries.extend(self.values)
                active.extend(self.values)

            def __exit__(self, *_args):
                active.clear()

        def load(path, **kwargs):
            calls.append((path, kwargs, list(active)))
            raise RuntimeError("injected restricted load failure")

        torch.serialization = types.SimpleNamespace(safe_globals=ScopedGlobals)
        torch.load = load
        with patch.dict(sys.modules, {"torch": torch}), patch.object(np, "_core", types.SimpleNamespace(), create=True):
            with self.assertRaises(checkpoint.CheckpointError):
                checkpoint.restricted_load(Path("random_states_0.pkl"), numpy_rng=True)
            self.assertEqual(active, [])
            with self.assertRaises(checkpoint.CheckpointError):
                checkpoint.restricted_load(Path("optimizer.bin"))
        self.assertEqual([entry[1] for entry in entries[:2]],
                         ["numpy.core.multiarray._reconstruct", "numpy._core.multiarray._reconstruct"])
        self.assertEqual(entries[2:], [np.ndarray, np.dtype, type(np.dtype(np.uint32))])
        self.assertEqual(len(calls), 2)
        self.assertTrue(all(call[1] == {"map_location": "cpu", "weights_only": True} for call in calls))
        self.assertEqual(calls[1][2], [])


UNSAFE_CALLS = []


def unsafe_reduce_target():
    UNSAFE_CALLS.append(True)
    return "executed"


class MaliciousPayload:
    def __reduce__(self):
        return unsafe_reduce_target, ()


@unittest.skipUnless(importlib.util.find_spec("torch") and importlib.util.find_spec("numpy"), "genuine CPU Torch unavailable")
class GenuineTorchTests(unittest.TestCase):
    def test_mt19937_roundtrip_and_signed_zero_bytes(self):
        import numpy as np
        import torch

        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "rng.pt"
            original = checkpoint.capture_rng(False)
            torch.save(original, path)
            loaded = checkpoint.restricted_load(path, numpy_rng=True)
            checkpoint.validate_rng(loaded, False)
            self.assertEqual(checkpoint.state_sha(original), checkpoint.state_sha(loaded))
            self.assertNotEqual(checkpoint.state_sha(torch.tensor([0.0])), checkpoint.state_sha(torch.tensor([-0.0])))
            invalid = copy.deepcopy(loaded)
            invalid["numpy"] = ("MT19937", np.zeros(624, dtype=np.float32), 0, 0, 0.0)
            with self.assertRaises(checkpoint.CheckpointError):
                checkpoint.validate_rng(invalid, False)

    def test_malicious_reduce_and_unsupported_numpy_dtype_do_not_load(self):
        import numpy as np
        import torch

        UNSAFE_CALLS.clear()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "unsafe.pt"
            before = list(torch.serialization.get_safe_globals())
            torch.save({"value": MaliciousPayload()}, path)
            with self.assertRaises(checkpoint.CheckpointError):
                checkpoint.restricted_load(path, numpy_rng=True)
            self.assertEqual(UNSAFE_CALLS, [])
            self.assertCountEqual(torch.serialization.get_safe_globals(), before)
            torch.save(np.ones(624, dtype=np.float32), path)
            with self.assertRaises(checkpoint.CheckpointError):
                checkpoint.restricted_load(path, numpy_rng=True)
            self.assertCountEqual(torch.serialization.get_safe_globals(), before)

    def test_genuine_adamw_slot_and_scheduler_contract(self):
        import torch

        parameter = torch.nn.Parameter(torch.ones(2))
        optimizer = torch.optim.AdamW([parameter], lr=1e-4)
        scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lambda _step: 1.0)
        for _ in range(10):
            parameter.grad = torch.ones_like(parameter)
            optimizer.step()
            scheduler.step()
            optimizer.zero_grad(set_to_none=True)
        session, state = state_fixture()
        session.named = [("lora.weight", parameter)]
        state["parameters"] = {"lora.weight": parameter.detach().clone()}
        state["adapter"] = {"unet.lora.weight": parameter.detach().clone()}
        state["optimizer"] = checkpoint.cpu_tree(optimizer.state_dict())
        state["scheduler"] = scheduler.state_dict()
        state["rng"] = checkpoint.capture_rng(False)
        state["data"]["generator"] = torch.Generator().get_state()
        session.mlu = False
        live = copy.deepcopy(state)
        session.capture_state = lambda: copy.deepcopy(live)
        session.validate_state(state, 10)
        state["optimizer"]["state"][0]["exp_avg"].fill_(float("nan"))
        with self.assertRaises(checkpoint.CheckpointError):
            session.validate_state(state, 10)


if __name__ == "__main__":
    unittest.main()
