from __future__ import annotations

import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class TrellisModelResidencyContractTests(unittest.TestCase):
    def setUp(self):
        self.source = (ROOT / "src/genmlu/backends/trellis2_generation.py").read_text(
            encoding="utf-8"
        )
        self.tree = ast.parse(self.source)

    def test_residency_is_opt_in_in_backend(self):
        self.assertIn('config.get("retain_models_on_mlu", False)', self.source)
        self.assertIn("resident_models.append(model)", self.source)
        self.assertIn("_release(torch, model)", self.source)

    def test_all_five_stage_models_use_the_release_gate(self):
        function = next(
            node for node in self.tree.body
            if isinstance(node, ast.FunctionDef) and node.name == "run_trellis2_inference"
        )
        calls = [
            node for node in ast.walk(function)
            if isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "release_stage"
        ]
        self.assertEqual(len(calls), 5)


if __name__ == "__main__":
    unittest.main()
