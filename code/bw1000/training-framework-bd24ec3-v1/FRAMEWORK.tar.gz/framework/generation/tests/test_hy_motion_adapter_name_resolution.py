import unittest

from genmlu.backends.hy_motion_motionrft import _resolve_adapter_parameter_names


class HYMotionAdapterNameResolutionTest(unittest.TestCase):
    def test_loads_checkpoint_wrapped_state_into_unwrapped_model(self) -> None:
        state_names = {
            "double_blocks.0._checkpoint_wrapped_module.motion_mlp.fc1.lora_A",
            "double_blocks.0._checkpoint_wrapped_module.motion_mlp.fc1.lora_B",
        }
        parameter_names = {
            "double_blocks.0.motion_mlp.fc1.lora_A",
            "double_blocks.0.motion_mlp.fc1.lora_B",
        }
        self.assertEqual(
            _resolve_adapter_parameter_names(state_names, parameter_names),
            {
                "double_blocks.0._checkpoint_wrapped_module.motion_mlp.fc1.lora_A": "double_blocks.0.motion_mlp.fc1.lora_A",
                "double_blocks.0._checkpoint_wrapped_module.motion_mlp.fc1.lora_B": "double_blocks.0.motion_mlp.fc1.lora_B",
            },
        )

    def test_loads_unwrapped_state_into_checkpoint_wrapped_model(self) -> None:
        state_names = {"double_blocks.0.motion_mlp.fc1.lora_A"}
        parameter_names = {
            "double_blocks.0._checkpoint_wrapped_module.motion_mlp.fc1.lora_A"
        }
        self.assertEqual(
            _resolve_adapter_parameter_names(state_names, parameter_names),
            {
                "double_blocks.0.motion_mlp.fc1.lora_A": "double_blocks.0._checkpoint_wrapped_module.motion_mlp.fc1.lora_A"
            },
        )

    def test_rejects_an_ambiguous_canonical_parameter_name(self) -> None:
        with self.assertRaisesRegex(RuntimeError, "collide"):
            _resolve_adapter_parameter_names(
                {"double_blocks.0.motion_mlp.fc1.lora_A"},
                {
                    "double_blocks.0.motion_mlp.fc1.lora_A",
                    "double_blocks.0._checkpoint_wrapped_module.motion_mlp.fc1.lora_A",
                },
            )


if __name__ == "__main__":
    unittest.main()
