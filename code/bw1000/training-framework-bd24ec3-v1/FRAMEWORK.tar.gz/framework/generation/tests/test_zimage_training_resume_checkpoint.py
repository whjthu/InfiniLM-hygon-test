from __future__ import annotations

import copy
import random

import numpy as np
import pytest
import torch

from genmlu import hy_resume_checkpoint as common
from genmlu import zimage_training_resume_checkpoint as resume


def set_timesteps() -> None:
    pass


set_timesteps.__module__ = "diffsynth.diffusion.flow_match"
set_timesteps.__qualname__ = "FlowMatchScheduler.set_timesteps_z_image"


class Scheduler:
    def __init__(self) -> None:
        self.set_timesteps_fn = set_timesteps
        self.num_train_timesteps = 1000
        self.training = True
        self.timesteps = torch.arange(1000, dtype=torch.float32)


def make_contract() -> dict:
    return resume.build_contract(
        identity={key: "a" * 64 for key in resume.IDENTITY_FIELDS},
        seed=91,
        max_steps=8,
        sample_order=["row:0", "row:1", "row:2"],
        device_ids=[],
    )


def make_model(seed: int) -> tuple[torch.nn.Module, torch.optim.AdamW]:
    torch.manual_seed(seed)
    model = torch.nn.Sequential(torch.nn.Linear(3, 4), torch.nn.Tanh(), torch.nn.Linear(4, 2))
    return model, torch.optim.AdamW(model.parameters(), lr=3e-3, weight_decay=0.01)


def train_step(model: torch.nn.Module, optimizer: torch.optim.AdamW) -> float:
    optimizer.zero_grad(set_to_none=True)
    values = torch.randn(5, 3) + random.random() + float(np.random.rand())
    loss = model(values).square().mean()
    loss.backward()
    optimizer.step()
    return float(loss.detach())


def payload_at(step: int = 3):
    random.seed(4)
    np.random.seed(5)
    torch.manual_seed(6)
    contract = make_contract()
    model, optimizer = make_model(7)
    scheduler = Scheduler()
    progress = common.initial_optimizer_progress(model, optimizer)
    for _ in range(step):
        train_step(model, optimizer)
        progress = common.advance_optimizer_progress(progress, model, optimizer)
    expected_scheduler = resume.scheduler_spec(scheduler)
    contract["identity"]["scheduler"] = common.tree_sha256(expected_scheduler)
    payload = resume.make_payload(
        contract=contract, global_step=step, model=model, optimizer=optimizer,
        optimizer_progress=progress, scheduler=scheduler, expected_scheduler=expected_scheduler,
    )
    return contract, model, optimizer, scheduler, progress, expected_scheduler, payload


def test_restores_full_boundary_and_exact_next_cpu_update() -> None:
    contract, model, optimizer, scheduler, progress, expected, payload = payload_at()
    continuous_loss = train_step(model, optimizer)
    progress = common.advance_optimizer_progress(progress, model, optimizer)
    continuous = common.tree_sha256(common.capture_model_state(model, optimizer, progress))

    target, target_optimizer = make_model(71)
    target_scheduler = Scheduler()
    restored_progress, checked = resume.restore_checkpoint(
        payload, contract, target, target_optimizer, target_scheduler, expected
    )
    resume.assert_restored_boundary(
        payload, target, target_optimizer, restored_progress, target_scheduler, []
    )
    resumed_loss = train_step(target, target_optimizer)
    restored_progress = common.advance_optimizer_progress(restored_progress, target, target_optimizer)
    resumed = common.tree_sha256(common.capture_model_state(target, target_optimizer, restored_progress))

    assert checked["next"] == {
        "global_step": 4, "sample_cursor": 0, "sample_id": "row:0", "step_seed": 95,
    }
    assert resumed_loss == continuous_loss
    assert resumed == continuous


@pytest.mark.parametrize("corruption", ["identity", "scheduler", "legacy"])
def test_rejects_corrupt_or_mismatched_checkpoint_before_mutation(corruption: str) -> None:
    contract, _model, _optimizer, _scheduler, _progress, expected, payload = payload_at()
    candidate = copy.deepcopy(payload)
    if corruption == "identity":
        candidate["metadata"]["contract"]["identity"]["config"] = "b" * 64
    elif corruption == "scheduler":
        candidate["scheduler"]["training"] = False
    else:
        candidate = {"step": 3, "adapter": payload["state"]["trainable"]}
    if corruption != "legacy":
        candidate["integrity_sha256"] = common.tree_sha256(
            {key: value for key, value in candidate.items() if key != "integrity_sha256"}
        )
    target, target_optimizer = make_model(71)
    target_scheduler = Scheduler()
    before = common.tree_sha256({
        "state": common.capture_model_state(
            target, target_optimizer, common.initial_optimizer_progress(target, target_optimizer)
        ),
        "scheduler": resume.scheduler_spec(target_scheduler),
        "rng": common.capture_rng([]),
    })
    with pytest.raises((resume.CheckpointValidationError, common.CheckpointValidationError, ValueError)):
        resume.restore_checkpoint(candidate, contract, target, target_optimizer, target_scheduler, expected)
    after = common.tree_sha256({
        "state": common.capture_model_state(
            target, target_optimizer, common.initial_optimizer_progress(target, target_optimizer)
        ),
        "scheduler": resume.scheduler_spec(target_scheduler),
        "rng": common.capture_rng([]),
    })
    assert after == before


def test_rejects_current_scheduler_identity_mismatch() -> None:
    contract, _model, _optimizer, _scheduler, _progress, expected, payload = payload_at()
    target, target_optimizer = make_model(71)
    target_scheduler = Scheduler()
    target_scheduler.num_train_timesteps = 999
    with pytest.raises(resume.CheckpointValidationError, match="scheduler state or implementation mismatch"):
        resume.validate_checkpoint(payload, contract, target, target_optimizer, resume.scheduler_spec(target_scheduler), native_rng=False)


def test_cpu_preflight_rejects_empty_boundary_and_requested_schedule_mismatch() -> None:
    _contract, _model, _optimizer, _scheduler, _progress, _expected, payload = payload_at(step=3)
    config = {"seed": 91, "max_steps": 8, "learning_rate": 3e-3, "weight_decay": 0.01}
    resume.preflight_checkpoint(payload, requested_config=config)

    empty_boundary = copy.deepcopy(payload)
    empty_boundary["state"] = {}
    empty_boundary["rng"] = {}
    empty_boundary["adapter_sha256"] = common.tree_sha256({})
    empty_boundary["integrity_sha256"] = common.tree_sha256(
        {key: value for key, value in empty_boundary.items() if key != "integrity_sha256"}
    )
    with pytest.raises(resume.CheckpointValidationError, match="checkpoint model state fields mismatch"):
        resume.preflight_checkpoint(empty_boundary, requested_config=config)

    malformed_rng = copy.deepcopy(payload)
    malformed_rng["rng"] = {}
    malformed_rng["integrity_sha256"] = common.tree_sha256(
        {key: value for key, value in malformed_rng.items() if key != "integrity_sha256"}
    )
    with pytest.raises(resume.CheckpointValidationError, match="missing RNG stream"):
        resume.preflight_checkpoint(malformed_rng, requested_config=config)

    malformed_shape = copy.deepcopy(payload)
    parameter_id = next(iter(malformed_shape["state"]["optimizer"]["state"]))
    malformed_shape["state"]["optimizer"]["state"][parameter_id]["exp_avg"] = torch.zeros(99)
    malformed_shape["integrity_sha256"] = common.tree_sha256(
        {key: value for key, value in malformed_shape.items() if key != "integrity_sha256"}
    )
    with pytest.raises(resume.CheckpointValidationError, match="AdamW exp_avg/.+ shape or dtype mismatch"):
        resume.preflight_checkpoint(malformed_shape, requested_config=config)

    malformed_adapter = copy.deepcopy(payload)
    malformed_adapter["state"]["trainable"][next(iter(malformed_adapter["state"]["trainable"]))].add_(1)
    malformed_adapter["integrity_sha256"] = common.tree_sha256(
        {key: value for key, value in malformed_adapter.items() if key != "integrity_sha256"}
    )
    with pytest.raises(resume.CheckpointValidationError, match="adapter SHA mismatch"):
        resume.preflight_checkpoint(malformed_adapter, requested_config=config)

    with pytest.raises(resume.CheckpointValidationError, match="checkpoint seed does not match"):
        resume.preflight_checkpoint(payload, requested_config={**config, "seed": 92})
    with pytest.raises(resume.CheckpointValidationError, match="checkpoint max_steps does not match"):
        resume.preflight_checkpoint(payload, requested_config={**config, "max_steps": 2})

    _contract, _model, _optimizer, _scheduler, _progress, _expected, complete = payload_at(step=8)
    with pytest.raises(resume.CheckpointValidationError, match="checkpoint already completed"):
        resume.preflight_checkpoint(complete, requested_config=config)
