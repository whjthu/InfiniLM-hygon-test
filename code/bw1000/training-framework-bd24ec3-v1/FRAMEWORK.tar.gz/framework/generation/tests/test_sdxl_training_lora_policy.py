"""LoRA metadata gates; the real tiny-UNet fixture is CPU-only, not MLU acceptance."""
import importlib.util
import os
from types import SimpleNamespace

import pytest

from genmlu import sdxl_training_resume_checkpoint as checkpoint


def leaf():
    return SimpleNamespace(r={"default": 2, "other": 4}, lora_alpha={"default": 4, "other": 8},
                           scaling={"default": 2.0, "other": 2.0}, use_dora={"default": False, "other": False},
                           active_adapters=["default"], disable_adapters=False, merged=False, merged_adapters=[])


class Root:
    def __init__(self):
        self.layer = leaf()
        self.getter_calls = 0

    def active_adapters(self):
        self.getter_calls += 1
        return list(self.layer.active_adapters)

    def disable_adapters(self):
        raise AssertionError("policy capture must never invoke the root mutating API")

    def named_modules(self):
        return [("", self), ("to_q", self.layer)]


def test_callable_root_and_list_leaf_are_canonical_without_mutation():
    model = Root()
    policy = checkpoint._policy(model)
    assert model.getter_calls == 1
    assert policy[""] == {"active_adapters": ["default"]}
    assert policy["to_q"] == {key: value for key, value in vars(model.layer).items()
                              if key not in ("merged", "merged_adapters")}
    assert policy["to_q"]["disable_adapters"] is False
    model.layer.scaling["default"] = 0.5
    assert policy["to_q"]["scaling"]["default"] == 2.0  # Deep, JSON-safe snapshot.


def test_adapter_selection_scaling_and_enabled_state_change_identity():
    model = Root()
    before = checkpoint.json_sha(checkpoint._policy(model))
    model.layer.active_adapters = ["other"]
    selected = checkpoint._policy(model)
    assert selected[""]["active_adapters"] == selected["to_q"]["active_adapters"] == ["other"]
    assert checkpoint.json_sha(selected) != before
    before = checkpoint.json_sha(selected)
    model.layer.scaling["other"] = 0.5
    assert checkpoint.json_sha(checkpoint._policy(model)) != before
    before = checkpoint.json_sha(checkpoint._policy(model))
    model.layer.disable_adapters = True
    assert checkpoint.json_sha(checkpoint._policy(model)) != before


def test_string_getter_preserves_the_single_adapter_name():
    model = Root()
    model.active_adapters = lambda: "default"
    assert checkpoint._policy(model)[""]["active_adapters"] == ["default"]


@pytest.mark.parametrize("invalid", [None, [], [""], ["default", "default"], [False], ("default",), {"default"}])
def test_invalid_global_getter_result_fails_closed(invalid):
    model = Root()
    model.active_adapters = lambda: invalid
    with pytest.raises(checkpoint.CheckpointError, match="active adapter selection"):
        checkpoint._policy(model)


@pytest.mark.parametrize("field,value", [
    ("r", {"default": True, "other": 4}), ("r", {"default": 0, "other": 4}),
    ("r", {}), ("lora_alpha", {"default": float("nan"), "other": 8}),
    ("scaling", {"default": float("inf"), "other": 2.0}),
    ("scaling", {"default": lambda: 2.0, "other": 2.0}),
    ("scaling", {"default": 2.0}), ("use_dora", {"default": 0, "other": False}),
    ("disable_adapters", lambda: False), ("active_adapters", ["missing"]),
    ("merged", True), ("merged", None), ("merged_adapters", ["default"]), ("merged_adapters", ()),
])
def test_invalid_layer_metadata_is_not_stringified_or_dropped(field, value):
    model = Root()
    setattr(model.layer, field, value)
    with pytest.raises(checkpoint.CheckpointError):
        checkpoint._policy(model)


@pytest.mark.parametrize("field", ["r", "lora_alpha", "scaling", "use_dora", "active_adapters",
                                   "merged", "merged_adapters"])
def test_missing_layer_fields_fail_closed(field):
    model = Root()
    delattr(model.layer, field)
    if field == "active_adapters":
        model.active_adapters = lambda: ["default"]
    with pytest.raises(checkpoint.CheckpointError):
        checkpoint._policy(model)


def test_real_cpu_diffusers_unet_and_peft_lora_metadata():
    names = ("torch", "diffusers", "peft", "transformers", "huggingface_hub")
    missing = [name for name in names if importlib.util.find_spec(name) is None]
    if missing:
        if os.environ.get("GENMLU_REQUIRE_SDXL_POLICY_REAL") == "1":
            pytest.fail("mandatory CPU policy dependencies missing: " + ", ".join(missing))
        pytest.skip("real CPU metadata fixture unavailable: " + ", ".join(missing))
    import torch
    import diffusers
    import peft
    from diffusers import UNet2DConditionModel
    from peft import LoraConfig

    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(20261010)
        model = UNet2DConditionModel(sample_size=8, in_channels=4, out_channels=4, layers_per_block=1,
                    block_out_channels=(8, 16), down_block_types=("CrossAttnDownBlock2D", "DownBlock2D"),
                    up_block_types=("UpBlock2D", "CrossAttnUpBlock2D"), cross_attention_dim=8,
                    attention_head_dim=4, norm_num_groups=4)
        config = LoraConfig(r=2, lora_alpha=4, target_modules=["to_q", "to_k", "to_v", "to_out.0"])
        model.add_adapter(config, adapter_name="default")
        assert callable(model.active_adapters)
        layers = [(name, module) for name, module in model.named_modules() if hasattr(module, "lora_A")]
        assert layers and all(type(module.active_adapters) is list for _, module in layers)
        assert all(parameter.device.type == "cpu" for parameter in model.parameters())
        before = checkpoint._policy(model)
        assert before[""] == {"active_adapters": ["default"]}
        for name, _ in layers:
            assert before[name] == {"r": {"default": 2}, "lora_alpha": {"default": 4},
                "scaling": {"default": 2.0}, "use_dora": {"default": False},
                "active_adapters": ["default"], "disable_adapters": False}
        model.add_adapter(config, adapter_name="other")
        model.set_adapters("other")
        selected = checkpoint._policy(model)
        assert selected[""]["active_adapters"] == ["other"]
        assert all(selected[name]["active_adapters"] == ["other"] for name, _ in layers)
        assert checkpoint.json_sha(before) != checkpoint.json_sha(selected)
        layers[0][1].set_scale("other", 0.75)
        scaled = checkpoint._policy(model)
        assert scaled[layers[0][0]]["scaling"]["other"] == 1.5
        assert checkpoint.json_sha(selected) != checkpoint.json_sha(scaled)
        model.disable_adapters()
        disabled = checkpoint._policy(model)
        assert all(disabled[name]["disable_adapters"] is True for name, _ in layers)
        assert checkpoint.json_sha(disabled) != checkpoint.json_sha(scaled)
        model.enable_adapters()
        assert checkpoint._policy(model) == scaled
        layers[0][1].merge()
        with pytest.raises(checkpoint.CheckpointError, match="unmerged LoRA"):
            checkpoint._policy(model)
        layers[0][1].unmerge()
        assert checkpoint._policy(model) == scaled
        print({"scope": "real CPU tiny-UNet/PEFT metadata only; no forward/MLU acceptance",
               "diffusers": diffusers.__version__, "diffusers_origin": diffusers.__file__,
               "peft": peft.__version__, "peft_origin": peft.__file__, "lora_layers": len(layers)})
