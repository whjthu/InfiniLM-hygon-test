from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from genmlu.manifest import sha256_path
from genmlu.trellis_sparse_support import (
    admit_native_support, validate_arrays, validate_limit, validate_proof, write_proof,
)


def support(count=16, retained=None):
    native = np.column_stack((np.zeros(count), np.zeros(count), np.zeros(count), np.arange(count))).astype(np.int32)
    selected = np.arange(count if retained is None else retained, dtype=np.int64)
    coords = native[selected].copy()
    return {
        "native": native, "retained": coords, "selection": selected,
        **{key: coords.copy() for key in ("shape_input", "shape_output", "texture_input", "texture_output")},
    }


@pytest.mark.parametrize("value", [True, False, 0, 7, 32769, "1024", 1024.0, None])
def test_invalid_limit(value):
    with pytest.raises(ValueError):
        validate_limit(value)


def test_full_support_admission_boundary():
    admit_native_support(support()["native"], 16, full_mesh=True)
    with pytest.raises(ValueError, match="cannot truncate"):
        admit_native_support(support(17)["native"], 16, full_mesh=True)
    admit_native_support(support(17)["native"], 16, full_mesh=False)


def test_bounded_latent_is_not_full_mesh():
    arrays = support(retained=8)
    assert validate_arrays(arrays, full_mesh=False) == {
        "native_points": 16, "retained_points": 8, "dropped_points": 8, "native_preserved": False,
    }
    with pytest.raises(ValueError, match="all native coordinates"):
        validate_arrays(arrays, full_mesh=True)


@pytest.mark.parametrize("stage", ["shape_input", "shape_output", "texture_input", "texture_output"])
def test_equal_count_does_not_prove_equal_coordinates(stage):
    arrays = support()
    arrays[stage] = arrays[stage][::-1].copy()
    with pytest.raises(ValueError, match="ordered"):
        validate_arrays(arrays, full_mesh=True)


def proof(tmp_path: Path):
    arrays = support()
    evidence = write_proof(tmp_path / "support.npz", arrays, full_mesh=True)
    latent = tmp_path / "latent.npz"
    np.savez_compressed(latent, coords=arrays["retained"], shape_latent=np.zeros((16, 32), np.float32),
                        texture_latent=np.zeros((16, 32), np.float32), condition=np.zeros((1, 1, 1), np.float32),
                        structure_latent=np.zeros((1, 8, 16, 16, 16), np.float32))
    evidence["latent"] = {"path": str(latent), "sha256": sha256_path(latent)}
    return evidence, [evidence["proof"], evidence["latent"]]


def test_proof_binds_latent_and_stage_support(tmp_path):
    evidence, artifacts = proof(tmp_path)
    assert validate_proof(evidence, artifacts, full_mesh=True)["native_preserved"] is True
    evidence["retained_points"] = True
    with pytest.raises(ValueError, match="counts differ"):
        validate_proof(evidence, artifacts, full_mesh=True)


def test_missing_or_unverified_proof_fails_closed():
    with pytest.raises(ValueError, match="missing or invalid"):
        validate_proof(None, [], full_mesh=True)


def test_latent_coordinate_substitution_rejected(tmp_path):
    evidence, artifacts = proof(tmp_path)
    path = Path(evidence["latent"]["path"])
    with np.load(path, allow_pickle=False) as archive:
        arrays = {key: archive[key] for key in archive.files}
    arrays["coords"] = arrays["coords"][::-1].copy()
    np.savez_compressed(path, **arrays)
    evidence["latent"]["sha256"] = sha256_path(path)
    with pytest.raises(ValueError, match="ordered|latent coordinates differ"):
        validate_proof(evidence, artifacts, full_mesh=True)


@pytest.mark.parametrize("limit", [7, 8, True])
def test_manifest_proof_cannot_bypass_configured_budget(tmp_path, limit):
    evidence, artifacts = proof(tmp_path)
    with pytest.raises(ValueError, match="max_sparse_tokens"):
        validate_proof(evidence, artifacts, full_mesh=True, max_sparse_tokens=limit)


def test_native_decoder_logits_and_pooling():
    torch = pytest.importorskip("torch")
    from genmlu.backends.trellis2_generation import _native_structure_coords

    logits = torch.full((1, 1, 64, 64, 64), -1.0)
    logits[:, :, :4, :4, :4] = 1.0
    expected = np.column_stack((np.zeros(8), np.repeat([0, 1], 4), np.tile(np.repeat([0, 1], 2), 2), np.tile([0, 1], 4))).astype(np.int32)
    coords = _native_structure_coords(torch, logits).numpy()
    assert np.array_equal(coords, expected)
    admit_native_support(coords, 8, full_mesh=True)
    with pytest.raises(RuntimeError, match="finite single-batch"):
        _native_structure_coords(torch, logits[:, :, :32])
    logits[0, 0, 63, 63, 63] = float("nan")
    with pytest.raises(RuntimeError, match="finite single-batch"):
        _native_structure_coords(torch, logits)


def test_admission_precedes_sparse_model_loading():
    import ast
    import inspect
    from genmlu.backends.trellis2_generation import run_trellis2_inference

    tree = ast.parse(inspect.getsource(run_trellis2_inference))
    admission = next(n.lineno for n in ast.walk(tree) if isinstance(n, ast.Call)
                     and isinstance(n.func, ast.Name) and n.func.id == "admit_native_support")
    loads = [n.lineno for n in ast.walk(tree) if isinstance(n, ast.Assign)
             and any(isinstance(t, ast.Name) and t.id in {"shape_model", "texture_model"} for t in n.targets)]
    assert len(loads) == 2 and all(admission < line for line in loads)
