from __future__ import annotations

import copy
import inspect
import random

import numpy as np
import pytest
import torch

from genmlu.backends import sdxl_ddpo as backend
from genmlu import hy_resume_checkpoint as common
from genmlu import runtime as runtime_helpers


class TinySdxlAdapter(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.adapter = torch.nn.Linear(3, 2)

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return self.adapter(inputs)


def _identity() -> dict[str, str]:
    return {
        name: format(index, "x") * 64
        for index, name in enumerate(sorted(backend._SDXL_IDENTITY_FIELDS))
    }


def _contract() -> dict:
    return backend._build_checkpoint_contract(
        _identity(),
        {
            "seed": 1701,
            "warmup_steps": 1,
            "max_steps": 5,
            "total_global_steps": 6,
            "batch_size": 4,
            "sample_steps": 4,
        },
        [],
    )


def _model(seed: int) -> tuple[TinySdxlAdapter, torch.optim.AdamW]:
    torch.manual_seed(seed)
    model = TinySdxlAdapter()
    return model, torch.optim.AdamW(model.parameters(), lr=2e-3, betas=(0.8, 0.95))


def _update(
    model: TinySdxlAdapter,
    optimizer: torch.optim.AdamW,
    progress: dict[str, int],
) -> tuple[dict, dict[str, int]]:
    optimizer.zero_grad(set_to_none=True)
    inputs = torch.randn(5, 3) * (0.5 + random.random()) + float(np.random.uniform(-0.1, 0.1))
    targets = torch.randn(5, 2)
    loss = (model(inputs) - targets).square().mean()
    loss.backward()
    optimizer.step()
    progress = common.advance_optimizer_progress(progress, model, optimizer)
    return {
        "loss": loss.detach().clone(),
        "model": common.cpu_tree(dict(model.named_parameters())),
        "optimizer": common.cpu_tree(optimizer.state_dict()),
        "rng": common.capture_rng([]),
    }, progress


def _fingerprint(model: TinySdxlAdapter, optimizer: torch.optim.AdamW) -> str:
    return common.tree_sha256(
        {
            "state": common.capture_model_state(
                model, optimizer, common.initial_optimizer_progress(model, optimizer)
            ),
            "rng": common.capture_rng([]),
        }
    )


def _resign(payload: dict) -> None:
    payload["integrity_sha256"] = common.tree_sha256(
        {key: value for key, value in payload.items() if key != "integrity_sha256"}
    )


def _boundary() -> tuple[TinySdxlAdapter, torch.optim.AdamW, dict[str, int], dict, dict]:
    random.seed(31)
    np.random.seed(32)
    torch.manual_seed(33)
    model, optimizer = _model(34)
    progress = common.initial_optimizer_progress(model, optimizer)
    for _ in range(2):
        _unused, progress = _update(model, optimizer, progress)
    contract = _contract()
    payload = backend._make_checkpoint_payload(contract, 2, model, optimizer, progress)
    return model, optimizer, progress, contract, payload


def test_fresh_restore_matches_the_next_update_exactly() -> None:
    model, optimizer, progress, contract, payload = _boundary()
    continuous, continuous_progress = _update(model, optimizer, progress)

    fresh, fresh_optimizer = _model(99)
    progress, checked = backend._restore_checkpoint(payload, contract, fresh, fresh_optimizer)
    assert checked["metadata"]["next_global_step"] == 3
    assert checked["metadata"]["next_data_cursor"] == 0
    assert checked["metadata"]["next_rollout_seed"] == 1704
    backend._assert_restored_boundary(payload, contract, fresh, fresh_optimizer, progress)
    resumed, resumed_progress = _update(fresh, fresh_optimizer, progress)

    assert common.tree_sha256(continuous) == common.tree_sha256(resumed)
    assert all(value == 3 for value in continuous_progress.values())
    assert all(value == 3 for value in resumed_progress.values())
    assert not getattr(fresh, "_sdxl_resume_poisoned", False)


def test_checkpoint_coordinates_keep_warmup_outside_max_steps() -> None:
    contract = backend._build_checkpoint_contract(
        _identity(),
        {
            "seed": 1701,
            "warmup_steps": 5,
            "max_steps": 20,
            "total_global_steps": 25,
            "batch_size": 4,
            "sample_steps": 4,
        },
        [],
    )

    at_twenty = backend._checkpoint_metadata(contract, 20)
    final = backend._checkpoint_metadata(contract, 25)
    assert at_twenty["completed_measured_updates"] == 15
    assert backend._next_step_record(at_twenty) == {
        "global_step": 21,
        "measured_step": 16,
        "data_cursor": 0,
        "rollout_seed": 1722,
    }
    assert final["completed_measured_updates"] == 20
    assert backend._next_step_record(final)["global_step"] == 26


def test_dependency_drift_is_rejected_before_mutation() -> None:
    _model_at_boundary, _optimizer_at_boundary, _progress, contract, payload = _boundary()
    changed_contract = copy.deepcopy(contract)
    changed_contract["identity"]["dependencies"] = "f" * 64
    fresh, fresh_optimizer = _model(91)
    before = _fingerprint(fresh, fresh_optimizer)

    with pytest.raises(common.CheckpointValidationError, match="identity or schedule"):
        backend._restore_checkpoint(payload, changed_contract, fresh, fresh_optimizer)

    assert _fingerprint(fresh, fresh_optimizer) == before


def test_measurement_window_finalizes_before_optional_recovery() -> None:
    source = inspect.getsource(backend.run_sdxl_ddpo)
    finalization = source.index("checkpoint_final_sha256 = sha256_path(checkpoint)")
    artifact_records = source.index("artifact_records = [")
    window_end = source.index("measurement_window_seconds = time.perf_counter()")
    recovery = source.index("recovery_enabled = validate_recovery_enabled(config)")

    assert finalization < artifact_records < window_end < recovery


def test_dependency_coverage_hashes_the_actual_runtime_helper_sources() -> None:
    runtime_sha = backend._source_sha256(runtime_helpers, "runtime helper module")
    require_mlu_sha = backend._source_sha256(backend.require_mlu, "require_mlu helper")

    assert runtime_sha == common.file_sha256(inspect.getsourcefile(runtime_helpers))
    assert require_mlu_sha == common.file_sha256(inspect.getsourcefile(backend.require_mlu))
    dependency_source = inspect.getsource(backend._dependency_evidence)
    assert "pipe.unet.named_modules()" in dependency_source
    assert '"lora_layers"' in dependency_source


def test_actual_peft_lora_layer_source_is_hashable_when_available() -> None:
    pytest.importorskip("peft")
    from peft.tuners.lora.layer import Linear

    assert backend._source_sha256(Linear, "PEFT LoRA layer") == common.file_sha256(
        inspect.getsourcefile(Linear)
    )


@pytest.mark.parametrize("corruption", ["identity", "cursor", "rng", "optimizer", "legacy"])
def test_invalid_checkpoint_is_rejected_before_mutation(corruption: str) -> None:
    _model_at_boundary, _optimizer_at_boundary, _progress, contract, payload = _boundary()
    candidate = copy.deepcopy(payload)
    if corruption == "identity":
        candidate["metadata"]["contract"]["identity"]["model"] = "0" * 64
        _resign(candidate)
    elif corruption == "cursor":
        candidate["metadata"]["next_data_cursor"] = 1
        _resign(candidate)
    elif corruption == "rng":
        del candidate["rng"]["numpy"]
        _resign(candidate)
    elif corruption == "optimizer":
        state = next(iter(candidate["state"]["optimizer"]["state"].values()))
        del state["exp_avg"]
        _resign(candidate)
    else:
        candidate = {"step": 2, "adapter": payload["state"]["trainable"]}

    fresh, fresh_optimizer = _model(91)
    before = _fingerprint(fresh, fresh_optimizer)
    with pytest.raises(common.CheckpointValidationError):
        backend._restore_checkpoint(candidate, contract, fresh, fresh_optimizer)
    assert _fingerprint(fresh, fresh_optimizer) == before
    assert not getattr(fresh, "_sdxl_resume_poisoned", False)
