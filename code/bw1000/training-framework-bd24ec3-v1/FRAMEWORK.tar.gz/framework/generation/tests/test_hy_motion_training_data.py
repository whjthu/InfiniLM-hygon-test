from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest
import torch

from genmlu.backends.hy_motion_training import (
    _hy_motion_sample_for_step,
    _load_hy_motion_training_data,
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _sample(sample_id: str | None) -> dict[str, object]:
    sample: dict[str, object] = {
        "prompt": f"prompt {sample_id}",
        "length": 2,
        "motion": torch.zeros((2, 201), dtype=torch.float32),
        "vtxt_input": torch.zeros((1, 768), dtype=torch.bfloat16),
        "ctxt_input": torch.zeros((1, 4096), dtype=torch.bfloat16),
        "ctxt_length": 1,
    }
    if sample_id is not None:
        sample["sample_id"] = sample_id
    return sample


def _write_dataset_manifest(root: Path) -> str:
    path = root / "dataset-manifest.json"
    path.write_text('{"schema_version": 1}', encoding="utf-8")
    return _sha256(path)


def _write_shard(
    path: Path,
    sample_ids: list[str],
    dataset_manifest_sha256: str | None = None,
    include_sample_ids: bool = True,
) -> None:
    torch.save(
        {
            "schema_version": 1,
            "frames": 2,
            "feature_dim": 201,
            "dataset_manifest_sha256": dataset_manifest_sha256,
            "samples": [
                _sample(sample_id if include_sample_ids else None)
                for sample_id in sample_ids
            ],
        },
        path,
    )


def _write_manifest(root: Path, shards: list[dict[str, object]], dataset_sha: str) -> Path:
    sample_ids = [sample_id for shard in shards for sample_id in shard["sample_ids"]]
    path = root / "training-data-manifest.json"
    path.write_text(
        json.dumps(
            {
                "schema_version": 2,
                "format": "hy-motion-training-shards-v1",
                "frames": 2,
                "feature_dim": 201,
                "sample_count": len(sample_ids),
                "sample_ids": sample_ids,
                "dataset_manifest": "dataset-manifest.json",
                "dataset_manifest_sha256": dataset_sha,
                "shards": shards,
            }
        ),
        encoding="utf-8",
    )
    return path


def test_legacy_cache_retains_small_cache_step_order(tmp_path: Path) -> None:
    cache_path = tmp_path / "training-cache.pt"
    _write_shard(cache_path, ["a", "b"], include_sample_ids=False)

    samples, data = _load_hy_motion_training_data({"training_cache": str(cache_path)}, torch)

    assert data["shuffle_by_epoch"] is False
    assert [sample["sample_id"] for sample in samples] == ["legacy-00000000", "legacy-00000001"]
    assert [
        _hy_motion_sample_for_step(samples, 17, step, False)[0]["sample_id"]
        for step in range(1, 6)
    ] == [
        "legacy-00000000",
        "legacy-00000001",
        "legacy-00000000",
        "legacy-00000001",
        "legacy-00000000",
    ]


def test_shards_are_epoch_deterministic_and_report_cursor(tmp_path: Path) -> None:
    first = tmp_path / "part-00000.pt"
    second = tmp_path / "part-00001.pt"
    dataset_sha = _write_dataset_manifest(tmp_path)
    _write_shard(first, ["a", "b"], dataset_sha)
    _write_shard(second, ["c"], dataset_sha)
    manifest_path = _write_manifest(
        tmp_path,
        [
            {
                "path": first.name,
                "sha256": _sha256(first),
                "sample_count": 2,
                "sample_ids": ["a", "b"],
            },
            {
                "path": second.name,
                "sha256": _sha256(second),
                "sample_count": 1,
                "sample_ids": ["c"],
            },
        ], dataset_sha,
    )

    samples, data = _load_hy_motion_training_data(
        {"training_data_manifest": str(manifest_path)}, torch
    )
    first_epoch = [_hy_motion_sample_for_step(samples, 23, step, True) for step in range(1, 4)]
    repeat = [_hy_motion_sample_for_step(samples, 23, step, True) for step in range(1, 4)]
    second_epoch = [_hy_motion_sample_for_step(samples, 23, step, True) for step in range(4, 7)]

    assert [item[0]["sample_id"] for item in first_epoch] == [
        item[0]["sample_id"] for item in repeat
    ]
    assert sorted(item[0]["sample_id"] for item in first_epoch) == ["a", "b", "c"]
    assert [(item[1], item[2]) for item in first_epoch] == [(0, 0), (0, 1), (0, 2)]
    assert [(item[1], item[2]) for item in second_epoch] == [(1, 0), (1, 1), (1, 2)]
    assert data["training_data_manifest_sha256"] == _sha256(manifest_path)


def test_lazy_shard_load_rehashes_after_preflight(tmp_path: Path) -> None:
    first = tmp_path / "part-00000.pt"
    dataset_sha = _write_dataset_manifest(tmp_path)
    _write_shard(first, ["a"], dataset_sha)
    manifest_path = _write_manifest(
        tmp_path,
        [
            {
                "path": first.name,
                "sha256": _sha256(first),
                "sample_count": 1,
                "sample_ids": ["a"],
            }
        ],
        dataset_sha,
    )
    samples, _ = _load_hy_motion_training_data(
        {"training_data_manifest": str(manifest_path)}, torch
    )
    payload = torch.load(first, map_location="cpu", weights_only=False)
    payload["samples"][0]["prompt"] = "tampered after preflight"
    torch.save(payload, first)

    with pytest.raises(RuntimeError, match="shard changed"):
        samples[0]


@pytest.mark.parametrize(
    "corruption",
    ["manifest_sha", "dataset_sha", "shard_sha", "duplicate", "missing", "escape"],
)
def test_sharded_manifest_rejects_invalid_data(tmp_path: Path, corruption: str) -> None:
    first = tmp_path / "part-00000.pt"
    second = tmp_path / "part-00001.pt"
    dataset_sha = _write_dataset_manifest(tmp_path)
    _write_shard(first, ["a"], dataset_sha)
    _write_shard(second, ["b"], dataset_sha)
    shards: list[dict[str, object]] = [
        {
            "path": first.name,
            "sha256": _sha256(first),
            "sample_count": 1,
            "sample_ids": ["a"],
        },
        {
            "path": second.name,
            "sha256": _sha256(second),
            "sample_count": 1,
            "sample_ids": ["b"],
        },
    ]
    if corruption == "shard_sha":
        shards[0]["sha256"] = "0" * 64
    if corruption == "duplicate":
        shards[1]["sample_ids"] = ["a"]
    if corruption == "missing":
        shards[1]["sample_ids"] = ["not-b"]
    if corruption == "escape":
        shards[0]["path"] = "../part-00000.pt"
    manifest_path = _write_manifest(
        tmp_path, shards, "0" * 64 if corruption == "dataset_sha" else dataset_sha
    )
    config: dict[str, str] = {"training_data_manifest": str(manifest_path)}
    if corruption == "manifest_sha":
        config["training_data_manifest_sha256"] = "0" * 64

    with pytest.raises(RuntimeError):
        _load_hy_motion_training_data(config, torch)
