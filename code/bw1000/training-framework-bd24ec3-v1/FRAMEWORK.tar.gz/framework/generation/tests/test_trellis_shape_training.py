from __future__ import annotations

import copy
import json
from pathlib import Path
import random
import subprocess
import sys
from types import ModuleType, SimpleNamespace

import numpy as np
import pytest
import torch

from genmlu import hy_resume_checkpoint as common
from genmlu import trellis_training_contract as contract
from genmlu import trellis_training_resume_checkpoint as checkpoint
from genmlu.backends import trellis2_training as backend


def test_module_origin_accepts_verified_file_and_namespace(tmp_path):
    root = tmp_path / "source"
    backend.validate_module_origin(SimpleNamespace(__file__=str(root / "trellis2" / "models.py")), root, "trellis2.models")
    backend.validate_module_origin(SimpleNamespace(__file__=None, __path__=[str(root / "trellis2" / "modules")]), root, "trellis2.modules")


@pytest.mark.parametrize("paths", [[], ["/foreign/trellis2"], ["/foreign/trellis2", "inside"]])
def test_module_origin_rejects_foreign_or_empty_namespace(tmp_path, paths):
    root = tmp_path / "source"
    expanded = [str(root / "trellis2" / "modules") if path == "inside" else path for path in paths]
    with pytest.raises(ValueError, match="foreign TRELLIS namespace"):
        backend.validate_module_origin(SimpleNamespace(__file__=None, __path__=expanded), root, "trellis2.modules")


def test_module_origin_rejects_foreign_file(tmp_path):
    with pytest.raises(ValueError, match="foreign TRELLIS module"):
        backend.validate_module_origin(SimpleNamespace(__file__=str(tmp_path / "foreign.py")), tmp_path / "source", "trellis2.models")


def config(**changes):
    return contract.resolve_config({
        "training_cache": "/data/cache.npz", "training_cache_sha256": "a" * 64,
        "training_cache_semantic_sha256": "b" * 64, "cache_origin_kind": "generated",
        "dataset_id": "unit-test-cache", "max_tokens": 64, "max_condition_tokens": 16,
        "source_root": "/sources/trellis2", "source_revision": "c" * 40,
        "source_inventory_sha256": "d" * 64, **changes,
    })


def arrays(n=6, length=4):
    coords = np.zeros((n, 4), dtype=np.int32)
    coords[:, 1] = np.arange(n) % 32
    coords[:, 2] = np.arange(n) // 32
    coords[:, 3] = 7
    return {"coords": coords[::-1].copy(), "shape_latent": np.arange(n * 32, dtype=np.float32).reshape(n, 32) / 100,
            "condition": np.ones((1, length, 1024), dtype=np.float32)}


def validate_arrays(value, **limits):
    contract.validate_cache_arrays(value, **{"max_tokens": 64, "max_condition_tokens": 16, **limits})


def fake_model(*, linear=False):
    model = torch.nn.Module()
    for name, (out_features, in_features) in contract.TARGETS.items():
        parent = model
        parts = name.split(".")
        for part in parts[:-1]:
            if part not in parent._modules:
                parent.add_module(part, torch.nn.Module())
            parent = parent._modules[part]
        if linear:
            leaf = torch.nn.Linear(in_features, out_features, device="meta")
        else:
            leaf = torch.nn.Module()
            leaf.register_parameter("lora_A", torch.nn.Parameter(torch.zeros(2, in_features)))
            leaf.register_parameter("lora_B", torch.nn.Parameter(torch.zeros(out_features, 2)))
        parent.add_module(parts[-1], leaf)
    model.register_buffer("test_buffer", torch.ones(3))
    return model.train()


def cpu_contract(cfg):
    return checkpoint.build_contract(cfg, {k: {"sha256": "e" * 64} for k in checkpoint.IDENTITIES}, [])


def advance(model, optimizer, progress):
    for parameter in backend.trainable_parameters(model).values():
        parameter.grad = torch.randn_like(parameter) * 0.01 * (random.random() + float(np.random.rand()) + 1)
    optimizer.step()
    progress = common.advance_optimizer_progress(progress, model, optimizer)
    optimizer.zero_grad(set_to_none=True)
    return progress


def payload_at(step):
    random.seed(5)
    np.random.seed(5)
    torch.manual_seed(5)
    cfg = config()
    model = fake_model()
    optimizer = checkpoint.make_optimizer(list(backend.trainable_parameters(model).values()), cfg)
    progress = common.initial_optimizer_progress(model, optimizer)
    for _ in range(step):
        progress = advance(model, optimizer, progress)
    binding = cpu_contract(cfg)
    return checkpoint.make_payload(binding, step, model, optimizer, progress), binding, model, optimizer, progress


@pytest.fixture(autouse=True)
def cpu_threads():
    original = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(original)


def resign(value):
    value["adapter_sha256"] = common.tree_sha256(value["state"]["trainable"])
    value["integrity_sha256"] = common.tree_sha256({k: v for k, v in value.items() if k != "integrity_sha256"})


def test_general_plan_and_declared_cache():
    assert config()["max_steps"] == 25
    assert config(max_steps=1000, warmup_steps=200)["max_steps"] == 1000
    assert config(max_steps=1, warmup_steps=0)["warmup_steps"] == 0
    assert config(cache_origin_kind="real")["cache_origin_kind"] == "real"
    with pytest.raises(ValueError, match="missing required"):
        contract.resolve_config({})
    for key, value in (("max_steps", 0), ("warmup_steps", 25), ("max_tokens", 32769), ("max_condition_tokens", True),
                       ("training_cache_sha256", "placeholder"), ("cache_origin_kind", "verified-quality"),
                       ("precision", "float32"), ("lora_rank", 3), ("learning_rate", 0), ("weight_decay", float("nan"))):
        with pytest.raises(ValueError):
            config(**{key: value})


def test_resume_config_excludes_only_invocation_fields():
    base = config()
    changed = {**base, "resume_from_checkpoint": "/other/cp.pt", "resume_checkpoint_sha256": "f" * 64,
               "stop_after_global_step": 20, "run_name": "next", "output_root": "/next", "cards": [3]}
    assert contract.training_config(base) == contract.training_config(changed)
    assert contract.training_config(base) != contract.training_config(config(max_steps=26))
    assert contract.training_config(base) != contract.training_config(config(checkpoint_steps=[10, 11, 20, 21]))
    assert cpu_contract(config(container="worker-a", container_image="declared-label-a")) == cpu_contract(config(container="worker-b", container_image="declared-label-b", recovery_validation=False))
    with pytest.raises(ValueError, match="required for external resume"):
        config(resume_from_checkpoint="/checkpoint.pt")


def test_checkpoint_schedule_is_explicit_and_bounded():
    assert config()["checkpoint_steps"] == [10, 20]
    assert config(max_steps=1, warmup_steps=0)["checkpoint_steps"] == []
    assert config(checkpoint_steps=[21, 11, 10, 20])["checkpoint_steps"] == [10, 11, 20, 21]
    for value in ([0], [26], [10, 10], [True], "10,20", [1.0]):
        with pytest.raises(ValueError, match="checkpoint_steps"):
            config(checkpoint_steps=value)


@pytest.mark.parametrize("n,length", [(1, 1), (6, 4), (64, 16)])
def test_variable_cache_and_preserved_order(n, length):
    value = arrays(n, length)
    before = contract.semantic_sha(value)
    validate_arrays(value)
    assert contract.semantic_sha(value) == before
    if n > 1:
        reordered = {**value, "coords": value["coords"][::-1].copy()}
        assert contract.semantic_sha(reordered) != before


@pytest.mark.parametrize("mutation", [
    lambda a: a.pop("coords"),
    lambda a: a.update(coords=a["coords"].astype(np.float32)),
    lambda a: a["coords"].__setitem__((0, 0), 1),
    lambda a: a["coords"].__setitem__((0, 1), 32),
    lambda a: a["coords"].__setitem__((0, 1), -1),
    lambda a: a["coords"].__setitem__(0, a["coords"][1]),
    lambda a: a.update(shape_latent=a["shape_latent"][:, :31]),
    lambda a: a.update(condition=a["condition"][:, :, :1023]),
    lambda a: a["shape_latent"].__setitem__((0, 0), float("nan")),
    lambda a: a["condition"].__setitem__((0, 0, 0), float("inf")),
    lambda a: a.update(extra=np.zeros(1, dtype=np.float32)),
])
def test_malformed_cache_rejected(mutation):
    value = arrays()
    mutation(value)
    with pytest.raises(ValueError):
        validate_arrays(value)


def test_budgets_reject_without_truncation():
    value = arrays()
    before = contract.semantic_sha(value)
    with pytest.raises(ValueError, match="budget"):
        validate_arrays(value, max_tokens=5)
    with pytest.raises(ValueError, match="budget"):
        validate_arrays(value, max_condition_tokens=3)
    assert contract.semantic_sha(value) == before


def test_cache_identity_and_normalized_semantics(tmp_path):
    value = arrays()
    path = tmp_path / "cache.npz"
    np.savez(path, **value)
    cfg = config(training_cache=str(path), training_cache_sha256=contract.file_sha(path),
                 training_cache_semantic_sha256=contract.semantic_sha(value))
    normalization = {"mean": [0.5] * 32, "std": [2.0] * 32}
    normalized, identity = contract.load_cache(cfg, normalization)
    np.testing.assert_array_equal(normalized["coords"], value["coords"])
    np.testing.assert_array_equal(normalized["shape_latent"], (value["shape_latent"] - 0.5) / 2)
    assert identity["normalized_sha256"] == contract.semantic_sha(normalized)
    assert identity["dataset_id"] == cfg["dataset_id"]
    for key in ("training_cache_sha256", "training_cache_semantic_sha256"):
        with pytest.raises(ValueError, match="SHA"):
            contract.load_cache({**cfg, key: "f" * 64}, normalization)
    with pytest.raises(ValueError, match="normalization"):
        contract.load_cache(cfg, {"mean": [0.0] * 32, "std": [0.0] * 32})


def test_source_inventory_includes_untracked_and_rejects_change(tmp_path, monkeypatch):
    source = tmp_path / "trellis2"
    source.mkdir()
    code = source / "__init__.py"
    code.write_text("value = 1\n", encoding="utf-8")
    inventory = {"trellis2/__init__.py": contract.file_sha(code)}
    def fake_git(args, **kwargs):
        return SimpleNamespace(stdout=("c" * 40 + "\n").encode() if "rev-parse" in args else b"")
    monkeypatch.setattr(contract.subprocess, "run", fake_git)
    cfg = config(source_root=str(tmp_path), source_inventory_sha256=contract.json_sha(inventory))
    assert contract.verify_source(cfg)["files"] == inventory
    (source / "untracked.py").write_text("value = 2\n", encoding="utf-8")
    with pytest.raises(ValueError, match="inventory"):
        contract.verify_source(cfg)
    with pytest.raises(ValueError, match="revision"):
        contract.verify_source({**cfg, "source_revision": "a" * 40})


def test_exact_targets_and_no_extra_trainables():
    model = fake_model(linear=True)
    assert backend.inject_lora(model) == list(contract.TARGETS)
    values = backend.trainable_parameters(model)
    assert len(values) == 24 and sum(p.numel() for p in values.values()) == 96256
    model.register_parameter("extra", torch.nn.Parameter(torch.zeros(1)))
    with pytest.raises(ValueError, match="target set"):
        backend.trainable_parameters(model)


def test_target_validation_before_mutation():
    model = fake_model(linear=True)
    model.blocks._modules["0"].self_attn.to_qkv = torch.nn.Linear(5, 4, device="meta")
    with pytest.raises(ValueError, match="target schema"):
        backend.inject_lora(model)
    assert all(p.requires_grad for p in model.parameters())
    assert not any("lora_" in n for n, _ in model.named_parameters())


def test_strict_full_weight_load_preserves_native_precision(tmp_path, monkeypatch):
    model = torch.nn.Module()
    for index in range(640):
        model.register_buffer(f"weight_{index}", torch.zeros(1, dtype=torch.bfloat16 if index < 420 else torch.float32))
    header = {name: {"shape": [1], "dtype": "BF16"} for name in model.state_dict()}
    backend.validate_weight_layout(model, header)
    for bad in ({k: v for k, v in list(header.items())[1:]}, {**header, "weight_0": {"shape": [2], "dtype": "BF16"}},
                {**header, "weight_0": {"shape": [1], "dtype": "F32"}}):
        with pytest.raises(ValueError):
            backend.validate_weight_layout(model, bad)
    path = tmp_path / "weights"
    path.write_bytes(b"unit-test weight reader")
    state = {name: torch.ones(1, dtype=torch.bfloat16) for name in header}
    class Reader:
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def keys(self): return state.keys()
        def get_tensor(self, name): return state[name]
    module = ModuleType("safetensors")
    module.safe_open = lambda *args, **kwargs: Reader()
    monkeypatch.setitem(sys.modules, "safetensors", module)
    identity = {"path": str(path), "sha256": contract.file_sha(path), "header": header}
    backend.load_base_weights(model, identity)
    assert all(bool((tensor == 1).all()) for tensor in model.state_dict().values())
    assert sum(t.dtype == torch.float32 for t in model.state_dict().values()) == 220
    state["weight_0"].fill_(float("inf"))
    with pytest.raises(ValueError, match="invalid base weight"):
        backend.load_base_weights(model, identity)
    state.pop("weight_0")
    with pytest.raises(ValueError, match="keys changed"):
        backend.load_base_weights(model, identity)


def test_all_named_preclip_grads_and_initial_zero_allowed():
    params = backend.trainable_parameters(fake_model())
    for name, p in params.items():
        p.grad = torch.zeros_like(p) if name.endswith("lora_A") else torch.ones_like(p)
    assert len(backend.preclip_gradients(params)["zero_tensors"]) == 12
    first = next(iter(params.values()))
    first.grad = None
    with pytest.raises(ValueError, match="preclip gradient"):
        backend.preclip_gradients(params)
    first.grad = torch.full_like(first, float("nan"))
    with pytest.raises(ValueError, match="preclip gradient"):
        backend.preclip_gradients(params)
    for p in params.values():
        p.grad = torch.zeros_like(p)
    with pytest.raises(ValueError, match="all gradients"):
        backend.preclip_gradients(params)


def test_adapter_change_and_total_allocator_peak(monkeypatch):
    with pytest.raises(ValueError, match="no actual"):
        backend.require_adapter_update("same", "same")
    backend.require_adapter_update("before", "after")
    monkeypatch.setattr(backend, "memory_stats", lambda: {"peak_reserved_bytes": 75_000_000_000, "peak_allocated_bytes": 42})
    assert backend.checked_memory()["peak_reserved_bytes"] == 75_000_000_000
    monkeypatch.setattr(backend, "memory_stats", lambda: {"peak_reserved_bytes": 75_000_000_001, "peak_allocated_bytes": 42})
    with pytest.raises(ValueError, match="allocator peak"):
        backend.checked_memory()


def test_warmup_uses_global_steps():
    assert backend.step_coordinate(5, 5)["warmup"] is True
    assert backend.step_coordinate(6, 5)["measurement_step"] == 1
    binding = cpu_contract(config())
    for step in (10, 20):
        metadata = checkpoint.boundary_metadata(binding, step)
        assert metadata["completed_optimizer_steps"] == step
        assert metadata["next_global_step"] == step + 1
        assert metadata["measured_steps"] == step - 5
        assert metadata["samples_consumed"] == step


def test_checkpoint_immutable_cpu_clones_and_restricted_load(tmp_path, monkeypatch):
    payload, binding, model, optimizer, progress = payload_at(1)
    before = common.tree_sha256(payload)
    advance(model, optimizer, progress)
    assert common.tree_sha256(payload) == before
    path = tmp_path / "checkpoint-1.pt"
    checkpoint.save_checkpoint(path, payload)
    original = torch.load
    def restricted(*args, **kwargs):
        assert kwargs["weights_only"] is True and kwargs["map_location"] == "cpu"
        return original(*args, **kwargs)
    monkeypatch.setattr(torch, "load", restricted)
    loaded, identity = checkpoint.load_checkpoint_with_identity(path, requested_config={**binding["config"], "resume_checkpoint_sha256": contract.file_sha(path)})
    assert identity == {"path": str(path.resolve()), "sha256": contract.file_sha(path)}
    assert common.tree_sha256(loaded) == before
    with pytest.raises(ValueError, match="SHA"):
        checkpoint.load_checkpoint(path, requested_config={**binding["config"], "resume_checkpoint_sha256": "f" * 64})
    with pytest.raises(ValueError, match="overwrite"):
        checkpoint.save_checkpoint(path, payload)


@pytest.mark.parametrize("kind", ["missing_target", "extra_target", "dtype", "nonfinite", "cursor", "bool_cursor", "step", "rng", "mode", "moment", "moment_nan", "negative_moment", "placement", "progress", "optimizer_order", "lr", "scheduler", "source", "cache", "buffer"])
def test_bad_checkpoint_rejected_before_apply(kind):
    payload, binding, model, optimizer, progress = payload_at(1)
    state = payload["state"]
    name = next(iter(state["trainable"]))
    index = next(iter(state["optimizer"]["state"]))
    if kind == "missing_target": state["trainable"].pop(name)
    elif kind == "extra_target": state["trainable"]["extra"] = torch.zeros(1)
    elif kind == "dtype": state["trainable"][name] = state["trainable"][name].half()
    elif kind == "nonfinite": state["trainable"][name].fill_(float("nan"))
    elif kind == "cursor": payload["metadata"]["samples_consumed"] = 2
    elif kind == "bool_cursor": payload["metadata"]["samples_consumed"] = True
    elif kind == "step": payload["metadata"]["global_step"] = 0
    elif kind == "rng": payload["rng"]["numpy"]["keys"][0] = -1
    elif kind == "mode": state["modes"][""] = False
    elif kind == "moment": state["optimizer"]["state"][index].pop("exp_avg")
    elif kind == "moment_nan": state["optimizer"]["state"][index]["exp_avg"].fill_(float("inf"))
    elif kind == "negative_moment": state["optimizer"]["state"][index]["exp_avg_sq"].fill_(-1)
    elif kind == "placement": state["optimizer_placements"][index]["exp_avg"] = "mlu:0"
    elif kind == "progress": state["optimizer_progress"][name] = 0
    elif kind == "optimizer_order": state["optimizer_parameter_names"][0].reverse()
    elif kind == "lr": state["optimizer"]["param_groups"][0]["lr"] = 0.0
    elif kind == "scheduler": payload["lr_scheduler"] = {}
    elif kind in ("source", "cache"): payload["metadata"]["contract"]["identities"][kind]["sha256"] = "f" * 64
    elif kind == "buffer": state["buffers"].pop("test_buffer")
    resign(payload)
    before = common.tree_sha256(common.capture_model_state(model, optimizer, progress))
    rng_before = common.tree_sha256(checkpoint.pack_rng(common.capture_rng([])))
    with pytest.raises((ValueError, RuntimeError)):
        checkpoint.restore_checkpoint(payload, binding, model, optimizer)
    assert common.tree_sha256(common.capture_model_state(model, optimizer, progress)) == before
    assert common.tree_sha256(checkpoint.pack_rng(common.capture_rng([]))) == rng_before


def test_old_or_corrupt_checkpoint_rejected(tmp_path):
    path = tmp_path / "old.pt"
    torch.save({"adapter": {}, "step": 20}, path)
    with pytest.raises(ValueError, match="not a complete"):
        checkpoint.load_checkpoint(path, requested_config=config(resume_checkpoint_sha256=contract.file_sha(path)))
    payload, binding, *_ = payload_at(1)
    payload["integrity_sha256"] = "f" * 64
    with pytest.raises(ValueError, match="integrity"):
        checkpoint.preflight_checkpoint(payload, requested_config=binding["config"])


@pytest.mark.parametrize("step", [10, 20])
def test_cpu_fresh_process_next_update_exact(step, tmp_path):
    payload, binding, model, optimizer, progress = payload_at(step)
    path = tmp_path / f"checkpoint-{step}.pt"
    checkpoint.save_checkpoint(path, payload)
    progress = advance(model, optimizer, progress)
    expected = common.tree_sha256(checkpoint.make_payload(binding, step + 1, model, optimizer, progress))
    child = """
import runpy, sys
helpers = runpy.run_path(sys.argv[1])
torch, cp, backend = helpers['torch'], helpers['checkpoint'], helpers['backend']
torch.set_num_threads(1)
cfg = helpers['config']()
path = helpers['Path'](sys.argv[2])
payload = cp.load_checkpoint(path, requested_config={**cfg, 'resume_checkpoint_sha256': helpers['contract'].file_sha(path)})
model = helpers['fake_model']()
optimizer = cp.make_optimizer(list(backend.trainable_parameters(model).values()), cfg)
binding = helpers['cpu_contract'](cfg)
progress = cp.restore_checkpoint(payload, binding, model, optimizer)
progress = helpers['advance'](model, optimizer, progress)
result = cp.make_payload(binding, payload['metadata']['global_step'] + 1, model, optimizer, progress)
print(helpers['common'].tree_sha256(result))
"""
    result = subprocess.run([sys.executable, "-B", "-c", child, str(Path(__file__).resolve()), str(path)],
                            check=True, capture_output=True, text=True, timeout=60)
    assert result.stdout.strip() == expected


def test_cli_component_route_and_rejections(tmp_path, monkeypatch):
    import yaml
    from genmlu import cli
    from genmlu.models import get_spec
    spec = get_spec(cli.DEFAULT_MODELS, contract.COMPONENT)
    called = []
    monkeypatch.setattr(cli, "_call", lambda *args: called.append(args) or {})
    (tmp_path / "trellis2").mkdir()
    cli.run_backend("train", spec, tmp_path, config(), tmp_path, tmp_path)
    assert called[0][:2] == ("genmlu.backends.trellis2_training", "run_trellis2_training")
    for command in ("infer", "rl"):
        with pytest.raises(RuntimeError, match="not implemented"):
            cli.run_backend(command, spec, tmp_path, config(), tmp_path, tmp_path)
    config_path = tmp_path / "config.yaml"
    config_path.write_text(yaml.safe_dump(config()), encoding="utf-8")
    assert cli.load_run_config(config_path, contract.COMPONENT)["max_steps"] == 25
    args = cli.build_parser().parse_args(["train", "--model", contract.COMPONENT, "--config", str(config_path),
                                        "--output-root", str(tmp_path / "out"), "--run-name", "test", "--cards", "0,1"])
    with pytest.raises(ValueError, match="exactly one"):
        cli.cmd_run(args)
    assert not (tmp_path / "out").exists()


def test_cli_rejects_old_resume_before_runtime(tmp_path, monkeypatch):
    from genmlu import cli
    path = tmp_path / "old.pt"
    torch.save({"adapter": {}, "step": 20}, path)
    monkeypatch.setattr(cli, "inspect_runtime", lambda: pytest.fail("runtime must not be inspected"))
    with pytest.raises(ValueError, match="not a complete"):
        cli.preflight_external_resume("train", contract.COMPONENT, config(resume_from_checkpoint=str(path), resume_checkpoint_sha256=contract.file_sha(path)))
