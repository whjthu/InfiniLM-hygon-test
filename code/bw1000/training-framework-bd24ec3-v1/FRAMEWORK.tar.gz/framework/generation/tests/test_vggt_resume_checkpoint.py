from __future__ import annotations

import copy
import inspect
import random
import sys
from types import ModuleType, SimpleNamespace

import numpy as np
import pytest
import torch

from genmlu.backends import vggt_training as vggt
from genmlu.recovery_validation import run_recovery_validation


def make_contract() -> dict:
    return vggt._vggt_contract(
        identity={key: "a" * 64 for key in vggt._VGGT_IDENTITY_FIELDS},
        seed=19,
        warmup_steps=2,
        max_steps=5,
        view_order=["seq-a:0,1", "seq-b:2,3", "seq-c:4,5"],
        device_ids=[],
    )


def make_model(seed: int) -> tuple[torch.nn.Module, torch.optim.AdamW]:
    torch.manual_seed(seed)
    module = torch.nn.Sequential(torch.nn.Linear(3, 5), torch.nn.Tanh(), torch.nn.Linear(5, 2))
    return module, torch.optim.AdamW(module.parameters(), lr=3e-3, weight_decay=0.01)


def optimizer_step(module: torch.nn.Module, optimizer: torch.optim.AdamW) -> dict:
    optimizer.zero_grad(set_to_none=True)
    values = torch.randn(4, 3) + random.random() + float(np.random.rand())
    loss = module(values).square().mean()
    loss.backward()
    optimizer.step()
    return {
        "loss": loss.detach().clone(),
        "parameters": {name: value.detach().clone() for name, value in module.state_dict().items()},
        "optimizer": vggt.resume_common.cpu_tree(optimizer.state_dict()),
        "python_random": random.random(),
        "numpy_random": float(np.random.rand()),
        "torch_random": torch.rand(3),
    }


def checkpoint_at(global_optimizer_step: int = 5) -> tuple[dict, torch.nn.Module, torch.optim.AdamW, dict]:
    random.seed(7)
    np.random.seed(8)
    torch.manual_seed(9)
    contract = make_contract()
    module, optimizer = make_model(10)
    for _ in range(global_optimizer_step):
        optimizer_step(module, optimizer)
    payload = vggt._vggt_make_checkpoint(
        contract=contract,
        global_optimizer_step=global_optimizer_step,
        module=module,
        optimizer=optimizer,
        torch=torch,
    )
    return contract, module, optimizer, payload


def test_restore_continues_with_exact_rng_optimizer_model_and_batch_coordinate() -> None:
    contract, module, optimizer, payload = checkpoint_at()
    continuous = optimizer_step(module, optimizer)

    restored_module, restored_optimizer = make_model(99)
    checked = vggt._vggt_restore_checkpoint(
        payload, contract, restored_module, restored_optimizer, torch
    )
    assert checked["next"] == {"global_optimizer_step": 6, "batch_cursor": 2}
    resumed = optimizer_step(restored_module, restored_optimizer)
    assert vggt.resume_common.tree_sha256(continuous) == vggt.resume_common.tree_sha256(resumed)


def test_restore_clones_saved_optimizer_and_rng_before_updates() -> None:
    contract, _module, _optimizer, payload = checkpoint_at()
    payload_sha = vggt.resume_common.tree_sha256(
        {key: value for key, value in payload.items() if key != "integrity_sha256"}
    )
    target, target_optimizer = make_model(75)
    vggt._vggt_restore_checkpoint(payload, contract, target, target_optimizer, torch)
    optimizer_step(target, target_optimizer)
    assert payload["integrity_sha256"] == payload_sha
    assert vggt.resume_common.tree_sha256(
        {key: value for key, value in payload.items() if key != "integrity_sha256"}
    ) == payload_sha
    vggt._vggt_restore_checkpoint(payload, contract, target, target_optimizer, torch)


@pytest.mark.parametrize("corruption", ["identity", "view_order", "optimizer_state"])
def test_invalid_resume_is_rejected_before_model_or_optimizer_mutation(corruption: str) -> None:
    contract, _module, _optimizer, payload = checkpoint_at()
    candidate = copy.deepcopy(payload)
    if corruption == "identity":
        candidate["metadata"]["contract"]["identity"]["data"] = "b" * 64
    elif corruption == "view_order":
        candidate["metadata"]["contract"]["view_order"].reverse()
    else:
        candidate["state"]["optimizer"]["state"][0]["exp_avg"][0] = float("nan")
    candidate["integrity_sha256"] = vggt.resume_common.tree_sha256(
        {key: value for key, value in candidate.items() if key != "integrity_sha256"}
    )

    target, target_optimizer = make_model(41)
    before = vggt.resume_common.tree_sha256(
        {"model": target.state_dict(), "optimizer": vggt.resume_common.cpu_tree(target_optimizer.state_dict())}
    )
    with pytest.raises(vggt.VGGTCheckpointValidationError):
        vggt._vggt_restore_checkpoint(candidate, contract, target, target_optimizer, torch)
    after = vggt.resume_common.tree_sha256(
        {"model": target.state_dict(), "optimizer": vggt.resume_common.cpu_tree(target_optimizer.state_dict())}
    )
    assert after == before


def test_fractional_adam_step_is_rejected_before_restore() -> None:
    contract, _module, _optimizer, payload = checkpoint_at()
    candidate = copy.deepcopy(payload)
    state = next(iter(candidate["state"]["optimizer"]["state"].values()))
    state["step"].fill_(5.5)
    candidate["integrity_sha256"] = vggt.resume_common.tree_sha256(
        {key: value for key, value in candidate.items() if key != "integrity_sha256"}
    )
    target, target_optimizer = make_model(81)
    with pytest.raises(vggt.VGGTCheckpointValidationError, match="AdamW step"):
        vggt._vggt_restore_checkpoint(candidate, contract, target, target_optimizer, torch)


def test_completed_measured_bounds_are_derived_from_global_optimizer_step() -> None:
    contract = make_contract()
    metadata = vggt._vggt_boundary_metadata(contract, 5)
    assert metadata["global_optimizer_step"] == 5
    assert metadata["completed_measured_steps"] == 3
    assert metadata["next_global_optimizer_step"] == 6
    assert metadata["next_batch_cursor"] == 2
    assert vggt._vggt_next_coordinate(metadata) == {"global_optimizer_step": 6, "batch_cursor": 2}
    with pytest.raises(vggt.VGGTCheckpointValidationError):
        vggt._vggt_boundary_metadata(contract, 2)
    with pytest.raises(vggt.VGGTCheckpointValidationError):
        vggt._vggt_boundary_metadata(contract, 8)


def test_formal_warmup_and_measurement_schedule_uses_global_checkpoint_steps() -> None:
    contract = vggt._vggt_contract(
        identity={key: "c" * 64 for key in vggt._VGGT_IDENTITY_FIELDS},
        seed=19,
        warmup_steps=5,
        max_steps=20,
        view_order=["seq-a:0,1", "seq-b:2,3"],
        device_ids=[],
    )
    checkpoint_ten = vggt._vggt_boundary_metadata(contract, 10)
    checkpoint_twenty = vggt._vggt_boundary_metadata(contract, 20)
    final = vggt._vggt_boundary_metadata(contract, 25)
    assert checkpoint_ten["completed_measured_steps"] == 5
    assert checkpoint_ten["next_global_optimizer_step"] == 11
    assert checkpoint_twenty["completed_measured_steps"] == 15
    assert checkpoint_twenty["next_global_optimizer_step"] == 21
    assert final["completed_measured_steps"] == 20
    assert vggt._vggt_next_coordinate(final) is None


def test_selected_batch_content_hash_changes_for_inputs_or_targets() -> None:
    batch = {
        "seq_name": "seq-a",
        "ids": [0, 1],
        "images": torch.zeros(1, 2, 3, 2, 2),
        "depths": torch.zeros(1, 2, 2, 2),
        "extrinsics": torch.eye(4).repeat(1, 2, 1, 1),
        "intrinsics": torch.eye(3).repeat(1, 2, 1, 1),
        "point_masks": torch.ones(1, 2, 2, 2, dtype=torch.bool),
    }
    original = vggt._vggt_batch_content_sha256([batch])
    changed_image = copy.deepcopy(batch)
    changed_image["images"][0, 0, 0, 0, 0] = 1
    changed_target = copy.deepcopy(batch)
    changed_target["extrinsics"][0, 1, 0, 3] = 2
    assert original != vggt._vggt_batch_content_sha256([changed_image])
    assert original != vggt._vggt_batch_content_sha256([changed_target])


def test_full_boundary_hash_includes_optimizer_rng_and_cursor() -> None:
    contract, module, optimizer, _payload = checkpoint_at()
    original = vggt._vggt_boundary_sha256(
        contract=contract,
        global_optimizer_step=5,
        module=module,
        optimizer=optimizer,
        torch=torch,
    )
    torch.rand(1)
    assert original != vggt._vggt_boundary_sha256(
        contract=contract,
        global_optimizer_step=5,
        module=module,
        optimizer=optimizer,
        torch=torch,
    )
    state = next(iter(optimizer.state.values()))
    state["exp_avg"].add_(1)
    optimizer_changed = vggt._vggt_boundary_sha256(
        contract=contract,
        global_optimizer_step=5,
        module=module,
        optimizer=optimizer,
        torch=torch,
    )
    assert original != optimizer_changed
    assert optimizer_changed != vggt._vggt_boundary_sha256(
        contract=contract,
        global_optimizer_step=4,
        module=module,
        optimizer=optimizer,
        torch=torch,
    )


def test_cpu_resume_step_twenty_executes_twenty_one_through_twenty_five_with_validation() -> None:
    contract = vggt._vggt_contract(
        identity={key: "d" * 64 for key in vggt._VGGT_IDENTITY_FIELDS},
        seed=19,
        warmup_steps=5,
        max_steps=20,
        view_order=["seq-a:0,1", "seq-b:2,3"],
        device_ids=[],
    )
    random.seed(17)
    np.random.seed(18)
    torch.manual_seed(19)
    source, source_optimizer = make_model(20)
    for _ in range(20):
        optimizer_step(source, source_optimizer)
    external_checkpoint = vggt._vggt_make_checkpoint(
        contract=contract,
        global_optimizer_step=20,
        module=source,
        optimizer=source_optimizer,
        torch=torch,
    )

    resumed, resumed_optimizer = make_model(21)
    restored = vggt._vggt_restore_checkpoint(
        external_checkpoint, contract, resumed, resumed_optimizer, torch
    )
    vggt._vggt_assert_restored_boundary(
        external_checkpoint, contract, resumed, resumed_optimizer, torch
    )
    assert restored["next"] == {"global_optimizer_step": 21, "batch_cursor": 0}
    executed = []
    for global_step in range(21, 26):
        optimizer_step(resumed, resumed_optimizer)
        executed.append(global_step)
    assert executed == [21, 22, 23, 24, 25]
    final_checkpoint = vggt._vggt_make_checkpoint(
        contract=contract,
        global_optimizer_step=25,
        module=resumed,
        optimizer=resumed_optimizer,
        torch=torch,
    )

    vggt._vggt_restore_checkpoint(
        external_checkpoint, contract, resumed, resumed_optimizer, torch
    )

    def update() -> dict:
        optimizer_step(resumed, resumed_optimizer)
        return {
            "loss": 0.0,
            "boundary": vggt._vggt_recovery_boundary_sha256(
                contract=contract,
                global_optimizer_step=21,
                module=resumed,
                optimizer=resumed_optimizer,
                torch=torch,
            ),
        }

    def restore() -> int:
        checked = vggt._vggt_restore_checkpoint(
            external_checkpoint, contract, resumed, resumed_optimizer, torch
        )
        vggt._vggt_assert_restored_boundary(
            external_checkpoint, contract, resumed, resumed_optimizer, torch
        )
        return int(checked["metadata"]["global_optimizer_step"])

    recovery = run_recovery_validation(
        enabled=True,
        expected_step=20,
        metric_names=("boundary_match",),
        update=update,
        restore=restore,
        fingerprint=None,
        compare=lambda continuous, restored, _left, _right: (
            continuous["boundary"] == restored["boundary"],
            {"boundary_match": continuous["boundary"] == restored["boundary"]},
        ),
    )
    assert recovery.passed is True
    vggt._vggt_restore_checkpoint(
        final_checkpoint, contract, resumed, resumed_optimizer, torch
    )
    assert vggt._vggt_boundary_sha256(
        contract=contract,
        global_optimizer_step=25,
        module=resumed,
        optimizer=resumed_optimizer,
        torch=torch,
    ) == vggt.resume_common.tree_sha256(
        {key: final_checkpoint[key] for key in ("metadata", "state", "rng")}
    )


def test_resume_preflight_precedes_output_mutation_and_measurement_end() -> None:
    source = inspect.getsource(vggt.run_vggt_training)
    assert source.index("resume_boundary_validated = True") < source.index(
        "output_dir.mkdir(parents=True, exist_ok=True)"
    )
    exhausted_resume = source.index("if completed_global_step >= final_global_step:")
    output_mutation = source.index("output_dir.mkdir(parents=True, exist_ok=True)")
    assert exhausted_resume < output_mutation
    measurement_sync = source.index("synchronize()\n                measurement_started = perf_counter()")
    measurement_timer = source.index("measurement_started = perf_counter()")
    assert measurement_sync < measurement_timer
    final_hashes = source.index("final_checkpoint_sha256 = sha256_path(final_checkpoint)")
    log_record = source.index("step_log_records =")
    window_end = source.index("full_measurement_wall_seconds =")
    recovery = source.index("recovery_enabled = validate_recovery_enabled(config)")
    assert final_hashes < log_record < window_end < recovery


def test_measurement_metrics_describe_only_the_current_resume_invocation() -> None:
    source = inspect.getsource(vggt.run_vggt_training)
    assert '"measurement_steps": len(measured_steps)' in source
    assert '"measurement_scope": "current_invocation_remaining_post_warmup"' in source


def resign(payload: dict) -> None:
    payload["integrity_sha256"] = vggt.resume_common.tree_sha256(
        {key: value for key, value in payload.items() if key != "integrity_sha256"}
    )


def snapshot(module, optimizer) -> str:
    return vggt.resume_common.tree_sha256(
        vggt._vggt_capture_runtime_state(
            contract=make_contract(), module=module, optimizer=optimizer, torch=torch
        )
    )


@pytest.mark.parametrize("stream", ["python", "numpy", "torch_cpu"])
def test_invalid_rng_is_rejected_before_any_model_optimizer_or_rng_mutation(stream) -> None:
    contract, _module, _optimizer, payload = checkpoint_at()
    candidate = copy.deepcopy(payload)
    candidate["rng"][stream] = torch.zeros(1, dtype=torch.uint8) if stream == "torch_cpu" else ()
    resign(candidate)
    target, target_optimizer = make_model(85)
    before = snapshot(target, target_optimizer)

    with pytest.raises(vggt.VGGTCheckpointValidationError, match="RNG"):
        vggt._vggt_restore_checkpoint(candidate, contract, target, target_optimizer, torch)

    assert snapshot(target, target_optimizer) == before
    assert not getattr(target, "_vggt_resume_poisoned", False)


@pytest.mark.parametrize("mode", ["valid", "malformed", "alias", "unavailable"])
def test_mlu_rng_preflight_uses_only_a_disposable_generator(monkeypatch, mode) -> None:
    class Generator:
        def __init__(self, state):
            self.state = state.clone()
            self.set_calls = 0

        def clone_state(self):
            if mode == "alias":
                return self
            if mode == "unavailable":
                raise RuntimeError("clone unavailable")
            return Generator(self.state)

        def set_state(self, state):
            self.set_calls += 1
            if state.numel() != 4:
                raise ValueError("invalid native RNG length")
            self.state = state.clone()

        def get_state(self):
            return self.state.clone()

    state = vggt._vggt_capture_rng(torch, [])
    host_before = vggt.resume_common.tree_sha256(state)
    live = Generator(torch.tensor([1, 2, 3, 4], dtype=torch.uint8))
    live_before = live.get_state()
    monkeypatch.setattr(torch, "mlu", SimpleNamespace(default_generators=[live]), raising=False)
    state["mlu"] = {0: torch.zeros(1 if mode == "malformed" else 4, dtype=torch.uint8)}

    if mode == "valid":
        vggt._vggt_validate_rng(state, torch, [0])
    else:
        with pytest.raises(vggt.VGGTCheckpointValidationError, match="RNG"):
            vggt._vggt_validate_rng(state, torch, [0])

    assert live.set_calls == 0
    assert torch.equal(live.get_state(), live_before)
    assert vggt.resume_common.tree_sha256(vggt._vggt_capture_rng(torch, [])) == host_before


def test_checkpoint_records_and_restores_actual_optimizer_placements() -> None:
    contract, _module, _optimizer, payload = checkpoint_at()
    assert payload["metadata"]["schema"] == "vggt-full-optimizer-step-v2"
    for slots in payload["state"]["optimizer_placements"].values():
        assert slots == {"step": "cpu", "exp_avg": "cpu", "exp_avg_sq": "cpu"}
    target, target_optimizer = make_model(86)
    vggt._vggt_restore_checkpoint(payload, contract, target, target_optimizer, torch)
    vggt._vggt_assert_restored_boundary(payload, contract, target, target_optimizer, torch)
    assert all(state["step"].device.type == "cpu" for state in target_optimizer.state.values())


def test_accelerator_moments_do_not_move_a_saved_cpu_step_counter() -> None:
    moves = []

    class Slot:
        def __init__(self, name):
            self.name = name

        def to(self, device):
            moves.append((self.name, device))
            return self

    parameter = object()
    optimizer = SimpleNamespace(
        param_groups=[{"params": [parameter]}],
        state={parameter: {key: Slot(key) for key in ("step", "exp_avg", "exp_avg_sq")}},
    )
    placements = {7: {"step": "cpu", "exp_avg": "mlu:0", "exp_avg_sq": "mlu:0"}}
    vggt._restore_optimizer_placements(optimizer, {"param_groups": [{"params": [7]}]}, placements)
    assert moves == [("step", "cpu"), ("exp_avg", "mlu:0"), ("exp_avg_sq", "mlu:0")]


@pytest.mark.parametrize("corruption", ["missing", "extra", "step", "moment", "legacy"])
def test_invalid_or_missing_placement_schema_is_rejected_before_mutation(corruption) -> None:
    contract, _module, _optimizer, payload = checkpoint_at()
    candidate = copy.deepcopy(payload)
    placements = candidate["state"]["optimizer_placements"]
    first = next(iter(placements))
    if corruption == "missing":
        del placements[first]["step"]
    elif corruption == "extra":
        placements[-1] = placements[first].copy()
    elif corruption == "legacy":
        candidate["metadata"]["schema"] = "vggt-full-optimizer-step-v1"
        del candidate["state"]["optimizer_placements"]
    else:
        placements[first]["step" if corruption == "step" else "exp_avg"] = "mlu:99"
    resign(candidate)
    target, target_optimizer = make_model(87)
    before = snapshot(target, target_optimizer)
    with pytest.raises(vggt.VGGTCheckpointValidationError):
        vggt._vggt_restore_checkpoint(candidate, contract, target, target_optimizer, torch)
    assert snapshot(target, target_optimizer) == before


def test_boundary_readback_includes_optimizer_placement_metadata() -> None:
    contract, module, optimizer, payload = checkpoint_at()
    changed = copy.deepcopy(payload)
    next(iter(changed["state"]["optimizer_placements"].values()))["step"] = "mlu:0"
    with pytest.raises(vggt.VGGTCheckpointValidationError, match="boundary differs"):
        vggt._vggt_assert_restored_boundary(changed, contract, module, optimizer, torch)


@pytest.mark.parametrize("changed_source", ["model", "pose", "runtime"])
def test_actual_source_file_drift_changes_identity_and_rejects_resume(tmp_path, monkeypatch, changed_source) -> None:
    package = tmp_path / "vggt"
    utils = package / "utils"
    utils.mkdir(parents=True)
    model_file = package / "model.py"
    model_file.write_text("MODEL_VERSION = 1\n", encoding="utf-8")
    pose_file = utils / "pose_enc.py"
    pose_file.write_text("def extri_intri_to_pose_encoding(*args):\n    return args\n", encoding="utf-8")
    runtime_file = tmp_path / "runtime.py"
    runtime_file.write_text("RUNTIME_VERSION = 1\n", encoding="utf-8")

    upstream = ModuleType("vggt")
    upstream.__path__ = [str(package)]
    upstream_utils = ModuleType("vggt.utils")
    upstream_utils.__path__ = [str(utils)]
    pose = ModuleType("vggt.utils.pose_enc")
    pose.__file__ = str(pose_file)
    exec(compile(pose_file.read_text(encoding="utf-8"), str(pose_file), "exec"), pose.__dict__)
    runtime = ModuleType("fixture_runtime")
    runtime.__file__ = str(runtime_file)
    for name, module in (("vggt", upstream), ("vggt.utils", upstream_utils), ("vggt.utils.pose_enc", pose)):
        monkeypatch.setitem(sys.modules, name, module)
    monkeypatch.setattr(vggt, "runtime_helpers", runtime)

    weights = tmp_path / "weights"
    weights.mkdir()
    (weights / "model.pt").write_bytes(b"fixture model contents")
    model = torch.nn.Module()
    model.aggregator = torch.nn.Linear(3, 3)
    model.camera_head = torch.nn.Linear(3, 2)
    optimizer = torch.optim.AdamW(model.camera_head.parameters(), lr=3e-3, weight_decay=0.01)
    kwargs = dict(
        weights=weights, config={}, dataset_root=tmp_path / "data", annotation_root=tmp_path / "annotations",
        model=model, optimizer=optimizer, batches=[], cache_enabled=False,
    )
    identity, evidence = vggt._vggt_resume_identity(**kwargs)
    assert evidence["sources"]["upstream_python"]["model.py"] == vggt.resume_common.file_sha256(model_file)
    assert evidence["sources"]["runtime"] == vggt.resume_common.file_sha256(runtime_file)
    contract = make_contract()
    contract["identity"] = identity
    for _ in range(5):
        optimizer_step(model.camera_head, optimizer)
    payload = vggt._vggt_make_checkpoint(
        contract=contract, global_optimizer_step=5, module=model.camera_head, optimizer=optimizer, torch=torch
    )

    changed_file = {"model": model_file, "pose": pose_file, "runtime": runtime_file}[changed_source]
    changed_file.write_text(changed_file.read_text(encoding="utf-8") + "# changed implementation\n", encoding="utf-8")
    changed_identity, _ = vggt._vggt_resume_identity(**kwargs)
    assert changed_identity["sources"] != identity["sources"]
    assert all(changed_identity[key] == value for key, value in identity.items() if key != "sources")
    changed_contract = copy.deepcopy(contract)
    changed_contract["identity"] = changed_identity
    before = snapshot(model.camera_head, optimizer)
    with pytest.raises(vggt.VGGTCheckpointValidationError, match="identity"):
        vggt._vggt_restore_checkpoint(payload, changed_contract, model.camera_head, optimizer, torch)
    assert snapshot(model.camera_head, optimizer) == before
