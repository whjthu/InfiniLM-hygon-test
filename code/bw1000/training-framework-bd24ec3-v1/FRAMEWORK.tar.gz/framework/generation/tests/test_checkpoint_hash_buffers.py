"""Byte-exact compatibility with the original checkpoint tree hash."""
import hashlib
import random

import pytest

np = pytest.importorskip("numpy")
torch = pytest.importorskip("torch")

from genmlu import hy_resume_checkpoint as resume


def historical_tree_sha256(value):
    digest = hashlib.sha256()

    def feed(item):
        digest.update(type(item).__name__.encode("utf-8") + b"\0")
        if isinstance(item, torch.Tensor):
            tensor = item.detach().cpu().contiguous()
            digest.update(str(tensor.dtype).encode("ascii"))
            digest.update(str(tuple(tensor.shape)).encode("ascii"))
            digest.update(tensor.reshape(-1).view(torch.uint8).numpy().tobytes())
        elif isinstance(item, np.ndarray):
            digest.update(str(item.dtype).encode("ascii"))
            digest.update(str(item.shape).encode("ascii"))
            digest.update(item.tobytes())
        elif isinstance(item, dict):
            for key in sorted(item, key=lambda candidate: (type(candidate).__name__, repr(candidate))):
                feed(key)
                feed(item[key])
        elif isinstance(item, (tuple, list)):
            digest.update(str(len(item)).encode("ascii"))
            for child in item:
                feed(child)
        else:
            resume._require(
                item is None or type(item) in (str, int, float, bool, bytes),
                f"unsupported hash value: {type(item)}",
            )
            digest.update(repr(item).encode("utf-8"))
        digest.update(b"\xff")

    feed(value)
    return digest.hexdigest()


def assert_historical(value):
    actual = resume.tree_sha256(value)
    assert actual == historical_tree_sha256(value)
    assert len(actual) == 64 and set(actual) <= set("0123456789abcdef")


@pytest.mark.parametrize("dtype", [
    "bool", "int8", "uint8", "int16", "uint16", "int32", "uint32",
    "int64", "uint64", "float16", "float32", "float64", "longdouble",
    "complex64", "complex128", "clongdouble", ">i4", ">f8", ">c16",
])
@pytest.mark.parametrize("layout", ["c", "fortran", "negative", "strided", "scalar", "empty"])
def test_numpy_numeric_layouts(dtype, layout):
    value = np.arange(24).astype(dtype).reshape(4, 6)
    if layout == "fortran":
        value = np.asfortranarray(value)
    elif layout == "negative":
        value = value[::-1, ::-1]
    elif layout == "strided":
        value = value[:, ::2]
    elif layout == "scalar":
        value = np.array(value[0, 0], dtype=dtype).reshape(())
    elif layout == "empty":
        value = np.empty((2, 0, 3), dtype=dtype)
    assert_historical(value)


@pytest.mark.parametrize("value", [
    np.array(["alpha", "beta"], dtype="U5"),
    np.array("alpha", dtype="U5"),
    np.empty((0, 2), dtype="U5"),
    np.array([b"a", b"b"], dtype="S2"),
    np.array([(1, 2.0), (3, 4.0)], dtype=[("x", "i4"), ("y", "f8")]),
    np.zeros(2, dtype=np.dtype([("x", "u1"), ("y", "i8")], align=True)),
    np.array([object(), None, "text"], dtype=object),
    np.array(object(), dtype=object),
    np.empty((0, 2), dtype=object),
    np.array([(object(),)], dtype=[("x", object)]),
    np.array(["2026-01-01"], dtype="datetime64[D]"),
    np.array([1, 2], dtype="timedelta64[ns]"),
    np.broadcast_to(np.array(7), (3, 4)),
])
def test_numpy_fallback_preserves_existing_tobytes(value):
    assert_historical(value)
    assert_historical(value.reshape(-1)[::-1])


@pytest.mark.parametrize("dtype", [
    torch.bool, torch.uint8, torch.int8, torch.int16, torch.int32, torch.int64,
    torch.float16, torch.bfloat16, torch.float32, torch.float64,
    torch.complex64, torch.complex128,
])
@pytest.mark.parametrize("layout", ["c", "transpose", "strided", "scalar", "empty"])
def test_tensor_layouts(dtype, layout):
    value = torch.arange(24).to(dtype).reshape(4, 6)
    if layout == "transpose":
        value = value.t()
    elif layout == "strided":
        value = value[:, ::2]
    elif layout == "scalar":
        value = value[0, 0]
    elif layout == "empty":
        value = torch.empty((2, 0, 3), dtype=dtype)
    assert_historical(value)


def test_nan_payloads_and_signed_zero_are_not_normalized():
    value = np.array([0x7FC00001, 0x7FC00002, 0xFFC00001, 0x80000000, 0], dtype="u4")
    assert_historical(value.view("f4"))
    assert_historical(torch.from_numpy(value.view("f4")))
    assert resume.tree_sha256(value[:1].view("f4")) != resume.tree_sha256(value[1:2].view("f4"))
    bf16 = torch.tensor([0x7FC1, 0x7FC2, -32768, 0], dtype=torch.int16).view(torch.bfloat16)
    assert_historical(bf16)


def test_randomized_nested_structures():
    rng = random.Random(1742)
    arrays = np.random.default_rng(1742)

    def build(depth):
        if depth and rng.randrange(2):
            children = [build(depth - 1) for _ in range(rng.randrange(5))]
            return rng.choice([list, tuple, lambda xs: dict(enumerate(xs))])(children)
        value = arrays.integers(-100, 100, size=(3, 4)).astype(rng.choice(["i8", "f4", "f8"]))
        return rng.choice([
            lambda: value, lambda: value.T, lambda: value[::-1],
            lambda: torch.from_numpy(value),
            lambda: rng.choice([None, True, 42, -0.0, float("nan"), "text", b"bytes"]),
        ])()

    for _ in range(100):
        assert_historical({"nested": build(4), 1: (), b"key": [False, None]})


@pytest.mark.parametrize("tensor", [False, True])
def test_mutation_is_observed_without_cache(tensor):
    source = np.arange(12, dtype="f4").reshape(3, 4)
    value = torch.from_numpy(source) if tensor else source
    tree = {"first": value, "alias": [value]}
    before = resume.tree_sha256(tree)
    source[0, 0] = 99
    assert_historical(tree)
    assert resume.tree_sha256(tree) != before
    source[0, 0] = 0
    assert resume.tree_sha256(tree) == before


@pytest.mark.parametrize("value", [set(), object(), np.float32(1), {"bad": bytearray(b"x")},
    torch.tensor([1 + 2j]).conj(), torch.sparse_coo_tensor([[0]], [1.0], (2,)),
])
def test_historical_errors_unchanged(value):
    with pytest.raises(Exception) as previous:
        historical_tree_sha256(value)
    with pytest.raises(type(previous.value)) as current:
        resume.tree_sha256(value)
    assert str(current.value) == str(previous.value)


def test_contiguous_numeric_update_uses_shared_buffer(monkeypatch):
    original = hashlib.sha256
    updates = []

    class RecordingDigest:
        def __init__(self):
            self.digest = original()

        def update(self, data):
            updates.append(data)
            self.digest.update(data)

        def hexdigest(self):
            return self.digest.hexdigest()

    array = np.arange(12, dtype="f4").reshape(3, 4)
    tensor = torch.from_numpy(array)
    expected = historical_tree_sha256([array, tensor])
    monkeypatch.setattr(resume.hashlib, "sha256", RecordingDigest)
    assert resume.tree_sha256([array, tensor]) == expected
    buffers = [data for data in updates if isinstance(data, memoryview)]
    assert len(buffers) == 2
    assert all(buffer.nbytes == array.nbytes for buffer in buffers)
    assert all(np.shares_memory(buffer.obj, array) for buffer in buffers)
