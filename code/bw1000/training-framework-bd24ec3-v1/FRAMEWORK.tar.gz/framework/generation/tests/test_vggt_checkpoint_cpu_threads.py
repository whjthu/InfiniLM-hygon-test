from __future__ import annotations

import copy
import threading
from pathlib import Path
from types import SimpleNamespace

import pytest
import yaml

torch = pytest.importorskip("torch")

from genmlu.backends import vggt_training as vggt


def test_default_config_keeps_checkpoint_thread_limit_disabled() -> None:
    config_path = Path(__file__).resolve().parents[1] / "configs" / "vggt-training.yaml"
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    assert config.get("checkpoint_cpu_threads_16", False) is False


class SimulatedThreadControl:
    def __init__(
        self,
        original: int,
        *,
        change_then_throw_target: bool = False,
        target_readback: int | None = None,
        restore_readback: int | None = None,
    ):
        self.threads = original
        self.original = original
        self.change_then_throw_target = change_then_throw_target
        self.target_readback = target_readback
        self.restore_readback = restore_readback
        self.target_applied = False
        self.restore_applied = False
        self.get_calls = 0
        self.set_calls: list[int] = []

    def get_num_threads(self) -> int:
        self.get_calls += 1
        if self.target_applied and self.threads == 16 and self.target_readback is not None:
            return self.target_readback
        if self.restore_applied and self.threads == self.original and self.restore_readback is not None:
            return self.restore_readback
        return self.threads

    def set_num_threads(self, value: int) -> None:
        self.set_calls.append(value)
        self.threads = value
        if value == 16:
            self.target_applied = True
            if self.change_then_throw_target:
                raise RuntimeError("target set changed then failed")
        if value == self.original:
            self.restore_applied = True

    def __getattr__(self, name: str):
        return getattr(torch, name)


def make_contract() -> dict:
    return vggt._vggt_contract(
        identity={key: "a" * 64 for key in vggt._VGGT_IDENTITY_FIELDS},
        seed=19,
        warmup_steps=2,
        max_steps=5,
        view_order=["seq-a:0,1", "seq-b:2,3"],
        device_ids=[],
    )


def make_model(seed: int) -> tuple[torch.nn.Module, torch.optim.AdamW]:
    torch.manual_seed(seed)
    module = torch.nn.Sequential(torch.nn.Linear(3, 5), torch.nn.Tanh(), torch.nn.Linear(5, 2))
    return module, torch.optim.AdamW(module.parameters(), lr=3e-3, weight_decay=0.01)


def step(module: torch.nn.Module, optimizer: torch.optim.AdamW) -> None:
    optimizer.zero_grad(set_to_none=True)
    module(torch.randn(4, 3)).square().mean().backward()
    optimizer.step()


def checkpoint() -> tuple[dict, torch.nn.Module, torch.optim.AdamW, dict]:
    contract = make_contract()
    module, optimizer = make_model(10)
    for _ in range(5):
        step(module, optimizer)
    payload = vggt._vggt_make_checkpoint(
        contract=contract,
        global_optimizer_step=5,
        module=module,
        optimizer=optimizer,
        torch=torch,
    )
    return contract, module, optimizer, payload


@pytest.mark.parametrize("value", [0, 1, "true", None])
def test_checkpoint_cpu_thread_flag_is_strict_bool_before_runtime_initialization(monkeypatch, value) -> None:
    called = False

    def fail_runtime():
        nonlocal called
        called = True
        raise AssertionError("runtime initialization must not happen")

    monkeypatch.setattr(vggt, "require_mlu", fail_runtime)
    with pytest.raises(ValueError, match="checkpoint_cpu_threads_16"):
        vggt.run_vggt_training(Path("weights"), {"checkpoint_cpu_threads_16": value}, Path("out"), Path("source"))
    assert not called
    assert vggt._vggt_checkpoint_cpu_threads_enabled({}) is False


@pytest.mark.parametrize("original", [1, 8, 16, 255])
def test_checkpoint_thread_context_bounds_and_restores_each_original_count(original: int) -> None:
    spy = SimulatedThreadControl(original)
    with vggt._vggt_checkpoint_cpu_thread_limit(spy, True):
        assert spy.threads == min(original, 16)
    assert spy.threads == original
    if original <= 16:
        assert spy.set_calls == []
    else:
        assert spy.set_calls == [16, original]


def test_checkpoint_thread_context_disabled_does_not_touch_torch() -> None:
    spy = SimulatedThreadControl(255)
    with vggt._vggt_checkpoint_cpu_thread_limit(spy, False):
        assert spy.threads == 255
    assert spy.get_calls == 0
    assert spy.set_calls == []


def test_checkpoint_thread_context_nesting_and_no_effect_do_not_overwrite_outer_setting() -> None:
    spy = SimulatedThreadControl(255)
    with vggt._vggt_checkpoint_cpu_thread_limit(spy, True):
        assert spy.threads == 16
        with vggt._vggt_checkpoint_cpu_thread_limit(spy, True):
            assert spy.threads == 16
        assert spy.threads == 16
    assert spy.threads == 255
    assert spy.set_calls == [16, 255]


def test_checkpoint_thread_context_serializes_process_wide_changes() -> None:
    spy = SimulatedThreadControl(255)
    first_entered = threading.Event()
    release_first = threading.Event()
    second_entered = threading.Event()

    def first() -> None:
        with vggt._vggt_checkpoint_cpu_thread_limit(spy, True):
            first_entered.set()
            assert release_first.wait(2)

    def second() -> None:
        with vggt._vggt_checkpoint_cpu_thread_limit(spy, True):
            second_entered.set()

    first_thread = threading.Thread(target=first)
    second_thread = threading.Thread(target=second)
    first_thread.start()
    assert first_entered.wait(2)
    second_thread.start()
    assert not second_entered.wait(0.05)
    release_first.set()
    first_thread.join(2)
    second_thread.join(2)
    assert not first_thread.is_alive() and not second_thread.is_alive()
    assert spy.threads == 255
    assert spy.set_calls == [16, 255, 16, 255]


def test_checkpoint_thread_context_restores_after_changed_target_set_failure_and_keyboard_interrupt() -> None:
    failed = SimulatedThreadControl(255, change_then_throw_target=True)
    body_entered = False
    with pytest.raises(RuntimeError, match="target set changed then failed"):
        with vggt._vggt_checkpoint_cpu_thread_limit(failed, True):
            body_entered = True
    assert failed.threads == 255
    assert failed.set_calls == [16, 255]
    assert not body_entered

    interrupted = SimulatedThreadControl(255)
    with pytest.raises(KeyboardInterrupt):
        with vggt._vggt_checkpoint_cpu_thread_limit(interrupted, True):
            raise KeyboardInterrupt
    assert interrupted.threads == 255
    assert interrupted.set_calls == [16, 255]


def test_checkpoint_thread_context_rejects_target_and_restore_readback_mismatches() -> None:
    target_mismatch = SimulatedThreadControl(255, target_readback=15)
    target_body_entered = False
    with pytest.raises(RuntimeError, match="did not take effect"):
        with vggt._vggt_checkpoint_cpu_thread_limit(target_mismatch, True):
            target_body_entered = True
    assert target_mismatch.threads == 255
    assert target_mismatch.set_calls == [16, 255]
    assert not target_body_entered

    restore_mismatch = SimulatedThreadControl(255, restore_readback=254)
    with pytest.raises(RuntimeError, match="was not restored") as error:
        with vggt._vggt_checkpoint_cpu_thread_limit(restore_mismatch, True):
            raise ValueError("body failure")
    assert isinstance(error.value.__context__, ValueError)
    assert restore_mismatch.threads == 255
    assert restore_mismatch.set_calls == [16, 255]


def test_checkpoint_hash_and_state_validation_restore_threads_and_keep_rng_outside(monkeypatch) -> None:
    contract, module, optimizer, payload = checkpoint()
    spy = SimulatedThreadControl(255)
    original_capture = vggt._vggt_capture_boundary
    original_hash = vggt.resume_common.tree_sha256
    capture_threads: list[int] = []
    hash_threads: list[int] = []
    rng_threads: list[int] = []

    def capture(**kwargs):
        capture_threads.append(spy.threads)
        return original_capture(**kwargs)

    def hashed(value):
        hash_threads.append(spy.threads)
        return original_hash(value)

    original_rng = vggt._vggt_validate_rng

    def validate_rng(*args, **kwargs):
        rng_threads.append(spy.threads)
        return original_rng(*args, **kwargs)

    monkeypatch.setattr(vggt, "_vggt_capture_boundary", capture)
    monkeypatch.setattr(vggt.resume_common, "tree_sha256", hashed)
    monkeypatch.setattr(vggt, "_vggt_validate_rng", validate_rng)
    vggt._vggt_make_checkpoint(
        contract=contract,
        global_optimizer_step=5,
        module=module,
        optimizer=optimizer,
        torch=spy,
        checkpoint_cpu_threads_16=True,
    )
    assert capture_threads == [255]
    assert hash_threads == [16, 16]
    assert rng_threads == [255]
    assert spy.threads == 255


def test_checkpoint_hash_failure_and_finite_failure_restore_threads_before_rng(monkeypatch) -> None:
    contract, module, optimizer, payload = checkpoint()
    spy = SimulatedThreadControl(255)
    original_hash = vggt.resume_common.tree_sha256

    def broken_hash(_value):
        assert spy.threads == 16
        raise RuntimeError("hash failure")

    monkeypatch.setattr(vggt.resume_common, "tree_sha256", broken_hash)
    with pytest.raises(RuntimeError, match="hash failure"):
        vggt._vggt_make_checkpoint(
            contract=contract,
            global_optimizer_step=5,
            module=module,
            optimizer=optimizer,
            torch=spy,
            checkpoint_cpu_threads_16=True,
        )
    assert spy.threads == 255

    monkeypatch.setattr(vggt.resume_common, "tree_sha256", original_hash)
    invalid = copy.deepcopy(payload)
    next(iter(invalid["state"]["optimizer"]["state"].values()))["exp_avg"][0] = float("nan")
    invalid["integrity_sha256"] = original_hash({key: value for key, value in invalid.items() if key != "integrity_sha256"})
    rng_called = False

    def should_not_preflight(*_args, **_kwargs):
        nonlocal rng_called
        rng_called = True
        raise AssertionError("RNG preflight must follow successful state validation")

    monkeypatch.setattr(vggt, "_vggt_validate_rng", should_not_preflight)
    with pytest.raises(vggt.VGGTCheckpointValidationError, match="AdamW"):
        vggt._vggt_validate_checkpoint(
            invalid,
            contract,
            module,
            optimizer,
            spy,
            native_rng=False,
            checkpoint_cpu_threads_16=True,
        )
    assert not rng_called
    assert spy.threads == 255


def test_checkpoint_application_and_serialization_stay_outside_thread_context(monkeypatch, tmp_path) -> None:
    contract, _module, _optimizer, payload = checkpoint()
    spy = SimulatedThreadControl(255)
    target, target_optimizer = make_model(99)
    observed: list[int] = []
    original_module_load = target.load_state_dict
    original_optimizer_load = target_optimizer.load_state_dict

    def module_load(state, **kwargs):
        observed.append(spy.threads)
        return original_module_load(state, **kwargs)

    def optimizer_load(state):
        observed.append(spy.threads)
        return original_optimizer_load(state)

    monkeypatch.setattr(target, "load_state_dict", module_load)
    monkeypatch.setattr(target_optimizer, "load_state_dict", optimizer_load)
    vggt._vggt_restore_checkpoint(
        payload,
        contract,
        target,
        target_optimizer,
        spy,
        checkpoint_cpu_threads_16=True,
    )
    vggt._vggt_assert_restored_boundary(
        payload,
        contract,
        target,
        target_optimizer,
        spy,
        checkpoint_cpu_threads_16=True,
    )
    forward_hook = target.register_forward_pre_hook(lambda *_args: observed.append(spy.threads))
    original_step = target_optimizer.step

    def optimizer_step(*args, **kwargs):
        observed.append(spy.threads)
        return original_step(*args, **kwargs)

    monkeypatch.setattr(target_optimizer, "step", optimizer_step)
    target_optimizer.zero_grad(set_to_none=True)
    target(torch.ones(2, 3)).sum().backward()
    target_optimizer.step()
    forward_hook.remove()
    assert observed == [255, 255, 255, 255]
    vggt._vggt_save_checkpoint(tmp_path / "checkpoint.pt", payload, spy)
    assert spy.threads == 255
    assert spy.set_calls == [16, 255, 16, 255]


def test_checkpoint_thread_switch_is_operational_but_other_identity_changes_remain_blocking(monkeypatch, tmp_path) -> None:
    monkeypatch.setattr(vggt, "sha256_path", lambda _path: "a" * 64)
    monkeypatch.setattr(vggt, "_module_sha", lambda _module: "b" * 64)
    monkeypatch.setattr(vggt, "_vggt_source_evidence", lambda _model, _optimizer: {"fixture": "c" * 64})
    monkeypatch.setattr(vggt, "_vggt_optimizer_evidence", lambda _optimizer, _module: {"fixture": "d" * 64})
    monkeypatch.setattr(vggt, "_vggt_batch_content_sha256", lambda _batches: "e" * 64)
    model = SimpleNamespace(aggregator=object(), camera_head=object())
    kwargs = {
        "weights": tmp_path,
        "dataset_root": tmp_path / "data",
        "annotation_root": tmp_path / "annotations",
        "model": model,
        "optimizer": object(),
        "batches": [],
        "cache_enabled": False,
    }
    base, _ = vggt._vggt_resume_identity(config={"checkpoint_cpu_threads_16": False}, **kwargs)
    switched, _ = vggt._vggt_resume_identity(config={"checkpoint_cpu_threads_16": True}, **kwargs)
    changed, _ = vggt._vggt_resume_identity(config={"checkpoint_cpu_threads_16": True, "frames_per_step": 3}, **kwargs)
    assert switched == base
    assert changed["workload"] != base["workload"]
    assert all(changed[key] == base[key] for key in base if key != "workload")


def test_real_cpu_torch_thread_context_restores() -> None:
    original = torch.get_num_threads()
    try:
        torch.set_num_threads(32)
        assert torch.get_num_threads() == 32
        with vggt._vggt_checkpoint_cpu_thread_limit(torch, True):
            assert torch.get_num_threads() == 16
        assert torch.get_num_threads() == 32
    finally:
        torch.set_num_threads(original)
