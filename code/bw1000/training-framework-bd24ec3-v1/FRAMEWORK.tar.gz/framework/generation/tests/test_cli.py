from __future__ import annotations

import copy
from contextlib import contextmanager
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from genmlu import cli
from genmlu.models import ModelSpec


def backend_result(tmp_path: Path, checks: dict[str, bool] | None = None) -> dict[str, object]:
    artifact = tmp_path / "artifact.bin"
    artifact.write_bytes(b"verified artifact")
    return {
        "artifacts": [{"path": str(artifact), "sha256": cli.sha256_path(artifact)}],
        "logs": [],
        "metrics": {},
        "stage_timings": {},
        "checks": {} if checks is None else checks,
    }


@pytest.mark.parametrize("command", ["train", "rl"])
def test_trellis_qualification_drivers_are_not_runtime_commands(tmp_path, command):
    spec = ModelSpec("trellis-2-4b", "3d-generation", "trellis", "trellis-2-4b", "bfloat16", "not-included")
    with pytest.raises(RuntimeError, match="not implemented"):
        cli.run_backend(command, spec, tmp_path, {}, tmp_path, None)


def test_path_only_inference_result_is_rejected(tmp_path: Path) -> None:
    artifact = tmp_path / "image.png"
    artifact.write_bytes(b"image")
    with pytest.raises(TypeError, match="unsupported result type"):
        cli.normalize_backend_result(artifact)


def test_invalid_recovery_flag_is_rejected_during_config_loading(tmp_path: Path) -> None:
    config = tmp_path / "run.yaml"
    config.write_text('validate_recovery: "false"\n', encoding="utf-8")
    with pytest.raises(ValueError, match="validate_recovery must be a boolean"):
        cli.load_run_config(config, "sdxl-1.0")


@pytest.mark.parametrize("literal", ["1e-5", "1e-05", "1.0e-05", "2e-05"])
def test_json_config_preserves_scientific_numbers_as_floats(
    tmp_path: Path, literal: str
) -> None:
    config = tmp_path / "run.json"
    config.write_text(
        '{"model":"hunyuanvideo-1.5","learning_rate":' + literal + '}\n',
        encoding="utf-8",
    )

    loaded = cli.load_run_config(config, "hunyuanvideo-1.5")

    assert type(loaded["learning_rate"]) is float
    assert loaded["learning_rate"] == float(literal)


def test_yaml_config_loading_semantics_are_unchanged(tmp_path: Path) -> None:
    config = tmp_path / "run.yaml"
    config.write_text(
        "model: hunyuanvideo-1.5\nlearning_rate: 1e-5\n",
        encoding="utf-8",
    )

    loaded = cli.load_run_config(config, "hunyuanvideo-1.5")

    assert loaded["learning_rate"] == "1e-5"


def test_json_config_rejects_yaml_only_syntax(tmp_path: Path) -> None:
    config = tmp_path / "run.json"
    config.write_text(
        "model: hunyuanvideo-1.5\nlearning_rate: 1.0e-5\n",
        encoding="utf-8",
    )

    with pytest.raises(json.JSONDecodeError):
        cli.load_run_config(config, "hunyuanvideo-1.5")


def test_vggt_dispatch_passes_its_source_root_by_keyword(tmp_path: Path, monkeypatch) -> None:
    source_root = tmp_path / "sources"
    (source_root / "vggt").mkdir(parents=True)
    observed = {}

    def fake_call(_module, _function, *args, **kwargs):
        observed["args"] = args
        observed["kwargs"] = kwargs
        return {"artifacts": [], "logs": [], "metrics": {}, "stage_timings": {}, "checks": {}}

    monkeypatch.setattr(cli, "_call", fake_call)
    spec = ModelSpec("vggt-1b", "geometry", "vggt", "vggt-1b", "bfloat16", "not-applicable")
    cli.run_backend("infer", spec, tmp_path / "weights", {}, tmp_path / "out", source_root)
    assert len(observed["args"]) == 3
    assert observed["kwargs"] == {"source_root": source_root / "vggt"}


def test_output_root_inside_the_repository_is_rejected_before_creating_a_run() -> None:
    with pytest.raises(ValueError, match="external to the delivery worktree"):
        cli.create_run_dir(cli.PACKAGE_ROOT / "outputs", "sdxl-1.0", "infer", "run-1")


def test_output_root_reached_through_a_symlink_is_rejected(tmp_path: Path) -> None:
    link = tmp_path / "repository-link"
    try:
        link.symlink_to(cli.PACKAGE_ROOT, target_is_directory=True)
    except OSError:
        pytest.skip("symlinks are unavailable in this test environment")
    with pytest.raises(ValueError, match="external to the delivery worktree"):
        cli.create_run_dir(link / "outputs", "sdxl-1.0", "infer", "run-1")


def test_symlinked_child_of_output_root_is_rejected(tmp_path: Path) -> None:
    output_root = tmp_path / "outputs"
    output_root.mkdir()
    target = tmp_path / "outside"
    target.mkdir()
    try:
        (output_root / "sdxl-1.0").symlink_to(target, target_is_directory=True)
    except OSError:
        pytest.skip("symlinks are unavailable in this test environment")
    with pytest.raises(ValueError, match="must not be a symlink"):
        cli.create_run_dir(output_root, "sdxl-1.0", "infer", "run-1")


def test_run_name_matching_a_parent_component_does_not_reject_that_parent(tmp_path: Path) -> None:
    output_root = tmp_path / "outputs"
    (output_root / "sdxl-1.0" / "infer").mkdir(parents=True)
    directory = cli.create_run_dir(output_root, "sdxl-1.0", "infer", "infer")
    assert directory == output_root / "sdxl-1.0" / "infer" / "infer"


def test_lease_covers_backend_execution(tmp_path: Path, monkeypatch) -> None:
    entered = False
    manifest_configs = []
    monkeypatch.setenv("MLU_VISIBLE_DEVICES", "0,2")

    @contextmanager
    def fake_acquire(cards, *_args, **_kwargs):
        nonlocal entered
        assert cards == (0, 2)
        entered = True
        yield tmp_path / "locks"
        entered = False

    def fake_backend(*_args, **_kwargs):
        assert entered
        return backend_result(tmp_path)

    def fake_runtime():
        assert entered
        return SimpleNamespace(torch_version=None, mlu_available=False, mlu_count=0, device_name=None)

    spec = ModelSpec("sdxl-1.0", "image", "diffusers", "sdxl-1.0", "bfloat16", "ddpo")
    monkeypatch.setattr(cli, "get_spec", lambda *_args: spec)
    monkeypatch.setattr(cli, "load_run_config", lambda *_args: {})
    monkeypatch.setattr(cli, "resolve_weights", lambda *_args: tmp_path / "weights")
    monkeypatch.setattr(cli, "create_run_dir", lambda *_args: tmp_path / "run")
    monkeypatch.setattr(
        cli,
        "new_manifest",
        lambda _command, _model, config, _runtime: manifest_configs.append(copy.deepcopy(config)) or {
            "checks": {}, "provenance": {}, "execution": {}
        },
    )
    monkeypatch.setattr(cli, "write_manifest", lambda *_args: None)
    monkeypatch.setattr(cli, "acquire", fake_acquire)
    monkeypatch.setattr(cli, "inspect_runtime", fake_runtime)
    monkeypatch.setattr(cli, "run_backend", fake_backend)
    args = SimpleNamespace(
        command="infer", models_config="models.yaml", model="sdxl-1.0", config="run.yaml",
        output_root=str(tmp_path / "outputs"), run_name="run-1", model_root=None, weights=None,
        source_root=None, dry_run=False, cards="2,0", lock_root=str(tmp_path / "locks"), lock_host="physical-a",
    )
    assert cli.cmd_run(args) == 0
    assert manifest_configs == [{"model": "sdxl-1.0", "run_name": "run-1", "output_root": str(tmp_path / "outputs"), "cards": [0, 2]}]
    assert not entered


def test_visible_cards_is_fixed_before_runtime_initialization(monkeypatch) -> None:
    monkeypatch.delenv("MLU_VISIBLE_DEVICES", raising=False)
    cli.configure_visible_cards((3, 1))
    assert cli.os.environ["MLU_VISIBLE_DEVICES"] == "3,1"
    with pytest.raises(RuntimeError, match="refusing to switch"):
        cli.configure_visible_cards((0,))


@pytest.mark.parametrize("failed", [True, False])
def test_backend_checks_and_optional_observations(tmp_path: Path, monkeypatch, failed) -> None:
    written = []
    entered = False
    monkeypatch.setenv("MLU_VISIBLE_DEVICES", "0")

    @contextmanager
    def fake_acquire(*_args, **_kwargs):
        nonlocal entered
        entered = True
        yield tmp_path / "locks"
        entered = False

    def fake_runtime():
        assert entered
        return SimpleNamespace(torch_version=None, mlu_available=False, mlu_count=0, device_name=None)

    spec = ModelSpec("sdxl-1.0", "image", "diffusers", "sdxl-1.0", "bfloat16", "ddpo")
    monkeypatch.setattr(cli, "get_spec", lambda *_args: spec)
    monkeypatch.setattr(cli, "load_run_config", lambda *_args: {})
    monkeypatch.setattr(cli, "resolve_weights", lambda *_args: tmp_path / "weights")
    monkeypatch.setattr(cli, "create_run_dir", lambda *_args: tmp_path / "run")
    monkeypatch.setattr(cli, "new_manifest", lambda *_args: {"checks": {}, "provenance": {}, "execution": {}})
    monkeypatch.setattr(cli, "write_manifest", lambda _path, manifest: written.append(copy.deepcopy(manifest)))
    monkeypatch.setattr(cli, "parse_cards", lambda _value: (0,))
    monkeypatch.setattr(cli, "acquire", fake_acquire)
    monkeypatch.setattr(cli, "inspect_runtime", fake_runtime)
    result = backend_result(tmp_path, {"finite_tensors": not failed})
    result["observations"] = {"mlu_utilization_captured": False}
    monkeypatch.setattr(cli, "run_backend", lambda *_args: result)
    args = SimpleNamespace(
        command="infer", models_config="models.yaml", model="sdxl-1.0", config="run.yaml",
        output_root=str(tmp_path / "outputs"), run_name="run-1", model_root=None, weights=None,
        source_root=None, dry_run=False, cards="0", lock_root=str(tmp_path / "locks"), lock_host="physical-a",
    )
    if failed:
        with pytest.raises(RuntimeError, match="finite_tensors"):
            cli.cmd_run(args)
        assert written[-1]["status"] == "failed"
        assert written[-1]["execution"]["failed_checks"] == ["finite_tensors"]
    else:
        assert cli.cmd_run(args) == 0
        assert written[-1]["status"] == "completed"
    assert written[-1]["observations"] == {"mlu_utilization_captured": False}


def test_missing_physical_lock_host_fails_before_runtime_or_backend(tmp_path: Path, monkeypatch) -> None:
    written = []
    spec = ModelSpec("sdxl-1.0", "image", "diffusers", "sdxl-1.0", "bfloat16", "ddpo")
    monkeypatch.setattr(cli, "get_spec", lambda *_args: spec)
    monkeypatch.setattr(cli, "load_run_config", lambda *_args: {})
    monkeypatch.setattr(cli, "resolve_weights", lambda *_args: tmp_path / "weights")
    monkeypatch.setattr(cli, "create_run_dir", lambda *_args: tmp_path / "run")
    monkeypatch.setattr(cli, "write_manifest", lambda _path, manifest: written.append(copy.deepcopy(manifest)))
    monkeypatch.setattr(cli, "inspect_runtime", lambda: (_ for _ in ()).throw(AssertionError("runtime")))
    monkeypatch.setattr(cli, "run_backend", lambda *_args: (_ for _ in ()).throw(AssertionError("backend")))
    args = SimpleNamespace(
        command="infer", models_config="models.yaml", model="sdxl-1.0", config="run.yaml",
        output_root=str(tmp_path / "outputs"), run_name="run-1", model_root=None, weights=None,
        source_root=None, dry_run=False, cards="0", lock_root=str(tmp_path / "locks"), lock_host=None,
    )
    with pytest.raises(ValueError, match="--lock-host"):
        cli.cmd_run(args)
    assert written[-1]["status"] == "failed"
    assert written[-1]["execution"]["stage"] == "configure_lease"


def test_backend_exception_replaces_running_manifest_with_failed_state(tmp_path: Path, monkeypatch) -> None:
    written = []
    entered = False
    monkeypatch.setenv("MLU_VISIBLE_DEVICES", "0")

    @contextmanager
    def fake_acquire(*_args, **_kwargs):
        nonlocal entered
        entered = True
        try:
            yield tmp_path / "locks"
        finally:
            entered = False

    def fake_runtime():
        assert entered
        return SimpleNamespace(torch_version=None, mlu_available=False, mlu_count=0, device_name=None)

    def failed_backend(*_args, **_kwargs):
        assert entered
        raise RuntimeError("backend exploded")

    spec = ModelSpec("sdxl-1.0", "image", "diffusers", "sdxl-1.0", "bfloat16", "ddpo")
    monkeypatch.setattr(cli, "get_spec", lambda *_args: spec)
    monkeypatch.setattr(cli, "load_run_config", lambda *_args: {})
    monkeypatch.setattr(cli, "resolve_weights", lambda *_args: tmp_path / "weights")
    monkeypatch.setattr(cli, "create_run_dir", lambda *_args: tmp_path / "run")
    monkeypatch.setattr(cli, "write_manifest", lambda _path, manifest: written.append(copy.deepcopy(manifest)))
    monkeypatch.setattr(cli, "parse_cards", lambda _value: (0,))
    monkeypatch.setattr(cli, "acquire", fake_acquire)
    monkeypatch.setattr(cli, "inspect_runtime", fake_runtime)
    monkeypatch.setattr(cli, "run_backend", failed_backend)
    args = SimpleNamespace(
        command="infer", models_config="models.yaml", model="sdxl-1.0", config="run.yaml",
        output_root=str(tmp_path / "outputs"), run_name="run-1", model_root=None, weights=None,
        source_root=None, dry_run=False, cards="0", lock_root=str(tmp_path / "locks"), lock_host="physical-a",
    )
    with pytest.raises(RuntimeError, match="backend exploded"):
        cli.cmd_run(args)
    assert written[0]["status"] == "running"
    assert written[-1]["status"] == "failed"
    assert written[-1]["execution"]["stage"] == "run_backend"
    assert written[-1]["execution"]["error"]["type"] == "RuntimeError"
    assert not entered


def test_dry_run_never_configures_cards_or_inspects_the_runtime(tmp_path: Path, monkeypatch) -> None:
    written = []
    spec = ModelSpec("sdxl-1.0", "image", "diffusers", "sdxl-1.0", "bfloat16", "ddpo")
    monkeypatch.setattr(cli, "get_spec", lambda *_args: spec)
    monkeypatch.setattr(cli, "load_run_config", lambda *_args: {})
    monkeypatch.setattr(cli, "resolve_weights", lambda *_args: (_ for _ in ()).throw(AssertionError("weights")))
    monkeypatch.setattr(cli, "create_run_dir", lambda *_args: tmp_path / "run")
    monkeypatch.setattr(cli, "inspect_runtime", lambda: (_ for _ in ()).throw(AssertionError("runtime")))
    monkeypatch.setattr(cli, "configure_visible_cards", lambda *_args: (_ for _ in ()).throw(AssertionError("cards")))
    monkeypatch.setattr(cli, "write_manifest", lambda _path, manifest: written.append(manifest.copy()))
    args = SimpleNamespace(
        command="infer", models_config="models.yaml", model="sdxl-1.0", config="run.yaml",
        output_root=str(tmp_path / "outputs"), run_name="run-1", model_root=None, weights=None,
        source_root=None, dry_run=True, cards="not-parsed", lock_root=str(tmp_path / "locks"), lock_host=None,
    )
    assert cli.cmd_run(args) == 0
    assert written[-1]["status"] == "planned"
    assert written[-1]["runtime"] == {"inspection": "deferred"}
