from __future__ import annotations

import inspect

import pytest
import torch

from genmlu.backends import hy_motion_motionrft as motionrft


class WrappedAdapter(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.block = torch.nn.Module()
        self.block._checkpoint_wrapped_module = torch.nn.Module()
        self.block._checkpoint_wrapped_module.used = torch.nn.Parameter(torch.ones(2))
        self.unused = torch.nn.Parameter(torch.zeros(2))


def test_named_gradients_before_clip_are_complete_and_checkpoint_canonical() -> None:
    adapter = WrappedAdapter()
    adapter.block._checkpoint_wrapped_module.used.grad = torch.tensor([3.0, -4.0])

    gradients = motionrft._named_gradients_before_clip(adapter, max_bytes=8)

    assert list(gradients) == ["block.used", "unused"]
    assert gradients["unused"] is None
    assert torch.equal(gradients["block.used"], torch.tensor([3.0, -4.0]))
    adapter.block._checkpoint_wrapped_module.used.grad.zero_()
    assert torch.equal(gradients["block.used"], torch.tensor([3.0, -4.0]))


def test_validation_trace_snapshots_gradients_before_legacy_clipping() -> None:
    source = inspect.getsource(motionrft.run_hy_motion_motionrft)
    assert source.index('"named_gradients_before_clip"') < source.index(
        "torch.nn.utils.clip_grad_norm_"
    )
    assert source.index('validation_trace["gradient"]') > source.index(
        "torch.nn.utils.clip_grad_norm_"
    )


@pytest.mark.parametrize(
    "config",
    [
        {"write_validation_trace": "true"},
        {"validation_trace_max_steps": 0},
        {"validation_trace_max_bytes": 0},
    ],
)
def test_validation_trace_rejects_invalid_limits(config: dict[str, object]) -> None:
    with pytest.raises(ValueError):
        motionrft._validation_trace_options(config)


def test_validation_trace_collector_respects_step_and_byte_budgets() -> None:
    collector = motionrft._ValidationTraceCollector(max_steps=1, max_bytes=8)
    assert collector.append({"gradient": torch.ones(2)})
    assert not collector.append({"gradient": torch.ones(1)})
    assert collector.bytes_used == 8
    assert collector.dropped_records == 1


def test_named_gradient_capture_rejects_over_budget_snapshot() -> None:
    adapter = WrappedAdapter()
    adapter.block._checkpoint_wrapped_module.used.grad = torch.ones(2)
    with pytest.raises(ValueError, match="byte budget"):
        motionrft._named_gradients_before_clip(adapter, max_bytes=7)
