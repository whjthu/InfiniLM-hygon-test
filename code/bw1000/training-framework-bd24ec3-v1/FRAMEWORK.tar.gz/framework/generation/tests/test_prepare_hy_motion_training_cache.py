from __future__ import annotations

import importlib.util
from argparse import Namespace
from pathlib import Path

import numpy as np
import pytest


def _prepare_module():
    path = Path(__file__).parents[1] / "scripts" / "prepare_hy_motion_training_cache.py"
    spec = importlib.util.spec_from_file_location("prepare_hy_motion_training_cache", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.mark.parametrize("sample_id", ["../outside", "..\\outside", "/absolute", "C:\\outside"])
def test_train_sample_id_rejects_path_escape(sample_id: str) -> None:
    with pytest.raises(RuntimeError, match="invalid HumanML3D train sample ID"):
        _prepare_module()._validate_train_sample_id(sample_id)


def test_missing_sources_are_recorded_and_next_eligible_sample_is_selected(tmp_path: Path) -> None:
    root = tmp_path / "humanml3d"
    root.mkdir()
    (root / "train.txt").write_text("000001\n000002\n", encoding="utf-8")
    for name in ("joints_6d", "new_joints", "texts"):
        (root / name).mkdir()
    np.save(root / "joints_6d" / "000002.npy", np.zeros((2, 135), dtype=np.float32))
    np.save(root / "new_joints" / "000002.npy", np.zeros((2, 22, 3), dtype=np.float32))
    (root / "texts" / "000002.txt").write_text("walk forward\n", encoding="utf-8")
    args = Namespace(dataset_root=root, samples=1, min_frames=1, frames=2)
    skipped: list[dict[str, object]] = []

    selected = list(_prepare_module().iter_selected_samples(args, skipped))

    assert [sample["sample_id"] for sample in selected] == ["000002"]
    assert skipped == [
        {
            "sample_id": "000001",
            "reason": "missing_source_files",
            "missing_paths": [
                str(root / "joints_6d" / "000001.npy"),
                str(root / "new_joints" / "000001.npy"),
                str(root / "texts" / "000001.txt"),
            ],
        }
    ]


def test_requested_eligible_sample_count_is_enforced_after_skips(tmp_path: Path) -> None:
    root = tmp_path / "humanml3d"
    root.mkdir()
    (root / "train.txt").write_text("000001\n", encoding="utf-8")
    args = Namespace(dataset_root=root, samples=128, min_frames=1, frames=2)

    with pytest.raises(RuntimeError, match="selected 0 samples, expected 128"):
        list(_prepare_module().iter_selected_samples(args, []))


def test_staged_output_is_published_once_and_rejects_existing_target(tmp_path: Path) -> None:
    module = _prepare_module()
    output = tmp_path / "published"
    staging = module._create_staging_output(output)
    (staging / "manifest.json").write_text("{}", encoding="utf-8")

    module._publish_staged_output(staging, output)

    assert (output / "manifest.json").is_file()
    with pytest.raises(RuntimeError, match="already exists"):
        module._create_staging_output(output)
