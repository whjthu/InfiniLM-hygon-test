from contextlib import nullcontext
from pathlib import Path
from types import SimpleNamespace
import sys

import pytest
import numpy as np
from PIL import Image

from genmlu.backends import diffusers_image, vggt_geometry
from genmlu.manifest import merge_backend_result, new_manifest, sha256_path


def assert_result(result, model):
    manifest = new_manifest("infer", model, {}, {})
    merge_backend_result(manifest, result)
    assert manifest["metrics"]["measurement_samples"] == 1
    assert manifest["checks"]["main_forward_device"] == "mlu"
    for artifact in result["artifacts"]:
        assert sha256_path(Path(artifact["path"])) == artifact["sha256"]


@pytest.mark.parametrize("pixel", [0.0, 1.0, float("nan"), float("inf")])
def test_single_image_retains_metrics_and_checks(tmp_path, monkeypatch, pixel):
    class Pipeline:
        image_processor = SimpleNamespace(numpy_to_pil=lambda pixels: [
            Image.fromarray((pixels * 255).round().astype("uint8")),
        ])
        @classmethod
        def from_pretrained(cls, *args, **kwargs):
            return cls()

        def to(self, device):
            assert device == "mlu"
            return self

        def __call__(self, **kwargs):
            assert kwargs["output_type"] == "np"
            return SimpleNamespace(images=[np.full((8, 8, 3), pixel, dtype=np.float32)])

    torch = SimpleNamespace(
        manual_seed=lambda seed: None, bfloat16=object(),
        mlu=SimpleNamespace(manual_seed_all=lambda seed: None,
                            reset_peak_memory_stats=lambda: None,
                            max_memory_reserved=lambda: 123),
    )
    monkeypatch.setitem(sys.modules, "diffusers", SimpleNamespace(DiffusionPipeline=Pipeline))
    monkeypatch.setattr(diffusers_image, "require_mlu", lambda: torch)
    monkeypatch.setattr(diffusers_image, "autocast_bf16", nullcontext)
    monkeypatch.setattr(diffusers_image, "synchronize", lambda: None)
    def run():
        return diffusers_image.run_image_inference(
            "sdxl-1.0", tmp_path, {"prompt": "a square"}, tmp_path / "out",
        )

    if not np.isfinite(pixel):
        with pytest.raises(RuntimeError, match="non-finite output pixels"):
            run()
        assert not (tmp_path / "out" / "image.png").exists()
        return
    result = run()
    assert_result(result, "sdxl-1.0")
    assert result["checks"]["finite_tensors"] is True
    assert result["artifact"].name == "image.png"


@pytest.mark.parametrize("finite", [True, False])
def test_single_vggt_result_preserves_finiteness(tmp_path, monkeypatch, finite):
    torch = pytest.importorskip("torch")

    class Model:
        def load_state_dict(self, state, strict):
            assert strict

        def to(self, device):
            assert device == "mlu"
            return self

        def eval(self):
            return self

        def __call__(self, images):
            return {"pose_enc": torch.tensor([1.0 if finite else float("nan")])}

    runtime = SimpleNamespace(
        load=lambda *args, **kwargs: {}, save=torch.save, no_grad=torch.no_grad,
        isfinite=torch.isfinite, mlu=SimpleNamespace(
            reset_peak_memory_stats=lambda: None, max_memory_reserved=lambda: 123,
        ),
    )
    monkeypatch.setitem(sys.modules, "vggt.models.vggt", SimpleNamespace(VGGT=Model))
    monkeypatch.setitem(sys.modules, "vggt.utils.load_fn", SimpleNamespace(
        load_and_preprocess_images=lambda paths: SimpleNamespace(to=lambda device: paths),
    ))
    monkeypatch.setattr(sys, "path", list(sys.path))
    monkeypatch.setattr(vggt_geometry, "require_mlu", lambda: runtime)
    monkeypatch.setattr(vggt_geometry, "autocast_bf16", nullcontext)
    monkeypatch.setattr(vggt_geometry, "synchronize", lambda: None)
    image_path = tmp_path / "input.png"
    Image.new("RGB", (8, 8), "white").save(image_path)
    result = vggt_geometry.run_vggt_inference(
        tmp_path, {"image_paths": [str(image_path)]}, tmp_path / "out", source_root=tmp_path,
    )
    assert_result(result, "vggt-1b")
    assert result["checks"]["finite_tensors"] is finite
