"""Dependency-free DP2 admission and wiring tests; no runtime is loaded."""
import ast
import math
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src/genmlu/backends/hunyuanvideo_data_parallel.py"
TREE = ast.parse(SOURCE.read_text(encoding="utf-8"))
NAMESPACE = {"Any": Any, "math": math, "os": os, "Path": Path, "sys": sys}
for name in ("validate_config", "worker_rank", "validate_visible_cards", "bind_visible_cards",
             "validate_parent_launch", "validate_source_root", "validate_loaded_native_modules",
             "validate_dp_checks", "validate_dp_result", "_local_torchrun_command"):
    node = next(node for node in TREE.body if isinstance(node, ast.FunctionDef) and node.name == name)
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(SOURCE), "exec"), NAMESPACE)
validate = NAMESPACE["validate_config"]
rank = NAMESPACE["worker_rank"]


def valid():
    return {"parallel_mode": "data_parallel", "cards": [3, 7], "training_cache_sha": "a" * 64}


class DPAdmissionTests(unittest.TestCase):
    def test_static_loopback_command_has_no_standalone_or_hostname(self):
        arguments = ["--worker", "/tmp/request.json", "--request-sha", "a" * 64]
        command = NAMESPACE["_local_torchrun_command"]("genmlu.backends.hunyuanvideo_data_parallel", arguments)
        self.assertEqual(command, [sys.executable, "-m", "torch.distributed.run", "--nnodes=1",
            "--nproc-per-node=2", "--rdzv-backend=static", "--rdzv-endpoint=127.0.0.1:29500",
            "--node-rank=0", "--master-addr=127.0.0.1", "--master-port=29500",
            "--local-addr=127.0.0.1", "--max-restarts=0", "--module",
            "genmlu.backends.hunyuanvideo_data_parallel", *arguments])
        self.assertNotIn("--standalone", command)
        self.assertEqual(arguments, ["--worker", "/tmp/request.json", "--request-sha", "a" * 64])
        parent = ast.get_source_segment(SOURCE.read_text(encoding="utf-8"),
            next(node for node in TREE.body if isinstance(node, ast.FunctionDef)
                 and node.name == "run_hunyuanvideo_data_parallel"))
        self.assertIn('_local_torchrun_command("genmlu.backends.hunyuanvideo_data_parallel"', parent)
        self.assertNotIn("--standalone", parent)

    def test_valid_config(self):
        validate(valid())

    def test_fixed_eight_rank_admission_and_static_command(self):
        config = valid() | {"world_size": 8, "cards": list(range(8))}
        validate(config)
        command = NAMESPACE["_local_torchrun_command"]("worker", [], 8)
        self.assertIn("--nproc-per-node=8", command)
        self.assertIn("--max-restarts=0", command)
        environment = {}
        NAMESPACE["bind_visible_cards"](config, environment)
        self.assertEqual(environment, {name: "0,1,2,3,4,5,6,7"
            for name in ("MLU_VISIBLE_DEVICES", "CNRT_VISIBLE_DEVICES")})
        for index in range(8):
            env = {"WORLD_SIZE": "8", "LOCAL_WORLD_SIZE": "8",
                   "RANK": str(index), "LOCAL_RANK": str(index)}
            self.assertEqual(rank(env, 8), index)
            for change in ({"WORLD_SIZE": "2"}, {"LOCAL_WORLD_SIZE": "2"}, {"RANK": "8"},
                           {"RANK": "07"}, {"LOCAL_RANK": "8"}, {"TORCHELASTIC_RESTART_COUNT": "1"}):
                with self.subTest(index=index, change=change), self.assertRaises(ValueError):
                    rank(env | change, 8)
        for change in ({"world_size": 2}, {"world_size": True}, {"world_size": 4},
                       {"cards": list(range(7))}, {"cards": list(range(7)) + [6]},
                       {"cards": [False] + list(range(1, 8))}, {"seed": 2**32 - 7},
                       {"sp": 8}, {"sequence_parallel_size": 8}, {"elastic": True},
                       {"fsdp": True}, {"optimizer_sharding": True}):
            with self.subTest(change=change), self.assertRaises(ValueError):
                validate(config | change)
        for name in ("MLU_VISIBLE_DEVICES", "CNRT_VISIBLE_DEVICES"):
            with self.subTest(name=name), self.assertRaises(RuntimeError):
                NAMESPACE["validate_parent_launch"](config, {name: "0,1"})

    def test_cli_card_count_uses_admitted_world_and_keeps_other_models_single(self):
        path = ROOT / "src/genmlu/cli.py"
        tree = ast.parse(path.read_text(encoding="utf-8"))
        command = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "cmd_run")
        gate = next(node for node in command.body if isinstance(node, ast.If)
                    and any(isinstance(item, ast.Name) and item.id == "required_cards" for item in ast.walk(node)))
        for model, world in (("hunyuanvideo-1.5", 2), ("hunyuanvideo-1.5", 8), ("hy-motion-1.0", 1)):
            namespace = {"args": SimpleNamespace(command="train", cards=list(range(world))),
                "spec": SimpleNamespace(name=model), "config": {"parallel_mode": "data_parallel", "world_size": world},
                "parse_cards": lambda cards: cards}
            exec(compile(ast.Module(body=[gate], type_ignores=[]), str(path), "exec"), namespace)
            self.assertEqual(namespace["required_cards"], world)
            namespace["args"].cards = list(range(world + 1))
            with self.assertRaises(ValueError):
                exec(compile(ast.Module(body=[gate], type_ignores=[]), str(path), "exec"), namespace)

    def test_rejects_card_and_parallel_variants(self):
        for update in ({"cards": [0]}, {"cards": [0, 0]}, {"cards": [False, 1]},
                       {"cards": [-1, 2]}, {"cards": "0,1"}, {"cards": [0, "1"]},
                       {"parallel_mode": "fsdp"}, {"world_size": True}, {"world_size": 3},
                       {"sp": 2}, {"fsdp": True}, {"elastic": True}, {"optimizer_sharding": True},
                       {"rank": 0}, {"local_rank": 0}, {"validate_recovery": True}):
            with self.subTest(update=update), self.assertRaises(ValueError):
                validate(valid() | update)

    def test_rejects_bad_schedule_cache_and_numeric_policy(self):
        for update in ({"seed": True}, {"max_steps": 0}, {"warmup_steps": -1},
                       {"checkpoint_steps": [True]}, {"checkpoint_steps": [5]},
                       {"checkpoint_step_basis": "measured"}, {"training_cache_sha": None},
                       {"training_cache_sha": "A" * 64}, {"learning_rate": math.nan},
                       {"max_grad_norm": 0}, {"deterministic_algorithms": False},
                       {"process_timeout_seconds": 0}, {"collective_timeout_seconds": 1801}):
            with self.subTest(update=update), self.assertRaises(ValueError):
                validate(valid() | update)

    def test_worker_rank_mapping_and_restart_refusal(self):
        env = {"WORLD_SIZE": "2", "LOCAL_WORLD_SIZE": "2", "RANK": "0", "LOCAL_RANK": "0"}
        self.assertEqual(rank(env), 0)
        self.assertEqual(rank(env | {"RANK": "1", "LOCAL_RANK": "1"}), 1)
        for update in ({"WORLD_SIZE": "1"}, {"LOCAL_WORLD_SIZE": "4"}, {"RANK": "2"},
                       {"LOCAL_RANK": "1"}, {"RANK": "00"}, {"RANK": True},
                       {"TORCHELASTIC_RESTART_COUNT": "1"}, {"GROUP_RANK": "1"}):
            with self.subTest(update=update), self.assertRaises(ValueError):
                rank(env | update)

    def test_parent_rejects_recursive_launcher_before_side_effects(self):
        validate_parent = NAMESPACE["validate_parent_launch"]
        validate_parent(valid(), {})
        for name in ("WORLD_SIZE", "RANK", "LOCAL_RANK", "LOCAL_WORLD_SIZE"):
            with self.subTest(name=name), self.assertRaises(RuntimeError):
                validate_parent(valid(), {name: "0"})

    def test_visibility_binds_both_and_rejects_cnrt_mismatch_before_side_effects(self):
        validate_parent = NAMESPACE["validate_parent_launch"]
        validate_visible = NAMESPACE["validate_visible_cards"]
        bind = NAMESPACE["bind_visible_cards"]
        environment = {}
        validate_parent(valid(), environment)
        bind(valid(), environment)
        self.assertEqual(environment, {"MLU_VISIBLE_DEVICES": "3,7", "CNRT_VISIBLE_DEVICES": "3,7"})
        validate_visible(valid(), environment, require_bound=True)
        for environment in ({"CNRT_VISIBLE_DEVICES": "5,6"},
                            {"MLU_VISIBLE_DEVICES": "3,7", "CNRT_VISIBLE_DEVICES": "5,6"},
                            {"MLU_VISIBLE_DEVICES": "5,6", "CNRT_VISIBLE_DEVICES": "3,7"}):
            before = dict(environment)
            with self.subTest(environment=environment):
                with self.assertRaises(RuntimeError):
                    validate_parent(valid(), environment)
                with self.assertRaises(RuntimeError):
                    bind(valid(), environment)
                with self.assertRaises(RuntimeError):
                    validate_visible(valid(), environment, require_bound=True)
                self.assertEqual(environment, before)
        with self.assertRaises(RuntimeError):
            validate_visible(valid(), {"MLU_VISIBLE_DEVICES": "3,7"}, require_bound=True)

    def test_dp_checks_exact_schema_rejects_null_missing_empty_false_and_nonbool(self):
        fresh = {name: True for name in ("nonzero_finite_gradients", "replicated_state_agreement",
                 "complete_trainable_gradient_coverage", "current_adapter", "peak_reserved_below_75gb",
                 "main_forward_device")}
        check = NAMESPACE["validate_dp_checks"]
        result = NAMESPACE["validate_dp_result"]
        check(fresh, resumed=False)
        resumed = fresh | {"checkpoint_resume": True, "external_resume_boundary": True}
        check(resumed, resumed=True)
        result({"checks": resumed}, resumed=True)
        for resumed_mode, checks in ((False, fresh), (True, resumed)):
            for bad in (None, {}, [], checks | {"unknown": True}):
                with self.subTest(bad=bad, resumed=resumed_mode), self.assertRaises(RuntimeError):
                    check(bad, resumed=resumed_mode)
            for name in checks:
                for value in (None, False, 1, "True"):
                    with self.subTest(name=name, value=value), self.assertRaises(RuntimeError):
                        result({"checks": checks | {name: value}}, resumed=resumed_mode)
                missing = {key: value for key, value in checks.items() if key != name}
                with self.assertRaises(RuntimeError):
                    check(missing, resumed=resumed_mode)
        for bad in (None, {}, {"checks": None}, {"checks": {}}):
            with self.assertRaises(RuntimeError):
                result(bad, resumed=True)
        with self.assertRaises(RuntimeError):
            check(fresh, resumed=True)
        with self.assertRaises(RuntimeError):
            check(resumed, resumed=False)

    def test_source_tree_and_transitive_import_origins(self):
        validate_source = NAMESPACE["validate_source_root"]
        validate_modules = NAMESPACE["validate_loaded_native_modules"]
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            approved = root / "approved"
            source = approved / "hunyuanvideo-1.5"
            source.mkdir(parents=True)
            inside = source / "module.py"
            inside.write_text("# fixture\n", encoding="utf-8")
            outside = root / "outside"
            outside.mkdir()
            foreign = outside / "module.py"
            foreign.write_text("# foreign\n", encoding="utf-8")
            self.assertEqual(validate_source(source, approved_parent=approved), source)
            with self.assertRaises(RuntimeError):
                validate_source(outside, approved_parent=approved)
            with self.assertRaises(RuntimeError):
                validate_source(approved, approved_parent=approved)
            native = SimpleNamespace(__file__=str(inside), __path__=[str(source)],
                                     __spec__=SimpleNamespace(origin=str(inside)))
            validate_modules(source, {"hyvideo": native, "unrelated": SimpleNamespace(__file__=str(foreign))})
            namespace = SimpleNamespace(__file__=None, __path__=[str(source)], __spec__=SimpleNamespace(origin=None))
            validate_modules(source, {"hyvideo": native, "hyvideo.namespace": namespace})
            for module in (SimpleNamespace(__file__=str(foreign)), SimpleNamespace(__file__=None),
                           SimpleNamespace(__file__=str(inside), __path__=[str(outside)]),
                           SimpleNamespace(__file__=None, __path__=[str(source), str(outside)],
                                           __spec__=SimpleNamespace(origin=None)),
                           SimpleNamespace(__file__=str(inside), __spec__=SimpleNamespace(origin=str(foreign)))):
                with self.subTest(module=module), self.assertRaises(RuntimeError):
                    validate_modules(source, {"hyvideo": native, "hyvideo.transitive": module})

    def test_source_symlink_escape_rejected_for_root_file_and_directory(self):
        validate_source = NAMESPACE["validate_source_root"]
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            approved, outside = root / "approved", root / "outside"
            approved.mkdir()
            outside.mkdir()
            foreign = outside / "foreign.py"
            foreign.write_text("# foreign\n", encoding="utf-8")
            alias = approved / "hunyuan"
            try:
                alias.symlink_to(outside, target_is_directory=True)
            except OSError as error:
                self.skipTest(f"symlink creation unavailable: {error}")
            with self.assertRaises(RuntimeError):
                validate_source(alias, approved_parent=approved)
            source = approved / "real"
            source.mkdir()
            file_link = source / "module.py"
            file_link.symlink_to(foreign)
            with self.assertRaises(RuntimeError):
                validate_source(source, approved_parent=approved)
            file_link.unlink()
            (source / "package").symlink_to(outside, target_is_directory=True)
            with self.assertRaises(RuntimeError):
                validate_source(source, approved_parent=approved)

    def test_approved_parent_alias_rejected_before_resolution(self):
        validate_source = NAMESPACE["validate_source_root"]
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            approved = root / "real-approved"
            source = approved / "hunyuanvideo-1.5"
            source.mkdir(parents=True)
            alias = root / "approved-alias"
            try:
                alias.symlink_to(approved, target_is_directory=True)
            except OSError as error:
                self.skipTest(f"symlink creation unavailable: {error}")
            selected = alias / source.name
            self.assertFalse(selected.is_symlink())
            for parent in (alias, selected.expanduser().parent):
                with self.subTest(parent=parent), self.assertRaisesRegex(RuntimeError, "approved source parent"):
                    validate_source(selected, approved_parent=parent)
            self.assertEqual(validate_source(source, approved_parent=approved), source)

    def test_cli_dp_validation_precedes_completion_without_changing_legacy_optional_none(self):
        path = ROOT / "src/genmlu/cli.py"
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source)
        command = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "cmd_run")
        body = ast.get_source_segment(source, command)
        self.assertLess(body.index("validate_source_root("), body.index("create_run_dir("))
        self.assertLess(body.index("validate_parent_launch("), body.index("create_run_dir("))
        self.assertLess(body.index("bind_visible_cards("), body.index("create_run_dir("))
        self.assertLess(body.index("validate_dp_result("), body.index("merge_backend_result("))
        self.assertIn('manifest["checks"] = dict(result["checks"])', body)
        legacy = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "failed_backend_checks")
        namespace = {"Any": Any}
        exec(compile(ast.Module(body=[legacy], type_ignores=[]), str(path), "exec"), namespace)
        self.assertEqual(namespace["failed_backend_checks"]("hunyuanvideo-1.5", {"checkpoint_resume": None}), [])

    def test_worker_order_and_native_math_binding(self):
        worker = ast.get_source_segment(SOURCE.read_text(encoding="utf-8"),
            next(node for node in TREE.body if isinstance(node, ast.FunctionDef) and node.name == "_worker"))
        self.assertLess(worker.index("init_process_group("), worker.index("optimizer = factory("))
        self.assertLess(worker.index("validate_visible_cards("), worker.index("require_mlu("))
        self.assertLess(worker.index("validate_source_root("), worker.index("require_mlu("))
        self.assertIn("validate_dp_checks(checks, resumed=resume is not None)", worker)
        parent = ast.get_source_segment(SOURCE.read_text(encoding="utf-8"),
            next(node for node in TREE.body if isinstance(node, ast.FunctionDef) and node.name == "run_hunyuanvideo_data_parallel"))
        self.assertLess(parent.index("validate_parent_launch("), parent.index("output_dir.mkdir("))
        self.assertLess(parent.index("validate_source_root("), parent.index("output_dir.mkdir("))
        self.assertIn("approved_parent = source_root.expanduser().parent\n", parent)
        self.assertLess(parent.index("validate_source_root("), parent.index("approved_parent.resolve("))
        self.assertIn("validate_dp_result(result, resumed=", parent)
        self.assertLess(worker.index("average_gradients("), worker.index("clip_grad_norm_("))
        self.assertLess(worker.index("clip_grad_norm_("), worker.index('"native optimizer step"'))
        self.assertIn("native.sample_native_flow_inputs", worker)
        self.assertIn("native.native_flow_mse", worker)
        restore = ast.get_source_segment(SOURCE.read_text(encoding="utf-8"),
            next(node for node in TREE.body if isinstance(node, ast.FunctionDef) and node.name == "restore_transaction"))
        self.assertLess(restore.index("all-rank restore preflight"), restore.index("state application"))
        self.assertLess(restore.index("state application"), restore.index("rank RNG restoration"))

    def test_cli_routes_dp_and_preserves_single_rank_guard(self):
        cli = (ROOT / "src/genmlu/cli.py").read_text(encoding="utf-8")
        self.assertIn('"run_hunyuanvideo_data_parallel"', cli)
        self.assertIn('"COMMITTED.json"', cli)
        old = ast.parse((ROOT / "src/genmlu/backends/hunyuanvideo_training.py").read_text(encoding="utf-8"))
        run = next(node for node in old.body if isinstance(node, ast.FunctionDef) and node.name == "run_hunyuanvideo_training")
        self.assertEqual(run.body[0].value.func.id, "validate_single_rank_launch")


if __name__ == "__main__":
    unittest.main()
