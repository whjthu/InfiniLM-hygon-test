"""Real CPU Accelerate shard replay; not native SDXL/MLU qualification.

The model/data and identity pins are fixtures. Checkpoint file emission uses the
existing CPU fixture, not Accelerate's MLU save hooks. Loader preparation,
prefetch, accumulation counters, optimizer/scheduler wrappers and RNG are real.
"""

import importlib.util
import json
import os
import random
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from genmlu import sdxl_training_resume_checkpoint as checkpoint
from test_sdxl_training_state_roundtrip import cpu_session, emit_native_files


AVAILABLE = all(importlib.util.find_spec(name) for name in ("torch", "numpy", "safetensors", "accelerate"))


def canonical_json(value):
    # Spawned results have passed through JSON; normalize both sides, not fields.
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def prepared_session(directory, data_root):
    from accelerate import Accelerator
    from accelerate.data_loader import DataLoaderShard

    session, loader = cpu_session(directory, data_root)
    accelerator = Accelerator(cpu=True, mixed_precision="no", gradient_accumulation_steps=1)
    model, optimizer, loader, scheduler = accelerator.prepare(
        session.model, session.optimizer, loader, session.scheduler
    )
    if not isinstance(loader, DataLoaderShard) or loader.num_workers != 0 or accelerator.num_processes != 1:
        raise AssertionError("fixture requires a real single-process, zero-worker DataLoaderShard")
    if loader.generator is not session.generator:
        raise AssertionError("prepared loader replaced the checkpointed generator")
    session.model = accelerator.unwrap_model(model)
    session.optimizer, session.scheduler, session.accelerator = optimizer, scheduler, accelerator
    return session, loader


def execute_prepared(session, loader, directory):
    import numpy as np
    import torch

    rows = []
    first_epoch = session.sampler.epoch
    if session.sampler.order is not None and session.sampler.consumed == len(session.sampler):
        first_epoch += 1
    for epoch in range(first_epoch, 26):
        # These are the same two calls used by the patched upstream producer.
        session.sampler.set_epoch(epoch)
        loader.set_epoch(epoch)
        for batch in session.iterator(loader):
            session.observe_batch(batch)
            with session.accelerator.accumulate(session.model):
                target = torch.randn(2) + float(np.random.normal()) + random.random()
                prediction = session.model.lora_weight * batch["pixel_values"][0] + session.model.scale
                loss = (prediction - target).square().sum()
                session.accelerator.backward(loss)
                session.optimizer.step()
                session.scheduler.step()
                session.advance(batch, session.step + 1)
                session.optimizer.zero_grad(set_to_none=True)
            with torch.no_grad():
                session.model.scale.add_(0.001)
            state = session.capture_state()
            rows.append({
                "step": session.step, "sample_witness": session.batch_witness,
                "loss_sha256": checkpoint.state_sha(loss), "state_sha256": checkpoint.state_sha(state),
                "rng_sha256": checkpoint.state_sha(state["rng"]),
                "cursor_sha256": checkpoint.state_sha(state["data"]),
                "accelerator_step": state["accelerator_step"],
            })
            if session.step in (10, 11, 20, 21, 25):
                emit_native_files(session, directory / f"checkpoint-{session.step}")
            if session.step == 25:
                return rows, state
    raise AssertionError("prepared loader failed to complete 25 updates")


def resume_worker(checkpoint_path, directory, data_root):
    import numpy as np
    import torch

    session, loader = prepared_session(directory, data_root)
    random.seed(19)
    np.random.seed(23)
    torch.manual_seed(29)
    with torch.no_grad():
        session.model.lora_weight.fill_(13)
        session.model.scale.fill_(-9)
    session.restore_checkpoint(checkpoint_path)
    session.preupdate_witness()
    rows, final = execute_prepared(session, loader, directory)
    (directory / "cpu-result.json").write_text(
        json.dumps({"rows": rows, "state_sha256": checkpoint.state_sha(final)}), encoding="utf-8"
    )


@unittest.skipUnless(AVAILABLE, "genuine CPU Torch/NumPy/safetensors/Accelerate unavailable")
class AccelerateCursorTests(unittest.TestCase):
    def test_prepared_fresh25_and_spawned_cp10_cp20_cp21_are_byte_exact(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            data_root = root / "images"
            data_root.mkdir()
            fresh = root / "fresh"
            session, loader = prepared_session(fresh, data_root)
            rows, final = execute_prepared(session, loader, fresh)
            self.assertEqual([row["step"] for row in rows], list(range(1, 26)))
            self.assertEqual(len(rows), 25)  # No warm updates or replayed prefix samples.
            environment = os.environ.copy()
            source = str(Path(__file__).resolve().parents[1] / "src")
            environment["PYTHONPATH"] = source + os.pathsep + environment.get("PYTHONPATH", "")
            for start in (10, 20, 21):
                output = root / f"from{start}"
                process = subprocess.run(
                    [sys.executable, "-B", str(Path(__file__).resolve()), "--resume-worker",
                     str(fresh / f"checkpoint-{start}"), str(output), str(data_root)],
                    capture_output=True, text=True, env=environment, timeout=120,
                )
                self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
                result = json.loads((output / "cpu-result.json").read_text(encoding="utf-8"))
                self.assertEqual(canonical_json(result["rows"]), canonical_json(rows[start:]))
                self.assertEqual(result["state_sha256"], checkpoint.state_sha(final))
                self.assertEqual(len(result["rows"]), 25 - start)
                witness = json.loads((output / "preupdate-witness.json").read_text(encoding="utf-8"))
                manifest = checkpoint.preflight(fresh / f"checkpoint-{start}")
                self.assertEqual(witness["state_sha256"], manifest["state_sha256"])
                self.assertEqual(witness["next_step"], start + 1)
                self.assertTrue(witness["restored_full_state_exact"])
                self.assertFalse(witness["fresh_recovery_verified"])
                self.assertFalse(witness["performance_accepted"])

    def test_prepared_shard_rejects_epoch_advance_before_consumption(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            data_root = root / "images"
            data_root.mkdir()
            session, loader = prepared_session(root / "fresh", data_root)
            session.sampler.set_epoch(0)
            loader.set_epoch(0)
            iterator = session.iterator(loader)
            batch = next(iterator)
            session.observe_batch(batch)
            self.assertEqual(session.sampler.consumed, 0)  # Prefetch is not consumption.
            before = checkpoint.state_sha(session.sampler.state_dict())
            with self.assertRaises(checkpoint.CheckpointError):
                session.sampler.set_epoch(1)
            self.assertEqual(checkpoint.state_sha(session.sampler.state_dict()), before)
            loader.set_epoch(0)
            self.assertEqual(checkpoint.state_sha(session.sampler.state_dict()), before)
            iterator.close()


class JSONRepresentationTests(unittest.TestCase):
    def test_roundtrip_normalizes_tuples_but_preserves_all_fields_and_hashes(self):
        fresh = [{"step": 11, "sample_witness": {"sample_ids": [2], "original_sizes": [(1, 1)],
                  "crop_top_lefts": [(0, 0)]}, "loss_sha256": "a" * 64, "state_sha256": "b" * 64,
                  "rng_sha256": "c" * 64, "cursor_sha256": "d" * 64, "accelerator_step": 2}]
        resumed = json.loads(json.dumps(fresh))
        self.assertNotEqual(resumed, fresh)
        self.assertEqual(canonical_json(resumed), canonical_json(fresh))
        for field in ("loss_sha256", "state_sha256", "rng_sha256", "cursor_sha256", "accelerator_step"):
            changed = json.loads(json.dumps(resumed))
            changed[0][field] = 3 if field == "accelerator_step" else "e" * 64
            with self.subTest(changed=field):
                self.assertNotEqual(canonical_json(changed), canonical_json(fresh))
        for field in ("sample_ids", "original_sizes", "crop_top_lefts"):
            changed = json.loads(json.dumps(resumed))
            changed[0]["sample_witness"][field][0] = [9, 9] if field != "sample_ids" else 1
            with self.subTest(changed=field):
                self.assertNotEqual(canonical_json(changed), canonical_json(fresh))
        resumed[0]["sample_witness"].pop("crop_top_lefts")
        self.assertNotEqual(canonical_json(resumed), canonical_json(fresh))

    def test_canonical_comparison_keeps_numeric_types_and_rejects_nonfinite(self):
        self.assertNotEqual(canonical_json({"step": 1}), canonical_json({"step": True}))
        self.assertNotEqual(canonical_json({"step": 1}), canonical_json({"step": 1.0}))
        for value in (float("nan"), float("inf"), float("-inf")):
            with self.subTest(value=value), self.assertRaises(ValueError):
                canonical_json({"loss": value})


if __name__ == "__main__":
    if len(sys.argv) == 5 and sys.argv[1] == "--resume-worker":
        resume_worker(Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4]))
    else:
        unittest.main()
