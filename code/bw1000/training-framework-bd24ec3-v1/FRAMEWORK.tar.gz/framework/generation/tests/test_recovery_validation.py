from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from genmlu.recovery_validation import run_recovery_validation, validate_recovery_enabled


def test_disabled_recovery_skips_updates_and_reports_none() -> None:
    calls = {"update": 0, "restore": 0}

    def update() -> int:
        calls["update"] += 1
        return 0

    def restore() -> int:
        calls["restore"] += 1
        return 4

    result = run_recovery_validation(
        enabled=False,
        expected_step=4,
        metric_names=("resume_error", "resume_fingerprint_match"),
        update=update,
        restore=restore,
        fingerprint=lambda: "unused",
        compare=lambda *_: (False, {}),
    )

    assert calls == {"update": 0, "restore": 0}
    assert result.passed is None
    assert result.metrics == {
        "resume_error": None,
        "resume_fingerprint_match": None,
    }


def test_enabled_recovery_compares_updates_and_restores_final_state() -> None:
    state = {"value": 4}
    calls = {"update": 0, "restore": 0}

    def update() -> int:
        calls["update"] += 1
        state["value"] += 1
        return state["value"]

    def restore() -> int:
        calls["restore"] += 1
        state["value"] = 4
        return 4

    def compare(
        continuous: int, resumed: int, continuous_fingerprint: str, resumed_fingerprint: str
    ) -> tuple[bool, dict[str, object]]:
        error = abs(continuous - resumed)
        fingerprints_match = continuous_fingerprint == resumed_fingerprint
        return error == 0 and fingerprints_match, {
            "resume_error": error,
            "resume_fingerprint_match": fingerprints_match,
        }

    result = run_recovery_validation(
        enabled=True,
        expected_step=4,
        metric_names=("resume_error", "resume_fingerprint_match"),
        update=update,
        restore=restore,
        fingerprint=lambda: str(state["value"]),
        compare=compare,
    )

    assert calls == {"update": 2, "restore": 2}
    assert state == {"value": 4}
    assert result.passed is True
    assert result.metrics == {"resume_error": 0, "resume_fingerprint_match": True}


def test_failed_recovery_comparison_still_restores_final_state() -> None:
    state = {"value": 4}

    def update() -> int:
        state["value"] += 1
        return state["value"]

    def restore() -> int:
        state["value"] = 4
        return 4

    result = run_recovery_validation(
        enabled=True,
        expected_step=4,
        metric_names=("resume_error",),
        update=update,
        restore=restore,
        fingerprint=lambda: str(state["value"]),
        compare=lambda *_: (False, {"resume_error": 1}),
    )

    assert result.passed is False
    assert state == {"value": 4}


def test_wrong_restored_step_is_not_accepted_and_restores_final_state() -> None:
    state = {"value": 4}

    def update() -> int:
        state["value"] += 1
        return state["value"]

    def restore() -> int:
        state["value"] = 4
        return 3

    result = run_recovery_validation(
        enabled=True,
        expected_step=4,
        metric_names=("resume_error",),
        update=update,
        restore=restore,
        fingerprint=None,
        compare=lambda *_: (True, {"resume_error": 0}),
    )

    assert result.passed is False
    assert state == {"value": 4}


def test_recovery_exception_still_restores_final_state() -> None:
    state = {"value": 4}
    calls = {"restore": 0}

    def update() -> int:
        state["value"] += 1
        return state["value"]

    def restore() -> int:
        calls["restore"] += 1
        state["value"] = 4
        return 4

    def fail_comparison(*_args: object) -> tuple[bool, dict[str, object]]:
        raise RuntimeError("injected comparison failure")

    try:
        run_recovery_validation(
            enabled=True,
            expected_step=4,
            metric_names=("resume_error",),
            update=update,
            restore=restore,
            fingerprint=None,
            compare=fail_comparison,
        )
    except RuntimeError as exc:
        assert str(exc) == "injected comparison failure"
    else:
        raise AssertionError("expected recovery comparison to fail")

    assert calls == {"restore": 2}
    assert state == {"value": 4}


def test_recovery_switch_requires_a_boolean() -> None:
    assert validate_recovery_enabled({}) is False
    assert validate_recovery_enabled({"validate_recovery": True}) is True
    try:
        validate_recovery_enabled({"validate_recovery": "false"})
    except ValueError as exc:
        assert str(exc) == "validate_recovery must be a boolean"
    else:
        raise AssertionError("expected string recovery switch to be rejected")

    try:
        run_recovery_validation(
            enabled="false",  # type: ignore[arg-type]
            expected_step=4,
            metric_names=("resume_error",),
            update=lambda: 0,
            restore=lambda: 4,
            fingerprint=None,
            compare=lambda *_: (True, {"resume_error": 0}),
        )
    except TypeError as exc:
        assert str(exc) == "recovery validation enabled must be a bool"
    else:
        raise AssertionError("expected non-boolean enabled value to be rejected")
