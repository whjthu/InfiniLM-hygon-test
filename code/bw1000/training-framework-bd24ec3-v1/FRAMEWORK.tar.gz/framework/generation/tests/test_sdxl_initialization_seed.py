from __future__ import annotations

import importlib.util
import random
import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np


ROOT = next(
    parent for parent in Path(__file__).resolve().parents
    if (parent / "src/genmlu/backends/sdxl_ddpo.py").is_file()
)
sys.path.insert(0, str(ROOT / "src"))
BACKEND_PATH = ROOT / "src/genmlu/backends/sdxl_ddpo.py"
SPEC = importlib.util.spec_from_file_location("genmlu._sdxl_seed_fixture.sdxl_ddpo", BACKEND_PATH)
backend = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = backend
SPEC.loader.exec_module(backend)


class InitializationSeedTests(unittest.TestCase):
    def test_seed_covers_host_rng_and_is_independent_of_recovery_validation(self):
        import torch as cpu_torch

        events = []
        created = []

        class StopAfterLora(RuntimeError):
            pass

        class FakeMlu:
            def manual_seed_all(self, seed):
                events.append(("mlu_seed", seed))

        torch_driver = SimpleNamespace(
            bfloat16=cpu_torch.bfloat16,
            manual_seed=lambda seed: (events.append(("cpu_seed", seed)), cpu_torch.manual_seed(seed))[1],
            mlu=FakeMlu(),
        )

        class FakeUnet:
            config = SimpleNamespace(in_channels=4)

            def __init__(self):
                self.pipeline_value = cpu_torch.rand(4)

            def requires_grad_(self, value):
                self.requires_grad = value

            def add_adapter(self, config):
                events.append("lora")
                self.adapter_value = cpu_torch.rand(4)

        class FakePipeline:
            def __init__(self):
                self.unet = FakeUnet()
                self.scheduler = SimpleNamespace(config=object())
                self.host_values = (random.random(), float(np.random.random()))

            def to(self, device):
                raise StopAfterLora(device)

        class FakePipelineFactory:
            @staticmethod
            def from_pretrained(*args, **kwargs):
                events.append("pipeline")
                pipe = FakePipeline()
                created.append((pipe.unet.pipeline_value.clone(), pipe.unet, pipe.host_values))
                return pipe

        class FakeScheduler:
            @staticmethod
            def from_config(config):
                return SimpleNamespace(config=config)

        fake_diffusers = SimpleNamespace(
            DDIMScheduler=FakeScheduler,
            StableDiffusionXLPipeline=FakePipelineFactory,
        )
        fake_peft = SimpleNamespace(LoraConfig=lambda **kwargs: kwargs)
        with TemporaryDirectory() as directory, patch.object(backend, "require_mlu", return_value=torch_driver), patch.dict(
            sys.modules, {"diffusers": fake_diffusers, "peft": fake_peft}
        ):
            for attempt, validate_recovery in enumerate((False, True)):
                with self.assertRaisesRegex(StopAfterLora, "mlu"):
                    backend.run_sdxl_ddpo(
                        Path(directory),
                        {"seed": 20260911, "validate_recovery": validate_recovery},
                        Path(directory) / f"out-{attempt}",
                    )

        self.assertEqual(
            events,
            [
                ("cpu_seed", 20260911), ("mlu_seed", 20260911), "pipeline", "lora",
                ("cpu_seed", 20260911), ("mlu_seed", 20260911), "pipeline", "lora",
            ],
        )
        first_pipeline, first_unet, first_host = created[0]
        second_pipeline, second_unet, second_host = created[1]
        self.assertTrue(cpu_torch.equal(first_pipeline, second_pipeline))
        self.assertTrue(cpu_torch.equal(first_unet.adapter_value, second_unet.adapter_value))
        self.assertEqual(first_host, second_host)


if __name__ == "__main__":
    unittest.main()
