from __future__ import annotations

import copy
import importlib.util
import os
import random
import sys
import types
from pathlib import Path

import numpy as np
import pytest
import torch


ROOT = Path(__file__).resolve().parent
CANDIDATE_ROOT = Path(os.environ.get("ZIMAGE_CHECKPOINT_REPO", ROOT.parent))
COMMON = Path(os.environ.get("ZIMAGE_COMMON_HELPER", CANDIDATE_ROOT / "src" / "genmlu" / "hy_resume_checkpoint.py"))
MODULE = CANDIDATE_ROOT / "src" / "genmlu" / "zimage_resume_checkpoint.py"


package = types.ModuleType("genmlu")
package.__path__ = []
sys.modules.setdefault("genmlu", package)
common_spec = importlib.util.spec_from_file_location("genmlu.hy_resume_checkpoint", COMMON)
assert common_spec and common_spec.loader
common = importlib.util.module_from_spec(common_spec)
sys.modules[common_spec.name] = common
common_spec.loader.exec_module(common)
module_spec = importlib.util.spec_from_file_location("genmlu.zimage_resume_checkpoint", MODULE)
assert module_spec and module_spec.loader
resume = importlib.util.module_from_spec(module_spec)
sys.modules[module_spec.name] = resume
module_spec.loader.exec_module(resume)


def set_timesteps_z_image() -> None:
    pass


set_timesteps_z_image.__module__ = "diffsynth.diffusion.flow_match"
set_timesteps_z_image.__qualname__ = "FlowMatchScheduler.set_timesteps_z_image"


class Scheduler:
    def __init__(self, seed: int = 55) -> None:
        self.set_timesteps_fn = set_timesteps_z_image
        self.num_train_timesteps = 1000
        self.noise_window = list(range(8))
        self.noise_level = 0.7
        self.sde_step_num = 8
        self.sde_type = "Flow-SDE"
        self.seed = seed
        self.sigmas = torch.linspace(1.0, 0.125, 8, dtype=torch.float32)
        self.timesteps = self.sigmas * self.num_train_timesteps
        self.training = False


def make_contract() -> dict:
    return resume.build_contract(
        identity={key: "a" * 64 for key in resume.IDENTITY_FIELDS},
        seed=91,
        max_steps=21,
        group_size=4,
        sample_order=["prompt:fixture"],
        device_ids=[],
    )


def make_model(seed: int) -> tuple[torch.nn.Module, torch.optim.AdamW]:
    torch.manual_seed(seed)
    model = torch.nn.Sequential(torch.nn.Linear(3, 4), torch.nn.Tanh(), torch.nn.Linear(4, 2))
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-3, weight_decay=0.01)
    return model, optimizer


def policy_step(model: torch.nn.Module, optimizer: torch.optim.AdamW) -> dict:
    optimizer.zero_grad(set_to_none=True)
    values = torch.randn(5, 3) + random.random() + float(np.random.rand())
    loss = model(values).square().mean()
    loss.backward()
    gradients = {name: parameter.grad.detach().clone() if parameter.grad is not None else None for name, parameter in model.named_parameters()}
    optimizer.step()
    return {"loss": loss.detach().clone(), "gradients": gradients, "state": common.cpu_tree(optimizer.state_dict()), "rng": common.capture_rng([])}


def rollout(contract: dict, global_step: int) -> dict:
    states = []
    for index in range(contract["group_size"]):
        generator = torch.Generator().manual_seed(contract["seed"] + global_step * contract["group_size"] + index + 1000003)
        torch.randn(8, generator=generator)
        states.append(generator.get_state().clone())
    return {"generator_states": states}


def payload_at(step: int = 10):
    random.seed(4)
    np.random.seed(5)
    torch.manual_seed(6)
    contract = make_contract()
    model, optimizer = make_model(7)
    progress = common.initial_optimizer_progress(model, optimizer)
    for _ in range(step):
        record = policy_step(model, optimizer)
        progress = common.advance_optimizer_progress(progress, model, optimizer)
    scheduler = Scheduler(contract["seed"] + step * contract["group_size"] + contract["group_size"] - 1)
    initial_scheduler = resume.capture_scheduler(Scheduler())
    expected = {key: initial_scheduler[key] for key in resume.SCHEDULER_STATIC_FIELDS}
    payload = resume.make_payload(contract=contract, global_step=step, model=model, optimizer=optimizer, optimizer_progress=progress, scheduler=scheduler, expected_scheduler=expected, rollout=rollout(contract, step))
    return contract, model, optimizer, scheduler, progress, expected, payload


def test_global_step_ten_resume_matches_the_next_step() -> None:
    contract, model, optimizer, _scheduler, _progress, expected, payload = payload_at(10)
    continuous = policy_step(model, optimizer)
    fresh, fresh_optimizer = make_model(99)
    fresh_scheduler = Scheduler()
    progress, checked = resume.restore_checkpoint(payload, contract, fresh, fresh_optimizer, fresh_scheduler, expected)
    assert checked["next"]["global_step"] == 11
    assert checked["next"]["rollout_seeds"] == [135, 136, 137, 138]
    resume.assert_restored_boundary(payload, fresh, fresh_optimizer, fresh_scheduler, progress, [])
    restored = policy_step(fresh, fresh_optimizer)
    assert common.tree_sha256(continuous) == common.tree_sha256(restored)


@pytest.mark.parametrize("global_step, measured_seed", [(10, 135), (20, 175)])
def test_global_checkpoint_metadata_uses_real_policy_step(global_step: int, measured_seed: int) -> None:
    contract = make_contract()
    metadata = resume.boundary_metadata(contract, global_step)
    assert metadata["global_step"] == global_step
    assert metadata["measured_step"] == global_step
    assert metadata["next_global_step"] == global_step + 1
    assert metadata["next_sample_cursor"] == 0
    assert resume.next_coordinate(metadata)["rollout_seeds"][0] == measured_seed


@pytest.mark.parametrize("corruption", ["identity", "generator", "scheduler", "legacy"])
def test_invalid_checkpoint_is_rejected_before_mutation(corruption: str) -> None:
    contract, _model, _optimizer, _scheduler, _progress, expected, payload = payload_at()
    candidate = copy.deepcopy(payload)
    if corruption == "identity":
        candidate["metadata"]["contract"]["identity"]["config"] = "b" * 64
    elif corruption == "generator":
        candidate["generators"]["states"] = []
    elif corruption == "scheduler":
        candidate["scheduler"]["training"] = True
    else:
        candidate = {"step": 10, "adapter": payload["state"]["trainable"]}
    if corruption != "legacy":
        candidate["integrity_sha256"] = common.tree_sha256({key: value for key, value in candidate.items() if key != "integrity_sha256"})
    target, target_optimizer = make_model(71)
    target_scheduler = Scheduler()
    before = common.tree_sha256({"state": common.capture_model_state(target, target_optimizer, common.initial_optimizer_progress(target, target_optimizer)), "scheduler": resume.capture_scheduler(target_scheduler), "rng": common.capture_rng([])})
    with pytest.raises((resume.CheckpointValidationError, common.CheckpointValidationError, ValueError)):
        resume.restore_checkpoint(candidate, contract, target, target_optimizer, target_scheduler, expected)
    after = common.tree_sha256({"state": common.capture_model_state(target, target_optimizer, common.initial_optimizer_progress(target, target_optimizer)), "scheduler": resume.capture_scheduler(target_scheduler), "rng": common.capture_rng([])})
    assert before == after
