from __future__ import annotations

import inspect
from pathlib import Path

import pytest
import yaml

from genmlu.backends import vggt_training as vggt


def test_camera_head_remains_the_default_scope() -> None:
    assert vggt._vggt_training_preflight({}) == ("camera_head", False)
    assert vggt._vggt_training_preflight(
        {"training_scope": "camera_backbone"}
    ) == ("camera_backbone", False)


@pytest.mark.parametrize(
    ("config", "message"),
    [
        ({"training_scope": "all"}, "training_scope"),
        (
            {
                "training_scope": "camera_backbone",
                "cache_frozen_aggregator_features": True,
            },
            "cannot cache",
        ),
        ({"training_scope": "camera_backbone", "cards": [0, 1]}, "exactly one card"),
        ({"training_scope": "camera_backbone", "cards": [-1]}, "exactly one card"),
    ],
)
def test_scope_cache_and_card_conflicts_are_rejected_before_mlu(
    monkeypatch: pytest.MonkeyPatch, config: dict, message: str
) -> None:
    runtime_called = False

    def fail_runtime():
        nonlocal runtime_called
        runtime_called = True
        raise AssertionError("MLU runtime must not be initialized")

    monkeypatch.setattr(vggt, "require_mlu", fail_runtime)
    with pytest.raises((ValueError, RuntimeError), match=message):
        vggt.run_vggt_training(
            Path("weights"), config, Path("output"), Path("source")
        )
    assert runtime_called is False


def test_camera_backbone_preset_is_bounded_and_disables_feature_cache() -> None:
    config_path = (
        Path(__file__).resolve().parents[1]
        / "configs"
        / "vggt-camera-backbone-training.yaml"
    )
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    assert config["training_scope"] == "camera_backbone"
    assert config["cache_frozen_aggregator_features"] is False
    assert config["max_steps"] == 20


def test_backbone_gradient_check_precedes_clip_and_optimizer_update() -> None:
    source = inspect.getsource(vggt.run_vggt_training)
    backward = source.index("loss.backward()")
    backbone_check = source.index(
        '_vggt_gradient_norm_before_clip(backbone_trainable, torch, "aggregator")'
    )
    clip = source.index("torch.nn.utils.clip_grad_norm_")
    update = source.index("optimizer.step()")
    assert backward < backbone_check < clip < update
    assert "VGGT(enable_camera=True, enable_point=False, enable_depth=False, enable_track=False)" in source


def test_scope_uses_distinct_checkpoint_state_names() -> None:
    source = inspect.getsource(vggt.run_vggt_training)
    assert "state_key=trainable_state_key" in source
    assert 'trained_state_path = output_dir / f"{trainable_state_key}.pt"' in source
    assert 'module=model.camera_head' not in source
