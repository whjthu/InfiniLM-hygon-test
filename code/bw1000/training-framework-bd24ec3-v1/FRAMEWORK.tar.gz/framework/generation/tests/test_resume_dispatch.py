from contextlib import contextmanager
import json
from pathlib import Path
from types import SimpleNamespace

import pytest
import torch

from genmlu import cli
from genmlu import hy_resume_checkpoint as hy_resume
from genmlu import zimage_training_resume_checkpoint as z_resume


def _zimage_payload_at_step(step: int = 3) -> dict:
    def set_timesteps() -> None:
        pass

    scheduler = SimpleNamespace(
        set_timesteps_fn=set_timesteps, num_train_timesteps=1000, training=True, timesteps=1000,
    )
    model = torch.nn.Linear(2, 2)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
    progress = hy_resume.initial_optimizer_progress(model, optimizer)
    for _ in range(step):
        optimizer.zero_grad(set_to_none=True)
        model(torch.ones(1, 2)).square().mean().backward()
        optimizer.step()
        progress = hy_resume.advance_optimizer_progress(progress, model, optimizer)
    contract = z_resume.build_contract(
        identity={key: "a" * 64 for key in z_resume.IDENTITY_FIELDS},
        seed=42, max_steps=8, sample_order=["row:0"], device_ids=[],
    )
    expected = z_resume.scheduler_spec(scheduler)
    contract["identity"]["scheduler"] = hy_resume.tree_sha256(expected)
    return z_resume.make_payload(
        contract=contract, global_step=step, model=model, optimizer=optimizer,
        optimizer_progress=progress, scheduler=scheduler, expected_scheduler=expected,
    )


def _declare_cpu_checkpoint_as_mlu(payload: dict) -> None:
    payload["metadata"]["contract"]["device_ids"] = [0]
    payload["rng"]["mlu"] = {0: torch.arange(16, dtype=torch.uint8)}


@pytest.mark.parametrize("command,model", [
    ("train", "vggt-1b"),
    ("train", "hunyuanvideo-1.5"), ("train", "hy-motion-1.0"), ("train", "z-image-turbo"),
    ("train", "stable-fast-3d"),
    ("rl", "sdxl-1.0"), ("rl", "hy-motion-1.0"), ("rl", "z-image-turbo"),
])
def test_supported_resume_request_is_preserved(tmp_path, command, model):
    checkpoint = tmp_path / "state.pt"
    checkpoint.write_bytes(b"checkpoint")
    config = {"resume_from_checkpoint": str(checkpoint)}
    cli.validate_resume_request(command, model, config)
    assert config == {"resume_from_checkpoint": str(checkpoint)}


def test_sdxl_training_accepts_accelerate_checkpoint_without_state_pt(tmp_path):
    checkpoint = tmp_path / "checkpoint-10"
    checkpoint.mkdir()
    (checkpoint / "pytorch_lora_weights.safetensors").write_bytes(b"adapter")
    cli.validate_resume_request("train", "sdxl-1.0", {"resume_from_checkpoint": str(checkpoint)})


@pytest.mark.parametrize("dirname,adapter", [("checkpoint-10", False), ("other", True)])
def test_sdxl_training_rejects_invalid_checkpoint_before_output(tmp_path, dirname, adapter):
    checkpoint = tmp_path / dirname
    checkpoint.mkdir()
    if adapter:
        (checkpoint / "pytorch_lora_weights.safetensors").write_bytes(b"adapter")
    with pytest.raises(ValueError, match="checkpoint-N directory with an adapter"):
        cli.validate_resume_request("train", "sdxl-1.0", {"resume_from_checkpoint": str(checkpoint)})


@pytest.mark.parametrize("command,model", [
    ("rl", "hunyuanvideo-1.5"),
    ("train", "trellis-2-4b"),
    ("rl", "vggt-1b"), ("rl", "stable-fast-3d"),
    ("infer", "sdxl-1.0"), ("eval", "sdxl-1.0"),
])
def test_unsupported_resume_fails_before_backend_import(tmp_path, monkeypatch, command, model):
    def forbidden(*args, **kwargs):
        pytest.fail("unsupported resume reached backend import")

    monkeypatch.setattr(cli, "_call", forbidden)
    with pytest.raises(ValueError, match="external checkpoint resume is not supported"):
        cli.run_backend(command, SimpleNamespace(name=model), tmp_path,
                        {"resume_from_checkpoint": "/checkpoints/state.pt"}, tmp_path, None)


@pytest.mark.parametrize("checkpoint", ["", "  ", False, 0, [], {}])
def test_invalid_resume_path_is_rejected(checkpoint):
    with pytest.raises(ValueError, match="non-empty path string"):
        cli.validate_resume_request("rl", "sdxl-1.0", {"resume_from_checkpoint": checkpoint})


def test_missing_supported_resume_path_is_rejected(tmp_path):
    with pytest.raises(ValueError, match="existing checkpoint file"):
        cli.validate_resume_request(
            "train", "hy-motion-1.0", {"resume_from_checkpoint": str(tmp_path / "missing.pt")}
        )


@pytest.mark.parametrize("dry_run", [False, True])
@pytest.mark.parametrize(
    "payload,error",
    [
        ({"legacy": True}, "not a full Z-Image training checkpoint"),
        ({
            "metadata": {}, "state": {}, "scheduler": {}, "lr_scheduler": None,
            "rng": {}, "adapter_sha256": "a" * 64, "integrity_sha256": "b" * 64,
        }, "checkpoint integrity mismatch"),
    ],
)
def test_zimage_malformed_resume_is_rejected_before_run_directory_or_model_load(
    tmp_path, monkeypatch, dry_run, payload, error
):
    checkpoint = tmp_path / "checkpoint-1" / "state.pt"
    checkpoint.parent.mkdir()
    torch.save(payload, checkpoint)
    monkeypatch.setattr(cli, "get_spec", lambda *_args: SimpleNamespace(name="z-image-turbo"))
    monkeypatch.setattr(cli, "load_run_config", lambda *_args: {
        "resume_from_checkpoint": str(checkpoint),
    })

    def forbidden(*_args, **_kwargs):
        pytest.fail("malformed Z-Image resume caused a run side effect")

    for name in ("create_run_dir", "resolve_weights", "configure_visible_cards", "acquire", "inspect_runtime"):
        monkeypatch.setattr(cli, name, forbidden)
    args = SimpleNamespace(
        command="train", model="z-image-turbo", models_config="models.yaml", config="run.yaml",
        output_root=str(tmp_path / "outputs"), run_name="bad", cards="0", dry_run=dry_run,
        model_root=None, weights=None, source_root=None, lock_root=None, lock_host=None,
    )
    with pytest.raises(ValueError, match=error):
        cli.cmd_run(args)
    assert not (tmp_path / "outputs").exists()


@pytest.mark.parametrize(
    "mutate,config,error",
    [
        (
            lambda payload: payload.update({"state": {}, "rng": {}, "adapter_sha256": hy_resume.tree_sha256({})}),
            {"seed": 42, "max_steps": 8, "learning_rate": 1e-3, "weight_decay": 0.01},
            "checkpoint model state fields mismatch",
        ),
        (
            lambda _payload: None,
            {"seed": 42, "max_steps": 2, "learning_rate": 1e-3, "weight_decay": 0.01},
            "checkpoint max_steps does not match requested configuration",
        ),
        (
            lambda payload: payload["state"]["optimizer"]["param_groups"][0].pop("eps"),
            {"seed": 42, "max_steps": 8, "learning_rate": 1e-3, "weight_decay": 0.01},
            "checkpoint AdamW parameter-group fields mismatch",
        ),
        (
            lambda payload: payload["state"]["optimizer_placements"][
                next(iter(payload["state"]["optimizer_placements"]))
            ].update({"exp_avg": "not-a-device"}),
            {"seed": 42, "max_steps": 8, "learning_rate": 1e-3, "weight_decay": 0.01},
            "checkpoint AdamW placement device mismatch",
        ),
        (
            _declare_cpu_checkpoint_as_mlu,
            {"seed": 42, "max_steps": 8, "learning_rate": 1e-3, "weight_decay": 0.01},
            "checkpoint AdamW placement device mismatch",
        ),
        (
            lambda payload: payload["scheduler"].update({"training": False}),
            {"seed": 42, "max_steps": 8, "learning_rate": 1e-3, "weight_decay": 0.01},
            "checkpoint scheduler does not match contract identity",
        ),
    ],
)
def test_zimage_cli_preflight_rejects_self_consistent_bad_boundary_before_run_directory(
    tmp_path, monkeypatch, mutate, config, error
):
    payload = _zimage_payload_at_step()
    mutate(payload)
    payload["integrity_sha256"] = hy_resume.tree_sha256(
        {key: value for key, value in payload.items() if key != "integrity_sha256"}
    )
    checkpoint = tmp_path / "checkpoint-3" / "state.pt"
    checkpoint.parent.mkdir()
    torch.save(payload, checkpoint)
    monkeypatch.setattr(cli, "get_spec", lambda *_args: SimpleNamespace(name="z-image-turbo"))
    monkeypatch.setattr(cli, "load_run_config", lambda *_args: {
        "resume_from_checkpoint": str(checkpoint), **config,
    })

    def forbidden(*_args, **_kwargs):
        pytest.fail("invalid Z-Image resume created a run or loaded a model")

    for name in ("create_run_dir", "resolve_weights", "configure_visible_cards", "acquire", "inspect_runtime"):
        monkeypatch.setattr(cli, name, forbidden)
    args = SimpleNamespace(
        command="train", model="z-image-turbo", models_config="models.yaml", config="run.yaml",
        output_root=str(tmp_path / "outputs"), run_name="bad", cards="0", dry_run=False,
        model_root=None, weights=None, source_root=None, lock_root=None, lock_host=None,
    )
    with pytest.raises(ValueError, match=error):
        cli.cmd_run(args)
    assert not (tmp_path / "outputs").exists()


@pytest.mark.parametrize("config", [{}, {"resume_from_checkpoint": None}])
def test_fresh_run_remains_available(config):
    cli.validate_resume_request("train", "hunyuanvideo-1.5", config)


def test_hunyuanvideo_training_resume_reaches_selected_backend(tmp_path, monkeypatch):
    source = tmp_path / "hunyuanvideo-1.5"
    source.mkdir()
    called = []

    def selected(module, function, *args):
        called.append((module, function, args))
        return {"status": "completed"}

    monkeypatch.setattr(cli, "_call", selected)
    checkpoint = tmp_path / "checkpoint-10" / "state.pt"
    checkpoint.parent.mkdir()
    checkpoint.write_bytes(b"checkpoint")
    config = {"resume_from_checkpoint": str(checkpoint)}
    result = cli.run_backend(
        "train", SimpleNamespace(name="hunyuanvideo-1.5"), tmp_path,
        config, tmp_path, tmp_path,
    )
    assert result == {"status": "completed"}
    assert len(called) == 1
    assert called[0][:2] == (
        "genmlu.backends.hunyuanvideo_training", "run_hunyuanvideo_training"
    )
    assert called[0][2] == (tmp_path, config, tmp_path, source)


def test_hy_motion_full_training_resume_reaches_selected_backend(tmp_path, monkeypatch):
    source = tmp_path / "hy-motion"
    source.mkdir()
    called = []

    def selected(module, function, *args):
        called.append((module, function, args))
        return {"status": "completed"}

    monkeypatch.setattr(cli, "_call", selected)
    checkpoint = tmp_path / "checkpoint-10" / "state.pt"
    checkpoint.parent.mkdir()
    checkpoint.write_bytes(b"checkpoint")
    config = {"resume_from_checkpoint": str(checkpoint)}
    result = cli.run_backend(
        "train", SimpleNamespace(name="hy-motion-1.0"), tmp_path,
        config, tmp_path, tmp_path,
    )
    assert result == {"status": "completed"}
    assert len(called) == 1
    assert called[0][:2] == (
        "genmlu.backends.hy_motion_training", "run_hy_motion_training"
    )
    assert called[0][2] == (tmp_path, config, tmp_path, source)


def test_zimage_training_resume_reaches_selected_backend(tmp_path, monkeypatch):
    source = tmp_path / "diffsynth-studio-grpo"
    source.mkdir()
    called = []

    def selected(module, function, *args):
        called.append((module, function, args))
        return {"status": "completed"}

    monkeypatch.setattr(cli, "_call", selected)
    checkpoint = tmp_path / "checkpoint-10" / "state.pt"
    checkpoint.parent.mkdir()
    checkpoint.write_bytes(b"checkpoint")
    config = {"resume_from_checkpoint": str(checkpoint)}
    result = cli.run_backend(
        "train", SimpleNamespace(name="z-image-turbo"), tmp_path,
        config, tmp_path, tmp_path,
    )
    assert result == {"status": "completed"}
    assert len(called) == 1
    assert called[0][:2] == (
        "genmlu.backends.zimage_training", "run_zimage_training"
    )
    assert called[0][2] == (tmp_path, config, tmp_path, source)


def test_sf3d_training_resume_reaches_selected_backend(tmp_path, monkeypatch):
    source = tmp_path / "stable-fast-3d"
    source.mkdir()
    called = []

    def selected(module, function, *args):
        called.append((module, function, args))
        return {"status": "completed"}

    monkeypatch.setattr(cli, "_call", selected)
    checkpoint = tmp_path / "checkpoint-10.pt"
    checkpoint.write_bytes(b"checkpoint")
    config = {"resume_from_checkpoint": str(checkpoint)}
    result = cli.run_backend(
        "train", SimpleNamespace(name="stable-fast-3d"), tmp_path,
        config, tmp_path, tmp_path,
    )
    assert result == {"status": "completed"}
    assert called == [(
        "genmlu.backends.sf3d_training", "run_sf3d_training", (tmp_path, config, tmp_path, source),
    )]


@pytest.mark.parametrize("dry_run", [False, True])
def test_cli_rejects_multicard_hunyuan_training_before_output(monkeypatch, dry_run):
    monkeypatch.setattr(cli, "get_spec", lambda *args: SimpleNamespace(name="hunyuanvideo-1.5"))
    monkeypatch.setattr(cli, "load_run_config", lambda *args: {})

    def forbidden(*args, **kwargs):
        pytest.fail("multi-card training caused a side effect")

    monkeypatch.setattr(cli, "create_run_dir", forbidden)
    args = SimpleNamespace(command="train", model="hunyuanvideo-1.5",
                           models_config="models.yaml", config="run.yaml",
                           cards="0,1", dry_run=dry_run)
    with pytest.raises(ValueError, match="requires exactly one card"):
        cli.cmd_run(args)


@pytest.mark.parametrize("dry_run", [False, True])
def test_cli_rejects_multicard_hy_motion_full_training_before_output(monkeypatch, dry_run):
    monkeypatch.setattr(cli, "get_spec", lambda *args: SimpleNamespace(name="hy-motion-1.0"))
    monkeypatch.setattr(cli, "load_run_config", lambda *args: {})

    def forbidden(*args, **kwargs):
        pytest.fail("multi-card training caused a side effect")

    monkeypatch.setattr(cli, "create_run_dir", forbidden)
    args = SimpleNamespace(command="train", model="hy-motion-1.0",
                           models_config="models.yaml", config="run.yaml",
                           cards="0,1", dry_run=dry_run)
    with pytest.raises(ValueError, match="requires exactly one card"):
        cli.cmd_run(args)


@pytest.mark.parametrize("dry_run", [False, True])
def test_cli_rejects_multicard_zimage_training_before_output(monkeypatch, dry_run):
    monkeypatch.setattr(cli, "get_spec", lambda *args: SimpleNamespace(name="z-image-turbo"))
    monkeypatch.setattr(cli, "load_run_config", lambda *args: {})

    def forbidden(*args, **kwargs):
        pytest.fail("multi-card Z-Image training caused a side effect")

    monkeypatch.setattr(cli, "create_run_dir", forbidden)
    args = SimpleNamespace(command="train", model="z-image-turbo",
                           models_config="models.yaml", config="run.yaml",
                           cards="0,1", dry_run=dry_run)
    with pytest.raises(ValueError, match="requires exactly one card"):
        cli.cmd_run(args)


@pytest.mark.parametrize("dry_run", [False, True])
def test_cli_rejects_missing_supported_resume_before_output_or_runtime(monkeypatch, dry_run):
    monkeypatch.setattr(cli, "get_spec", lambda *args: SimpleNamespace(name="hy-motion-1.0"))
    monkeypatch.setattr(cli, "load_run_config", lambda *args: {
        "resume_from_checkpoint": "/checkpoints/missing-state.pt",
    })

    def forbidden(*args, **kwargs):
        pytest.fail("missing resume checkpoint caused a side effect")

    for name in ("create_run_dir", "resolve_weights", "acquire", "inspect_runtime", "run_backend"):
        monkeypatch.setattr(cli, name, forbidden)
    args = SimpleNamespace(command="train", model="hy-motion-1.0",
                           models_config="models.yaml", config="run.yaml", cards="0",
                           dry_run=dry_run)
    with pytest.raises(ValueError, match="existing checkpoint file"):
        cli.cmd_run(args)


@pytest.mark.parametrize("failure", ["corrupt checkpoint", "checkpoint identity mismatch"])
def test_existing_rejected_resume_writes_failed_manifest_without_updates(
    tmp_path: Path, monkeypatch, failure: str
):
    checkpoint = tmp_path / "checkpoint-10" / "state.pt"
    checkpoint.parent.mkdir()
    checkpoint.write_bytes(failure.encode("utf-8"))
    optimizer_updates = 0

    @contextmanager
    def fake_acquire(*_args, **_kwargs):
        yield tmp_path / "locks"

    def rejected_backend(*_args, **_kwargs):
        assert optimizer_updates == 0
        raise hy_resume.CheckpointValidationError(failure)

    monkeypatch.setattr(cli, "get_spec", lambda *_args: SimpleNamespace(name="hy-motion-1.0"))
    monkeypatch.setattr(cli, "load_run_config", lambda *_args: {
        "resume_from_checkpoint": str(checkpoint),
    })
    monkeypatch.setattr(cli, "resolve_weights", lambda *_args: tmp_path / "weights")
    monkeypatch.setattr(cli, "configure_visible_cards", lambda *_args: None)
    monkeypatch.setattr(cli, "lease_location", lambda *_args: (tmp_path / "locks", "physical-a"))
    monkeypatch.setattr(cli, "acquire", fake_acquire)
    monkeypatch.setattr(
        cli, "inspect_runtime",
        lambda: SimpleNamespace(torch_version=None, mlu_available=False, mlu_count=0, device_name=None),
    )
    monkeypatch.setattr(cli, "run_backend", rejected_backend)
    args = SimpleNamespace(
        command="train", model="hy-motion-1.0", models_config="models.yaml", config="run.yaml",
        output_root=str(tmp_path / "outputs"), run_name="rejected", cards="0", dry_run=False,
        model_root=None, weights=None, source_root=None, lock_root=str(tmp_path / "locks"),
        lock_host="physical-a",
    )

    with pytest.raises(hy_resume.CheckpointValidationError, match=failure):
        cli.cmd_run(args)

    manifest_path = tmp_path / "outputs" / "hy-motion-1.0" / "train" / "rejected" / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert optimizer_updates == 0
    assert manifest["status"] == "failed"
    assert manifest["execution"]["stage"] == "run_backend"
    assert manifest["artifacts"] == []
    assert manifest["logs"] == []
    metrics = manifest["metrics"]
    assert metrics["measurement_qualification"] == "FAILED"
    for key in (
        "measurement_duration_seconds",
        "measurement_work_units",
        "measurement_unit",
        "measurement_rate_per_second",
    ):
        assert metrics[key] is None
    assert "steps" not in metrics
    assert "global_optimizer_step" not in metrics
    assert "output_capability" not in manifest


@pytest.mark.parametrize("dry_run", [False, True])
def test_cli_rejects_resume_before_output_or_runtime(monkeypatch, dry_run):
    monkeypatch.setattr(cli, "get_spec", lambda *args: SimpleNamespace(name="hunyuanvideo-1.5"))
    monkeypatch.setattr(cli, "load_run_config", lambda *args: {
        "resume_from_checkpoint": "/checkpoints/state.pt",
    })

    def forbidden(*args, **kwargs):
        pytest.fail("unsupported resume caused a side effect")

    for name in ("create_run_dir", "resolve_weights", "acquire", "inspect_runtime", "run_backend"):
        monkeypatch.setattr(cli, name, forbidden)
    args = SimpleNamespace(command="rl", model="hunyuanvideo-1.5",
                           models_config="models.yaml", config="run.yaml", dry_run=dry_run)
    with pytest.raises(ValueError, match="external checkpoint resume is not supported"):
        cli.cmd_run(args)
