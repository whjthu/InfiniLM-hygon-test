"""Real Torch CPU state tests, not Accelerate/SDXL/MLU producer qualification.

The CPU fixture bypasses the MLU-only session constructor. Production identity
pins are fixtures; only serialization, state application, RNG and cursor replay
use genuine implementations. Model hooks and the upstream trainer are untouched.
"""

import copy
import importlib.util
import json
import os
import random
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from genmlu import sdxl_training_resume_checkpoint as checkpoint
from test_sdxl_training_resume_checkpoint import contract, real_rows


AVAILABLE = all(importlib.util.find_spec(name) for name in ("torch", "numpy", "safetensors"))


def cpu_session(directory, data_root):
    import numpy as np
    import torch

    directory.mkdir()
    dataset, data = real_rows(data_root)
    random.seed(20260911)
    np.random.seed(20260911)
    torch.manual_seed(20260911)

    class TinyLoRA(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.lora_weight = torch.nn.Parameter(torch.randn(2))
            self.lora_unused = torch.nn.Parameter(torch.tensor([0.0, -0.0]))
            self.register_buffer("scale", torch.tensor([0.25, -0.0]))

    class Rows(torch.utils.data.Dataset):
        def __len__(self):
            return len(dataset)

        def __getitem__(self, index):
            return {
                "genmlu_sample_ids": index, "pixel_values": torch.tensor([index + 1.0, index + 2.0]),
                "input_ids_one": torch.tensor([index, index + 1]), "input_ids_two": torch.tensor([index + 2, index + 3]),
                "original_sizes": (1, 1), "crop_top_lefts": (0, 0),
            }

    def collate(rows):
        return {
            "genmlu_sample_ids": [row["genmlu_sample_ids"] for row in rows],
            **{key: torch.stack([row[key] for row in rows]) for key in ("pixel_values", "input_ids_one", "input_ids_two")},
            "original_sizes": [row["original_sizes"] for row in rows],
            "crop_top_lefts": [row["crop_top_lefts"] for row in rows],
        }

    model = TinyLoRA()
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
    optimizer.step_was_skipped = False
    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lambda _step: 1.0)
    generator = torch.Generator().manual_seed(20260911)
    original = torch.utils.data.BatchSampler(torch.utils.data.RandomSampler(Rows(), generator=generator), 1, False)
    sampler = checkpoint.make_batch_sampler(original, generator, torch)
    dataloader = torch.utils.data.DataLoader(Rows(), batch_sampler=sampler, generator=generator,
                                            num_workers=0, collate_fn=collate)
    session = checkpoint.NativeCheckpointSession.__new__(checkpoint.NativeCheckpointSession)
    session.args = type("Args", (), {"output_dir": str(directory), "max_train_steps": 25})()
    session.model, session.optimizer, session.scheduler = model, optimizer, scheduler
    session.accelerator = type("Counter", (), {"step": 0})()
    session.sampler, session.generator = sampler, generator
    session.named = list(model.named_parameters())
    session.counts = {name: 0 for name, _ in session.named}
    session.adapter_state = lambda: {"unet." + name: value for name, value in session.named}
    session.contract = contract(data)
    session.contract["parameters"] = checkpoint._schema(session.named)
    session.contract["buffers"] = checkpoint._schema(model.named_buffers())
    session.mlu = False  # CPU stream test seam, never evidence of an MLU checkpoint.
    session.step, session.restored, session.batch_witness = 0, None, None
    session.resumed_mid_epoch = False
    return session, dataloader


def emit_native_files(session, directory):
    import torch
    from safetensors.torch import save_file

    directory.mkdir()
    before = session.capture_state()
    save_file(before["adapter"], str(directory / "pytorch_lora_weights.safetensors"))
    torch.save(before["optimizer"], directory / "optimizer.bin")
    torch.save(before["scheduler"], directory / "scheduler.bin")
    rng = before["rng"]
    torch.save({"step": before["accelerator_step"], "random_state": rng["python"], "numpy_random_seed": rng["numpy"],
                "torch_manual_seed": rng["torch_cpu"], "torch_mlu_manual_seed": rng["mlu"]},
               directory / "random_states_0.pkl")
    session.save_checkpoint(directory, session.step, before)
    return before


def execute(session, dataloader, directory):
    import numpy as np
    import torch

    rows = []
    if session.sampler.order is not None and session.sampler.consumed == len(session.sampler):
        session.sampler.set_epoch(session.sampler.epoch + 1)
    iterator = session.iterator(dataloader)
    while session.step < 25:
        try:
            batch = next(iterator)
        except StopIteration:
            session.sampler.set_epoch(session.sampler.epoch + 1)
            iterator = session.iterator(dataloader)
            batch = next(iterator)
        session.observe_batch(batch)
        target = torch.randn(2) + float(np.random.normal()) + random.random()
        prediction = session.model.lora_weight * batch["pixel_values"][0] + session.model.scale
        loss = (prediction - target).square().sum()
        loss.backward()
        session.optimizer.step()
        session.scheduler.step()
        session.accelerator.step += 1
        session.advance(batch, session.step + 1)
        session.optimizer.zero_grad(set_to_none=True)
        with torch.no_grad():
            session.model.scale.add_(0.001)
        state = session.capture_state()
        rows.append({"step": session.step, "sample": session.batch_witness["sample_ids"],
                     "loss_sha256": checkpoint.state_sha(loss), "state_sha256": checkpoint.state_sha(state)})
        if session.step in (10, 11, 20, 21, 25):
            emit_native_files(session, directory / f"checkpoint-{session.step}")
    return rows, session.capture_state()


def resume_worker(checkpoint_path, directory, data_root):
    session, dataloader = cpu_session(directory, data_root)
    # Restore must override different globals, optimizer slots and model values.
    random.seed(19)
    import numpy as np
    import torch

    np.random.seed(23)
    torch.manual_seed(29)
    with torch.no_grad():
        session.model.lora_weight.fill_(13)
        session.model.scale.fill_(-9)
    session.restore_checkpoint(checkpoint_path)
    session.preupdate_witness()
    rows, state = execute(session, dataloader, directory)
    (directory / "cpu-result.json").write_text(json.dumps({"rows": rows, "state_sha256": checkpoint.state_sha(state)}),
                                               encoding="utf-8")


def rebind_artifacts(directory, payload):
    """Rehash corrupt state so tests reach semantic gates, not just file SHA gates."""
    import torch

    torch.save(payload, directory / checkpoint.STATE)
    torch.save(payload["state"]["optimizer"], directory / "optimizer.bin")
    torch.save(payload["state"]["scheduler"], directory / "scheduler.bin")
    manifest = json.loads((directory / checkpoint.MANIFEST).read_text(encoding="utf-8"))
    manifest["state_sha256"] = checkpoint.state_sha(payload["state"])
    manifest["files"] = {name: {"bytes": (directory / name).stat().st_size, "sha256": checkpoint.file_sha(directory / name)}
                         for name in checkpoint.FILES}
    manifest.pop("integrity_sha256")
    manifest["integrity_sha256"] = checkpoint.json_sha(manifest)
    (directory / checkpoint.MANIFEST).write_text(json.dumps(manifest), encoding="utf-8")


@unittest.skipUnless(AVAILABLE, "genuine CPU Torch/NumPy/safetensors unavailable")
class FullStateRoundtripTests(unittest.TestCase):
    def test_fresh25_and_spawned_consumers_are_byte_exact_including_epoch_boundary(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            data_root = root / "images"
            data_root.mkdir()
            fresh = root / "fresh"
            session, dataloader = cpu_session(fresh, data_root)
            expected_rows, final = execute(session, dataloader, fresh)
            expected = checkpoint.state_sha(final)
            environment = os.environ.copy()
            source = str(Path(__file__).resolve().parents[1] / "src")
            environment["PYTHONPATH"] = source + os.pathsep + environment.get("PYTHONPATH", "")
            for start in (10, 20, 21):
                output = root / f"from{start}"
                process = subprocess.run([sys.executable, "-B", str(Path(__file__).resolve()), "--resume-worker",
                                          str(fresh / f"checkpoint-{start}"), str(output), str(data_root)],
                                         capture_output=True, text=True, env=environment, timeout=120)
                self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
                result = json.loads((output / "cpu-result.json").read_text(encoding="utf-8"))
                self.assertEqual(result["rows"], expected_rows[start:])
                self.assertEqual(result["state_sha256"], expected)
                self.assertEqual([row["step"] for row in result["rows"]], list(range(start + 1, 26)))
                witness = json.loads((output / "preupdate-witness.json").read_text(encoding="utf-8"))
                manifest = checkpoint.preflight(fresh / f"checkpoint-{start}")
                self.assertEqual(witness["state_sha256"], manifest["state_sha256"])
                self.assertEqual(witness["next_step"], start + 1)
                self.assertTrue(witness["restored_full_state_exact"])
                self.assertFalse(witness["fresh_recovery_verified"])
                self.assertFalse(witness["performance_accepted"])
                for step in ((start + 1, 25) if start != 21 else (25,)):
                    baseline = checkpoint.restricted_load(fresh / f"checkpoint-{step}" / checkpoint.STATE, numpy_rng=True)
                    resumed = checkpoint.restricted_load(output / f"checkpoint-{step}" / checkpoint.STATE, numpy_rng=True)
                    self.assertEqual(checkpoint.state_sha(baseline["state"]), checkpoint.state_sha(resumed["state"]))
            self.assertEqual(final["parameter_update_counts"], {"lora_weight": 25, "lora_unused": 0})

    def test_rehashed_semantic_corruption_rejected_before_live_state_changes(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            data_root = root / "images"
            data_root.mkdir()
            session, dataloader = cpu_session(root / "fresh", data_root)
            execute(session, dataloader, root / "fresh")
            directory = root / "fresh" / "checkpoint-10"
            original = checkpoint.restricted_load(directory / checkpoint.STATE, numpy_rng=True)
            for index, mutate in enumerate((
                lambda state: state["optimizer"]["state"][0].pop("exp_avg_sq"),
                lambda state: state["scheduler"].update(last_epoch=9),
                lambda state: state["data"].update(order=[0, 0, 2]),
                lambda state: state["rng"].pop("torch_cpu"),
            )):
                payload = copy.deepcopy(original)
                mutate(payload["state"])
                rebind_artifacts(directory, payload)
                consumer, _loader = cpu_session(root / f"reject-{index}", data_root)
                before = checkpoint.state_sha(consumer.capture_state())
                with self.subTest(mutation=index), self.assertRaises(checkpoint.CheckpointError):
                    consumer.restore_checkpoint(directory)
                self.assertEqual(checkpoint.state_sha(consumer.capture_state()), before)
                self.assertEqual(consumer.step, 0)
                self.assertIsNone(consumer.restored)


if __name__ == "__main__":
    if len(sys.argv) == 5 and sys.argv[1] == "--resume-worker":
        resume_worker(Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4]))
    else:
        unittest.main()
