"""Exercise pinned patch application with real temporary Git checkouts."""

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest


pytestmark = pytest.mark.skipif(
    not shutil.which("bash") or not shutil.which("git"), reason="requires Bash and Git"
)
ROOT = Path(__file__).resolve().parents[1]
MAPPED_SOURCES = (
    "diffusers-v039",
    "diffsynth-studio-grpo",
    "stable-fast-3d",
    "hunyuanvideo-1.5",
    "hy-motion",
    "trellis2",
)
PATCH_FILES = (
    "diffusers-sdxl-training-evidence.patch",
    "diffsynth-mlu.patch",
    "stable-fast-3d-mlu.patch",
    "hunyuanvideo-1.5-mlu.patch",
    "hy-motion-mlu.patch",
    "hy-motion-cpu-sidecar.patch",
    "trellis2-mlu.patch",
)


def git(directory, *args):
    return subprocess.check_output(
        ["git", "-C", str(directory), *args], text=True, stderr=subprocess.PIPE
    ).strip()


@pytest.fixture
def checkout(tmp_path):
    package = tmp_path / "package"
    (package / "scripts").mkdir(parents=True)
    (package / "patches").mkdir()
    shutil.copy(ROOT / "scripts/apply_source_patches.sh", package / "scripts")
    source_root = tmp_path / "sources"
    source = source_root / "trellis2"
    source.mkdir(parents=True)
    git(source, "init")
    (source / "value.txt").write_text("before\n")
    git(source, "add", "value.txt")
    git(source, "-c", "user.name=Test", "-c", "user.email=test@example.invalid",
        "commit", "-m", "fixture")
    revision = git(source, "rev-parse", "HEAD")
    (package / "sources.lock.json").write_text(json.dumps({
        "sources": {"trellis2": {"revision": revision}}
    }))
    (package / "patches/trellis2-mlu.patch").write_text(
        "diff --git a/value.txt b/value.txt\n--- a/value.txt\n+++ b/value.txt\n"
        "@@ -1 +1 @@\n-before\n+after\n"
    )
    return package, source_root, source


def run(package, source_root):
    return subprocess.run(
        ["bash", str(package / "scripts/apply_source_patches.sh"),
         str(source_root), "trellis2"], capture_output=True, text=True
    )


def _write_patch(path: Path, before: str, after: str) -> None:
    path.write_text(
        "diff --git a/value.txt b/value.txt\n"
        "--- a/value.txt\n"
        "+++ b/value.txt\n"
        "@@ -1 +1 @@\n"
        f"-{before}\n+{after}\n",
        encoding="utf-8",
    )


@pytest.fixture
def locked_patch_sources(tmp_path):
    package = tmp_path / "package"
    (package / "scripts").mkdir(parents=True)
    (package / "patches").mkdir()
    shutil.copy(ROOT / "scripts/apply_source_patches.sh", package / "scripts")
    shutil.copy(ROOT / "scripts/verify_source_patches.sh", package / "scripts")
    source_root = tmp_path / "sources"
    lock_sources = {}
    original_contents = {}

    for source_name in MAPPED_SOURCES:
        source = source_root / source_name
        source.mkdir(parents=True)
        if source_name == "hy-motion":
            source.joinpath("value.txt").write_text("before-mlu\nbefore-sidecar\n", encoding="utf-8")
        else:
            source.joinpath("value.txt").write_text("before\n", encoding="utf-8")
        git(source, "init")
        git(source, "add", "value.txt")
        git(source, "-c", "user.name=Test", "-c", "user.email=test@example.invalid", "commit", "-m", "fixture")
        origin = f"https://example.invalid/{source_name}.git"
        git(source, "remote", "add", "origin", origin)
        lock_sources[source_name] = {"revision": git(source, "rev-parse", "HEAD"), "origin": origin}
        original_contents[source_name] = source.joinpath("value.txt").read_bytes()

    (package / "sources.lock.json").write_text(json.dumps({"sources": lock_sources}), encoding="utf-8")
    _write_patch(package / "patches/diffusers-sdxl-training-evidence.patch", "before", "after-diffusers")
    _write_patch(package / "patches/diffsynth-mlu.patch", "before", "after-diffsynth")
    _write_patch(package / "patches/stable-fast-3d-mlu.patch", "before", "after-sf3d")
    _write_patch(package / "patches/hunyuanvideo-1.5-mlu.patch", "before", "after-hunyuan")
    _write_patch(package / "patches/hy-motion-mlu.patch", "before-mlu", "after-mlu")
    _write_patch(package / "patches/hy-motion-cpu-sidecar.patch", "before-sidecar", "after-sidecar")
    _write_patch(package / "patches/trellis2-mlu.patch", "before", "after-trellis")
    return package, source_root, original_contents


def verify(package: Path, source_root: Path, environment=None):
    return subprocess.run(
        ["bash", str(package / "scripts/verify_source_patches.sh"), str(source_root)],
        capture_output=True,
        env=environment,
        text=True,
    )


def test_named_source_is_idempotent(checkout):
    package, source_root, source = checkout
    for _ in range(2):
        result = run(package, source_root)
        assert result.returncode == 0, result.stderr
    assert (source / "value.txt").read_text() == "after\n"


def test_wrong_revision_does_not_apply(checkout):
    package, source_root, source = checkout
    lock = package / "sources.lock.json"
    lock.write_text(json.dumps({"sources": {"trellis2": {"revision": "0" * 40}}}))
    assert run(package, source_root).returncode != 0
    assert (source / "value.txt").read_text() == "before\n"


def test_linked_worktree_is_supported(checkout, tmp_path):
    package, _, source = checkout
    linked_root = tmp_path / "linked"
    linked_root.mkdir()
    linked = linked_root / "trellis2"
    git(source, "worktree", "add", "--detach", str(linked), "HEAD")
    assert (linked / ".git").is_file()
    result = run(package, linked_root)
    assert result.returncode == 0, result.stderr
    assert (linked / "value.txt").read_text() == "after\n"
    assert (source / "value.txt").read_text() == "before\n"


def test_default_patches_exclude_inactive_upstream_entrypoints():
    hunyuan_patch = (ROOT / "patches/hunyuanvideo-1.5-mlu.patch").read_text()
    trellis_patch = (ROOT / "patches/trellis2-mlu.patch").read_text()

    assert "diff --git a/generate.py b/generate.py" not in hunyuan_patch
    assert "diff --git a/train.py b/train.py" not in hunyuan_patch
    assert "diff --git a/hyvideo/pipelines/hunyuan_video_pipeline.py" in hunyuan_patch
    assert "diff --git a/trellis2/pipelines/rembg/BiRefNet.py" not in trellis_patch
    assert "diff --git a/trellis2/modules/image_feature_extractor.py" in trellis_patch


def test_default_patch_streams_are_valid():
    for filename in PATCH_FILES:
        result = subprocess.run(
            ["git", "apply", "--numstat", "--summary", str(ROOT / "patches" / filename)],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, result.stderr


def test_verify_all_locked_patch_sources_uses_isolated_clones(locked_patch_sources):
    package, source_root, original_contents = locked_patch_sources
    git(source_root / "diffusers-v039", "checkout", "--detach", "HEAD")

    result = verify(package, source_root)

    assert result.returncode == 0, result.stderr
    assert "Verified 7 patch streams" in result.stdout
    for source_name, before in original_contents.items():
        source = source_root / source_name
        assert source.joinpath("value.txt").read_bytes() == before
        assert git(source, "status", "--porcelain", "--untracked-files=all") == ""


def test_verify_allows_dirty_cache_without_mutating_it(locked_patch_sources):
    package, source_root, _ = locked_patch_sources
    source = source_root / "diffusers-v039"
    source.joinpath("value.txt").write_text("locally patched\n", encoding="utf-8")
    source.joinpath("local-note.txt").write_text("retain this file\n", encoding="utf-8")
    before_status = git(source, "status", "--porcelain", "--untracked-files=all")

    result = verify(package, source_root)

    assert result.returncode == 0, result.stderr
    assert source.joinpath("value.txt").read_text(encoding="utf-8") == "locally patched\n"
    assert source.joinpath("local-note.txt").read_text(encoding="utf-8") == "retain this file\n"
    assert git(source, "status", "--porcelain", "--untracked-files=all") == before_status


def test_verify_uses_raw_origin_despite_transport_rewrite(locked_patch_sources, tmp_path):
    package, source_root, _ = locked_patch_sources
    global_config = tmp_path / "global.gitconfig"
    global_config.write_text(
        '[url "https://mirror.invalid/https://example.invalid/"]\n'
        "\tinsteadOf = https://example.invalid/\n",
        encoding="utf-8",
    )
    environment = {
        **os.environ,
        "GIT_CONFIG_GLOBAL": str(global_config),
        "GIT_CONFIG_NOSYSTEM": "1",
    }
    source = source_root / "diffusers-v039"
    expanded_origin = subprocess.check_output(
        ["git", "-C", str(source), "remote", "get-url", "origin"],
        env=environment,
        text=True,
    ).strip()
    raw_origin = subprocess.check_output(
        ["git", "-C", str(source), "config", "--get", "remote.origin.url"],
        env=environment,
        text=True,
    ).strip()

    result = verify(package, source_root, environment)

    assert expanded_origin == "https://mirror.invalid/https://example.invalid/diffusers-v039.git"
    assert raw_origin == "https://example.invalid/diffusers-v039.git"
    assert result.returncode == 0, result.stderr


@pytest.mark.parametrize("mutation, expected", [
    ("origin", "source origin mismatch"),
    ("revision", "source revision mismatch"),
])
def test_verify_rejects_untrusted_source_identity(locked_patch_sources, mutation, expected):
    package, source_root, _ = locked_patch_sources
    source = source_root / "diffusers-v039"
    if mutation == "origin":
        git(source, "remote", "set-url", "origin", "https://example.invalid/other.git")
    else:
        source.joinpath("value.txt").write_text("changed\n", encoding="utf-8")
        git(source, "add", "value.txt")
        git(source, "-c", "user.name=Test", "-c", "user.email=test@example.invalid", "commit", "-m", "other")

    result = verify(package, source_root)

    assert result.returncode != 0
    assert expected in result.stderr


def test_reference_only_sources_preserve_provenance():
    sources = json.loads((ROOT / "sources.lock.json").read_text())["sources"]
    patch_script = (ROOT / "scripts/apply_source_patches.sh").read_text()
    references = {
        "flow-grpo": (
            "879042cf5707f8b90daa98d147d7deac2317c5da",
            "https://github.com/yifan123/flow_grpo.git",
        ),
        "trl": (
            "d9e880c199e17ea682fba0fab9bf3a05caff7577",
            "https://github.com/huggingface/trl.git",
        ),
        "trl-ddpo-v0114": (
            "1f8ba929fbb6962249386f7dce20155da8a26cda",
            "https://github.com/huggingface/trl.git",
        ),
        "z-image": (
            "26f23eda626ffadda020b04ff79488e1d72004cd",
            "https://github.com/Tongyi-MAI/Z-Image.git",
        ),
    }

    for name, (revision, origin) in references.items():
        assert sources[name] == {
            "revision": revision,
            "origin": origin,
            "role": "reference-only",
        }
        assert name not in patch_script
