"""CPU/Gloo protocol fixtures using pinned Muon, not native-cache/MLU evidence."""
from __future__ import annotations

import json
import os
from pathlib import Path
import random
import shutil
import subprocess
import sys
import tempfile
from datetime import timedelta
import unittest
from unittest import mock

from test_hunyuanvideo_dp_checkpoint import actual_muon, make_model, torch


def loopback_worker(root, world_size=2):
    # Exercise the actual launcher without loading the native model.
    import socket
    from genmlu.backends import hunyuanvideo_data_parallel as dp

    rank = dp.worker_rank(os.environ, world_size)
    if os.environ["MASTER_ADDR"] != "127.0.0.1" or os.environ["MASTER_PORT"] != "29500":
        raise AssertionError("torchrun advertised a non-loopback rendezvous")
    with mock.patch.object(socket, "getfqdn", side_effect=AssertionError("unexpected Python FQDN lookup")):
        torch.set_num_threads(1)
        torch.distributed.init_process_group("gloo", timeout=timedelta(seconds=30))
        try:
            value = torch.tensor([rank + 1], dtype=torch.int64)
            torch.distributed.all_reduce(value)
            if value.item() != world_size * (world_size + 1) // 2:
                raise AssertionError("fixed-world Gloo sum differs")
            Path(root, f"rank-{rank}.json").write_text(json.dumps({"rank": rank, "sum": value.item(),
                "master_addr": os.environ["MASTER_ADDR"], "master_port": os.environ["MASTER_PORT"]}))
        finally:
            torch.distributed.destroy_process_group()


@unittest.skipIf(torch is None, "CPU Torch is unavailable")
@unittest.skipUnless(sys.platform.startswith("linux"), "static torchrun smoke requires the supported Linux runtime")
class StaticRendezvousTests(unittest.TestCase):
    def test_two_rank_loopback_torchrun(self):
        self.check_loopback(2)

    def test_eight_rank_loopback_torchrun(self):
        self.check_loopback(8)

    def check_loopback(self, world_size):
        if not torch.distributed.is_available() or not torch.distributed.is_gloo_available():
            self.skipTest("CPU Gloo is unavailable")
        from genmlu.backends import hunyuanvideo_data_parallel as dp

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            env = dict(os.environ, TORCH_DEVICE_BACKEND_AUTOLOAD="0", OMP_NUM_THREADS="1")
            # Deliberately hostile defaults must not override the explicit static CLI options.
            env.update(MASTER_ADDR="unresolvable.invalid", MASTER_PORT="1", HOSTNAME="unresolvable.invalid",
                       PET_RDZV_BACKEND="c10d", PET_RDZV_ENDPOINT="unresolvable.invalid:1",
                       PET_MASTER_ADDR="unresolvable.invalid", PET_MASTER_PORT="1",
                       PET_LOCAL_ADDR="unresolvable.invalid", PET_NODE_RANK="7")
            source = Path(__file__).resolve().parents[1] / "src"
            env["PYTHONPATH"] = os.pathsep.join((str(source), str(Path(__file__).resolve().parent),
                                                env.get("PYTHONPATH", "")))
            env["GLOO_SOCKET_IFNAME"] = "lo"
            command = dp._local_torchrun_command(
                "test_hunyuanvideo_dp_gloo", ["--loopback-worker", str(root), str(world_size)], world_size
            )
            with (root / "torchrun.log").open("w", encoding="utf-8") as log:
                result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=90)
            text = (root / "torchrun.log").read_text(encoding="utf-8", errors="replace")
            self.assertEqual(result.returncode, 0, text)
            self.assertNotIn("unresolvable.invalid", text)
            self.assertNotIn("gai error", text.lower())
            for rank in range(world_size):
                self.assertEqual(json.loads((root / f"rank-{rank}.json").read_text()),
                    {"rank": rank, "sum": world_size * (world_size + 1) // 2,
                     "master_addr": "127.0.0.1", "master_port": "29500"})


def gloo_worker(rank, root, mode, resume_step, world_size=2):
    import numpy as np
    from genmlu import hunyuanvideo_distributed_checkpoint as cp
    from genmlu.backends import hunyuanvideo_data_parallel as dp

    torch.set_num_threads(1)
    root = Path(root)
    run = root / mode
    run.mkdir(exist_ok=True)
    torch.distributed.init_process_group("gloo", init_method=(root / f"rendezvous-{mode}").as_uri(),
                                        rank=rank, world_size=world_size, timeout=timedelta(seconds=60))
    try:
        muon = actual_muon()
        model = make_model(123)
        optimizer = muon.get_muon_optimizer(model)
        contract = cp.build_contract(identity={key: "a" * 64 for key in cp.native.IDENTITY_FIELDS},
                                     model=model, optimizer=optimizer, seed=42,
                                     warmup_steps=0, max_steps=21, devices=["cpu"] * world_size)
        counts = cp.native.common.initial_optimizer_progress(model, optimizer)
        device = torch.device("cpu")
        random.seed(42 + rank)
        np.random.seed(42 + rank)
        torch.manual_seed(42 + rank)
        completed = 0
        before = dp._replica_state(model, optimizer, counts)
        if mode in ("bad-resume", "failed-apply"):
            patch = mock.patch.object(cp, "apply_rank_state", side_effect=RuntimeError("injected apply failure"))
            context = patch if mode == "failed-apply" and rank == world_size - 1 else __import__("contextlib").nullcontext()
            with context:
                try:
                    dp.restore_transaction(torch, device, root / "broken" if mode == "bad-resume" else
                                           root / "baseline/checkpoint-10", contract, model, optimizer, rank)
                except RuntimeError as error:
                    cp.write_json_atomic(run / f"rank-{rank}.json", {"rejected": True, "error": str(error),
                        "unchanged": before == dp._replica_state(model, optimizer, counts)})
                    return
            raise AssertionError("injected restore failure was admitted")
        if resume_step:
            completed, counts = dp.restore_transaction(torch, device, root / f"baseline/checkpoint-{resume_step}",
                                                       contract, model, optimizer, rank)
            dp.validate_dp_checks({"nonzero_finite_gradients": True, "replicated_state_agreement": True,
                "complete_trainable_gradient_coverage": all(value == completed for value in counts.values()),
                "current_adapter": True, "peak_reserved_below_75gb": True, "main_forward_device": True,
                "checkpoint_resume": completed == resume_step, "external_resume_boundary": completed == resume_step},
                resumed=True)
        if mode == "gradient-mean":
            for parameter in model.parameters():
                parameter.grad = torch.full_like(parameter, rank + 1)
            dp.average_gradients(torch, model, optimizer, device)
            exact = all(torch.equal(parameter.grad, torch.full_like(parameter, (world_size + 1) / 2))
                        for parameter in model.parameters())
            cp.write_json_atomic(run / f"rank-{rank}.json", {"exact_mean": exact})
            return
        records = []
        for step in range(completed + 1, 22):
            optimizer.zero_grad(set_to_none=True)
            value = random.random() + float(np.random.rand()) + float(torch.rand(()))
            loss = sum((p * value).sum() for p in model.parameters())
            loss.backward()
            if mode == "missing-gradient":
                if rank == world_size - 1:
                    model.bias.grad = None
                try:
                    dp.average_gradients(torch, model, optimizer, device)
                except RuntimeError as error:
                    cp.write_json_atomic(run / f"rank-{rank}.json", {"rejected": True, "error": str(error),
                        "unchanged": before == dp._replica_state(model, optimizer, counts)})
                    return
                raise AssertionError("one-rank missing gradient was admitted")
            dp.average_gradients(torch, model, optimizer, device)
            torch.nn.utils.clip_grad_norm_(list(model.parameters()), 1.0)
            optimizer.step()
            counts = cp.native.common.advance_optimizer_progress(counts, model, optimizer)
            payload = cp.capture_rank(contract=contract, model=model, optimizer=optimizer, rank=rank,
                                      step=step, gradient_counts=counts)
            records.append({"step": step, "loss": float(loss.detach()), "state": payload["integrity_sha256"],
                "rng": cp.native.tree_sha256(payload["rng"]), "cursor": payload["metadata"]["cache_cursor"],
                "next_global_step": payload["metadata"]["next_global_step"]})
            if mode == "failed-save":
                context = mock.patch.object(cp.native, "save_atomic", side_effect=OSError("injected save failure"))
                with context if rank == world_size - 1 else __import__("contextlib").nullcontext():
                    try:
                        dp.save_transaction(torch, device, run / "checkpoint-1", contract, model, optimizer, rank, step, counts)
                    except RuntimeError as error:
                        cp.write_json_atomic(run / f"rank-{rank}.json", {"rejected": True, "error": str(error),
                            "marker_exists": (run / "checkpoint-1/COMMITTED.json").exists()})
                        return
                raise AssertionError("injected save failure was admitted")
            if step in (10, 20, 21):
                dp.save_transaction(torch, device, run / f"checkpoint-{step}", contract, model, optimizer, rank, step, counts)
        cp.write_json_atomic(run / f"rank-{rank}.json", {"records": records, "completed_start": completed})
    finally:
        torch.distributed.destroy_process_group()


@unittest.skipIf(torch is None, "CPU Torch is unavailable")
class GlooProtocolTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        actual_muon()
        if not torch.distributed.is_available() or not torch.distributed.is_gloo_available():
            raise unittest.SkipTest("CPU Gloo is unavailable")

    def spawn(self, root, mode, step=0):
        torch.multiprocessing.spawn(gloo_worker, args=(str(root), mode, step), nprocs=2, join=True)

    def test_fresh_cp10_cp20_both_rank_suffixes_match_exactly(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            self.spawn(root, "baseline")
            for step in (10, 20):
                mode = f"resume-{step}"
                self.spawn(root, mode, step)
                for rank in (0, 1):
                    baseline = json.loads((root / f"baseline/rank-{rank}.json").read_text())
                    resumed = json.loads((root / f"{mode}/rank-{rank}.json").read_text())
                    self.assertEqual(resumed["completed_start"], step)
                    self.assertEqual(resumed["records"], baseline["records"][step:])

    def test_one_rank_save_failure_never_publishes(self):
        with tempfile.TemporaryDirectory() as root:
            self.spawn(root, "failed-save")
            for rank in (0, 1):
                result = json.loads((Path(root) / f"failed-save/rank-{rank}.json").read_text())
                self.assertTrue(result["rejected"])
                self.assertFalse(result["marker_exists"])

    def test_missing_rank_preflight_and_apply_failure_abort_both(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            self.spawn(root, "baseline")
            shutil.copytree(root / "baseline/checkpoint-10", root / "broken")
            (root / "broken/rank-1.pt").unlink()
            self.spawn(root, "bad-resume")
            self.spawn(root, "failed-apply")
            for mode in ("bad-resume", "failed-apply"):
                for rank in (0, 1):
                    result = json.loads((root / f"{mode}/rank-{rank}.json").read_text())
                    self.assertTrue(result["rejected"])
                    if mode == "bad-resume":
                        self.assertTrue(result["unchanged"])


@unittest.skipIf(torch is None, "CPU Torch is unavailable")
class EightRankGlooProtocolTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        actual_muon()
        if not torch.distributed.is_available() or not torch.distributed.is_gloo_available():
            raise unittest.SkipTest("CPU Gloo is unavailable")

    def spawn(self, root, mode, step=0):
        torch.multiprocessing.spawn(gloo_worker, args=(str(root), mode, step, 8), nprocs=8, join=True)

    def test_actual_eight_rank_sum_divided_by_world_is_exact(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.spawn(root, "gradient-mean")
            for rank in range(8):
                self.assertTrue(json.loads((root / f"gradient-mean/rank-{rank}.json").read_text())["exact_mean"])

    def test_fresh_cp10_cp20_all_eight_suffixes_state_rng_cursor_are_exact(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.spawn(root, "baseline")
            for step in (10, 20):
                mode = f"resume-{step}"
                self.spawn(root, mode, step)
                for rank in range(8):
                    baseline = json.loads((root / f"baseline/rank-{rank}.json").read_text())
                    resumed = json.loads((root / f"{mode}/rank-{rank}.json").read_text())
                    self.assertEqual(resumed["completed_start"], step)
                    self.assertEqual(resumed["records"], baseline["records"][step:])
                    self.assertEqual([row["step"] for row in resumed["records"]], list(range(step + 1, 22)))

    def test_rank7_save_and_gradient_failure_abort_all_without_mutation(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            for mode in ("failed-save", "missing-gradient"):
                self.spawn(root, mode)
                for rank in range(8):
                    result = json.loads((root / f"{mode}/rank-{rank}.json").read_text())
                    self.assertTrue(result["rejected"])
                    if mode == "failed-save":
                        self.assertFalse(result["marker_exists"])
                    else:
                        self.assertTrue(result["unchanged"])

    def test_rank7_missing_preflight_and_apply_failure_abort_all(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.spawn(root, "baseline")
            shutil.copytree(root / "baseline/checkpoint-10", root / "broken")
            (root / "broken/rank-7.pt").unlink()
            for mode in ("bad-resume", "failed-apply"):
                self.spawn(root, mode)
                for rank in range(8):
                    result = json.loads((root / f"{mode}/rank-{rank}.json").read_text())
                    self.assertTrue(result["rejected"])
                    if mode == "bad-resume":
                        self.assertTrue(result["unchanged"])


if __name__ == "__main__":
    if sys.argv[1:2] == ["--loopback-worker"]:
        loopback_worker(sys.argv[2], int(sys.argv[3]) if len(sys.argv) == 4 else 2)
    else:
        unittest.main()
