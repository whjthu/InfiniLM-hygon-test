import unittest

from genmlu.backends.hunyuanvideo_sage_grpo import _resolve_adapter_parameter_names


class HunyuanVideoAdapterNameResolutionTest(unittest.TestCase):
    def test_resolves_wrapped_state_into_unwrapped_model(self) -> None:
        self.assertEqual(
            _resolve_adapter_parameter_names(
                {"double_blocks.0._checkpoint_wrapped_module.img_attn_q.lora_A.default.weight"},
                {"double_blocks.0.img_attn_q.lora_A.default.weight"},
            ),
            {"double_blocks.0._checkpoint_wrapped_module.img_attn_q.lora_A.default.weight": "double_blocks.0.img_attn_q.lora_A.default.weight"},
        )

    def test_rejects_colliding_canonical_parameter_names(self) -> None:
        with self.assertRaisesRegex(RuntimeError, "collide"):
            _resolve_adapter_parameter_names(
                {"double_blocks.0.img_attn_q.lora_A.default.weight"},
                {"double_blocks.0.img_attn_q.lora_A.default.weight", "double_blocks.0._checkpoint_wrapped_module.img_attn_q.lora_A.default.weight"},
            )


if __name__ == "__main__":
    unittest.main()
