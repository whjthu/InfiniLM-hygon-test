import threading
import unittest

from genmlu.checkpoint_cpu_threads import checkpoint_cpu_threads, validate_limit


class ThreadControl:
    def __init__(self, initial=32):
        self.value = initial
        self.calls = []
        self.fail_target = False
        self.bad_target = False
        self.bad_restore = False

    def get_num_threads(self):
        return self.value

    def set_num_threads(self, value):
        self.calls.append(value)
        self.value = value
        if value == 1 and self.fail_target:
            raise RuntimeError("target changed then failed")
        if value == 1 and self.bad_target:
            self.value = 2
        if value == 32 and self.bad_restore:
            self.value = 4


class Tests(unittest.TestCase):
    def test_disabled_does_not_access_torch(self):
        with checkpoint_cpu_threads(None):
            pass

    def test_invalid_limit_before_torch_access(self):
        for value in (True, False, 0, -1, 1.0, "1", 257):
            with self.subTest(value=value), self.assertRaises(ValueError):
                with checkpoint_cpu_threads(None, value):
                    self.fail("body executed")
        self.assertIsNone(validate_limit(None))

    def test_scope_and_restoration(self):
        torch = ThreadControl()
        with checkpoint_cpu_threads(torch, 1):
            self.assertEqual(torch.value, 1)
        self.assertEqual(torch.calls, [1, 32])
        self.assertEqual(torch.value, 32)

    def test_does_not_increase_threads(self):
        torch = ThreadControl(1)
        with checkpoint_cpu_threads(torch, 16):
            self.assertEqual(torch.value, 1)
        self.assertEqual(torch.calls, [])

    def test_body_error_preserved(self):
        torch = ThreadControl()
        error = ValueError("snapshot failure")
        with self.assertRaises(ValueError) as caught:
            with checkpoint_cpu_threads(torch, 1):
                raise error
        self.assertIs(caught.exception, error)
        self.assertEqual(torch.value, 32)

    def test_set_failure_restores_changed_state(self):
        torch = ThreadControl()
        torch.fail_target = True
        with self.assertRaisesRegex(RuntimeError, "changed then failed"):
            with checkpoint_cpu_threads(torch, 1):
                self.fail("body executed")
        self.assertEqual(torch.value, 32)

    def test_target_readback_failure_restores(self):
        torch = ThreadControl()
        torch.bad_target = True
        with self.assertRaisesRegex(RuntimeError, "did not take effect"):
            with checkpoint_cpu_threads(torch, 1):
                self.fail("body executed")
        self.assertEqual(torch.value, 32)

    def test_restore_failure_is_fatal_with_body_error_context(self):
        torch = ThreadControl()
        torch.bad_restore = True
        with self.assertRaisesRegex(RuntimeError, "not restored") as caught:
            with checkpoint_cpu_threads(torch, 1):
                raise ValueError("snapshot failure")
        self.assertIsInstance(caught.exception.__context__, ValueError)

    def test_nested_scope_restores_each_owner(self):
        torch = ThreadControl()
        with checkpoint_cpu_threads(torch, 4):
            with checkpoint_cpu_threads(torch, 1):
                self.assertEqual(torch.value, 1)
            self.assertEqual(torch.value, 4)
        self.assertEqual(torch.value, 32)

    def test_nonmain_thread_rejected_before_torch_access(self):
        errors = []
        def work():
            try:
                with checkpoint_cpu_threads(None, 1):
                    errors.append("body executed")
            except RuntimeError as error:
                errors.append(str(error))
        worker = threading.Thread(target=work)
        worker.start()
        worker.join(timeout=2)
        self.assertFalse(worker.is_alive())
        self.assertEqual(errors, ["checkpoint CPU thread scope requires the main thread"])


if __name__ == "__main__":
    unittest.main()
