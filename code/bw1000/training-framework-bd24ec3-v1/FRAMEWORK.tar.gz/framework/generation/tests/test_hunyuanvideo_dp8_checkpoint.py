"""Real CPU Torch/pinned Muon DP8 states; skips without those dependencies."""
import copy
from pathlib import Path
import random
import tempfile
import unittest

from test_hunyuanvideo_dp_checkpoint import actual_muon, make_model, manual_step, torch


@unittest.skipIf(torch is None, "CPU Torch is unavailable")
class EightRankCheckpointTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.muon = actual_muon()
        from genmlu import hunyuanvideo_distributed_checkpoint as checkpoint
        cls.cp = checkpoint

    def setUp(self):
        import numpy as np
        self.model = make_model()
        self.optimizer = self.muon.get_muon_optimizer(self.model)
        self.contract = self.cp.build_contract(identity={key: "a" * 64 for key in self.cp.native.IDENTITY_FIELDS},
            model=self.model, optimizer=self.optimizer, seed=42, warmup_steps=0, max_steps=21, devices=["cpu"] * 8)
        self.counts = self.cp.native.common.initial_optimizer_progress(self.model, self.optimizer)
        manual_step(self.model, self.optimizer, self.counts, all_used=True)
        self.payloads = []
        for rank in range(8):
            random.seed(42 + rank)
            np.random.seed(42 + rank)
            torch.manual_seed(42 + rank)
            self.payloads.append(self.cp.capture_rank(contract=self.contract, model=self.model,
                optimizer=self.optimizer, rank=rank, step=1, gradient_counts=self.counts))

    def write_ranks(self, root, payloads):
        receipts = []
        for rank, payload in enumerate(payloads):
            path = root / f"rank-{rank}.pt"
            self.cp.native.save_atomic(path, payload)
            receipts.append({"rank": rank, "sha256": self.cp.native.file_sha256(path),
                             "replica_sha256": self.cp.replica_sha(payload)})
        return receipts

    def test_all_eight_states_rng_and_topology_roundtrip(self):
        self.assertEqual(self.contract["schema"], self.cp.DP8_SCHEMA)
        for group in self.contract["topology"]["groups"]:
            self.assertTrue(all(p["replicas"] == list(range(8)) for p in group["parameters"]))
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            receipts = self.write_ranks(root, self.payloads)
            self.cp.publish_commit(root, receipts, self.contract, 1, writer_rank=0)
            manifest, loaded = self.cp.load_committed(root)
            self.assertEqual(manifest["contract"], self.contract)
            for rank in range(8):
                self.assertEqual(self.cp.native.tree_sha256(loaded[rank]), self.cp.native.tree_sha256(self.payloads[rank]))
                self.cp.validate_rank(loaded[rank], self.contract, self.model, self.optimizer, rank, native_rng=False)
            self.assertEqual(len({self.cp.native.tree_sha256(p["rng"]) for p in loaded}), 8)

    def test_rehashed_rank7_optimizer_divergence_refuses_commit(self):
        payloads = copy.deepcopy(self.payloads)
        payloads[7]["state"]["optimizer"]["state"][0]["momentum_buffer"].add_(1)
        payloads[7]["integrity_sha256"] = self.cp.native.tree_sha256(
            {key: value for key, value in payloads[7].items() if key != "integrity_sha256"})
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            receipts = self.write_ranks(root, payloads)
            with self.assertRaises(self.cp.Error):
                self.cp.publish_commit(root, receipts, self.contract, 1, writer_rank=0)
            self.assertFalse((root / "COMMITTED.json").exists())

    def test_cross_world_and_schema_reject_before_mutation(self):
        dp2 = self.cp.build_contract(identity=self.contract["identity"], model=self.model, optimizer=self.optimizer,
            seed=42, warmup_steps=0, max_steps=21, devices=["cpu", "cpu"])
        before = self.cp.native.tree_sha256(self.cp.native.capture_model_state(self.model, self.optimizer))
        for plan in (dp2, self.contract | {"schema": self.cp.SCHEMA}, self.contract | {"world_size": 2}):
            with self.subTest(plan=plan["schema"]), self.assertRaises(self.cp.Error):
                self.cp.validate_rank(self.payloads[0], plan, self.model, self.optimizer, 0, native_rng=False)
        self.assertEqual(before, self.cp.native.tree_sha256(self.cp.native.capture_model_state(self.model, self.optimizer)))

    def test_every_rank_rng_boundary_and_next_optimizer_update_are_exact(self):
        import numpy as np
        for rank, payload in enumerate(self.payloads):
            with self.subTest(rank=rank):
                baseline, resumed = make_model(999), make_model(888)
                baseline_opt = self.muon.get_muon_optimizer(baseline)
                resumed_opt = self.muon.get_muon_optimizer(resumed)
                self.cp.apply_rank_state(payload, baseline, baseline_opt)
                self.cp.restore_rank_rng(payload, self.contract, rank)
                value = random.random() + float(np.random.rand()) + float(torch.rand(()))
                manual_step(baseline, baseline_opt, dict(self.counts), value=value, all_used=True)
                expected = self.cp.native.tree_sha256(self.cp.native.capture_model_state(baseline, baseline_opt))
                self.cp.validate_rank(payload, self.contract, resumed, resumed_opt, rank, native_rng=False)
                self.cp.apply_rank_state(payload, resumed, resumed_opt)
                self.cp.restore_rank_rng(payload, self.contract, rank)
                boundary = self.cp.capture_rank(contract=self.contract, model=resumed, optimizer=resumed_opt,
                    rank=rank, step=1, gradient_counts=self.counts)
                self.assertEqual(boundary["integrity_sha256"], payload["integrity_sha256"])
                replay = random.random() + float(np.random.rand()) + float(torch.rand(()))
                self.assertEqual(replay, value)
                manual_step(resumed, resumed_opt, dict(self.counts), value=replay, all_used=True)
                self.assertEqual(expected, self.cp.native.tree_sha256(self.cp.native.capture_model_state(resumed, resumed_opt)))


if __name__ == "__main__":
    unittest.main()
