"""Inspect and execute bounded opt-in patch fragments without importing Torch."""

import argparse
import ast
import types
import unittest
from pathlib import Path


PATCH = Path(__file__).resolve().parents[1] / "patches/diffusers-sdxl-training-evidence.patch"


class ProducerPatchTests(unittest.TestCase):
    def setUp(self):
        self.text = PATCH.read_text(encoding="utf-8")

    def test_new_parser_arguments_are_off_by_default(self):
        lines = [line[1:] for line in self.text.splitlines()
                 if line.startswith('+    parser.add_argument("--genmlu_')]
        self.assertEqual(len(lines), 4)
        parser = argparse.ArgumentParser()
        source = "\n".join(line.strip() for line in lines)
        exec(compile(ast.parse(source), "patch-arguments", "exec"), {"parser": parser})
        self.assertFalse(parser.parse_args([]).genmlu_full_checkpoint)
        self.assertTrue(parser.parse_args(["--genmlu_full_checkpoint"]).genmlu_full_checkpoint)

    def test_main_gate_rejects_scope_before_any_model_setup(self):
        block = self.text.split("\n def main(args):\n", 1)[1].split("\n     if args.report_to", 1)[0]
        source = "def gate(args):\n" + "\n".join(line[1:] for line in block.splitlines() if line.startswith("+"))
        namespace = {}
        exec(compile(ast.parse(source), "patch-gate", "exec"), namespace)
        args = types.SimpleNamespace(genmlu_full_checkpoint=False, genmlu_external_resume_from_checkpoint=None)
        namespace["gate"](args)
        args.genmlu_external_resume_from_checkpoint = "/fixture/checkpoint-10"
        with self.assertRaises(ValueError):
            namespace["gate"](args)
        defaults = dict(genmlu_full_checkpoint=True, genmlu_external_resume_from_checkpoint=None,
                        dataloader_num_workers=0, train_batch_size=1, gradient_accumulation_steps=1,
                        pretrained_vae_model_name_or_path=None, dataset_name=None)
        namespace["gate"](types.SimpleNamespace(**defaults))
        for field, value in (("dataloader_num_workers", 1), ("train_batch_size", 2),
                             ("gradient_accumulation_steps", 2), ("pretrained_vae_model_name_or_path", "other"),
                             ("dataset_name", "remote-dataset")):
            with self.subTest(field=field), self.assertRaises(ValueError):
                namespace["gate"](types.SimpleNamespace(**dict(defaults, **{field: value})))

    def test_backend_resume_auto_enables_full_contract_without_changing_fresh_default(self):
        backend = PATCH.parents[1] / "src/genmlu/backends/sdxl_training.py"
        module = ast.parse(backend.read_text(encoding="utf-8"))
        run = next(node for node in module.body if isinstance(node, ast.FunctionDef)
                   and node.name == "run_sdxl_training")
        start = next(index for index, node in enumerate(run.body) if isinstance(node, ast.Assign)
                     and any(isinstance(target, ast.Name) and target.id == "full_checkpoint"
                             for target in node.targets))
        selection = ast.Module(body=run.body[start:start + 3], type_ignores=[])
        self.assertEqual([type(node) for node in selection.body], [ast.Assign, ast.If, ast.Assign])
        code = compile(ast.fix_missing_locations(selection), str(backend), "exec")
        for config, resume, expected in (({}, None, False), ({"full_checkpoint": False}, None, False),
                                         ({"full_checkpoint": True}, None, True), ({}, Path("checkpoint-10"), True),
                                         ({"full_checkpoint": False}, Path("checkpoint-20"), True)):
            with self.subTest(config=config, resume=resume):
                namespace = {"config": config, "resume_checkpoint": resume}
                exec(code, namespace)
                self.assertIs(namespace["full_checkpoint"], expected)
        for value in (None, 0, 1, "false", "true"):
            with self.subTest(invalid=value), self.assertRaises(ValueError):
                exec(code, {"config": {"full_checkpoint": value}, "resume_checkpoint": Path("checkpoint-10")})

    def test_no_model_hook_or_training_math_replacement(self):
        additions = [line[1:] for line in self.text.splitlines() if line.startswith("+") and not line.startswith("+++")]
        deletions = [line[1:] for line in self.text.splitlines() if line.startswith("-") and not line.startswith("---")]
        self.assertFalse(any("def save_model_hook" in line or "def load_model_hook" in line for line in additions + deletions))
        self.assertFalse(any(line.strip().startswith(("optimizer.step(", "lr_scheduler.step(", "accelerator.backward(",
                                                     "model_pred =", "loss =")) for line in additions + deletions))
        self.assertIn("genmlu_session.advance(batch, global_step + 1)", self.text)
        self.assertLess(self.text.index("genmlu_session.advance(batch, global_step + 1)"),
                        self.text.index("optimizer.zero_grad()"))
        self.assertLess(self.text.index("accelerator.save_state(save_path)"),
                        self.text.index("genmlu_session.save_checkpoint(Path(save_path)"))

    def test_completed_epoch_and_preupdate_boundaries_do_not_add_updates(self):
        self.assertIn("if genmlu_sampler.consumed == len(genmlu_sampler):", self.text)
        self.assertIn("first_epoch += 1", self.text)
        self.assertIn("train_dataloader.set_epoch(epoch)", self.text)
        self.assertLess(self.text.index("genmlu_session.preupdate_witness()"), self.text.index("progress_bar = tqdm"))
        self.assertIn("global_step == args.max_train_steps", self.text)
        self.assertIn("full-checkpoint resume cannot fall back to a fresh run", self.text)
        self.assertIn('record["sample_witness"] = genmlu_session.batch_witness', self.text)


if __name__ == "__main__":
    unittest.main()
