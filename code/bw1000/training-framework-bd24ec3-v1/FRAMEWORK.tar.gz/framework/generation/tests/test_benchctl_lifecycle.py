import argparse
import json
import os
import signal
import subprocess
import time
from pathlib import Path

import pytest

import genmlu.benchctl as benchctl
from genmlu.benchctl import (
    ContainerIdentity,
    PreflightResult,
    RunInterrupted,
    _resume_checkpoint,
    _stop_owned_container,
    _validate_run_args,
    build_parser,
    cleanup_owned_containers,
    command_run,
    inspect_owned_container,
    normalize_container_names,
    prepare_command,
    prepare_managed_command,
    process_tree_pids,
    refresh_owned_containers,
)


def run_args(tmp_path: Path, **overrides: object) -> argparse.Namespace:
    values: dict[str, object] = {
        "output_root": str(tmp_path),
        "project": "generative-mlu",
        "host_label": "mlu-10000",
        "cards": "0",
        "sample_interval": 0,
        "watch_interval": 60,
        "timeout_seconds": 8 * 60 * 60,
        "run_id": "case-1",
        "container_name": None,
        "command": ["--", "/bin/true"],
        "checkpoint": None,
    }
    values.update(overrides)
    return argparse.Namespace(**values)


def ready_result() -> PreflightResult:
    return PreflightResult(
        host="test",
        cards=(0,),
        card_states=(benchctl.CardState(0, 0, 0),),
        foreign_accelerator_processes=(),
        checked_at_utc="2026-09-06T00:00:00+00:00",
    )


def test_prepare_direct_docker_run_injects_exact_identity() -> None:
    command, name = prepare_command(["docker", "run", "image", "cmd"], "case-container", "case-1")
    assert name == "case-container"
    assert command[:6] == [
        "docker",
        "run",
        "--label",
        "genmlu.run_id=case-1",
        "--name",
        "case-container",
    ]


def test_prepare_nested_python_runner_is_not_rewritten() -> None:
    original = ["python3", "scripts/run_performance_case.py", "--case", "x"]
    command, name = prepare_command(original, "case-container", "case-1")
    assert command == original
    assert name == "case-container"


def test_repeated_container_names_are_preserved_and_direct_multi_is_rejected() -> None:
    args = build_parser().parse_args(
        [
            "run",
            "--host-label",
            "mlu-10000",
            "--container-name",
            "vllm-0",
            "--container-name",
            "actor-1",
            "--",
            "python3",
            "runner.py",
        ]
    )
    assert normalize_container_names(args.container_name) == ("vllm-0", "actor-1")
    command, names = prepare_managed_command(
        ["python3", "runner.py"], ("vllm-0", "actor-1"), "case-1"
    )
    assert command == ["python3", "runner.py"]
    assert names == ("vllm-0", "actor-1")
    with pytest.raises(ValueError, match="cannot own multiple"):
        prepare_managed_command(["docker", "run", "image"], names, "case-1")


def test_inspect_requires_run_id_label_before_accepting_pid() -> None:
    payload = [
        {
            "Id": "abcdef",
            "Config": {"Labels": {"genmlu.run_id": "case-1"}},
            "State": {"Pid": 9123},
        }
    ]

    def runner(command: tuple[str, ...], timeout: int) -> str:
        assert command == ("docker", "inspect", "case-container")
        assert timeout == 20
        return json.dumps(payload)

    assert inspect_owned_container("case-container", "case-1", runner=runner) == ContainerIdentity(
        "case-container", "abcdef", 9123
    )
    payload[0]["Config"]["Labels"]["genmlu.run_id"] = "someone-else"
    with pytest.raises(RuntimeError, match="ownership label mismatch"):
        inspect_owned_container("case-container", "case-1", runner=runner)


def test_multi_container_inspect_requires_lease_label() -> None:
    labels = {"genmlu.run_id": "case-1"}
    payload = [{"Id": "one", "Config": {"Labels": labels}, "State": {"Pid": 101}}]

    def runner(command: tuple[str, ...], timeout: int) -> str:
        del command, timeout
        return json.dumps(payload)

    with pytest.raises(RuntimeError, match="lease label mismatch"):
        inspect_owned_container(
            "vllm-0",
            "case-1",
            lease_id="lease-1",
            require_lease_id=True,
            runner=runner,
        )
    labels["genmlu.lease_id"] = "lease-1"
    assert inspect_owned_container(
        "vllm-0",
        "case-1",
        lease_id="lease-1",
        require_lease_id=True,
        runner=runner,
    ) == ContainerIdentity("vllm-0", "one", 101)


def test_real_docker_missing_shape_with_stdout_is_not_success(monkeypatch: pytest.MonkeyPatch) -> None:
    completed = subprocess.CompletedProcess(
        ["docker", "inspect", "missing"],
        1,
        stdout="[]\n",
        stderr="Error: No such object: missing\n",
    )
    monkeypatch.setattr(benchctl.subprocess, "run", lambda *args, **kwargs: completed)
    assert inspect_owned_container("missing", "case-1", runner=benchctl._run) is None


def test_inspect_missing_detection_is_case_insensitive_but_narrow() -> None:
    def runner_with(message: str):
        def runner(command: tuple[str, ...], timeout: int) -> str:
            del timeout
            raise benchctl.CommandFailure(command, subprocess.CompletedProcess(
                command, 1, stdout="[]\n", stderr=message))

        return runner

    assert inspect_owned_container(
        "missing",
        "case-1",
        runner=runner_with("error: no such object: missing"),
    ) is None
    for message in (
        "Cannot connect to the Docker daemon at unix:///var/run/docker.sock",
        "permission denied while trying to connect to the Docker daemon socket",
        "dial unix /var/run/docker.sock: connect: no such file or directory",
    ):
        with pytest.raises(RuntimeError) as error:
            inspect_owned_container("missing", "case-1", runner=runner_with(message))
        assert str(error.value) == message


@pytest.mark.parametrize("returncode,stdout,stderr", [
    (1, "[]\n", "Error: No such object: missing\npermission denied"),
    (1, "[]\n", "Error: No such object: other"),
    (1, "garbage", "Error: No such object: missing"),
    (2, "[]\n", "Error: No such object: missing"),
    (True, "[]\n", "Error: No such object: missing"),
])
def test_inspect_rejects_mixed_wrong_or_untyped_missing_metadata(
    monkeypatch, returncode, stdout, stderr,
) -> None:
    completed = subprocess.CompletedProcess(
        ["docker", "inspect", "missing"], returncode, stdout=stdout, stderr=stderr)
    monkeypatch.setattr(benchctl.subprocess, "run", lambda *a, **k: completed)
    with pytest.raises(benchctl.CommandFailure):
        inspect_owned_container("missing", "case-1", runner=benchctl._run)


def test_unstructured_missing_error_is_unknown() -> None:
    def runner(*args, **kwargs):
        raise RuntimeError("Error: No such object: missing")
    with pytest.raises(RuntimeError):
        inspect_owned_container("missing", "case-1", runner=runner)


def test_direct_container_gets_controller_nonce_and_rejects_supplied_nonce() -> None:
    token = "a" * 32
    command = ["docker", "run", "image", "true"]
    prepared, names = prepare_managed_command(command, (), "case-1", token)
    assert names == ("genmlu-case-1",)
    assert prepared[2:4] == ["--label", "genmlu.lease_id=" + token]
    assert command == ["docker", "run", "image", "true"]
    with pytest.raises(ValueError, match="controller supplies"):
        prepare_managed_command(["docker", "run", "--label",
                                 "genmlu.lease_id=" + token, "image"], (), "case-1", token)


@pytest.mark.parametrize("option", [
    ["-l", "genmlu.lease_id=old"], ["-lgenmlu.lease_id=old"],
    ["--label=genmlu.lease_id=old"],
    ["-l", "genmlu.lease_id"],
    ["--label", "genmlu.lease_id"], ["--label=genmlu.lease_id"],
    ["-lgenmlu.lease_id"],
])
def test_nonce_cannot_be_overridden_by_short_or_attached_labels(option) -> None:
    with pytest.raises(ValueError, match="controller supplies"):
        prepare_managed_command(["docker", "run", *option, "image"], (), "case-1", "a" * 32)


@pytest.mark.parametrize("option", [["--label-file", "labels"], ["--label-file=labels"]])
def test_opaque_label_files_are_rejected(option) -> None:
    with pytest.raises(ValueError, match="unsupported docker run options"):
        prepare_managed_command(["docker", "run", *option, "image"], (), "case-1", "a" * 32)


@pytest.mark.parametrize("option", [
    ["--label", "genmlu.run_id"], ["--label=genmlu.run_id"],
    ["-lgenmlu.run_id"], ["-l", "genmlu.run_id"],
])
def test_empty_run_label_cannot_override_controller_identity(option) -> None:
    with pytest.raises(ValueError, match="run_id label"):
        prepare_managed_command(["docker", "run", *option, "image"],
                                (), "case-1", "a" * 32)


def test_payload_labels_and_trailing_label_are_preserved() -> None:
    payload = ["python", "--label", "genmlu.lease_id=payload", "--label"]
    command = ["docker", "run", "--rm", "image", *payload]
    prepared, _ = prepare_managed_command(command, (), "case-1", "a" * 32)
    assert prepared[-len(payload):] == payload
    assert benchctl._docker_run_options(prepared).label == [
        "genmlu.lease_id=" + "a" * 32, "genmlu.run_id=case-1"]


def test_nested_launcher_receives_no_docker_argument_rewrite() -> None:
    command = ["python3", "entry.py", "--label", "application"]
    prepared, names = prepare_managed_command(command, ("worker",), "case-1", "a" * 32)
    assert prepared == command and names == ("worker",)


def test_container_cleanup_targets_only_verified_container_id() -> None:
    calls: list[tuple[str, ...]] = []
    running = True

    def runner(command: tuple[str, ...], timeout: int) -> str:
        nonlocal running
        del timeout
        calls.append(command)
        if command[:2] == ("docker", "inspect"):
            return json.dumps(
                [
                    {
                        "Id": "owned-id",
                        "Config": {"Labels": {"genmlu.run_id": "case-1"}},
                        "State": {"Pid": 123 if running else 0},
                    }
                ]
            )
        running = False
        return "owned-id\n"

    _stop_owned_container("case-container", "case-1", runner=runner)
    assert calls == [
        ("docker", "inspect", "case-container"),
        ("docker", "inspect", "case-container"),
        ("docker", "stop", "--time", "30", "owned-id"),
        ("docker", "inspect", "owned-id"),
    ]


def test_process_tree_includes_pgid_and_container_descendants() -> None:
    def runner(command: tuple[str, ...], timeout: int) -> str:
        del command, timeout
        return "10 1 10\n11 10 10\n90 1 90\n91 90 91\n92 91 92\n500 1 500\n"

    assert process_tree_pids({10, 90}, 10, runner=runner) == frozenset({10, 11, 90, 91, 92})


def test_two_registered_pids_are_owned_but_same_label_third_pid_is_foreign() -> None:
    containers = {
        "vllm-0": ("id-0", 101),
        "actor-1": ("id-1", 202),
    }

    def docker_runner(command: tuple[str, ...], timeout: int) -> str:
        del timeout
        name = command[-1]
        container_id, pid = containers[name]
        return json.dumps(
            [
                {
                    "Id": container_id,
                    "Config": {
                        "Labels": {
                            "genmlu.run_id": "case-1",
                            "genmlu.lease_id": "lease-1",
                        }
                    },
                    "State": {"Pid": pid},
                }
            ]
        )

    bindings: dict[str, ContainerIdentity] = {}
    current = refresh_owned_containers(
        ("vllm-0", "actor-1"),
        "case-1",
        "lease-1",
        bindings,
        require_lease_id=True,
        runner=docker_runner,
    )
    assert {identity.pid for identity in current.values()} == {101, 202}
    info = """
Card 0
  MLU Average : 10 %
  Physical Memory Usage
    Used : 4096 MiB
Card 1
  MLU Average : 10 %
  Physical Memory Usage
    Used : 4096 MiB
"""
    process_table = """
|  Card  MI  PID     Command Line                             MLU Memory Usage |
|  0     /   101     python vllm.py                             1024 MiB       |
|  1     /   202     python actor.py                            1024 MiB       |
|  0     /   303     python unregistered.py                     1024 MiB       |
"""

    def cnmon_runner(command: tuple[str, ...], timeout: int) -> str:
        del timeout
        return info if command == ("cnmon", "info") else process_table

    result = benchctl.sample_preflight(
        (0, 1),
        runner=cnmon_runner,
        owned_pids=frozenset({101, 202}),
        host="test",
    )
    assert len(result.foreign_accelerator_processes) == 1
    assert "pid=303" in result.foreign_accelerator_processes[0]


def test_replacement_is_not_stopped_and_other_owned_container_is_cleaned() -> None:
    bindings = {
        "vllm-0": ContainerIdentity("vllm-0", "original-0", 101),
        "actor-1": ContainerIdentity("actor-1", "original-1", 202),
    }
    running = {"vllm-0": ("replacement-0", 303), "actor-1": ("original-1", 202)}
    stopped: list[str] = []

    def runner(command: tuple[str, ...], timeout: int) -> str:
        del timeout
        if command[:2] == ("docker", "stop"):
            stopped.append(command[-1])
            running["actor-1"] = ("original-1", 0)
            return "original-1\n"
        reference = command[-1]
        name = "actor-1" if reference == "original-1" else reference
        container_id, pid = running[name]
        return json.dumps(
            [
                {
                    "Id": container_id,
                    "Config": {
                        "Labels": {
                            "genmlu.run_id": "case-1",
                            "genmlu.lease_id": "lease-1",
                        }
                    },
                    "State": {"Pid": pid},
                }
            ]
        )

    errors = cleanup_owned_containers(
        ("vllm-0", "actor-1"),
        "case-1",
        "lease-1",
        bindings,
        require_lease_id=True,
        runner=runner,
    )
    assert len(errors) == 1 and "identity changed" in errors[0]
    assert stopped == ["original-1"]


def test_runtime_limits_and_mlu_10001_policy(tmp_path: Path) -> None:
    args = run_args(tmp_path, timeout_seconds=28801)
    with pytest.raises(ValueError, match="timeout"):
        _validate_run_args(args, (0,))
    args = run_args(tmp_path, host_label="mlu-10001", cards="0,1", sample_interval=300)
    with pytest.raises(ValueError, match="all cards"):
        _validate_run_args(args, (0, 1))
    args = run_args(tmp_path, host_label="mlu-10001", cards="0,1,2,3,4,5,6,7", sample_interval=299)
    with pytest.raises(ValueError, match="300 seconds"):
        _validate_run_args(args, tuple(range(8)))


def test_resume_requires_exact_existing_checkpoint_in_command(tmp_path: Path) -> None:
    checkpoint = tmp_path / "checkpoint-20.pt"
    checkpoint.write_bytes(b"checkpoint")
    args = run_args(tmp_path, checkpoint=str(checkpoint))
    with pytest.raises(ValueError, match="must contain"):
        _resume_checkpoint(args, ["python3", "train.py"])
    assert _resume_checkpoint(args, ["python3", "train.py", "--resume", str(checkpoint)]) == str(checkpoint)


class ImmediateChild:
    pid = 4242
    returncode = 0

    def __init__(self) -> None:
        self.wait_timeouts: list[float | None] = []

    def wait(self, timeout: float | None = None) -> int:
        self.wait_timeouts.append(timeout)
        return self.returncode

    def poll(self) -> int:
        return self.returncode


def test_completed_child_returns_without_trailing_watch_sleep(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    child = ImmediateChild()
    ready = ready_result()
    monkeypatch.setattr(benchctl, "require_idle", lambda cards, interval: (ready, ready))
    monkeypatch.setattr(benchctl.subprocess, "Popen", lambda *args, **kwargs: child)
    monkeypatch.setattr(benchctl.time, "sleep", lambda seconds: pytest.fail(f"unexpected sleep {seconds}"))
    monkeypatch.setattr(benchctl, "_terminate_process_group", lambda process: None)

    assert command_run(run_args(tmp_path)) == 0
    assert len(child.wait_timeouts) == 1
    assert child.wait_timeouts[0] is not None and 0 < child.wait_timeouts[0] <= 60
    lease = json.loads(
        (tmp_path / "generative-mlu" / "mlu-10000" / "case-1" / "lease.json").read_text(encoding="utf-8")
    )
    assert lease["state"] == "completed"
    assert not (tmp_path / "generative-mlu" / "mlu-10000" / ".leases" / "cards-0.json").exists()


def test_multi_runner_sees_starting_lease_with_exact_registry(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    ready = ready_result()
    observed: dict[str, object] = {}

    def popen(*args: object, **kwargs: object) -> ImmediateChild:
        del args, kwargs
        active = (
            tmp_path
            / "generative-mlu"
            / "mlu-10000"
            / ".leases"
            / "cards-0-1.json"
        )
        observed.update(json.loads(active.read_text(encoding="utf-8")))
        return ImmediateChild()

    monkeypatch.setattr(benchctl, "require_idle", lambda cards, interval: (ready, ready))
    monkeypatch.setattr(benchctl, "inspect_owned_container", lambda name, run_id, **kwargs: None)
    monkeypatch.setattr(benchctl.subprocess, "Popen", popen)
    monkeypatch.setattr(benchctl, "_terminate_process_group", lambda process: None)
    monkeypatch.setattr(benchctl, "cleanup_owned_containers", lambda *args, **kwargs: ())

    assert command_run(
        run_args(
            tmp_path,
            cards="0,1",
            container_name=["qwen-vllm-0", "qwen-actor-1"],
        )
    ) == 0
    assert observed["state"] == "starting"
    assert observed["cards"] == [0, 1]
    assert observed["container_names"] == ["qwen-vllm-0", "qwen-actor-1"]
    assert observed["container_lease_label_required"] is True
    assert observed["lease_id"]
    assert observed["pid"] == os.getpid()


class WaitingChild:
    pid = 4343
    returncode = None

    def wait(self, timeout: float | None = None) -> int:
        raise subprocess.TimeoutExpired(["fake"], timeout)

    def poll(self) -> None:
        return None


def test_timeout_terminates_only_child_group_and_releases_lease(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    child = WaitingChild()
    ready = ready_result()
    times = iter((0.0, 0.0, 1.0))
    terminated: list[int] = []
    monkeypatch.setattr(benchctl, "require_idle", lambda cards, interval: (ready, ready))
    monkeypatch.setattr(benchctl.subprocess, "Popen", lambda *args, **kwargs: child)
    monkeypatch.setattr(benchctl.time, "monotonic", lambda: next(times))
    monkeypatch.setattr(benchctl, "_terminate_process_group", lambda process: terminated.append(process.pid))

    assert command_run(run_args(tmp_path, timeout_seconds=1)) == 124
    assert terminated and set(terminated) == {child.pid}
    run_lease = tmp_path / "generative-mlu" / "mlu-10000" / "case-1" / "lease.json"
    assert json.loads(run_lease.read_text(encoding="utf-8"))["state"] == "timed_out"
    assert not (tmp_path / "generative-mlu" / "mlu-10000" / ".leases" / "cards-0.json").exists()


def test_interrupt_during_preflight_releases_lease(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        benchctl,
        "require_idle",
        lambda cards, interval: (_ for _ in ()).throw(RunInterrupted(signal.SIGTERM)),
    )
    assert command_run(run_args(tmp_path)) == 128 + signal.SIGTERM
    assert not (tmp_path / "generative-mlu" / "mlu-10000" / ".leases" / "cards-0.json").exists()


def test_interrupt_record_failure_still_releases_original_lease(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        benchctl,
        "require_idle",
        lambda cards, interval: (_ for _ in ()).throw(RunInterrupted(signal.SIGTERM)),
    )
    monkeypatch.setattr(
        benchctl,
        "_update_run_files",
        lambda *args, **kwargs: (_ for _ in ()).throw(TimeoutError("AFS lock busy")),
    )

    with pytest.raises(RuntimeError, match="after lease release"):
        command_run(run_args(tmp_path))
    active = tmp_path / "generative-mlu" / "mlu-10000" / ".leases" / "cards-0.json"
    durable = tmp_path / "generative-mlu" / "mlu-10000" / "case-1" / "lease.json"
    assert not active.exists()
    payload = json.loads(durable.read_text(encoding="utf-8"))
    assert payload["state"] == "cleanup_failed"
    assert "AFS lock busy" in payload["cleanup_error"]
    assert payload["signal"] == signal.SIGTERM


def test_release_lock_timeout_retains_lease_and_records_cleanup_failure(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    child = ImmediateChild()
    ready = ready_result()
    monkeypatch.setattr(benchctl, "require_idle", lambda cards, interval: (ready, ready))
    monkeypatch.setattr(benchctl.subprocess, "Popen", lambda *args, **kwargs: child)
    monkeypatch.setattr(benchctl, "_terminate_process_group", lambda process: None)
    monkeypatch.setattr(
        benchctl,
        "release_lease",
        lambda handle: (_ for _ in ()).throw(TimeoutError("AFS lock busy")),
    )

    with pytest.raises(RuntimeError, match="lease retained"):
        command_run(run_args(tmp_path))
    active = tmp_path / "generative-mlu" / "mlu-10000" / ".leases" / "cards-0.json"
    durable = tmp_path / "generative-mlu" / "mlu-10000" / "case-1" / "lease.json"
    assert active.is_file()
    payload = json.loads(durable.read_text(encoding="utf-8"))
    assert payload["state"] == "cleanup_failed"
    assert "lease release: TimeoutError: AFS lock busy" in payload["cleanup_error"]


def test_existing_run_directory_is_never_modified(tmp_path: Path) -> None:
    run_dir = tmp_path / "generative-mlu" / "mlu-10000" / "case-1"
    run_dir.mkdir(parents=True)
    evidence = run_dir / "lease.json"
    evidence.write_text('{"state": "completed", "evidence": "keep"}\n', encoding="utf-8")

    with pytest.raises(FileExistsError):
        command_run(run_args(tmp_path))
    assert evidence.read_text(encoding="utf-8") == '{"state": "completed", "evidence": "keep"}\n'
    assert not (tmp_path / "generative-mlu" / "mlu-10000" / ".leases" / "cards-0.json").exists()


def test_any_preexisting_multi_container_rejects_all_without_cleanup(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    stopped: list[str] = []
    inspected: list[str] = []

    def inspect(name: str, run_id: str, **kwargs: object) -> ContainerIdentity | None:
        del run_id, kwargs
        inspected.append(name)
        if name == "actor-1":
            return ContainerIdentity(name, "preexisting", 777)
        return None

    monkeypatch.setattr(
        benchctl,
        "inspect_owned_container",
        inspect,
    )
    monkeypatch.setattr(
        benchctl,
        "cleanup_owned_containers",
        lambda *args, **kwargs: stopped.append("called"),
    )

    with pytest.raises(RuntimeError, match="already exists before launch"):
        command_run(run_args(tmp_path, container_name=["vllm-0", "actor-1"]))
    assert inspected == ["vllm-0", "actor-1"]
    assert stopped == []


def test_cleanup_failure_overrides_success_and_retains_blocking_lease(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    child = ImmediateChild()
    ready = ready_result()
    monkeypatch.setattr(benchctl, "require_idle", lambda cards, interval: (ready, ready))
    monkeypatch.setattr(benchctl.subprocess, "Popen", lambda *args, **kwargs: child)
    monkeypatch.setattr(benchctl, "inspect_owned_container", lambda name, run_id, **kwargs: None)
    monkeypatch.setattr(benchctl, "_terminate_process_group", lambda process: None)
    monkeypatch.setattr(
        benchctl,
        "cleanup_owned_containers",
        lambda *args, **kwargs: ("case-container: still running",),
    )

    with pytest.raises(RuntimeError, match="lease retained"):
        command_run(run_args(tmp_path, container_name="case-container"))
    active = tmp_path / "generative-mlu" / "mlu-10000" / ".leases" / "cards-0.json"
    durable = tmp_path / "generative-mlu" / "mlu-10000" / "case-1" / "lease.json"
    assert json.loads(active.read_text(encoding="utf-8"))["state"] == "cleanup_failed"
    durable_payload = json.loads(durable.read_text(encoding="utf-8"))
    assert durable_payload["state"] == "cleanup_failed"
    assert durable_payload["containers"] == [
        {
            "name": "case-container",
            "state": "cleanup_failed",
            "cleanup_error": "still running",
        }
    ]


@pytest.mark.skipif(os.name == "nt", reason="requires POSIX process groups")
def test_terminate_group_cleans_grandchild_after_parent_exits() -> None:
    child = subprocess.Popen(
        ["sh", "-c", "trap '' TERM; sleep 30 & exit 0"],
        start_new_session=True,
    )
    child.wait(timeout=5)
    time.sleep(0.05)
    os.killpg(child.pid, 0)
    benchctl._terminate_process_group(child, grace_seconds=0.05)
    assert benchctl._live_process_group_pids(child.pid) == ()


@pytest.mark.parametrize("gone_error", [FileNotFoundError, ProcessLookupError])
def test_group_scan_ignores_process_disappearing_during_stat_read(tmp_path, monkeypatch, gone_error):
    proc = tmp_path / "proc"
    proc.mkdir()
    for pid, state, group in [(101, "S", 500), (102, "Z", 500), (103, "S", 600), (104, "S", 500)]:
        entry = proc / str(pid)
        entry.mkdir()
        (entry / "stat").write_text(f"{pid} (worker name) {state} 1 {group} 0", encoding="utf-8")
    original_read = Path.read_text

    def read_stat(path, *args, **kwargs):
        if path == proc / "104" / "stat":
            raise gone_error("process exited after enumeration")
        return original_read(path, *args, **kwargs)

    monkeypatch.setattr(benchctl, "Path", lambda value: proc if value == "/proc" else Path(value))
    monkeypatch.setattr(Path, "read_text", read_stat)
    assert benchctl._live_process_group_pids(500) == (101,)


def test_group_scan_propagates_unexpected_io_error(tmp_path, monkeypatch):
    proc = tmp_path / "proc"
    (proc / "101").mkdir(parents=True)

    def read_stat(path, *args, **kwargs):
        raise OSError("unexpected proc read failure")

    monkeypatch.setattr(benchctl, "Path", lambda value: proc if value == "/proc" else Path(value))
    monkeypatch.setattr(Path, "read_text", read_stat)
    with pytest.raises(OSError, match="unexpected proc read failure"):
        benchctl._live_process_group_pids(500)
