from __future__ import annotations

from contextlib import nullcontext
import copy
from pathlib import Path
import struct
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

from genmlu import sdxl_rollout_graph as graph_module
from genmlu.backends import sdxl_ddpo as backend


class FakeDevice:
    def __init__(self, kind: str) -> None:
        self.type = kind

    def __str__(self) -> str:
        return self.type + ":0" if self.type != "cpu" else "cpu"


class FakeStorage:
    def __init__(self, pointer: int) -> None:
        self.pointer = pointer

    def data_ptr(self) -> int:
        return self.pointer


class FakeTensor:
    next_pointer = 100

    def __init__(
        self,
        values=(0,),
        *,
        shape=None,
        stride=None,
        dtype="torch.bfloat16",
        device="mlu",
        requires_grad=False,
        owner=None,
    ) -> None:
        self._values = list(values)
        self.shape = tuple(shape if shape is not None else (len(self._values),))
        self._stride = tuple(stride if stride is not None else ((1,) if self.shape else ()))
        self.dtype = dtype
        self.device = FakeDevice(device)
        self.layout = "torch.strided"
        self.requires_grad = requires_grad
        self.ndim = len(self.shape)
        self._version = 0
        self.owner = owner
        self.pointer = owner.pointer if owner is not None else FakeTensor.next_pointer
        if owner is None:
            FakeTensor.next_pointer += 1

    @property
    def values(self):
        if self.owner is not None:
            return self.owner.values * (self.shape[0] if self.shape else 1)
        return list(self._values)

    def stride(self):
        return self._stride

    def clone(self):
        return FakeTensor(
            self.values,
            shape=self.shape,
            stride=self._stride,
            dtype=self.dtype,
            device=self.device.type,
            requires_grad=self.requires_grad,
        )

    def detach(self):
        return self

    def cpu(self):
        return FakeTensor(
            self.values,
            shape=self.shape,
            stride=self._stride,
            dtype=self.dtype,
            device="cpu",
            requires_grad=self.requires_grad,
        )

    def contiguous(self):
        return self

    def reshape(self, *_shape):
        return self

    def view(self, dtype):
        formats = {
            "torch.bfloat16": "f",
            "torch.float32": "f",
            "torch.int64": "q",
            "torch.uint8": "B",
        }
        payload = b"".join(struct.pack("<" + formats[self.dtype], item) for item in self.values)
        return FakeTensor(payload, dtype=dtype, device=self.device.type)

    def numpy(self):
        return bytes(self.values)

    def expand_as(self, source):
        return FakeTensor(
            shape=source.shape,
            stride=source.stride(),
            dtype=self.dtype,
            device=self.device.type,
            requires_grad=self.requires_grad,
            owner=self,
        )

    def copy_(self, source):
        self._values = list(source.values)
        self._version += 1
        return self

    def __getitem__(self, index):
        return FakeTensor(
            [self.values[index]],
            shape=(),
            stride=(),
            dtype=self.dtype,
            device=self.device.type,
            requires_grad=self.requires_grad,
        )

    def data_ptr(self):
        return self.pointer

    def untyped_storage(self):
        return FakeStorage(self.pointer)

    def storage_offset(self):
        return 0


class FakeModule:
    def __init__(self, *, training=False, active=(), dropout_probability=0.0) -> None:
        self.training = training
        self.active_adapters = list(active)
        self.merged = False
        self.disable_adapters = False
        self.processor = None
        self.p = dropout_probability
        self._forward_pre_hooks = {}
        self._forward_hooks = {}
        self._compiled_call_impl = None

    def forward(self, *_args, **_kwargs):
        return None

    def _call_impl(self, *_args, **_kwargs):
        return self.forward(*_args, **_kwargs)


class FakeDropout(FakeModule):
    pass


class FakeLoraModule(FakeModule):
    def __init__(self) -> None:
        super().__init__(training=False, active=["default"])
        self.lora_A = object()
        self.scaling = {"default": 1.0}
        self.r = {"default": 4}
        self.lora_alpha = {"default": 4}
        self.use_dora = {"default": False}


class FakeUnet(FakeModule):
    def __init__(self, *, mutate_value=False, frozen_value=2, mutation=99) -> None:
        super().__init__(training=False, active=["default"])
        self.disable_adapters = lambda: False
        self.lora = FakeTensor([1], requires_grad=True)
        self.frozen = FakeTensor([frozen_value], dtype="torch.float32")
        self.buffer = FakeTensor([3])
        self.lora_layer = FakeLoraModule()
        self.dropout = FakeDropout(training=False, dropout_probability=0.1)
        self.mutate_value = mutate_value
        self.mutation = mutation
        self.calls = 0

    def named_parameters(self):
        return [("block.lora_A.weight", self.lora), ("block.weight", self.frozen)]

    def named_buffers(self):
        return [("position", self.buffer)]

    def named_modules(self):
        return [("", self), ("lora", self.lora_layer), ("dropout", self.dropout)]

    def __call__(self, latent, timestep, **_kwargs):
        self.calls += 1
        if self.mutate_value:
            self.frozen._values = [self.mutation]
        return (FakeTensor([self.calls], shape=latent.shape, stride=latent.stride()),)


class FakeStream:
    def __init__(self) -> None:
        self.waited = []

    def wait_stream(self, stream) -> None:
        self.waited.append(stream)


class FakeGraph:
    def __init__(self) -> None:
        self.replays = 0

    def replay(self) -> None:
        self.replays += 1


class FakeMlu:
    def __init__(self) -> None:
        self.current = FakeStream()
        self.capture = None

    def get_rng_state(self):
        return FakeTensor([29], dtype="torch.uint8", device="cpu")

    def Stream(self):
        return FakeStream()

    def current_stream(self):
        return self.current

    def stream(self, _stream):
        return nullcontext()

    def synchronize(self):
        return None

    def MLUGraph(self):
        return FakeGraph()

    def graph(self, graph, **kwargs):
        self.capture = (graph, kwargs)
        return nullcontext()


class FakeTorch:
    bfloat16 = "torch.bfloat16"
    uint8 = "torch.uint8"

    def __init__(self) -> None:
        self.mlu = FakeMlu()
        self.nn = SimpleNamespace(
            modules=SimpleNamespace(
                module=SimpleNamespace(
                    _global_forward_pre_hooks={}, _global_forward_hooks={}
                )
            )
        )

    def get_rng_state(self):
        return FakeTensor([17], dtype="torch.uint8", device="cpu")

    def empty_strided(self, shape, stride, *, dtype, device):
        return FakeTensor(
            [0] * max(1, shape[0]), shape=shape, stride=stride, dtype=dtype, device=device.type
        )

    def equal(self, left, right):
        return left.values == right.values

    def no_grad(self):
        return nullcontext()

    def autocast(self, *args, **kwargs):
        return nullcontext()


def graph_values():
    return [
        FakeTensor([1, 2], shape=(2,), stride=(1,)),
        FakeTensor([9, 9], shape=(2,), stride=(0,), dtype="torch.int64"),
        FakeTensor([3, 4], shape=(2,), stride=(1,)),
        FakeTensor([5, 6], shape=(2,), stride=(1,)),
        FakeTensor([7, 8], shape=(2,), stride=(1,)),
    ]


class GraphRuntimeTests(unittest.TestCase):
    def test_one_shot_global_capture_and_replay_clone(self):
        torch, unet, values = FakeTorch(), FakeUnet(), graph_values()
        runtime = graph_module.SDXLRolloutGraph(torch)
        runtime.setup(unet, values, "a" * 64)
        runtime.begin_rollout(unet, "a" * 64)
        result = runtime(unet, values)

        self.assertEqual(4, unet.calls)
        self.assertEqual(1, runtime.graph.replays)
        self.assertIsNot(result, runtime.output)
        self.assertEqual("global", torch.mlu.capture[1]["capture_error_mode"])
        self.assertEqual((0,), tuple(runtime.inputs[1].value.stride()))
        self.assertEqual(1, runtime.replays)
        self.assertNotIn("input_observations", runtime.report())
        self.assertGreaterEqual(runtime.report()["value_validation_seconds"], 0.0)
        with self.assertRaisesRegex(RuntimeError, "one-shot"):
            runtime.setup(unet, values, "a" * 64)

    def test_missing_graph_api_is_rejected_only_when_runtime_is_constructed(self):
        torch = FakeTorch()
        torch.mlu.graph = None
        with self.assertRaisesRegex(RuntimeError, "torch.mlu.graph"):
            graph_module.SDXLRolloutGraph(torch)

    def test_stride_and_call_metadata_guards_abort_without_recapture(self):
        torch, unet, values = FakeTorch(), FakeUnet(), graph_values()
        runtime = graph_module.SDXLRolloutGraph(torch)
        runtime.setup(unet, values, "a" * 64)
        runtime.begin_rollout(unet, "a" * 64)
        changed = list(values)
        changed[0] = FakeTensor([1, 2], shape=(2,), stride=(2,))
        with self.assertRaisesRegex(RuntimeError, "input metadata changed"):
            runtime(unet, changed)
        self.assertEqual(0, runtime.graph.replays)
        with self.assertRaisesRegex(RuntimeError, "unsupported graph input stride"):
            graph_module._PersistentInput(
                torch, FakeTensor([1, 2, 3, 4], shape=(2, 2), stride=(2, 0))
            )

    def test_boundaries_allow_only_in_place_lora_updates(self):
        torch, unet, values = FakeTorch(), FakeUnet(), graph_values()
        runtime = graph_module.SDXLRolloutGraph(torch)
        runtime.setup(unet, values, "a" * 64)
        runtime.begin_rollout(unet, "a" * 64)
        unet.lora._version += 1
        runtime.begin_rollout(unet, "b" * 64)
        unet.lora._version += 1
        unet.frozen._version += 1
        with self.assertRaisesRegex(RuntimeError, "frozen UNet tensor changed"):
            runtime.begin_rollout(unet, "c" * 64)

    def test_lora_scaling_policy_and_boolean_state_are_guarded(self):
        torch, unet, values = FakeTorch(), FakeUnet(), graph_values()
        runtime = graph_module.SDXLRolloutGraph(torch)
        runtime.setup(unet, values, "a" * 64)
        self.assertIsNone(runtime.structure["modules"][""]["disable_adapters"])
        self.assertFalse(runtime.structure["modules"]["lora"]["disable_adapters"])
        runtime.begin_rollout(unet, "a" * 64)
        unet.lora._version += 1
        unet.lora_layer.scaling["default"] = 2.0
        with self.assertRaisesRegex(RuntimeError, "adapter policy changed"):
            runtime.begin_rollout(unet, "b" * 64)

    def test_setup_rejects_data_mutation_without_version_change(self):
        torch, unet, values = FakeTorch(), FakeUnet(mutate_value=True), graph_values()
        runtime = graph_module.SDXLRolloutGraph(torch)
        with self.assertRaisesRegex(RuntimeError, "setup modified UNet state"):
            runtime.setup(unet, values, "a" * 64)
        self.assertEqual(0, unet.frozen._version)

    def test_setup_byte_hash_rejects_signed_zero_mutation_without_version_change(self):
        torch = FakeTorch()
        unet = FakeUnet(mutate_value=True, frozen_value=0.0, mutation=-0.0)
        runtime = graph_module.SDXLRolloutGraph(torch)
        with self.assertRaisesRegex(RuntimeError, "setup modified UNet state"):
            runtime.setup(unet, graph_values(), "a" * 64)
        self.assertEqual(0, unet.frozen._version)

    def test_forward_and_call_implementation_replacement_are_rejected(self):
        for attribute in ("forward", "_call_impl", "_compiled_call_impl"):
            with self.subTest(attribute=attribute):
                torch, unet = FakeTorch(), FakeUnet()
                runtime = graph_module.SDXLRolloutGraph(torch)
                runtime.setup(unet, graph_values(), "a" * 64)
                setattr(unet.lora_layer, attribute, lambda *_args, **_kwargs: None)
                with self.assertRaisesRegex(RuntimeError, "topology"):
                    runtime.begin_rollout(unet, "a" * 64)

    def test_local_global_and_dispatch_hooks_are_rejected(self):
        cases = ("local", "global", "dispatch")
        for case in cases:
            with self.subTest(case=case):
                torch, unet = FakeTorch(), FakeUnet()
                if case == "local":
                    unet.lora_layer._forward_pre_hooks[1] = object()
                    message = "local forward hooks"
                elif case == "global":
                    torch.nn.modules.module._global_forward_hooks[1] = object()
                    message = "global forward hooks"
                else:
                    unet.lora_layer._hf_hook = object()
                    message = "dispatch/offload hooks"
                with self.assertRaisesRegex(RuntimeError, message):
                    graph_module.SDXLRolloutGraph(torch).setup(
                        unet, graph_values(), "a" * 64
                    )

    def test_training_dropout_is_rejected_without_mode_mutation(self):
        torch, unet, values = FakeTorch(), FakeUnet(), graph_values()
        unet.dropout.training = True
        runtime = graph_module.SDXLRolloutGraph(torch)
        with self.assertRaisesRegex(RuntimeError, "deterministic dropout"):
            runtime.setup(unet, values, "a" * 64)
        self.assertTrue(unet.dropout.training)


class Blob:
    def __mul__(self, _value):
        return self


class Timesteps(list):
    def detach(self):
        return self

    def clone(self):
        return Timesteps(self)


class RolloutTorch:
    bfloat16 = "torch.bfloat16"

    def __init__(self):
        self.seeds = []

    def manual_seed(self, seed):
        self.seeds.append(seed)

    def randn(self, *_args, **_kwargs):
        return Blob()

    def no_grad(self):
        return nullcontext()

    def stack(self, values, dim=0):
        return (tuple(values), dim)


class BackendIntegrationTests(unittest.TestCase):
    def test_graph_source_evidence_is_mode_scoped(self):
        peft_type = type("Layer", (), {"__module__": "peft.fake"})
        peft_layer = peft_type()
        peft_layer.lora_A = object()

        class Unet:
            attn_processors = {"main": object()}

            def named_modules(self):
                return [("lora", peft_layer)]

            def add_adapter(self):
                return None

        pipe = SimpleNamespace(unet=Unet())
        eager_torch = SimpleNamespace(
            __version__="2.12", version=SimpleNamespace(mlu="1.33"), mlu=object()
        )
        graph_torch = SimpleNamespace(
            __version__="2.12",
            version=SimpleNamespace(mlu="1.33"),
            mlu=SimpleNamespace(graph=lambda: None, MLUGraph=type("MLUGraph", (), {})),
        )
        source = lambda _value, label: label
        with mock.patch.object(backend, "_source_sha256", side_effect=source), mock.patch.object(
            backend.resume_checkpoint, "file_sha256", return_value="backend"
        ):
            eager = backend._dependency_evidence(pipe, object, object, eager_torch, False)
            graph = backend._dependency_evidence(pipe, object, object, graph_torch, True)
        self.assertNotIn("rollout_graph_module", eager["helpers"])
        self.assertEqual("SDXL rollout graph module", graph["helpers"]["rollout_graph_module"])
        self.assertEqual("SDXL rollout graph class", graph["helpers"]["rollout_graph_class"])
        self.assertNotIn("graph_context_source", eager["torch_mlu"])
        self.assertEqual("torch.mlu.graph", graph["torch_mlu"]["graph_context_source"])
        self.assertEqual("torch.mlu.MLUGraph", graph["torch_mlu"]["graph_class_source"])

    def test_graph_sdk_source_changes_checkpoint_identity(self):
        with tempfile.TemporaryDirectory() as temporary:
            weights = Path(temporary)
            (weights / "model.bin").write_bytes(b"weights")
            resolved = {
                "prompt": "p",
                "target_rgb": (0.1, 0.2, 0.3),
                "rollout_graph": True,
            }
            dependencies = {
                "helpers": {"backend": "a" * 64},
                "torch_mlu": {
                    "torch_version": "2.12",
                    "mlu_version": "1.33",
                    "graph_context_source": "b" * 64,
                    "graph_class_source": "c" * 64,
                },
            }
            first = backend._checkpoint_identity(weights, resolved, dependencies)
            changed = copy.deepcopy(dependencies)
            changed["torch_mlu"]["graph_context_source"] = "d" * 64
            second = backend._checkpoint_identity(weights, resolved, changed)
        self.assertNotEqual(first["runtime"], second["runtime"])
        self.assertNotEqual(first["dependencies"], second["dependencies"])

    def test_unidentifiable_graph_sdk_source_has_clear_failure(self):
        with self.assertRaisesRegex(
            RuntimeError, "cannot identify SDXL resume dependency source: torch.mlu.graph"
        ):
            backend._source_sha256(object(), "torch.mlu.graph")

    def test_sample_rollouts_uses_only_explicit_keyword_predictor(self):
        torch = RolloutTorch()
        scheduler = SimpleNamespace(timesteps=Timesteps(), init_noise_sigma=1)

        def set_timesteps(steps, device):
            scheduler.timesteps = Timesteps(range(steps))

        scheduler.set_timesteps = set_timesteps
        pipe = SimpleNamespace(
            scheduler=scheduler,
            unet=SimpleNamespace(config=SimpleNamespace(in_channels=4)),
            vae_scale_factor=8,
        )
        calls = []

        def predictor(pipe, latents, timestep, conditioning, guidance):
            calls.append((pipe, latents, timestep, conditioning, guidance))
            return Blob()

        with mock.patch.object(backend, "require_mlu", return_value=torch), mock.patch.object(
            backend, "_ddim_step_with_log_prob", side_effect=lambda *_a, **_k: (Blob(), Blob(), Blob(), True)
        ), mock.patch.object(backend, "_decode_images", return_value=Blob()), mock.patch.object(
            backend, "_predict_noise", side_effect=AssertionError("eager predictor used")
        ):
            backend._sample_rollouts(
                pipe, {}, 4, 256, 256, 2, 5.0, 1.0, 43, predict_noise=predictor
            )
        self.assertEqual(2, len(calls))
        self.assertIs(pipe, calls[0][0])

    def test_sample_rollouts_keeps_eager_predictor_positional(self):
        torch = RolloutTorch()
        scheduler = SimpleNamespace(timesteps=Timesteps(), init_noise_sigma=1)
        scheduler.set_timesteps = lambda steps, device: setattr(
            scheduler, "timesteps", Timesteps(range(steps))
        )
        pipe = SimpleNamespace(
            scheduler=scheduler,
            unet=SimpleNamespace(config=SimpleNamespace(in_channels=4)),
            vae_scale_factor=8,
        )
        calls = []

        def eager_predictor(*args):
            calls.append(args)
            return Blob()

        with mock.patch.object(backend, "require_mlu", return_value=torch), mock.patch.object(
            backend, "_ddim_step_with_log_prob", side_effect=lambda *_a, **_k: (Blob(), Blob(), Blob(), True)
        ), mock.patch.object(backend, "_decode_images", return_value=Blob()), mock.patch.object(
            backend, "_predict_noise", side_effect=eager_predictor
        ):
            backend._sample_rollouts(pipe, {}, 4, 256, 256, 2, 5.0, 1.0, 43)
        self.assertEqual(2, len(calls))
        self.assertTrue(all(len(call) == 5 for call in calls))

    def test_mode_is_strict_boolean_and_separates_checkpoint_identities(self):
        with tempfile.TemporaryDirectory() as temporary:
            weights = Path(temporary)
            (weights / "model.bin").write_bytes(b"weights")
            with self.assertRaisesRegex(ValueError, "must be a boolean"):
                backend.run_sdxl_ddpo(weights, {"rollout_graph": 1}, weights / "out")
            dependencies = {
                "helpers": {"backend": "a" * 64},
                "torch_mlu": {"torch_version": "2.12", "mlu_version": "1.33"},
            }
            resolved = {"prompt": "p", "target_rgb": (0.1, 0.2, 0.3), "rollout_graph": False}
            eager = backend._checkpoint_identity(weights, resolved, dependencies)
            graph = backend._checkpoint_identity(
                weights, {**resolved, "rollout_graph": True}, dependencies
            )
            legacy = backend._checkpoint_identity(
                weights, {key: value for key, value in resolved.items() if key != "rollout_graph"}, dependencies
            )
        self.assertNotEqual(eager["config"], graph["config"])
        self.assertEqual(eager["config"], legacy["config"])
        config = Path(backend.__file__).resolve().parents[3] / "configs" / "sdxl-rl.yaml"
        self.assertIn("rollout_graph: false", config.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
