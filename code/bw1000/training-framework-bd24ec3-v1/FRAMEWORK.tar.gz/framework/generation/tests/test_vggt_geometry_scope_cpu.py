from __future__ import annotations

import copy
import importlib.util
import math
import os
from pathlib import Path
import sys

import numpy as np
import pytest

torch = pytest.importorskip("torch")

from genmlu.backends import vggt_training as vggt


class TinyAggregator(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.projection = torch.nn.Linear(4, 6)
        self.norm = torch.nn.LayerNorm(6)
        self.mask_token = torch.nn.Parameter(torch.zeros(6), requires_grad=False)

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        return self.norm(self.projection(values)).tanh()


class TinyGeometryModel(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.aggregator = TinyAggregator()
        self.camera_head = torch.nn.Linear(6, 2)
        self.depth_head = torch.nn.Linear(6, 1)
        self.point_head = torch.nn.Linear(6, 3)
        self.track_head = None

    def forward(self, values: torch.Tensor) -> tuple[torch.Tensor, ...]:
        features = self.aggregator(values)
        return (
            self.camera_head(features),
            self.depth_head(features),
            self.point_head(features),
        )


def make_geometry(seed: int):
    torch.manual_seed(seed)
    model = TinyGeometryModel()
    module, state_key = vggt._vggt_bind_trainable_scope(
        torch, model, vggt.VGGT_GEOMETRY_SCOPE
    )
    parameters = [parameter for parameter in module.parameters() if parameter.requires_grad]
    optimizer = torch.optim.AdamW(parameters, lr=3e-3, weight_decay=0.01)
    vggt._vggt_assert_optimizer_binding(optimizer, parameters)
    return model, module, state_key, parameters, optimizer


def step(model, parameters, optimizer, values: torch.Tensor) -> dict[str, float]:
    optimizer.zero_grad(set_to_none=True)
    camera, depth, point = model(values)
    loss = camera.square().mean() + depth.square().mean() + point.square().mean()
    loss.backward()
    norms = {}
    for name in ("aggregator", "camera_head", "depth_head", "point_head"):
        selected = [
            parameter
            for parameter in getattr(model, name).parameters()
            if parameter.requires_grad
        ]
        norms[name] = vggt._vggt_gradient_norm_before_clip(selected, torch, name)
    torch.nn.utils.clip_grad_norm_(parameters, 1.0)
    optimizer.step()
    vggt._vggt_assert_optimizer_state_initialized(optimizer, parameters)
    return norms


def make_contract() -> dict:
    return vggt._vggt_contract(
        identity={key: "a" * 64 for key in vggt._VGGT_IDENTITY_FIELDS},
        seed=19,
        warmup_steps=0,
        max_steps=3,
        view_order=["seq-a:0,1", "seq-b:2,3"],
        device_ids=[],
    )


def make_raw_geometry() -> dict:
    frames, height, width = 2, 11, 11
    depths = [np.full((height, width), 2.0 + index, np.float32) for index in range(frames)]
    cam_points = []
    world_points = []
    for index, depth in enumerate(depths):
        points = np.stack((depth * 0.1, depth * 0.2, depth), axis=-1)
        cam_points.append(points.astype(np.float32))
        world_points.append((points + index).astype(np.float32))
    return {
        "images": [np.full((height, width, 3), 64 + index, np.uint8) for index in range(frames)],
        "depths": depths,
        "extrinsics": [
            np.concatenate((np.eye(3), np.zeros((3, 1))), axis=1).astype(np.float32)
            for _ in range(frames)
        ],
        "intrinsics": [np.eye(3, dtype=np.float32) for _ in range(frames)],
        "point_masks": [np.ones((height, width), dtype=np.bool_) for _ in range(frames)],
        "cam_points": cam_points,
        "world_points": world_points,
        "seq_name": "co3d-fixture",
        "ids": np.asarray([3, 7]),
    }


def test_geometry_batch_retains_official_targets_and_uses_normalizer() -> None:
    batch = vggt._tensor_batch(torch, make_raw_geometry(), include_geometry=True)
    original_world = batch["world_points"].clone()
    calls = 0

    def normalize(**kwargs):
        nonlocal calls
        calls += 1
        return (
            kwargs["extrinsics"].clone(),
            kwargs["cam_points"] / 2,
            kwargs["world_points"] / 2,
            kwargs["depths"] / 2,
        )

    normalized = vggt._vggt_normalize_geometry_batch(torch, batch, normalize)
    assert calls == 1
    assert torch.equal(normalized["world_points"], original_world / 2)
    assert normalized["point_masks"].dtype == torch.bool
    assert vggt.valid_depth_batch(normalized["point_masks"])


@pytest.mark.parametrize("missing", ["cam_points", "world_points"])
def test_geometry_batch_rejects_missing_loader_target(missing: str) -> None:
    raw = make_raw_geometry()
    raw.pop(missing)
    with pytest.raises(ValueError, match=missing):
        vggt._tensor_batch(torch, raw, include_geometry=True)


def test_geometry_batch_rejects_invalid_target_before_normalization() -> None:
    batch = vggt._tensor_batch(torch, make_raw_geometry(), include_geometry=True)
    batch["world_points"][0, 0, 0, 0, 0] = float("nan")
    with pytest.raises(ValueError, match="world_points must be finite"):
        vggt._vggt_normalize_geometry_batch(torch, batch, lambda **kwargs: kwargs)


def geometry_predictions() -> dict[str, object]:
    pose = torch.zeros((1, 2, 9))
    return {
        "pose_enc": pose.clone(),
        "pose_enc_list": [pose.clone(), pose.clone()],
        "depth": torch.ones((1, 2, 2, 2, 1), requires_grad=True),
        "depth_conf": torch.ones((1, 2, 2, 2)),
        "world_points": torch.ones((1, 2, 2, 2, 3)),
        "world_points_conf": torch.ones((1, 2, 2, 2)),
    }


class FixedOfficialLoss:
    def __init__(self, wrong_objective: bool = False) -> None:
        self.wrong_objective = wrong_objective

    def __call__(self, _predictions, _batch):
        anchor = _predictions["depth"].sum() * 0
        values = {
            "loss_camera": torch.tensor(2.0),
            "loss_T": torch.tensor(0.5),
            "loss_R": torch.tensor(0.5),
            "loss_FL": torch.tensor(0.5),
            "loss_conf_depth": torch.tensor(3.0),
            "loss_reg_depth": torch.tensor(4.0),
            "loss_grad_depth": torch.tensor(5.0),
            "loss_conf_point": torch.tensor(6.0),
            "loss_reg_point": torch.tensor(7.0),
            "loss_grad_point": torch.tensor(8.0),
        }
        values["objective"] = anchor + (0.0 if self.wrong_objective else 43.0)
        return values


class OfficialNumericLoss(FixedOfficialLoss):
    def __init__(self, name: str, value: object, objective: float = 43.0) -> None:
        super().__init__()
        self.name = name
        self.value = value
        self.objective = objective

    def __call__(self, predictions, batch):
        values = super().__call__(predictions, batch)
        if self.name == "objective":
            values["objective"] = self.value
        else:
            values[self.name] = self.value
            values["objective"] = predictions["depth"].sum() * 0 + self.objective
        return values


def test_geometry_loss_enforces_official_schema_and_weights() -> None:
    batch = {"images": torch.zeros((1, 2, 3, 2, 2))}
    objective, losses = vggt._vggt_geometry_loss(
        torch, FixedOfficialLoss(), geometry_predictions(), batch
    )
    assert objective.item() == 43.0
    assert objective.requires_grad
    assert set(losses) == {
        "loss_camera",
        "loss_T",
        "loss_R",
        "loss_FL",
        "loss_conf_depth",
        "loss_reg_depth",
        "loss_grad_depth",
        "loss_conf_point",
        "loss_reg_point",
        "loss_grad_point",
        "objective",
    }
    with pytest.raises(RuntimeError, match="objective weights differ"):
        vggt._vggt_geometry_loss(
            torch, FixedOfficialLoss(wrong_objective=True), geometry_predictions(), batch
        )


@pytest.mark.parametrize(
    ("name", "value", "objective"),
    [
        ("loss_grad_depth", 0, 38.0),
        ("loss_grad_point", 0.0, 35.0),
    ],
)
def test_geometry_loss_accepts_only_official_numeric_gradient_zero(
    name: str, value: object, objective: float
) -> None:
    predictions = geometry_predictions()
    loss, components = vggt._vggt_geometry_loss(
        torch,
        OfficialNumericLoss(name, value, objective),
        predictions,
        {"images": torch.zeros((1, 2, 3, 2, 2))},
    )
    assert components[name] == 0.0
    assert type(components[name]) is float
    assert vggt._vggt_loss_log_value(torch, components[name]) == 0.0
    assert vggt._vggt_loss_log_value(torch, torch.tensor(1.25)) == 1.25
    loss.backward()
    assert predictions["depth"].grad is not None
    assert bool(torch.isfinite(predictions["depth"].grad).all())


@pytest.mark.parametrize(
    ("name", "value"),
    [
        ("loss_grad_point", 1),
        ("loss_grad_depth", -2.0),
        ("loss_grad_point", float("nan")),
        ("loss_grad_point", float("inf")),
        ("loss_grad_point", True),
        ("loss_reg_point", 0),
        ("loss_camera", 0.0),
        ("objective", 0),
    ],
)
def test_geometry_loss_rejects_other_python_scalars(name: str, value: object) -> None:
    with pytest.raises(RuntimeError, match=f"invalid: {name}"):
        vggt._vggt_geometry_loss(
            torch,
            OfficialNumericLoss(name, value),
            geometry_predictions(),
            {"images": torch.zeros((1, 2, 3, 2, 2))},
        )


def test_geometry_loss_requires_autograd_objective() -> None:
    class DetachedObjective(FixedOfficialLoss):
        def __call__(self, predictions, batch):
            values = super().__call__(predictions, batch)
            values["objective"] = values["objective"].detach()
            return values

    with pytest.raises(RuntimeError, match="must require autograd"):
        vggt._vggt_geometry_loss(
            torch,
            DetachedObjective(),
            geometry_predictions(),
            {"images": torch.zeros((1, 2, 3, 2, 2))},
        )


def test_geometry_loss_rejects_missing_or_nonfinite_prediction() -> None:
    batch = {"images": torch.zeros((1, 2, 3, 2, 2))}
    missing = geometry_predictions()
    missing.pop("world_points")
    with pytest.raises(RuntimeError, match="incomplete"):
        vggt._vggt_geometry_loss(torch, FixedOfficialLoss(), missing, batch)
    nonfinite = geometry_predictions()
    with torch.no_grad():
        nonfinite["depth"][0, 0, 0, 0, 0] = float("inf")
    with pytest.raises(RuntimeError, match="not finite"):
        vggt._vggt_geometry_loss(torch, FixedOfficialLoss(), nonfinite, batch)


def test_official_sparse_mask_numeric_zero_objective_backward(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source_value = os.environ.get("VGGT_OFFICIAL_TRAINING_SOURCE_ROOT")
    if not source_value:
        pytest.skip("set VGGT_OFFICIAL_TRAINING_SOURCE_ROOT to the frozen training source")
    source_root = Path(source_value).resolve()
    source_evidence = vggt._vggt_training_source_evidence(source_root)
    loss_path = source_root / "loss.py"
    assert source_evidence["loss.py"] == vggt.resume_common.file_sha256(loss_path)
    monkeypatch.syspath_prepend(str(source_root.parent))
    monkeypatch.syspath_prepend(str(source_root))
    module_name = "vggt_official_sparse_loss"
    spec = importlib.util.spec_from_file_location(module_name, loss_path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    monkeypatch.setitem(sys.modules, module_name, module)
    spec.loader.exec_module(module)
    vggt._vggt_require_source_origin(module.MultitaskLoss, loss_path)

    batch_size, frames, height, width = 1, 2, 224, 224
    mask = torch.zeros((batch_size, frames, height, width), dtype=torch.bool)
    mask[:, :, ::16, ::16] = True
    assert int(mask[0, 0].sum()) == 196
    assert vggt.valid_depth_batch(mask)
    depth = torch.full((batch_size, frames, height, width), 2.0)
    yy, xx = torch.meshgrid(
        torch.arange(height, dtype=torch.float32),
        torch.arange(width, dtype=torch.float32),
        indexing="ij",
    )
    points = torch.stack((xx / width, yy / height, torch.ones_like(xx) * 2), dim=-1)
    points = points.expand(batch_size, frames, -1, -1, -1).clone()
    extrinsics = torch.eye(4, dtype=torch.float32)[:3].expand(
        batch_size, frames, -1, -1
    ).clone()
    intrinsics = torch.eye(3, dtype=torch.float32).expand(
        batch_size, frames, -1, -1
    ).clone()
    images = torch.zeros((batch_size, frames, 3, height, width))
    target_pose = module.extri_intri_to_pose_encoding(
        extrinsics, intrinsics, (height, width)
    )
    pose_stages = [
        (target_pose.detach() + offset).requires_grad_() for offset in (0.1, 0.05)
    ]
    predictions = {
        "pose_enc": pose_stages[-1],
        "pose_enc_list": pose_stages,
        "depth": (depth[..., None] + 0.2).requires_grad_(),
        "depth_conf": torch.full(
            (batch_size, frames, height, width), 1.1, requires_grad=True
        ),
        "world_points": (points + 0.1).requires_grad_(),
        "world_points_conf": torch.full(
            (batch_size, frames, height, width), 1.1, requires_grad=True
        ),
    }
    batch = {
        "images": images,
        "depths": depth,
        "extrinsics": extrinsics,
        "intrinsics": intrinsics,
        "point_masks": mask,
        "world_points": points,
    }
    loss_module = module.MultitaskLoss(**vggt.VGGT_GEOMETRY_LOSS_CONFIG)
    objective, components = vggt._vggt_geometry_loss(
        torch, loss_module, predictions, batch
    )
    assert components["loss_grad_point"] == 0.0
    assert type(components["loss_grad_point"]) is float
    assert objective.requires_grad and bool(torch.isfinite(objective))
    objective.backward()
    for value in (
        *pose_stages,
        predictions["depth"],
        predictions["depth_conf"],
        predictions["world_points"],
        predictions["world_points_conf"],
    ):
        assert value.grad is not None and bool(torch.isfinite(value.grad).all())


def test_geometry_backward_updates_four_modules_and_preserves_native_freeze() -> None:
    model, module, state_key, parameters, optimizer = make_geometry(3)
    before = {
        name: vggt._module_sha(getattr(model, name))
        for name in ("aggregator", "camera_head", "depth_head", "point_head")
    }
    norms = step(model, parameters, optimizer, torch.ones((4, 4)))
    assert state_key == "camera_depth_point_backbone"
    assert set(module) == {"aggregator", "camera_head", "depth_head", "point_head"}
    assert model.aggregator.mask_token.requires_grad is False
    assert id(model.aggregator.mask_token) not in {id(parameter) for parameter in parameters}
    assert all(math.isfinite(value) and value > 0 for value in norms.values())
    for name, digest in before.items():
        assert vggt._module_sha(getattr(model, name)) != digest


def test_geometry_checkpoint_restores_full_range_and_next_update() -> None:
    values = torch.arange(16, dtype=torch.float32).reshape(4, 4) / 8
    contract = make_contract()
    source, source_module, state_key, source_parameters, source_optimizer = make_geometry(5)
    step(source, source_parameters, source_optimizer, values)
    payload = vggt._vggt_make_checkpoint(
        contract=contract,
        global_optimizer_step=1,
        module=source_module,
        optimizer=source_optimizer,
        torch=torch,
        state_key=state_key,
    )
    saved = payload["state"][state_key]
    for prefix in ("aggregator.", "camera_head.", "depth_head.", "point_head."):
        assert any(name.startswith(prefix) for name in saved)

    step(source, source_parameters, source_optimizer, values)
    continuous = vggt.resume_common.tree_sha256(
        {
            "module": source_module.state_dict(),
            "optimizer": vggt.resume_common.cpu_tree(source_optimizer.state_dict()),
        }
    )
    resumed, resumed_module, resumed_key, resumed_parameters, resumed_optimizer = make_geometry(99)
    checked = vggt._vggt_restore_checkpoint(
        payload,
        contract,
        resumed_module,
        resumed_optimizer,
        torch,
        state_key=resumed_key,
    )
    vggt._vggt_assert_restored_boundary(
        payload,
        contract,
        resumed_module,
        resumed_optimizer,
        torch,
        state_key=resumed_key,
    )
    assert checked["next"] == {"global_optimizer_step": 2, "batch_cursor": 1}
    step(resumed, resumed_parameters, resumed_optimizer, values)
    restored = vggt.resume_common.tree_sha256(
        {
            "module": resumed_module.state_dict(),
            "optimizer": vggt.resume_common.cpu_tree(resumed_optimizer.state_dict()),
        }
    )
    assert restored == continuous


def test_geometry_checkpoint_rejects_missing_head_state_after_resigning() -> None:
    contract = make_contract()
    model, module, state_key, parameters, optimizer = make_geometry(7)
    step(model, parameters, optimizer, torch.ones((4, 4)))
    payload = vggt._vggt_make_checkpoint(
        contract=contract,
        global_optimizer_step=1,
        module=module,
        optimizer=optimizer,
        torch=torch,
        state_key=state_key,
    )
    changed = copy.deepcopy(payload)
    point_name = next(
        name
        for name in changed["state"][state_key]
        if name.startswith("point_head.")
    )
    changed["state"][state_key].pop(point_name)
    unsigned = {key: value for key, value in changed.items() if key != "integrity_sha256"}
    changed["integrity_sha256"] = vggt.resume_common.tree_sha256(unsigned)
    with pytest.raises(vggt.VGGTCheckpointValidationError, match="state keys mismatch"):
        vggt._vggt_validate_checkpoint(
            changed,
            contract,
            module,
            optimizer,
            torch,
            native_rng=False,
            state_key=state_key,
        )


def test_training_source_evidence_is_complete_and_content_bound(tmp_path) -> None:
    for relative in vggt.VGGT_GEOMETRY_TRAINING_SOURCES:
        path = tmp_path / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(relative + "\n", encoding="utf-8")
    evidence = vggt._vggt_training_source_evidence(tmp_path)
    assert set(evidence) == set(vggt.VGGT_GEOMETRY_TRAINING_SOURCES)
    first = vggt.VGGT_GEOMETRY_TRAINING_SOURCES[0]
    (tmp_path / first).write_text("changed\n", encoding="utf-8")
    assert vggt._vggt_training_source_evidence(tmp_path)[first] != evidence[first]


def test_geometry_resume_identity_binds_components_and_training_sources(
    monkeypatch, tmp_path
) -> None:
    monkeypatch.setattr(vggt, "sha256_path", lambda _path: "a" * 64)
    monkeypatch.setattr(vggt, "_vggt_source_evidence", lambda *_args: {"source": "b" * 64})
    monkeypatch.setattr(vggt, "_vggt_batch_content_sha256", lambda _batches: "c" * 64)
    model, module, _state_key, _parameters, optimizer = make_geometry(11)
    components = {
        name: vggt._module_sha(getattr(model, name))
        for name in ("aggregator", "camera_head", "depth_head", "point_head")
    }
    sources = {name: "d" * 64 for name in vggt.VGGT_GEOMETRY_TRAINING_SOURCES}
    identity, evidence = vggt._vggt_resume_identity(
        weights=tmp_path,
        config={"training_scope": vggt.VGGT_GEOMETRY_SCOPE},
        dataset_root=tmp_path / "data",
        annotation_root=tmp_path / "annotations",
        model=model,
        optimizer=optimizer,
        batches=[],
        cache_enabled=False,
        training_scope=vggt.VGGT_GEOMETRY_SCOPE,
        trainable_module=module,
        aggregator_sha256=components["aggregator"],
        component_sha256=components,
        training_source_evidence=sources,
    )
    assert set(identity) == vggt._VGGT_IDENTITY_FIELDS
    assert evidence["sources"]["official_training"] == sources
    assert evidence["frozen_model"]["initial_component_sha256"] == components
    with pytest.raises(ValueError, match="official training sources"):
        vggt._vggt_resume_identity(
            weights=tmp_path,
            config={"training_scope": vggt.VGGT_GEOMETRY_SCOPE},
            dataset_root=tmp_path / "data",
            annotation_root=tmp_path / "annotations",
            model=model,
            optimizer=optimizer,
            batches=[],
            cache_enabled=False,
            training_scope=vggt.VGGT_GEOMETRY_SCOPE,
            trainable_module=module,
            aggregator_sha256=components["aggregator"],
            component_sha256=components,
        )


def test_geometry_forward_witness_requires_every_enabled_module_on_mlu() -> None:
    modules = {"aggregator", "camera_head", "depth_head", "point_head"}
    observed = {name: ["mlu:0"] for name in modules}
    assert vggt._vggt_forward_modules_on_device(observed, modules, "mlu")
    missing = dict(observed)
    missing.pop("point_head")
    assert not vggt._vggt_forward_modules_on_device(missing, modules, "mlu")
    mixed = dict(observed)
    mixed["depth_head"] = ["cpu"]
    assert not vggt._vggt_forward_modules_on_device(mixed, modules, "mlu")
