from __future__ import annotations

from pathlib import Path

import pytest

from genmlu.backends.hunyuanvideo_training import _build_training_result
from genmlu.recovery_validation import RecoveryValidation


def _inputs(tmp_path: Path) -> dict[str, object]:
    step_log = tmp_path / "steps.ndjson"
    summary = tmp_path / "summary.json"
    step_log.write_text('{"global_step": 1}\n', encoding="utf-8")
    summary.write_text('{"checks": {}}\n', encoding="utf-8")
    return {
        "artifacts": [],
        "step_log": step_log,
        "summary_path": summary,
        "metrics": {"steps": 20},
        "stage_timings": {"training_seconds": 1.0},
        "checks": {"checkpoint_resume": None},
    }


def test_training_result_keeps_disabled_recovery_metric_null(tmp_path: Path) -> None:
    recovery = RecoveryValidation.not_run(
        ("resume_loss_error", "continuous_adapter_sha", "resumed_adapter_sha")
    )
    result = _build_training_result(**_inputs(tmp_path), recovery=recovery)
    assert result["metrics"]["resume_loss_error"] is None
    assert result["checks"]["checkpoint_resume"] is None


def test_training_result_uses_enabled_recovery_error_without_defaulting(tmp_path: Path) -> None:
    recovery = RecoveryValidation(
        True,
        {
            "resume_loss_error": 0.125,
            "continuous_adapter_sha": "continuous",
            "resumed_adapter_sha": "resumed",
        },
    )
    result = _build_training_result(**_inputs(tmp_path), recovery=recovery)
    assert result["metrics"]["resume_loss_error"] == 0.125


def test_training_result_rejects_enabled_recovery_without_declared_loss_metric(tmp_path: Path) -> None:
    recovery = RecoveryValidation(True, {"continuous_adapter_sha": "continuous"})
    with pytest.raises(KeyError, match="resume_loss_error"):
        _build_training_result(**_inputs(tmp_path), recovery=recovery)
