import pytest
import torch
from torch.distributed.algorithms._checkpoint.checkpoint_wrapper import checkpoint_wrapper

from genmlu.hy_resume_checkpoint import CheckpointValidationError, validate_anchor


def test_anchor_accepts_real_checkpoint_wrapper_without_changing_live_names():
    model = torch.nn.Sequential(checkpoint_wrapper(torch.nn.Linear(2, 2)))
    live = dict(model.named_parameters())
    assert any("._checkpoint_wrapped_module" in name for name in live)
    anchor = {
        name.replace("._checkpoint_wrapped_module", ""): value.detach().cpu().clone()
        for name, value in live.items()
    }
    validate_anchor(anchor, live)
    assert set(live) == set(dict(model.named_parameters()))


def test_anchor_rejects_missing_or_colliding_names():
    value = torch.ones(2)
    with pytest.raises(CheckpointValidationError, match="keys mismatch"):
        validate_anchor({}, {"block.weight": value})
    with pytest.raises(CheckpointValidationError, match="collide"):
        validate_anchor({"block.weight": value}, {
            "block.weight": value, "block._checkpoint_wrapped_module.weight": value,
        })


def test_anchor_still_rejects_wrong_shape_and_nonfinite_values():
    live = {"block._checkpoint_wrapped_module.weight": torch.ones(2)}
    with pytest.raises(CheckpointValidationError, match="shape"):
        validate_anchor({"block.weight": torch.ones(3)}, live)
    with pytest.raises(CheckpointValidationError, match="non-finite"):
        validate_anchor({"block.weight": torch.tensor([float("nan"), 1.0])}, live)
