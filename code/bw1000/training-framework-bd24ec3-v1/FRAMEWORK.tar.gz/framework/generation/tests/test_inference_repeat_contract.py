from __future__ import annotations

import unittest

import numpy as np

from genmlu.backends import hunyuanvideo_inference, hy_motion_inference, sf3d_reconstruction


class InferenceRepeatContractTest(unittest.TestCase):
    def test_hunyuan_and_hy_only_measure_repeated_nonbenchmark_runs(self) -> None:
        for backend in (hunyuanvideo_inference, hy_motion_inference):
            self.assertIsNone(backend._repeat_determinism(["same"], False))
            self.assertIsNone(backend._repeat_determinism(["same", "same"], True))
            self.assertTrue(backend._repeat_determinism(["same", "same"], False))
            self.assertFalse(backend._repeat_determinism(["one", "two"], False))
            self.assertTrue(backend._checks_pass({"artifact": True, "deterministic": None}))
            self.assertFalse(backend._checks_pass({"artifact": True, "deterministic": False}))
            self.assertFalse(backend._checks_pass({"artifact": 0}))
            self.assertFalse(backend._checks_pass({"artifact": np.bool_(False)}))

    def test_sf3d_only_compares_same_input_repeats(self) -> None:
        semantic = [
            {"vertices": "vertices", "faces": "faces", "uv": "uv"},
            {"vertices": "vertices", "faces": "faces", "uv": "uv"},
        ]
        self.assertIsNone(
            sf3d_reconstruction._repeat_determinism(
                ["input-a"], ["scene"], ["mesh"], semantic[:1], True, False
            )
        )
        self.assertIsNone(
            sf3d_reconstruction._repeat_determinism(
                ["input-a", "input-b"], ["scene", "scene"], ["mesh", "mesh"], semantic, True, False
            )
        )
        self.assertIsNone(
            sf3d_reconstruction._repeat_determinism(
                ["input-a", "input-a"], ["scene", "scene"], ["mesh", "mesh"], semantic, True, True
            )
        )
        self.assertTrue(
            sf3d_reconstruction._repeat_determinism(
                ["input-a", "input-a"], ["scene", "scene"], ["mesh", "mesh"], semantic, True, False
            )
        )
        self.assertFalse(
            sf3d_reconstruction._repeat_determinism(
                ["input-a", "input-a"], ["scene", "changed"], ["mesh", "mesh"], semantic, True, False
            )
        )
        self.assertTrue(sf3d_reconstruction._checks_pass({"artifact": True, "deterministic": None}))
        self.assertFalse(sf3d_reconstruction._checks_pass({"artifact": True, "deterministic": False}))

    def test_sf3d_single_repeat_status_is_unmeasured(self) -> None:
        deterministic = sf3d_reconstruction._repeat_determinism(
            ["input-a"],
            ["scene"],
            ["mesh"],
            [{"vertices": "vertices", "faces": "faces", "uv": "uv"}],
            True,
            False,
        )
        self.assertIsNone(deterministic)
        self.assertTrue(
            sf3d_reconstruction._checks_pass(
                {"valid_artifact": True, "deterministic_repeat": deterministic}
            )
        )


if __name__ == "__main__":
    unittest.main()
