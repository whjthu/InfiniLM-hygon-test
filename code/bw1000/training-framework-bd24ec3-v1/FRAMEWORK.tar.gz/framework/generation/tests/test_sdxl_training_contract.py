import hashlib
import json
from pathlib import Path

import pytest
import torch
from safetensors.torch import save_file

from genmlu.backends import sdxl_training


def _training_layout(tmp_path: Path) -> tuple[Path, Path, Path]:
    weights = tmp_path / "weights"
    dataset = tmp_path / "images"
    source_root = tmp_path / "diffusers"
    script = source_root / "examples" / "text_to_image" / "train_text_to_image_lora_sdxl.py"
    weights.mkdir()
    dataset.mkdir()
    script.parent.mkdir(parents=True)
    script.write_text("# fixture trainer\n", encoding="utf-8")
    return weights, dataset, source_root


def _write_metrics(command: list[str], steps: range) -> None:
    metrics_path = Path(command[command.index("--genmlu_metrics_path") + 1])
    metrics_path.write_text(
        "".join(
            json.dumps(
                {
                    "global_step": step,
                    "loss": 1.0 / step,
                    "grad_norm": 1.0,
                    "peak_reserved_bytes": 1024,
                    "step_seconds": 0.5,
                    "forward_devices": {
                        "input": "mlu:0",
                        "output": "mlu:0",
                        "trainable_parameters": ["mlu:0"],
                    },
                }
            )
            + "\n"
            for step in steps
        ),
        encoding="utf-8",
    )


def _write_adapter(
    path: Path,
    contents: bytes,
    metadata: dict[str, str] | None = None,
    dtype: torch.dtype = torch.uint8,
) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    save_file(
        {"adapter": torch.tensor(list(contents), dtype=dtype)},
        str(path),
        metadata=metadata,
    )
    return path


def _write_initial_adapter(
    command: list[str],
    contents: bytes = b"initial adapter",
    metadata: dict[str, str] | None = None,
) -> Path:
    initial_path = Path(command[command.index("--genmlu_initial_adapter_path") + 1])
    return _write_adapter(initial_path, contents, metadata)


def test_fresh_one_step_uses_trainer_initial_adapter(tmp_path, monkeypatch):
    weights, dataset, source_root = _training_layout(tmp_path)
    output_dir = tmp_path / "new-run"
    commands = []

    def fake_run(command, **_kwargs):
        commands.append(command)
        _write_metrics(command, range(1, 2))
        _write_initial_adapter(command)
        _write_adapter(output_dir / "pytorch_lora_weights.safetensors", b"updated adapter")

    monkeypatch.setattr(sdxl_training.subprocess, "run", fake_run)
    result = sdxl_training.run_sdxl_training(
        weights,
        {"train_data_dir": str(dataset), "max_train_steps": 1},
        output_dir,
        source_root,
    )

    command = commands[0]
    assert command[command.index("--checkpointing_steps") + 1] == "10"
    assert result["metrics"]["measurement_steps"] == 1
    assert result["metrics"]["warmup_steps"] == 0
    assert result["checks"]["weight_sha_changed"] is True
    assert {Path(entry["path"]).name for entry in result["artifacts"]} == {
        "initial_adapter.safetensors",
        "pytorch_lora_weights.safetensors",
    }


def test_fresh_twenty_steps_respects_explicit_warmup(tmp_path, monkeypatch):
    weights, dataset, source_root = _training_layout(tmp_path)
    output_dir = tmp_path / "new-run"

    def fake_run(command, **_kwargs):
        _write_metrics(command, range(1, 21))
        _write_initial_adapter(command)
        _write_adapter(output_dir / "pytorch_lora_weights.safetensors", b"updated adapter")

    monkeypatch.setattr(sdxl_training.subprocess, "run", fake_run)
    result = sdxl_training.run_sdxl_training(
        weights,
        {"train_data_dir": str(dataset), "max_train_steps": 20, "warmup_steps": 5},
        output_dir,
        source_root,
    )

    assert result["metrics"]["measurement_steps"] == 15
    assert result["metrics"]["warmup_steps"] == 5


def test_fifty_steps_accepts_rotated_ten_step_checkpoints(tmp_path, monkeypatch):
    weights, dataset, source_root = _training_layout(tmp_path)
    output_dir = tmp_path / "new-run"
    commands = []

    def fake_run(command, **_kwargs):
        commands.append(command)
        _write_metrics(command, range(1, 51))
        _write_initial_adapter(command)
        for step in (40, 50):
            checkpoint = output_dir / f"checkpoint-{step}"
            checkpoint.mkdir()
            _write_adapter(
                checkpoint / "pytorch_lora_weights.safetensors", f"adapter {step}".encode()
            )
        _write_adapter(output_dir / "pytorch_lora_weights.safetensors", b"updated adapter")

    monkeypatch.setattr(sdxl_training.subprocess, "run", fake_run)
    result = sdxl_training.run_sdxl_training(
        weights,
        {
            "train_data_dir": str(dataset),
            "max_train_steps": 50,
            "checkpointing_steps": 10,
            "checkpoints_total_limit": 2,
        },
        output_dir,
        source_root,
    )

    command = commands[0]
    assert command[command.index("--checkpointing_steps") + 1] == "10"
    assert command[command.index("--checkpoints_total_limit") + 1] == "2"
    assert not (output_dir / "checkpoint-10").exists()
    assert {Path(entry["path"]).parent.name for entry in result["artifacts"]} >= {
        "checkpoint-40",
        "checkpoint-50",
    }


def test_arbitrary_positive_checkpoint_interval_and_retention_are_forwarded(tmp_path, monkeypatch):
    weights, dataset, source_root = _training_layout(tmp_path)
    output_dir = tmp_path / "new-run"
    commands = []

    def fake_run(command, **_kwargs):
        commands.append(command)
        _write_metrics(command, range(1, 21))
        _write_initial_adapter(command)
        _write_adapter(output_dir / "pytorch_lora_weights.safetensors", b"updated adapter")

    monkeypatch.setattr(sdxl_training.subprocess, "run", fake_run)
    sdxl_training.run_sdxl_training(
        weights,
        {
            "train_data_dir": str(dataset),
            "max_train_steps": 20,
            "checkpointing_steps": 7,
            "checkpoints_total_limit": 4,
        },
        output_dir,
        source_root,
    )

    command = commands[0]
    assert command[command.index("--checkpointing_steps") + 1] == "7"
    assert command[command.index("--checkpoints_total_limit") + 1] == "4"


def test_adapter_only_external_checkpoint_is_rejected_without_mutation(tmp_path, monkeypatch):
    weights, dataset, source_root = _training_layout(tmp_path)
    old_checkpoint = tmp_path / "old-run" / "checkpoint-20"
    old_checkpoint.mkdir(parents=True)
    old_adapter = old_checkpoint / "pytorch_lora_weights.safetensors"
    _write_adapter(old_adapter, b"old adapter", {"source": "checkpoint"})
    old_adapter_bytes = old_adapter.read_bytes()
    output_dir = tmp_path / "new-run"
    commands = []

    def fake_run(command, **_kwargs):
        commands.append(command)

    monkeypatch.setattr(sdxl_training.subprocess, "run", fake_run)
    with pytest.raises(RuntimeError, match="complete native full checkpoint"):
        sdxl_training.run_sdxl_training(
            weights,
            {"train_data_dir": str(dataset), "max_train_steps": 25, "resume_from_checkpoint": str(old_checkpoint)},
            output_dir, source_root,
        )
    assert not commands
    assert old_adapter.read_bytes() == old_adapter_bytes


def test_external_checkpoint_requires_adapter_before_child_process(tmp_path, monkeypatch):
    weights, dataset, source_root = _training_layout(tmp_path)
    checkpoint = tmp_path / "old-run" / "checkpoint-20"
    checkpoint.mkdir(parents=True)
    called = False

    def fake_run(*_args, **_kwargs):
        nonlocal called
        called = True

    monkeypatch.setattr(sdxl_training.subprocess, "run", fake_run)
    with pytest.raises(RuntimeError, match="missing its adapter"):
        sdxl_training.run_sdxl_training(
            weights,
            {
                "train_data_dir": str(dataset),
                "max_train_steps": 25,
                "resume_from_checkpoint": str(checkpoint),
            },
            tmp_path / "new-run",
            source_root,
        )
    assert not called


def test_unchanged_adapter_is_rejected(tmp_path, monkeypatch):
    weights, dataset, source_root = _training_layout(tmp_path)
    output_dir = tmp_path / "new-run"

    def fake_run(command, **_kwargs):
        _write_metrics(command, range(1, 2))
        _write_initial_adapter(command, b"unchanged", {"state": "before"})
        _write_adapter(
            output_dir / "pytorch_lora_weights.safetensors",
            b"unchanged",
            {"state": "after"},
        )

    monkeypatch.setattr(sdxl_training.subprocess, "run", fake_run)
    with pytest.raises(RuntimeError, match="did not change"):
        sdxl_training.run_sdxl_training(
            weights,
            {"train_data_dir": str(dataset), "max_train_steps": 1},
            output_dir,
            source_root,
        )


def test_adapter_tensor_hash_ignores_safetensors_metadata(tmp_path):
    before = _write_adapter(
        tmp_path / "before.safetensors", b"same tensors", {"state": "before"}
    )
    after = _write_adapter(
        tmp_path / "after.safetensors", b"same tensors", {"state": "after"}
    )

    assert hashlib.sha256(before.read_bytes()).hexdigest() != hashlib.sha256(
        after.read_bytes()
    ).hexdigest()
    assert sdxl_training._adapter_tensor_identity(before)[0] == sdxl_training._adapter_tensor_identity(
        after
    )[0]


def test_dtype_only_adapter_change_is_rejected(tmp_path, monkeypatch):
    weights, dataset, source_root = _training_layout(tmp_path)
    output_dir = tmp_path / "new-run"

    def fake_run(command, **_kwargs):
        _write_metrics(command, range(1, 2))
        _write_initial_adapter(command, b"same")
        _write_adapter(
            output_dir / "pytorch_lora_weights.safetensors", b"same", dtype=torch.float32
        )

    monkeypatch.setattr(sdxl_training.subprocess, "run", fake_run)
    with pytest.raises(RuntimeError, match="tensor layouts differ"):
        sdxl_training.run_sdxl_training(
            weights,
            {"train_data_dir": str(dataset), "max_train_steps": 1},
            output_dir,
            source_root,
        )


@pytest.mark.parametrize("values", [[], [float("nan")], [float("inf")]])
def test_adapter_tensor_identity_rejects_empty_or_nonfinite_dumps(tmp_path, values):
    path = tmp_path / "invalid.safetensors"
    tensors = {} if not values else {"adapter": torch.tensor(values)}
    save_file(tensors, str(path))

    with pytest.raises(RuntimeError, match="contains (no tensors|non-finite tensor values)"):
        sdxl_training._adapter_tensor_identity(path)


def test_missing_initial_adapter_is_rejected(tmp_path, monkeypatch):
    weights, dataset, source_root = _training_layout(tmp_path)
    output_dir = tmp_path / "new-run"

    def fake_run(command, **_kwargs):
        _write_metrics(command, range(1, 2))
        _write_adapter(output_dir / "pytorch_lora_weights.safetensors", b"updated adapter")

    monkeypatch.setattr(sdxl_training.subprocess, "run", fake_run)
    with pytest.raises(RuntimeError, match="artifacts are incomplete"):
        sdxl_training.run_sdxl_training(
            weights,
            {"train_data_dir": str(dataset), "max_train_steps": 1},
            output_dir,
            source_root,
        )


@pytest.mark.parametrize(
    ("key", "value"),
    [
        ("checkpointing_steps", 0),
        ("checkpointing_steps", True),
        ("checkpointing_steps", 1.5),
        ("checkpointing_steps", "1"),
        ("checkpoints_total_limit", 0),
        ("checkpoints_total_limit", True),
        ("checkpoints_total_limit", 1.5),
        ("checkpoints_total_limit", "1"),
    ],
)
def test_invalid_checkpoint_configuration_is_rejected(tmp_path, key, value):
    weights, dataset, source_root = _training_layout(tmp_path)
    with pytest.raises(ValueError, match="must be positive"):
        sdxl_training.run_sdxl_training(
            weights,
            {"train_data_dir": str(dataset), "max_train_steps": 1, key: value},
            tmp_path / "new-run",
            source_root,
        )


def test_sdxl_config_and_patch_keep_the_external_resume_contract():
    root = Path(__file__).resolve().parents[1]
    config = (root / "configs" / "sdxl-training.yaml").read_text(encoding="utf-8")
    patch = (root / "patches" / "diffusers-sdxl-training-evidence.patch").read_text(encoding="utf-8")

    assert "train_data_dir:" in config
    assert "max_train_steps:" in config
    assert "dataset_root:" not in config
    assert "max_steps:" not in config
    assert "--genmlu_external_resume_from_checkpoint" in patch
    assert "accelerator.load_state(load_path)" in patch
    assert "genmlu_session.restore_checkpoint(Path(load_path))" in patch
    assert '"--genmlu_full_checkpoint", action="store_true", default=False' in patch
    assert "genmlu_session.preupdate_witness()" in patch
    assert "genmlu_session.save_checkpoint(Path(save_path), global_step, genmlu_before_save)" in patch
    assert "--genmlu_initial_adapter_path" in patch
    assert "save_lora_weights(Path(args.genmlu_initial_adapter_path))" in patch
    assert patch.index("save_lora_weights(Path(args.genmlu_initial_adapter_path))") < patch.index("progress_bar = tqdm")
    assert "checkpoint-10" not in patch
    assert '"input": str(noisy_model_input.device)' in patch
    assert '"output": str(model_pred.device)' in patch


@pytest.mark.parametrize("changed", [
    {"dataloader_num_workers": 1}, {"dataloader_num_workers": False},
    {"train_batch_size": 2}, {"train_batch_size": True},
    {"gradient_accumulation_steps": 2}, {"gradient_accumulation_steps": True},
    {"runtime_image_id": "unverified"}, {"learning_rate": float("nan")},
])
def test_full_checkpoint_invalid_scope_fails_before_child(tmp_path, monkeypatch, changed):
    weights, dataset, source_root = _training_layout(tmp_path)
    config = {"train_data_dir": str(dataset), "max_train_steps": 25, "full_checkpoint": True,
              "dataloader_num_workers": 0, "runtime_image_id": "sha256:" + "a" * 64}
    config.update(changed)
    commands = []
    monkeypatch.setattr(sdxl_training.subprocess, "run", lambda *args, **kwargs: commands.append(args))
    with pytest.raises(ValueError):
        sdxl_training.run_sdxl_training(weights, config, tmp_path / "run", source_root)
    assert commands == []


def test_full_checkpoint_flag_is_only_added_for_explicit_optin(tmp_path, monkeypatch):
    weights, dataset, source_root = _training_layout(tmp_path)
    config = {"train_data_dir": str(dataset), "max_train_steps": 25, "full_checkpoint": True,
              "dataloader_num_workers": 0, "runtime_image_id": "sha256:" + "a" * 64}
    commands = []

    def stop_at_child(command, **kwargs):
        commands.append(command)
        raise RuntimeError("fake child boundary")

    monkeypatch.setattr(sdxl_training.subprocess, "run", stop_at_child)
    with pytest.raises(RuntimeError, match="fake child boundary"):
        sdxl_training.run_sdxl_training(weights, config, tmp_path / "enabled", source_root)
    assert "--genmlu_full_checkpoint" in commands[-1]
    assert commands[-1][commands[-1].index("--genmlu_source_root") + 1] == str(source_root.resolve())
    config.pop("full_checkpoint")
    with pytest.raises(RuntimeError, match="fake child boundary"):
        sdxl_training.run_sdxl_training(weights, config, tmp_path / "disabled", source_root)
    assert "--genmlu_full_checkpoint" not in commands[-1]


def test_full_checkpoint_backend_accepts_complete_cpu_fixture_without_recovery_claim(tmp_path, monkeypatch):
    # Fake child/device metadata exercises wrapper plumbing, not native MLU support.
    from test_sdxl_training_state_roundtrip import cpu_session, execute
    from genmlu import sdxl_training_resume_checkpoint as checkpoint

    weights, dataset, source_root = _training_layout(tmp_path)
    output = tmp_path / "run"

    def fake_run(command, **kwargs):
        session, dataloader = cpu_session(output / "fixture", dataset)
        session.args.output_dir = str(output)
        (output / "native-contract.json").write_text(json.dumps(session.contract), encoding="utf-8")
        save_file(checkpoint.cpu_tree(session.adapter_state()), str(output / "initial_adapter.safetensors"))
        session.preupdate_witness()
        actual, _state = execute(session, dataloader, output)
        save_file(checkpoint.cpu_tree(session.adapter_state()), str(output / "pytorch_lora_weights.safetensors"))
        _write_metrics(command, range(1, 26))
        metrics = Path(command[command.index("--genmlu_metrics_path") + 1])
        rows = [json.loads(line) for line in metrics.read_text(encoding="utf-8").splitlines()]
        for row, observed in zip(rows, actual):
            index = observed["sample"][0]
            row["sample_witness"] = {
                "epoch": (row["global_step"] - 1) // 3, "batch_index": (row["global_step"] - 1) % 3,
                "sample_ids": [index], "samples": [session.contract["data"]["records"][index]],
                "tensors": {"pixel_values": checkpoint.state_sha(torch.tensor([[index + 1.0, index + 2.0]])),
                            "input_ids_one": checkpoint.state_sha(torch.tensor([[index, index + 1]])),
                            "input_ids_two": checkpoint.state_sha(torch.tensor([[index + 2, index + 3]]))},
                "original_sizes": [[1, 1]], "crop_top_lefts": [[0, 0]],
            }
        metrics.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")

    monkeypatch.setattr(sdxl_training.subprocess, "run", fake_run)
    result = sdxl_training.run_sdxl_training(
        weights, {"train_data_dir": str(dataset), "max_train_steps": 25, "warmup_steps": 5,
                  "full_checkpoint": True, "dataloader_num_workers": 0, "lora_rank": 4,
                  "checkpoints_total_limit": 5, "extra_checkpoint_steps": "11,21,25",
                  "runtime_image_id": "sha256:" + "a" * 64}, output, source_root,
    )
    assert result["metrics"]["executed_steps"] == 25
    assert result["metrics"]["measurement_steps"] == 20
    assert result["metrics"]["next_global_optimizer_step"] == 26
    assert result["metrics"]["fresh_recovery_verified"] is False
    assert result["metrics"]["performance_accepted"] is False
    assert result["checks"]["native_full_checkpoint"] is True
    assert any(record["path"].endswith("checkpoint-25/genmlu-checkpoint.json")
               or record["path"].endswith("checkpoint-25\\genmlu-checkpoint.json") for record in result["artifacts"])


@pytest.mark.parametrize("proof", [
    None,
    {},
    {"input": "cpu", "output": "cpu", "trainable_parameters": ["cpu"]},
    {"input": "mlu:0", "output": "cpu", "trainable_parameters": ["mlu:0"]},
    {"input": "mlu:0", "output": "mlu:0", "trainable_parameters": []},
    {"input": "mlu:0", "output": "mlu:0", "trainable_parameters": ["mlu:0", "cpu"]},
    {"input": "mlu:0", "output": "mlu:0", "trainable_parameters": ["mlu:1"]},
])
def test_missing_or_non_mlu_forward_evidence_is_rejected(proof):
    with pytest.raises(RuntimeError, match="(evidence|one MLU)"):
        sdxl_training._observed_unet_device([{"forward_devices": proof}])


def test_forward_device_is_read_from_all_update_records():
    def record(device):
        return {"forward_devices": {
            "input": device, "output": device, "trainable_parameters": [device],
        }}

    assert sdxl_training._observed_unet_device([record("mlu:1"), record("mlu:1")]) == "mlu:1"
    with pytest.raises(RuntimeError, match="changed"):
        sdxl_training._observed_unet_device([record("mlu:0"), record("mlu:1")])
    with pytest.raises(RuntimeError, match="not observed"):
        sdxl_training._observed_unet_device([])


def test_reordered_training_updates_are_rejected(tmp_path, monkeypatch):
    weights, dataset, source_root = _training_layout(tmp_path)
    output_dir = tmp_path / "new-run"

    def fake_run(command, **_kwargs):
        _write_metrics(command, range(1, 4))
        path = Path(command[command.index("--genmlu_metrics_path") + 1])
        rows = path.read_text().splitlines()
        path.write_text("\n".join([rows[1], rows[0], rows[2]]) + "\n")

    monkeypatch.setattr(sdxl_training.subprocess, "run", fake_run)
    with pytest.raises(RuntimeError, match="recorded"):
        sdxl_training.run_sdxl_training(
            weights, {"train_data_dir": str(dataset), "max_train_steps": 3},
            output_dir, source_root,
        )
