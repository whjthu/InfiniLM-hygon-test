from __future__ import annotations

import pytest

torch = pytest.importorskip("torch")

from genmlu.backends import vggt_training as vggt


class TinyAggregator(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.projection = torch.nn.Linear(4, 6)
        self.norm = torch.nn.LayerNorm(6)
        self.mask_token = torch.nn.Parameter(torch.zeros(6), requires_grad=False)

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        return self.norm(self.projection(values)).tanh()


class TinyCameraModel(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.aggregator = TinyAggregator()
        self.camera_head = torch.nn.Sequential(
            torch.nn.Linear(6, 5), torch.nn.Tanh(), torch.nn.Linear(5, 2)
        )

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        return self.camera_head(self.aggregator(values)).float()


def make_backbone(seed: int):
    torch.manual_seed(seed)
    model = TinyCameraModel()
    module, state_key = vggt._vggt_bind_trainable_scope(
        torch, model, "camera_backbone"
    )
    parameters = [parameter for parameter in module.parameters() if parameter.requires_grad]
    optimizer = torch.optim.AdamW(parameters, lr=3e-3, weight_decay=0.01)
    vggt._vggt_assert_optimizer_binding(optimizer, parameters)
    return model, module, state_key, parameters, optimizer


def step(model, parameters, optimizer, values: torch.Tensor) -> tuple[float, float]:
    optimizer.zero_grad(set_to_none=True)
    loss = model(values).square().mean()
    loss.backward()
    backbone = [
        parameter for parameter in model.aggregator.parameters() if parameter.requires_grad
    ]
    camera_head = [
        parameter for parameter in model.camera_head.parameters() if parameter.requires_grad
    ]
    backbone_norm = vggt._vggt_gradient_norm_before_clip(
        backbone, torch, "aggregator"
    )
    camera_head_norm = vggt._vggt_gradient_norm_before_clip(
        camera_head, torch, "camera_head"
    )
    torch.nn.utils.clip_grad_norm_(parameters, 1.0)
    optimizer.step()
    vggt._vggt_assert_optimizer_state_initialized(optimizer, parameters)
    return backbone_norm, camera_head_norm


def make_contract() -> dict:
    return vggt._vggt_contract(
        identity={key: "a" * 64 for key in vggt._VGGT_IDENTITY_FIELDS},
        seed=11,
        warmup_steps=0,
        max_steps=3,
        view_order=["seq-a:0,1", "seq-b:2,3"],
        device_ids=[],
    )


def test_camera_backbone_forward_preserves_native_frozen_mask() -> None:
    model, module, state_key, parameters, _optimizer = make_backbone(1)
    output = model(torch.arange(12, dtype=torch.float32).reshape(3, 4))
    assert output.shape == (3, 2)
    assert output.dtype == torch.float32
    assert state_key == "camera_backbone"
    assert model.training and model.aggregator.training and model.camera_head.training
    assert model.aggregator.mask_token.requires_grad is False
    assert id(model.aggregator.mask_token) not in {id(parameter) for parameter in parameters}
    assert set(module) == {"aggregator", "camera_head"}


def test_camera_head_binding_retains_the_frozen_aggregator_default() -> None:
    torch.manual_seed(5)
    model = TinyCameraModel()
    module, state_key = vggt._vggt_bind_trainable_scope(torch, model, "camera_head")
    assert module is model.camera_head
    assert state_key == "camera_head"
    assert model.aggregator.training is False
    assert model.camera_head.training is True
    assert all(not parameter.requires_grad for parameter in model.aggregator.parameters())


def test_camera_backbone_backward_updates_aggregator_and_camera_head_separately() -> None:
    model, _module, _state_key, parameters, optimizer = make_backbone(2)
    aggregator_before = vggt._module_sha(model.aggregator)
    camera_head_before = vggt._module_sha(model.camera_head)
    backbone_norm, camera_head_norm = step(
        model, parameters, optimizer, torch.ones(4, 4)
    )
    assert backbone_norm > 0.0
    assert camera_head_norm > 0.0
    assert vggt._module_sha(model.aggregator) != aggregator_before
    assert vggt._module_sha(model.camera_head) != camera_head_before


def test_unused_optimizer_parameter_is_rejected_before_update() -> None:
    used = torch.nn.Parameter(torch.ones(2))
    unused = torch.nn.Parameter(torch.ones(2))
    used.square().sum().backward()
    with pytest.raises(RuntimeError, match="unused optimizer parameter"):
        vggt._vggt_gradient_norm_before_clip([used, unused], torch, "fixture")


def test_camera_backbone_checkpoint_restores_full_range_and_next_update() -> None:
    values = torch.arange(16, dtype=torch.float32).reshape(4, 4) / 8
    contract = make_contract()
    source, source_module, state_key, source_parameters, source_optimizer = make_backbone(3)
    step(source, source_parameters, source_optimizer, values)
    payload = vggt._vggt_make_checkpoint(
        contract=contract,
        global_optimizer_step=1,
        module=source_module,
        optimizer=source_optimizer,
        torch=torch,
        state_key=state_key,
    )
    assert set(payload["state"]) == {
        "camera_backbone",
        "optimizer",
        "optimizer_placements",
    }
    assert any(name.startswith("aggregator.") for name in payload["state"][state_key])
    assert any(name.startswith("camera_head.") for name in payload["state"][state_key])

    step(source, source_parameters, source_optimizer, values)
    continuous = vggt.resume_common.tree_sha256(
        {
            "module": source_module.state_dict(),
            "optimizer": vggt.resume_common.cpu_tree(source_optimizer.state_dict()),
        }
    )

    resumed, resumed_module, resumed_key, resumed_parameters, resumed_optimizer = make_backbone(99)
    checked = vggt._vggt_restore_checkpoint(
        payload,
        contract,
        resumed_module,
        resumed_optimizer,
        torch,
        state_key=resumed_key,
    )
    vggt._vggt_assert_restored_boundary(
        payload,
        contract,
        resumed_module,
        resumed_optimizer,
        torch,
        state_key=resumed_key,
    )
    assert checked["next"] == {"global_optimizer_step": 2, "batch_cursor": 1}
    step(resumed, resumed_parameters, resumed_optimizer, values)
    restored = vggt.resume_common.tree_sha256(
        {
            "module": resumed_module.state_dict(),
            "optimizer": vggt.resume_common.cpu_tree(resumed_optimizer.state_dict()),
        }
    )
    assert restored == continuous


def test_resume_identity_distinguishes_camera_backbone_scope(monkeypatch, tmp_path) -> None:
    monkeypatch.setattr(vggt, "sha256_path", lambda _path: "a" * 64)
    monkeypatch.setattr(vggt, "_vggt_source_evidence", lambda *_args: {"source": "b" * 64})
    monkeypatch.setattr(vggt, "_vggt_batch_content_sha256", lambda _batches: "c" * 64)
    model, module, _state_key, _parameters, optimizer = make_backbone(4)
    common = dict(
        weights=tmp_path,
        dataset_root=tmp_path / "data",
        annotation_root=tmp_path / "annotations",
        model=model,
        optimizer=optimizer,
        batches=[],
        cache_enabled=False,
        aggregator_sha256="d" * 64,
    )
    with pytest.raises(ValueError, match="full trainable module"):
        vggt._vggt_resume_identity(
            config={"training_scope": "camera_backbone"},
            training_scope="camera_backbone",
            **common,
        )
    head_identity, _ = vggt._vggt_resume_identity(
        config={"training_scope": "camera_head"},
        training_scope="camera_head",
        trainable_module=model.camera_head,
        **common,
    )
    backbone_identity, evidence = vggt._vggt_resume_identity(
        config={"training_scope": "camera_backbone"},
        training_scope="camera_backbone",
        trainable_module=module,
        **common,
    )
    assert backbone_identity["workload"] != head_identity["workload"]
    assert backbone_identity["frozen_model"] != head_identity["frozen_model"]
    assert evidence["workload"]["trainable_state_key"] == "camera_backbone"
    assert evidence["frozen_model"]["aggregator_role"] == "trainable"
