from __future__ import annotations

import ast
import inspect
from pathlib import Path

import pytest
import yaml

from genmlu.backends import vggt_training as vggt


def test_geometry_scope_is_explicit_and_bounded() -> None:
    assert vggt._vggt_training_preflight(
        {"training_scope": "camera_depth_point_backbone"}
    ) == ("camera_depth_point_backbone", False)
    with pytest.raises(ValueError, match="cannot cache"):
        vggt._vggt_training_preflight(
            {
                "training_scope": "camera_depth_point_backbone",
                "cache_frozen_aggregator_features": True,
            }
        )


def test_geometry_scope_conflicts_fail_before_mlu(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    called = False

    def fail_runtime():
        nonlocal called
        called = True
        raise AssertionError("MLU runtime must not be initialized")

    monkeypatch.setattr(vggt, "require_mlu", fail_runtime)
    with pytest.raises(ValueError, match="cannot cache"):
        vggt.run_vggt_training(
            Path("weights"),
            {
                "training_scope": "camera_depth_point_backbone",
                "cache_frozen_aggregator_features": True,
            },
            Path("output"),
            Path("source"),
        )
    assert called is False


def test_geometry_preset_has_no_track_or_feature_cache() -> None:
    path = (
        Path(__file__).resolve().parents[1]
        / "configs"
        / "vggt-camera-depth-point-backbone-training.yaml"
    )
    config = yaml.safe_load(path.read_text(encoding="utf-8"))
    assert config["training_scope"] == "camera_depth_point_backbone"
    assert config["cache_frozen_aggregator_features"] is False
    assert config["checkpoint_steps"] == [10, 20]


def test_geometry_source_uses_official_targets_loss_and_normalization() -> None:
    source = inspect.getsource(vggt.run_vggt_training)
    assert "normalize_camera_extrinsics_and_points_batch" in source
    assert "MultitaskLoss" in source
    assert "include_geometry=geometry_scope" in source
    assert "enable_point=True" in source
    assert "enable_depth=True" in source
    assert "enable_track=False" in source
    assert "aten::_upsample_bicubic2d_aa_backward" in source


def test_official_multitask_weights_are_fixed() -> None:
    assert vggt.VGGT_GEOMETRY_LOSS_CONFIG == {
        "camera": {"weight": 5.0, "loss_type": "l1"},
        "depth": {
            "weight": 1.0,
            "gradient_loss_fn": "grad",
            "valid_range": 0.98,
        },
        "point": {
            "weight": 1.0,
            "gradient_loss_fn": "normal",
            "valid_range": 0.98,
        },
        "track": None,
    }


def test_geometry_normalization_only_follows_valid_pixel_selection() -> None:
    tree = ast.parse(inspect.getsource(vggt.run_vggt_training))
    loop = next(node for node in ast.walk(tree) if isinstance(node, ast.While))
    selection = next(node for node in loop.body if isinstance(node, ast.If))
    assert isinstance(selection.test, ast.Call)
    assert selection.test.func.id == "valid_depth_batch"
    calls = [node.func.id for node in ast.walk(selection)
             if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)]
    assert "_vggt_normalize_geometry_batch" in calls
    assert not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                   and node.func.id == "_vggt_normalize_geometry_batch"
                   for statement in loop.body if statement is not selection
                   for node in ast.walk(statement))
