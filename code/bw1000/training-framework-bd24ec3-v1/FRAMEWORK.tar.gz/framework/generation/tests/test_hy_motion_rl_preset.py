from pathlib import Path

import yaml


CONFIGS = Path(__file__).resolve().parents[1] / "configs"


def test_full_motionrft_preset_is_scoped() -> None:
    preset = yaml.safe_load((CONFIGS / "hy-motion-rl-full-gc-off.yaml").read_text())
    general = yaml.safe_load((CONFIGS / "hy-motion-rl.yaml").read_text())

    assert preset["model"] == general["model"] == "hy-motion-1.0"
    assert preset["variant"] == "HY-Motion-1.0"
    assert preset["gradient_checkpointing"] is False
    assert "gradient_checkpointing" not in general
    assert (preset["group_size"], preset["sampling_steps"]) == (4, 4)
    assert (preset["warmup_steps"], preset["max_steps"]) == (5, 20)
    assert preset["checkpoint_steps"] == [10, 20]
    assert preset["precision"] == "bfloat16"
    assert preset["lora_target_modules"] == ["qkv", "proj", "fc1", "fc2"]
    assert preset["save_trajectories"] is False
    assert preset["container"] == (
        "cambricon-base/pytorch:v26.06.0-torch2.12.0-torchmlu1.33.1-ubuntu24.04-py312"
    )
    assert preset["learning_rate"] == "5e-05"
    assert preset["resume_atol"] == "1e-06"
    assert preset["profile_actor_update_stages"] is False
    assert "resume_from_checkpoint" not in preset
    for key in ("dataset_sha", "training_cache_sha", "model_sha"):
        assert len(preset[key]) == 64
