"""CPU integration contracts, executing only the real backend's narrow loop AST.

No model/MLU/torch import is required. Payload capture/serialization are mocks;
these tests do not establish tensor equivalence, recovery or device performance.
"""
from __future__ import annotations

import ast
from contextlib import ExitStack
import hashlib
import inspect
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from genmlu.backends import zimage_training as training


def _backend_function():
    tree = ast.parse(inspect.getsource(training.run_zimage_training))
    return next(node for node in tree.body if isinstance(node, ast.FunctionDef))


def _execute(nodes, namespace):
    module = ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[]))
    exec(compile(module, inspect.getsourcefile(training), 'exec'), namespace)


class _Threads:
    def __init__(self):
        self.current = 255
        self.set_calls = []

    def get_num_threads(self):
        return self.current

    def set_num_threads(self, count):
        self.set_calls.append(count)
        self.current = count


class TestZImageCheckpointThreadScope(unittest.TestCase):
    def test_invalid_limit_rejected_before_runtime_resume_or_model_read(self):
        for value in (True, False, 0, -1, 257, 1.0, '1', [], {}):
            with self.subTest(value=value), ExitStack() as stack:
                guards = [stack.enter_context(patch.object(training, name,
                    side_effect=AssertionError('validation reached ' + name)))
                    for name in ('require_mlu', '_training_module_class', 'local_model_paths',
                                 '_checkpoint_path')]
                stack.enter_context(patch.object(Path, 'is_file',
                    side_effect=AssertionError('validation reached a filesystem read')))
                with self.assertRaisesRegex(ValueError, 'checkpoint CPU thread limit'):
                    training.run_zimage_training(Path('unused-weights'),
                        {'checkpoint_cpu_threads': value, 'resume_from_checkpoint': 'unused.pt'},
                        Path('unused-output'), Path('unused-source'))
                for guard in guards:
                    guard.assert_not_called()

    def test_source_identity_hashes_actual_helper_and_changes_with_it(self):
        helper = Path(inspect.getsourcefile(inspect.unwrap(training.checkpoint_cpu_threads)))
        self.assertEqual(helper.name, 'checkpoint_cpu_threads.py')
        expected = hashlib.sha256(helper.read_bytes()).hexdigest()
        with tempfile.TemporaryDirectory() as tmp, ExitStack() as stack:
            adapter = Path(tmp) / 'adapter'
            adapter.write_bytes(b'cpu-fixture')
            stack.enter_context(patch.object(training, '_pinned_tree_sha256', return_value='a'*64))
            stack.enter_context(patch.object(training, '_imported_execution_module_sources', return_value={}))
            stack.enter_context(patch.object(training, '_execution_source_sha256', return_value='b'*64))
            stack.enter_context(patch.object(training, '_tree_sha256', return_value='c'*64))
            stack.enter_context(patch.object(training.z_resume, 'scheduler_spec', return_value={'fixture': 1}))
            stack.enter_context(patch.object(training.z_resume.common, 'tree_sha256', return_value='d'*64))
            kwargs = dict(torch=SimpleNamespace(__version__='cpu-protocol-fixture'),
                weights=Path(tmp), config={'preset_lora_path': str(adapter)}, source_root=Path(tmp),
                training_class=object, dataset_type=list,
                model=SimpleNamespace(pipe=SimpleNamespace(dit=object())), scheduler=object(),
                data_evidence={'fixture': True}, sample_order=['fixture'], max_steps=25)
            contract, evidence = training._build_resume_contract(**kwargs)
            self.assertEqual(evidence['source']['checkpoint_cpu_threads'], expected)
            self.assertEqual(contract['identity']['source'],
                training.z_resume.common.json_sha256(evidence['source']))
            source_sha = training._source_sha256
            def changed_helper(path, label):
                return 'e'*64 if path.resolve() == helper.resolve() else source_sha(path, label)
            with patch.object(training, '_source_sha256', side_effect=changed_helper):
                changed, _ = training._build_resume_contract(**kwargs)
            self.assertNotEqual(contract['identity']['source'], changed['identity']['source'])

    def _loop(self, config, fail_payload=False, fail_save=False):
        function = _backend_function()
        # Execute backend-owned validation/default assignment and its actual loop,
        # not a hand-written approximation or the whole model construction path.
        limit_assignment = function.body[0]
        self.assertIsInstance(limit_assignment, ast.Assign)
        self.assertEqual([target.id for target in limit_assignment.targets], ['checkpoint_thread_limit'])
        loops = [node for node in function.body if isinstance(node, ast.For)
                 and isinstance(node.target, ast.Name) and node.target.id == 'global_step']
        self.assertEqual(len(loops), 1)
        loop = loops[0]
        scopes = [node for node in ast.walk(loop) if isinstance(node, ast.With)
                  and any(isinstance(item.context_expr, ast.Call)
                          and isinstance(item.context_expr.func, ast.Name)
                          and item.context_expr.func.id == 'checkpoint_cpu_threads' for item in node.items)]
        self.assertEqual(len(scopes), 1)
        self.assertEqual(len(scopes[0].body), 1)
        self.assertIsInstance(scopes[0].body[0], ast.Assign)
        call = scopes[0].body[0].value
        self.assertIsInstance(call, ast.Call)
        self.assertEqual(ast.unparse(call.func), 'z_resume.make_payload')
        threads, seen = _Threads(), []

        def step(*args):
            self.assertEqual(threads.current, 255)
            seen.append(('step', args[3], threads.current))
            return {'loss': 1.0}

        def progress(value, *_args):
            self.assertEqual(threads.current, 255)
            return value

        def payload(**kwargs):
            self.assertEqual(threads.current, 255 if config.get('checkpoint_cpu_threads') is None else 1)
            seen.append(('payload', kwargs['global_step'], threads.current))
            if fail_payload:
                raise RuntimeError('snapshot failure')
            return {'step': kwargs['global_step']}

        def save(path, value):
            self.assertEqual(threads.current, 255)
            self.assertEqual(path.parent.name, 'checkpoint-' + str(value['step']))
            seen.append(('save', value['step'], threads.current))
            if fail_save:
                raise RuntimeError('serialization failure')

        with tempfile.TemporaryDirectory() as tmp:
            namespace = dict(config=config, validate_limit=training.validate_limit,
                completed_global_step=0, max_steps=25, model=SimpleNamespace(
                    pipe=SimpleNamespace(scheduler=object())), optimizer=object(), dataset=[{}],
                optimizer_progress={}, metrics=[], raw_log=Path(tmp)/'steps.jsonl',
                output_dir=Path(tmp), checkpoint_steps={10,20,25}, written_checkpoint_paths=set(),
                resume_contract={'fixture': True}, scheduler_identity={'fixture': True},
                torch=threads, checkpoint_cpu_threads=training.checkpoint_cpu_threads,
                z_resume=SimpleNamespace(make_payload=payload, save_atomic=save,
                    common=SimpleNamespace(advance_optimizer_progress=progress)),
                _train_step=step, json=json)
            try:
                if fail_payload or fail_save:
                    with self.assertRaisesRegex(RuntimeError,
                            'snapshot failure' if fail_payload else 'serialization failure'):
                        _execute([limit_assignment, loop], namespace)
                else:
                    _execute([limit_assignment, loop], namespace)
                    self.assertEqual(len(namespace['metrics']), 25)
                    self.assertEqual(len(namespace['written_checkpoint_paths']), 3)
                    self.assertEqual(len(namespace['raw_log'].read_text().splitlines()), 25)
            finally:
                self.assertEqual(threads.current, 255)
        return threads, seen, namespace['checkpoint_thread_limit']

    def test_actual_loop_default_none_and_explicit_none_do_not_set_threads(self):
        for config in ({}, {'checkpoint_cpu_threads': None}):
            with self.subTest(config=config):
                threads, seen, limit = self._loop(config)
                self.assertIsNone(limit)
                self.assertEqual(threads.set_calls, [])
                self.assertEqual([(s[1],s[2]) for s in seen if s[0]=='payload'],
                                 [(10,255),(20,255),(25,255)])

    def test_actual_loop_scopes_only_payload_and_restores_before_serialization(self):
        threads, seen, _ = self._loop({'checkpoint_cpu_threads': 1})
        self.assertEqual(threads.set_calls, [1,255]*3)
        self.assertEqual(len([s for s in seen if s[0]=='step']), 25)
        self.assertEqual([(s[1],s[2]) for s in seen if s[0]=='payload'], [(10,1),(20,1),(25,1)])
        self.assertEqual([(s[1],s[2]) for s in seen if s[0]=='save'], [(10,255),(20,255),(25,255)])

    def test_actual_loop_payload_failure_restores_and_never_serializes(self):
        threads, seen, _ = self._loop({'checkpoint_cpu_threads': 1}, fail_payload=True)
        self.assertEqual(threads.set_calls, [1,255])
        self.assertFalse(any(s[0]=='save' for s in seen))

    def test_actual_loop_serialization_failure_occurs_after_restore(self):
        threads, seen, _ = self._loop({'checkpoint_cpu_threads': 1}, fail_save=True)
        self.assertEqual(threads.set_calls, [1,255])
        self.assertEqual(seen[-1], ('save',10,255))


if __name__ == '__main__':
    unittest.main()
