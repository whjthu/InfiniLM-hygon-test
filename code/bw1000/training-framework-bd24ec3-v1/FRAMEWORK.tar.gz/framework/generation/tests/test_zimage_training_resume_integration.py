from __future__ import annotations

import copy
import importlib
import sys
import random
from pathlib import Path
from types import SimpleNamespace

import pytest
import torch
import numpy as np

from genmlu.backends import zimage_training as training


class _Generator:
    def __init__(self, state: torch.Tensor) -> None:
        self.state = state.clone()

    def clone_state(self) -> "_Generator":
        return _Generator(self.state)

    def get_state(self) -> torch.Tensor:
        return self.state.clone()

    def set_state(self, state: torch.Tensor) -> None:
        self.state = state.clone()


class _Mlu:
    def __init__(self) -> None:
        self.default_generators = [_Generator(torch.arange(16, dtype=torch.uint8))]

    def get_rng_state(self, index: int) -> torch.Tensor:
        return self.default_generators[index].get_state()

    def is_available(self) -> bool:
        return True

    def is_current_stream_capturing(self) -> bool:
        return False

    def set_rng_state(self, state: torch.Tensor, index: int) -> None:
        self.default_generators[index].set_state(state)

    def synchronize(self, _index: int | None = None) -> None:
        pass

    def reset_peak_memory_stats(self) -> None:
        pass

    def manual_seed_all(self, seed: int) -> None:
        self.default_generators[0].set_state(torch.full((16,), seed % 256, dtype=torch.uint8))


def _write_upstream(root: Path) -> None:
    files = {
        "diffsynth/__init__.py": "",
        "diffsynth/diffusion/__init__.py": "",
        "diffsynth/models/__init__.py": "",
        "diffsynth/pipelines/__init__.py": "",
        "diffsynth/models/z_image_dit.py": '''
from types import SimpleNamespace
class Dit:
    def parameters(self):
        yield SimpleNamespace(device=SimpleNamespace(type="mlu"))
    def eval(self):
        pass
    def __call__(self, value):
        return value
''',
        "diffsynth/pipelines/z_image_helpers.py": '''
from diffsynth.models.z_image_dit import Dit
def build_dit():
    return Dit()
''',
        "diffsynth/preprocessing.py": '''
def default_image_operator(value):
    return value
''',
        "diffsynth/core.py": '''
from diffsynth.preprocessing import default_image_operator
class UnifiedDataset:
    def __init__(self, **_kwargs):
        pass
    @staticmethod
    def default_image_operator(**_kwargs):
        return default_image_operator
    def __len__(self):
        return 1
    def __getitem__(self, index):
        return {"index": index}
''',
        "diffsynth/diffusion/flow_match.py": '''
def set_timesteps_z_image():
    pass
class Scheduler:
    def __init__(self):
        self.set_timesteps_fn = set_timesteps_z_image
        self.num_train_timesteps = 1000
        self.training = True
        self.timesteps = 1000
    def set_timesteps(self, count, training):
        self.num_train_timesteps = count
        self.training = training
        self.timesteps = count
''',
        "diffsynth/pipelines/z_image.py": '''
from types import SimpleNamespace
from diffsynth.diffusion.flow_match import Scheduler
from diffsynth.pipelines.z_image_helpers import build_dit
class Pipeline:
    def __init__(self):
        self.dit = build_dit()
        self.scheduler = Scheduler()
''',
        "examples/z_image/model_training/train.py": '''
import torch
from diffsynth.pipelines.z_image import Pipeline
class ZImageTrainingModule(torch.nn.Module):
    def __init__(self, **_kwargs):
        super().__init__()
        self.adapter = torch.nn.Parameter(torch.tensor(1.0))
        self.pipe = Pipeline()
    def forward(self, _data):
        return self.pipe.dit(self.adapter).square()
    def trainable_modules(self):
        return [self.adapter]
    def export_trainable_state_dict(self, state, remove_prefix):
        return state
''',
    }
    for relative, content in files.items():
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content.strip() + "\n", encoding="utf-8")


def _clear_upstream_modules() -> None:
    for name in list(sys.modules):
        if name == "diffsynth" or name.startswith("diffsynth."):
            del sys.modules[name]


def _prepare_inputs(tmp_path: Path) -> tuple[Path, Path, Path, Path, Path]:
    source = tmp_path / "source"
    _write_upstream(source)
    weights = tmp_path / "weights"
    for relative in (
        "transformer/model.safetensors", "text_encoder/model.safetensors",
        "vae/diffusion_pytorch_model.safetensors", "tokenizer/tokenizer.json",
    ):
        path = weights / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(relative.encode("utf-8"))
    dataset = tmp_path / "dataset"
    dataset.mkdir()
    (dataset / "image.bin").write_bytes(b"image")
    metadata = tmp_path / "metadata.csv"
    metadata.write_text("image\nimage.bin\n", encoding="utf-8")
    adapter = tmp_path / "adapter.safetensors"
    adapter.write_bytes(b"adapter")
    return source, weights, dataset, metadata, adapter


def _config(dataset: Path, metadata: Path, adapter: Path, **extra: object) -> dict[str, object]:
    return {
        "dataset_root": str(dataset), "dataset_metadata": str(metadata),
        "preset_lora_path": str(adapter), "lora_target_modules": "adapter",
        "max_steps": 2, "checkpoint_steps": [1, 2], "warmup_steps": 1,
        "regression_prompt": "fixture",
        **extra,
    }


def _install_cpu_mlu(monkeypatch) -> None:
    monkeypatch.setattr(torch, "mlu", _Mlu(), raising=False)
    monkeypatch.setattr(training, "require_mlu", lambda: torch)
    monkeypatch.setattr(training, "synchronize", lambda: None)
    monkeypatch.setattr(training, "memory_stats", lambda: {})
    monkeypatch.setattr(training, "_save_lora", lambda path, _model: path.write_bytes(b"adapter"))
    real_preflight = training.z_resume.preflight_checkpoint

    def preflight_cpu_fixture(payload, *, requested_config):
        # CPU tensors cannot represent production MLU optimizer placements.
        candidate = copy.deepcopy(payload)
        for placement in candidate["state"]["optimizer_placements"].values():
            for key in set(placement) - {"step"}:
                placement[key] = "mlu:0"
        candidate["integrity_sha256"] = training.z_resume.common.tree_sha256(
            {key: value for key, value in candidate.items() if key != "integrity_sha256"}
        )
        return real_preflight(candidate, requested_config=requested_config)

    monkeypatch.setattr(training.z_resume, "preflight_checkpoint", preflight_cpu_fixture)


def test_fresh_process_resume_restores_scheduler_after_turbo_and_uses_global_warmup(
    tmp_path: Path, monkeypatch
) -> None:
    _clear_upstream_modules()
    source, weights, dataset, metadata, adapter = _prepare_inputs(tmp_path)
    _install_cpu_mlu(monkeypatch)
    observed_scheduler_states: list[tuple[bool, int]] = []
    real_step = training._train_step

    def altered_turbo(model, _prompt, _seed, _size, path):
        model.pipe.scheduler.training = False
        model.pipe.scheduler.timesteps = 8
        path.write_bytes(b"image")

    def checked_step(model, optimizer, data, seed, max_grad_norm):
        observed_scheduler_states.append((model.pipe.scheduler.training, model.pipe.scheduler.timesteps))
        return real_step(model, optimizer, data, seed, max_grad_norm)

    monkeypatch.setattr(training, "_turbo_image", altered_turbo)
    monkeypatch.setattr(training, "_image_regression", lambda *_args: {
        "pixel_mae": 0.0, "output_std": 1.0, "passed": True,
    })
    monkeypatch.setattr(training, "_train_step", checked_step)
    first = training.run_zimage_training(
        weights, _config(dataset, metadata, adapter, validate_turbo_regression=True),
        tmp_path / "first", source,
    )
    imported_sources = first["metrics"]["checkpoint_identity_evidence"]["source"]["imported_execution_modules"]
    assert {"diffsynth.models.z_image_dit", "diffsynth.preprocessing", "diffsynth.pipelines.z_image_helpers"} <= set(imported_sources)
    checkpoint = tmp_path / "first" / "checkpoint-1" / "state.pt"
    resumed = training.run_zimage_training(
        weights, _config(
            dataset, metadata, adapter, validate_turbo_regression=True,
            resume_from_checkpoint=str(checkpoint),
        ), tmp_path / "resumed", source,
    )

    assert first["metrics"]["measurement_steps"] == 1
    assert resumed["metrics"]["completed_global_step_before_resume"] == 1
    assert resumed["metrics"]["measurement_steps"] == 1
    assert observed_scheduler_states == [(True, 1000), (True, 1000), (True, 1000)]
    assert resumed["checks"]["resume_boundary"] is True


def test_malformed_resume_is_rejected_before_mlu_or_output(tmp_path: Path, monkeypatch) -> None:
    checkpoint = tmp_path / "bad.pt"
    torch.save({"legacy": True}, checkpoint)
    output = tmp_path / "output"
    monkeypatch.setattr(training, "require_mlu", lambda: pytest.fail("malformed resume reached MLU runtime"))

    with pytest.raises(training.z_resume.CheckpointValidationError, match="not a full Z-Image training checkpoint"):
        training.run_zimage_training(Path("unused"), {"resume_from_checkpoint": str(checkpoint)}, output, Path("unused"))
    assert not output.exists()


def test_resume_restores_rng_after_a_consuming_pre_training_turbo_render(
    tmp_path: Path, monkeypatch
) -> None:
    _clear_upstream_modules()
    source, weights, dataset, metadata, adapter = _prepare_inputs(tmp_path)
    _install_cpu_mlu(monkeypatch)
    consume = {"enabled": False}
    observations: list[tuple[float, float, float, bytes]] = []
    real_step = training._train_step

    def render(model, _prompt, _seed, _size, path):
        if consume["enabled"]:
            random.random()
            np.random.rand()
            torch.rand(1)
            torch.mlu.default_generators[0].set_state(torch.full((16,), 99, dtype=torch.uint8))
            model.pipe.scheduler.training = False
            model.pipe.scheduler.timesteps = 8
        path.write_bytes(b"image")

    def record_rng(model, optimizer, data, seed, max_grad_norm):
        observations.append((
            random.random(), float(np.random.rand()), float(torch.rand(1)),
            bytes(torch.mlu.get_rng_state(0).tolist()),
        ))
        return real_step(model, optimizer, data, seed, max_grad_norm)

    monkeypatch.setattr(training, "_turbo_image", render)
    monkeypatch.setattr(training, "_image_regression", lambda *_args: {
        "pixel_mae": 0.0, "output_std": 1.0, "passed": True,
    })
    monkeypatch.setattr(training, "_train_step", record_rng)
    config = _config(dataset, metadata, adapter, validate_turbo_regression=True)
    training.run_zimage_training(weights, config, tmp_path / "first", source)
    checkpoint = tmp_path / "first" / "checkpoint-1" / "state.pt"

    observations.clear()
    consume["enabled"] = True
    training.run_zimage_training(
        weights, {**config, "resume_from_checkpoint": str(checkpoint)}, tmp_path / "consuming", source
    )
    consuming_observation = observations[-1]

    observations.clear()
    consume["enabled"] = False
    training.run_zimage_training(
        weights, {**config, "resume_from_checkpoint": str(checkpoint)}, tmp_path / "control", source
    )
    assert observations == [consuming_observation]


def test_pre_training_render_failure_restores_scheduler_and_rng(tmp_path: Path, monkeypatch) -> None:
    _install_cpu_mlu(monkeypatch)

    def set_timesteps() -> None:
        pass

    scheduler = SimpleNamespace(
        set_timesteps_fn=set_timesteps, num_train_timesteps=1000, training=True, timesteps=1000,
    )
    model = SimpleNamespace(pipe=SimpleNamespace(scheduler=scheduler))
    expected_scheduler = training.z_resume.scheduler_spec(scheduler)
    before_rng = training.z_resume.common.capture_rng([0])

    def fail_after_consuming(_options, _model, _path):
        random.random()
        np.random.rand()
        torch.rand(1)
        torch.mlu.default_generators[0].set_state(torch.full((16,), 7, dtype=torch.uint8))
        scheduler.training = False
        scheduler.timesteps = 8
        raise RuntimeError("render failed")

    monkeypatch.setattr(training, "render_turbo_regression_image", fail_after_consuming)
    with pytest.raises(RuntimeError, match="render failed"):
        training._render_turbo_preserving_training_boundary(
            {"prompt": "fixture", "seed": 1, "size": 8}, model, tmp_path / "image.png", expected_scheduler
        )
    assert training.z_resume.scheduler_spec(scheduler) == expected_scheduler
    assert training.z_resume.common.tree_sha256(
        training.z_resume.common.capture_rng([0])
    ) == training.z_resume.common.tree_sha256(before_rng)


def test_identity_rejects_symlink_directories_and_foreign_execution_origins(tmp_path: Path) -> None:
    _clear_upstream_modules()
    source, weights, dataset, metadata, _adapter = _prepare_inputs(tmp_path)
    try:
        (weights / "linked").symlink_to(weights / "transformer", target_is_directory=True)
        (dataset / "linked").symlink_to(dataset, target_is_directory=True)
    except OSError:
        pytest.skip("symlinks are unavailable in this environment")

    with pytest.raises(RuntimeError, match="symlinked model path"):
        training._tree_sha256(weights)
    (weights / "linked").unlink()
    metadata.write_text("image\nlinked/image.bin\n", encoding="utf-8")
    with pytest.raises(RuntimeError, match="image uses a symlink"):
        training._dataset_resume_evidence(dataset, metadata)
    with pytest.raises(RuntimeError, match="imported outside source_root"):
        training._execution_source_sha256(type(SimpleNamespace()), "fixture", source)
    foreign = tmp_path / "foreign.py"
    foreign.write_text("# foreign\n", encoding="utf-8")
    sys.modules["diffsynth.foreign"] = SimpleNamespace(__file__=str(foreign))
    try:
        with pytest.raises(RuntimeError, match="imported outside source_root"):
            training._imported_execution_module_sources(source)
    finally:
        del sys.modules["diffsynth.foreign"]


def test_imported_namespace_package_paths_are_pinned_and_foreign_paths_are_rejected(tmp_path: Path) -> None:
    _clear_upstream_modules()
    source = tmp_path / "source"
    foreign = tmp_path / "foreign"
    (source / "diffsynth" / "models").mkdir(parents=True)
    (foreign / "diffsynth" / "models").mkdir(parents=True)
    sys.path.insert(0, str(source))
    try:
        importlib.import_module("diffsynth.models")
        sources = training._imported_execution_module_sources(source)
        assert sources["diffsynth.models"] == {"namespace_paths": ["diffsynth/models"]}
    finally:
        sys.path.remove(str(source))
        _clear_upstream_modules()

    sys.path[:0] = [str(source), str(foreign)]
    try:
        importlib.import_module("diffsynth.models")
        with pytest.raises(RuntimeError, match="imported outside source_root"):
            training._imported_execution_module_sources(source)
    finally:
        del sys.path[:2]
        _clear_upstream_modules()


def test_resume_rejects_changed_dit_forward_in_pinned_execution_tree(tmp_path: Path, monkeypatch) -> None:
    _clear_upstream_modules()
    source, weights, dataset, metadata, adapter = _prepare_inputs(tmp_path)
    _install_cpu_mlu(monkeypatch)
    config = _config(dataset, metadata, adapter)
    training.run_zimage_training(weights, config, tmp_path / "first", source)
    checkpoint = tmp_path / "first" / "checkpoint-1" / "state.pt"
    dit = source / "diffsynth" / "models" / "z_image_dit.py"
    dit.write_text(dit.read_text(encoding="utf-8").replace("return value", "return value * 1.0"), encoding="utf-8")

    with pytest.raises(training.z_resume.CheckpointValidationError, match="checkpoint identity or schedule mismatch"):
        training.run_zimage_training(
            weights, {**config, "resume_from_checkpoint": str(checkpoint)}, tmp_path / "resumed", source
        )
