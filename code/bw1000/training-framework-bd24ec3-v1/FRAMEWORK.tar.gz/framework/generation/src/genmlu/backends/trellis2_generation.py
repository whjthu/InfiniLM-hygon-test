from __future__ import annotations

import gc
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from time import perf_counter, time
from typing import Any

import numpy as np
from PIL import Image

from ..manifest import sha256_path
from ..runtime import memory_stats, require_mlu, synchronize
from ..trellis_output_contract import DIAGNOSTIC_MULTIBOX, LATENT_ONLY, FULL_MESH, validate_output_contract
from ..trellis_sparse_support import admit_native_support, require_stage_support, validate_limit, write_proof


CPU_DECODE_RESULT_PREFIX = "GENMLU_TRELLIS_CPU_DECODE_RESULT="
PINNED_TRELLIS2_REVISION = "75fbf0183001ed9876c8dbb35de6b68552ee08bd"
CPU_DECODE_KEYS = {"coords", "shape_fields", "material_attrs", "vertices", "faces"}


def trellis_array_sha(arrays: dict[str, np.ndarray]) -> str:
    digest = hashlib.sha256()
    for name, value in sorted(arrays.items()):
        array = np.ascontiguousarray(value)
        digest.update(name.encode("utf-8"))
        digest.update(str(array.shape).encode("ascii"))
        digest.update(str(array.dtype).encode("ascii"))
        digest.update(array.tobytes())
    return digest.hexdigest()


def voxel_reward_terms(coords: np.ndarray, features: np.ndarray) -> dict[str, float]:
    if coords.ndim != 2 or coords.shape[1] != 4 or not len(coords):
        raise RuntimeError("TRELLIS coordinates must have shape [N, 4]")
    xyz = coords[:, 1:].astype(np.float32)
    extent = xyz.max(axis=0) - xyz.min(axis=0) + 1.0
    bbox_volume = float(np.prod(extent))
    occupancy = float(len(np.unique(xyz, axis=0)) / max(bbox_volume, 1.0))
    centered = xyz - xyz.mean(axis=0, keepdims=True)
    spread = float(np.linalg.norm(centered, axis=1).mean() / max(float(extent.max()), 1.0))
    material_variance = float(np.var(features[:, : min(6, features.shape[1])]))
    return {
        "material_variance": material_variance,
        "occupancy": occupancy,
        "spread": spread,
        "total": occupancy + 0.25 * spread + 0.01 * material_variance,
    }


def _artifact(path: Path) -> dict[str, str | None]:
    return {"path": str(path), "sha256": sha256_path(path)}


def _release(torch: Any, *objects: Any) -> None:
    for value in objects:
        if hasattr(value, "cpu"):
            value.cpu()
    del objects
    gc.collect()
    torch.mlu.empty_cache()
    synchronize()


def _flow_euler_sample(
    torch: Any,
    model: Any,
    noise: Any,
    condition: Any,
    negative_condition: Any,
    *,
    steps: int,
    rescale_t: float,
    guidance_strength: float,
    guidance_interval: tuple[float, float],
    step_records: list[dict[str, float]] | None = None,
    **model_kwargs: Any,
) -> Any:
    sample = noise
    times = np.linspace(1.0, 0.0, steps + 1)
    times = rescale_t * times / (1.0 + (rescale_t - 1.0) * times)
    for current, previous in zip(times[:-1], times[1:]):
        if step_records is not None:
            synchronize()
            started_unix = time()
            started = perf_counter()
        timestep = torch.full(
            (sample.shape[0],), 1000.0 * float(current),
            device=sample.device, dtype=torch.float32,
        )
        prediction = model(sample, timestep, condition, **model_kwargs)
        if (
            guidance_strength != 1.0
            and guidance_interval[0] <= current <= guidance_interval[1]
        ):
            negative = model(sample, timestep, negative_condition, **model_kwargs)
            prediction = negative + guidance_strength * (prediction - negative)
        sample = sample - float(current - previous) * prediction
        if step_records is not None:
            synchronize()
            step_records.append(
                {
                    "ended_unix": time(),
                    "started_unix": started_unix,
                    "step_seconds": perf_counter() - started,
                }
            )
    return sample


def combined_flow_records(
    stage_records: dict[str, list[dict[str, float]]], warmup_steps: int
) -> list[dict[str, Any]]:
    lengths = {len(records) for records in stage_records.values()}
    if not stage_records or len(lengths) != 1:
        raise RuntimeError("TRELLIS flow stages produced inconsistent benchmark records")
    count = lengths.pop()
    return [
        {
            "ended_unix": max(records[index]["ended_unix"] for records in stage_records.values()),
            "index": index,
            "stage_seconds": {
                name: records[index]["step_seconds"] for name, records in stage_records.items()
            },
            "started_unix": min(
                records[index]["started_unix"] for records in stage_records.values()
            ),
            "step_seconds": sum(
                records[index]["step_seconds"] for records in stage_records.values()
            ),
            "warmup": index < warmup_steps,
        }
        for index in range(count)
    ]


def _prepare_rgba(image: Image.Image) -> Image.Image:
    rgba = image.convert("RGBA")
    array = np.asarray(rgba)
    alpha = array[:, :, 3]
    foreground = np.argwhere(alpha > 0.8 * 255)
    if not len(foreground):
        raise RuntimeError("TRELLIS input image has an empty alpha foreground")
    x0, y0 = int(foreground[:, 1].min()), int(foreground[:, 0].min())
    x1, y1 = int(foreground[:, 1].max()), int(foreground[:, 0].max())
    center_x, center_y = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    size = max(x1 - x0, y1 - y0, 1)
    box = (
        int(center_x - size / 2),
        int(center_y - size / 2),
        int(center_x + size / 2),
        int(center_y + size / 2),
    )
    cropped = np.asarray(rgba.crop(box), dtype=np.float32) / 255.0
    rgb = cropped[:, :, :3] * cropped[:, :, 3:4]
    return Image.fromarray(np.clip(rgb * 255.0, 0, 255).astype(np.uint8), "RGB")


def _cpu_mesh_sidecar(
    coords: np.ndarray,
    texture_features: np.ndarray,
    output_dir: Path,
) -> tuple[Path, Path, dict[str, Any]]:
    cpu_dependencies = os.environ.get("TRELLIS_CPU_DEPS")
    if cpu_dependencies and cpu_dependencies not in sys.path:
        sys.path.append(cpu_dependencies)
    import trimesh

    xyz = coords[:, 1:].astype(np.int64)
    minimum = xyz.min(axis=0)
    xyz = xyz - minimum + 2
    shape = tuple((xyz.max(axis=0) + 3).tolist())
    occupancy = np.zeros(shape, dtype=bool)
    occupancy[tuple(xyz.T)] = True
    for axis in range(3):
        occupancy |= np.roll(occupancy, 1, axis=axis)
        occupancy |= np.roll(occupancy, -1, axis=axis)
    mesh = trimesh.voxel.ops.multibox(xyz.astype(np.float64), pitch=1.0)
    mesh.apply_translation(-mesh.bounding_box.centroid)
    scale = max(float(mesh.extents.max()), 1e-6)
    mesh.apply_scale(1.0 / scale)
    color = 1.0 / (1.0 + np.exp(-texture_features[:, :3].mean(axis=0)))
    rgba = np.concatenate([np.clip(color * 255.0, 0, 255), [255.0]]).astype(np.uint8)
    mesh.visual.vertex_colors = np.broadcast_to(rgba, (len(mesh.vertices), 4)).copy()
    glb_path = output_dir / "trellis2-diagnostic-multibox.glb"
    mesh.export(glb_path)

    projection = occupancy.max(axis=2).astype(np.uint8) * 255
    preview = Image.fromarray(projection, "L").resize((512, 512), Image.Resampling.NEAREST)
    preview_path = output_dir / "trellis2-diagnostic-multibox-preview.png"
    preview.save(preview_path)
    metrics = {
        "cpu_mesh_faces": int(len(mesh.faces)),
        "cpu_mesh_vertices": int(len(mesh.vertices)),
        "cpu_mesh_method": "trimesh-voxel-multibox",
        "cpu_occupancy_shape": list(occupancy.shape),
        "cpu_sidecar": True,
        "official_o_voxel_decoder": False,
    }
    return glb_path, preview_path, metrics


def _write_output_artifacts(
    output_contract: str,
    arrays: dict[str, np.ndarray],
    output_dir: Path,
) -> tuple[Path, list[dict[str, str | None]], dict[str, Any], dict[str, Any], str, float | None]:
    """Persist real latent evidence, with the multibox export kept diagnostic-only."""
    latent_path = output_dir / "trellis2-staged-latents.npz"
    np.savez_compressed(latent_path, **arrays)
    latent_artifact = _artifact(latent_path)
    semantic_sha = trellis_array_sha(arrays)
    artifacts = [latent_artifact]
    cpu_metrics: dict[str, Any] = {}
    sidecar_seconds: float | None = None
    diagnostic_preview = output_contract == DIAGNOSTIC_MULTIBOX
    if diagnostic_preview:
        started = perf_counter()
        glb_path, preview_path, cpu_metrics = _cpu_mesh_sidecar(
            arrays["coords"], arrays["texture_latent"], output_dir
        )
        sidecar_seconds = perf_counter() - started
        artifacts.extend((_artifact(glb_path), _artifact(preview_path)))
    capability = {
        "schema": "trellis-output-capability-v1",
        "requested": output_contract,
        "produced": "latent_with_diagnostic_multibox" if diagnostic_preview else "latent_only",
        "full_mesh_available": False,
        "formal_mesh_available": False,
        "textured_glb_available": False,
        "formal_output_contract": False,
        "primary_artifact": {
            "path": latent_artifact["path"],
            "sha256": latent_artifact["sha256"],
            "role": "latent",
        },
        "shape_decoder_executed": False,
        "texture_decoder_executed": False,
        "decoded_fields_artifact": None,
        "diagnostic_preview": diagnostic_preview,
    }
    return latent_path, artifacts, cpu_metrics, capability, semantic_sha, sidecar_seconds


def _sha256_config_value(config: dict[str, Any], name: str) -> str | None:
    value = config.get(name)
    if value is None:
        return None
    if (
        type(value) is not str
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(f"{name} must be a lowercase SHA256 digest")
    return value


def _validate_cpu_decode_npz(path: Path, *, max_points: int, resolution: int) -> dict[str, int]:
    with np.load(path, allow_pickle=False) as data:
        if set(data.files) != CPU_DECODE_KEYS:
            raise RuntimeError("TRELLIS CPU decoder artifact fields differ")
        arrays = {name: np.array(data[name], copy=False) for name in data.files}
        coords = arrays["coords"]
        shape_fields = arrays["shape_fields"]
        material_attrs = arrays["material_attrs"]
        vertices = arrays["vertices"]
        faces = arrays["faces"]
        if coords.dtype.kind not in "iu" or coords.ndim != 2 or coords.shape[1] != 4:
            raise RuntimeError("TRELLIS CPU decoder coordinates are invalid")
        if not len(coords) or len(coords) > max_points:
            raise RuntimeError("TRELLIS CPU decoder point count is outside its bound")
        if np.any(coords[:, 0] != 0) or np.any(coords[:, 1:] < 0) or np.any(coords[:, 1:] >= resolution):
            raise RuntimeError("TRELLIS CPU decoder coordinates are outside the grid")
        if len(np.unique(coords, axis=0)) != len(coords):
            raise RuntimeError("TRELLIS CPU decoder coordinates are not unique")
        if shape_fields.shape != (len(coords), 7) or material_attrs.shape != (len(coords), 6):
            raise RuntimeError("TRELLIS CPU decoder field shapes differ")
        if vertices.ndim != 2 or vertices.shape[1] != 3 or not 0 < len(vertices) <= max_points:
            raise RuntimeError("TRELLIS CPU decoder vertices are invalid")
        if faces.dtype.kind not in "iu" or faces.ndim != 2 or faces.shape[1] != 3 or not len(faces):
            raise RuntimeError("TRELLIS CPU decoder faces are invalid")
        if int(faces.min()) < 0 or int(faces.max()) >= len(vertices):
            raise RuntimeError("TRELLIS CPU decoder face index is outside the vertex array")
        for name in ("shape_fields", "material_attrs", "vertices"):
            if arrays[name].dtype.kind != "f" or not np.isfinite(arrays[name]).all():
                raise RuntimeError(f"TRELLIS CPU decoder {name} must be finite floating point")
    return {
        "cpu_decoded_points": int(len(coords)),
        "cpu_geometry_vertices": int(len(vertices)),
        "cpu_geometry_faces": int(len(faces)),
    }


def _validated_cpu_decode_report(
    report: Any,
    *,
    input_path: Path,
    input_sha256: str,
    output_path: Path,
    output_dir: Path,
    source_root: Path,
    weights_root: Path,
    config: dict[str, Any],
    max_points: int,
    resolution: int,
) -> tuple[dict[str, Any], dict[str, int]]:
    expected_keys = {
        "schema", "source_revision", "source_clean", "source_sha256", "sidecar_sha256",
        "input", "output", "decoders", "geometry", "runtime", "timings",
    }
    if not isinstance(report, dict) or set(report) != expected_keys:
        raise RuntimeError("TRELLIS CPU decoder report fields differ")
    if report["schema"] != "genmlu-trellis-cpu-decode-v1":
        raise RuntimeError("TRELLIS CPU decoder report schema differs")
    if report["source_revision"] != PINNED_TRELLIS2_REVISION or report["source_clean"] is not True:
        raise RuntimeError("TRELLIS CPU decoder did not verify the pinned clean source")

    resolved_output = output_path.resolve(strict=True)
    resolved_dir = output_dir.resolve(strict=True)
    try:
        resolved_output.relative_to(resolved_dir)
    except ValueError as error:
        raise RuntimeError("TRELLIS CPU decoder artifact escaped its output directory") from error
    try:
        input_path.resolve(strict=True).relative_to(resolved_dir)
    except ValueError as error:
        raise RuntimeError("TRELLIS CPU decoder input escaped its output directory") from error
    if (
        sha256_path(input_path) != input_sha256
        or report["input"] != {"path": str(input_path.resolve()), "sha256": input_sha256}
    ):
        raise RuntimeError("TRELLIS CPU decoder input identity differs")
    output = report["output"]
    if not isinstance(output, dict) or set(output) != {"path", "sha256", "keys"}:
        raise RuntimeError("TRELLIS CPU decoder output identity fields differ")
    if output["path"] != str(resolved_output) or output["keys"] != sorted(CPU_DECODE_KEYS):
        raise RuntimeError("TRELLIS CPU decoder output path or fields differ")
    actual_output_sha256 = sha256_path(resolved_output)
    if output["sha256"] != actual_output_sha256:
        raise RuntimeError("TRELLIS CPU decoder artifact SHA256 differs after child exit")

    package_sidecar = Path(__file__).resolve().parents[1] / "trellis_cpu_decode.py"
    if report["sidecar_sha256"] != sha256_path(package_sidecar):
        raise RuntimeError("TRELLIS CPU decoder package source SHA256 differs")
    expected_source = {
        "decoder": sha256_path(
            source_root / "trellis2" / "models" / "sc_vaes" / "sparse_unet_vae.py"
        ),
        "geometry": sha256_path(
            source_root / "o-voxel" / "o_voxel" / "convert" / "flexible_dual_grid.py"
        ),
    }
    if report["source_sha256"] != expected_source or any(value is None for value in expected_source.values()):
        raise RuntimeError("TRELLIS CPU decoder official source SHA256 differs")

    decoders = report["decoders"]
    if not isinstance(decoders, dict) or set(decoders) != {"shape", "material"}:
        raise RuntimeError("TRELLIS CPU decoder records are incomplete")
    expected_hashes = {
        "shape": _sha256_config_value(config, "cpu_shape_decoder_sha256"),
        "material": _sha256_config_value(config, "cpu_material_decoder_sha256"),
    }
    filenames = {
        "shape": "shape_dec_next_dc_f16c32_fp16",
        "material": "tex_dec_next_dc_f16c32_fp16",
    }
    for role, expected_count in (("shape", 292), ("material", 284)):
        record = decoders[role]
        expected_record_keys = {
            "checkpoint_resolution", "config_sha256", "expected_weights_sha256",
            "precision_parameter_counts", "requested_geometry_resolution",
            "strict_key_count", "weights_sha256", "output", "stages",
        }
        if (
            not isinstance(record, dict)
            or set(record) != expected_record_keys
            or record.get("strict_key_count") != expected_count
        ):
            raise RuntimeError(f"TRELLIS CPU {role} decoder strict key count differs")
        if record.get("expected_weights_sha256") != expected_hashes[role]:
            raise RuntimeError(f"TRELLIS CPU {role} expected weights SHA256 differs")
        if record.get("requested_geometry_resolution") != resolution:
            raise RuntimeError(f"TRELLIS CPU {role} requested geometry resolution differs")
        if role == "shape" and record.get("checkpoint_resolution") not in {256, 512, 1024}:
            raise RuntimeError("TRELLIS CPU shape checkpoint resolution is unsupported")
        if role == "material" and record.get("checkpoint_resolution") is not None:
            raise RuntimeError("TRELLIS CPU material checkpoint declared a geometry resolution")
        if expected_hashes[role] is not None and record.get("weights_sha256") != expected_hashes[role]:
            raise RuntimeError(f"TRELLIS CPU {role} weights SHA256 differs")
        expected_config_sha = sha256_path(
            weights_root / "ckpts" / f"{filenames[role]}.json"
        )
        if expected_config_sha is None or record.get("config_sha256") != expected_config_sha:
            raise RuntimeError(f"TRELLIS CPU {role} decoder config SHA256 differs")
        stages = record.get("stages")
        if not isinstance(stages, list) or len(stages) != 4:
            raise RuntimeError(f"TRELLIS CPU {role} decoder stage count differs")
        for stage in stages:
            if (
                not isinstance(stage, dict)
                or set(stage) != {
                    "guided_coords_sha256", "input_coords_sha256", "output", "raw_guide_sha256"
                }
                or stage.get("guided_coords_sha256") != stage.get("input_coords_sha256")
                or not isinstance(stage.get("raw_guide_sha256"), str)
                or not isinstance(stage.get("output"), dict)
            ):
                raise RuntimeError(f"TRELLIS CPU {role} guided stage identity differs")
        if not isinstance(record.get("weights_sha256"), str) or len(record["weights_sha256"]) != 64:
            raise RuntimeError(f"TRELLIS CPU {role} weights SHA256 is missing")
        precision_counts = record["precision_parameter_counts"]
        if (
            not isinstance(precision_counts, dict)
            or set(precision_counts) != {"fp16_torso", "fp32_norm", "fp32_head"}
            or any(type(value) is not int or value < 1 for value in precision_counts.values())
        ):
            raise RuntimeError(f"TRELLIS CPU {role} precision contract differs")
        output_record = record["output"]
        if (
            not isinstance(output_record, dict)
            or output_record.get("channels") != (7 if role == "shape" else 6)
            or output_record.get("dtype") != "torch.float32"
            or type(output_record.get("rows")) is not int
            or output_record["rows"] < 1
        ):
            raise RuntimeError(f"TRELLIS CPU {role} output contract differs")
    for shape_stage, material_stage in zip(
        decoders["shape"]["stages"], decoders["material"]["stages"]
    ):
        if (
            shape_stage["guided_coords_sha256"] != material_stage["guided_coords_sha256"]
            or shape_stage["raw_guide_sha256"] != material_stage["raw_guide_sha256"]
            or shape_stage.get("output", {}).get("coords_sha256")
            != material_stage.get("output", {}).get("coords_sha256")
        ):
            raise RuntimeError("TRELLIS CPU shape and material guided stages differ")

    runtime = report["runtime"]
    if (
        not isinstance(runtime, dict)
        or set(runtime) != {
            "device", "peak_rss_bytes", "threads", "torch_device_backend_autoload"
        }
        or runtime.get("device") != "cpu"
        or runtime.get("torch_device_backend_autoload") != "0"
        or runtime.get("threads") != int(config.get("cpu_decode_threads", 4))
        or (
            runtime.get("peak_rss_bytes") is not None
            and (type(runtime["peak_rss_bytes"]) is not int or runtime["peak_rss_bytes"] < 0)
        )
    ):
        raise RuntimeError("TRELLIS CPU decoder runtime identity differs")
    timings = report["timings"]
    expected_timings = {
        "cpu_shape_decoder_load_seconds", "cpu_shape_decoder_forward_seconds",
        "cpu_material_decoder_load_seconds", "cpu_material_decoder_forward_seconds",
        "cpu_geometry_seconds",
    }
    if (
        not isinstance(timings, dict)
        or set(timings) != expected_timings
        or any(
            type(value) not in (int, float) or not np.isfinite(value) or value < 0
            for value in timings.values()
        )
    ):
        raise RuntimeError("TRELLIS CPU decoder timings differ")
    counts = _validate_cpu_decode_npz(
        resolved_output, max_points=max_points, resolution=resolution
    )
    if (
        decoders["shape"]["output"]["rows"] != counts["cpu_decoded_points"]
        or decoders["material"]["output"]["rows"] != counts["cpu_decoded_points"]
        or decoders["shape"]["output"].get("coords_sha256")
        != decoders["material"]["output"].get("coords_sha256")
    ):
        raise RuntimeError("TRELLIS CPU decoder final coordinate identity differs")
    if report["geometry"] != {
        "faces": counts["cpu_geometry_faces"],
        "vertices": counts["cpu_geometry_vertices"],
    }:
        raise RuntimeError("TRELLIS CPU decoder geometry counts differ")
    return report, counts


def _run_cpu_decoder_sidecar(
    *,
    input_path: Path,
    output_dir: Path,
    source_root: Path,
    weights: Path,
    config: dict[str, Any],
) -> tuple[Path, dict[str, Any], dict[str, int]]:
    max_points = int(config.get("cpu_decode_max_points", 1_000_000))
    resolution = int(config["cpu_decode_resolution"])
    threads = int(config.get("cpu_decode_threads", 4))
    timeout = int(config.get("cpu_decode_timeout_seconds", 14_400))
    if min(max_points, resolution, threads, timeout) < 1:
        raise ValueError("TRELLIS CPU decoder bounds, threads, and timeout must be positive")
    input_sha256 = sha256_path(input_path)
    if input_sha256 is None:
        raise RuntimeError("TRELLIS latent artifact SHA256 is unavailable")
    output_path = (output_dir / "trellis2-decoded-fields-geometry.npz").resolve()
    command = [
        sys.executable,
        "-m",
        "genmlu.trellis_cpu_decode",
        "--source-root", str(source_root.resolve()),
        "--weights-root", str(weights.resolve()),
        "--input", str(input_path.resolve()),
        "--input-sha256", input_sha256,
        "--output", str(output_path.resolve()),
        "--resolution", str(resolution),
        "--max-points", str(max_points),
        "--threads", str(threads),
    ]
    for role, key in (
        ("shape", "cpu_shape_decoder_sha256"),
        ("material", "cpu_material_decoder_sha256"),
    ):
        expected = _sha256_config_value(config, key)
        if expected is not None:
            command.extend([f"--{role}-weights-sha256", expected])
    environment = dict(os.environ)
    environment["TORCH_DEVICE_BACKEND_AUTOLOAD"] = "0"
    environment["MLU_VISIBLE_DEVICES"] = ""
    package_source = str(Path(__file__).resolve().parents[2])
    environment["PYTHONPATH"] = package_source + os.pathsep + environment.get("PYTHONPATH", "")
    completed = subprocess.run(
        command,
        check=False,
        capture_output=True,
        text=True,
        timeout=timeout,
        env=environment,
        cwd=output_dir.resolve(),
    )
    if completed.returncode != 0:
        detail = completed.stderr.strip().splitlines()[-1] if completed.stderr.strip() else "no stderr"
        raise RuntimeError(f"TRELLIS CPU decoder child failed: {detail}")
    payloads = [
        line.removeprefix(CPU_DECODE_RESULT_PREFIX)
        for line in completed.stdout.splitlines()
        if line.startswith(CPU_DECODE_RESULT_PREFIX)
    ]
    if len(payloads) != 1:
        raise RuntimeError("TRELLIS CPU decoder child emitted an invalid result record")
    try:
        report = json.loads(payloads[0])
    except json.JSONDecodeError as error:
        raise RuntimeError("TRELLIS CPU decoder child result is not JSON") from error
    report, counts = _validated_cpu_decode_report(
        report,
        input_path=input_path,
        input_sha256=input_sha256,
        output_path=output_path,
        output_dir=output_dir,
        source_root=source_root,
        weights_root=weights,
        config=config,
        max_points=max_points,
        resolution=resolution,
    )
    return output_path, report, counts


def _run_cpu_texture_child(
    config_path: Path, output_dir: Path, config: dict[str, Any], *,
    preflight: bool, extra: list[str] | None = None,
) -> dict[str, Any]:
    from .. import trellis_cpu_texture_export as exporter
    environment = dict(os.environ)
    environment.update(TORCH_DEVICE_BACKEND_AUTOLOAD="0", MLU_VISIBLE_DEVICES="",
                       CNRT_VISIBLE_DEVICES="", CUDA_VISIBLE_DEVICES="",
                       PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", OMP_NUM_THREADS=str(config["threads"]),
                       MKL_NUM_THREADS=str(config["threads"]))
    environment["PYTHONPATH"] = str(Path(__file__).resolve().parents[2]) + os.pathsep + environment.get("PYTHONPATH", "")
    command = [sys.executable, "-B", "-m", "genmlu.trellis_cpu_texture_export", "--config", str(config_path.resolve())]
    command += ["--preflight"] if preflight else (extra or [])
    completed = subprocess.run(command, check=False, capture_output=True, text=True, encoding="utf-8",
                               timeout=config["timeout_seconds"], env=environment, cwd=output_dir.resolve())
    if completed.returncode:
        detail = completed.stderr.strip().splitlines()[-1] if completed.stderr.strip() else "no stderr"
        raise RuntimeError(f"CPU texture child failed: {detail}")
    records = [line[len(exporter.PREFIX):] for line in completed.stdout.splitlines() if line.startswith(exporter.PREFIX)]
    if len(records) != 1:
        raise RuntimeError("CPU texture child result count differs")
    payload = json.loads(records[0])
    if preflight:
        expected = {"schema": exporter.SCHEMA, "native_preflight_executed": True,
                    "dependency_identity": exporter.dependency_identity(config),
                    "exporter_sha256": exporter.sha(Path(exporter.__file__))}
        if payload != expected:
            raise RuntimeError("CPU texture native preflight identity differs")
    return payload


def preflight_cpu_texture_export(config: dict[str, Any], output_dir: Path) -> tuple[Path, dict[str, Any]]:
    from .. import trellis_cpu_texture_export as exporter
    validate_output_contract(config)
    texture_config = exporter.settings(config["cpu_texture_export"])
    path = output_dir / "trellis2-cpu-texture-config.json"
    data = exporter.canonical(texture_config)
    if path.exists():
        # CLI and direct-backend entry points both perform real native checks.
        exporter.require(path.read_bytes() == data, "CPU texture config changed after preflight")
    else:
        exporter.atomic_bytes(path, data)
    _run_cpu_texture_child(path, output_dir, texture_config, preflight=True)
    return path, texture_config


def _native_structure_coords(torch: Any, logits: Any) -> Any:
    if tuple(logits.shape) != (1, 1, 64, 64, 64) or not bool(torch.isfinite(logits).all().item()):
        raise RuntimeError("TRELLIS structure decoder requires finite single-batch 64-grid logits")
    occupied = torch.nn.functional.max_pool3d((logits > 0).float(), 2, 2, 0) > 0.5
    return torch.argwhere(occupied)[:, [0, 2, 3, 4]].int()


def run_trellis2_inference(
    weights: Path,
    config: dict[str, Any],
    output_dir: Path,
    source_root: Path,
) -> dict[str, Any]:
    output_contract = validate_output_contract(config)
    max_tokens = validate_limit(config.get("max_sparse_tokens", 1024))
    decode_cpu_fields = config.get("decode_cpu_fields", False)
    if type(decode_cpu_fields) is not bool:
        raise ValueError("decode_cpu_fields must be a boolean")
    if decode_cpu_fields and output_contract not in {LATENT_ONLY, FULL_MESH}:
        raise ValueError("decode_cpu_fields is only supported with latent_only or full_mesh")
    cpu_decoder_source_value = config.get("cpu_decoder_source_root")
    if cpu_decoder_source_value is not None and (
        type(cpu_decoder_source_value) is not str or not cpu_decoder_source_value
    ):
        raise ValueError("cpu_decoder_source_root must be a non-empty path string")
    cpu_decoder_source_root = (
        Path(cpu_decoder_source_value) if cpu_decoder_source_value is not None else source_root
    ).resolve()
    texture_config_path = None
    if output_contract == FULL_MESH:
        output_dir = output_dir.resolve()
        from .. import trellis_cpu_texture_export as texture_export
        texture_config_path, texture_config = preflight_cpu_texture_export(config, output_dir)
    torch = require_mlu()
    dependency_root = Path(str(config["dependency_root"]))
    image_path = Path(str(config["input_image"]))
    required = [
        weights / "pipeline.json",
        dependency_root / "dinov3-vitl16-pretrain-lvd1689m" / "model.safetensors",
        dependency_root / "trellis-image-large" / "ckpts" / "ss_dec_conv3d_16l8_fp16.safetensors",
        image_path,
    ]
    if decode_cpu_fields:
        for filename in (
            "shape_dec_next_dc_f16c32_fp16",
            "tex_dec_next_dc_f16c32_fp16",
        ):
            required.extend(
                (
                    weights / "ckpts" / f"{filename}.json",
                    weights / "ckpts" / f"{filename}.safetensors",
                )
            )
        required.extend(
            (
                cpu_decoder_source_root / "trellis2" / "models" / "sc_vaes" / "sparse_unet_vae.py",
                cpu_decoder_source_root / "o-voxel" / "o_voxel" / "convert" / "flexible_dual_grid.py",
            )
        )
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise RuntimeError(f"incomplete TRELLIS inference inputs: {missing}")

    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    os.environ["ATTN_BACKEND"] = "sdpa"
    os.environ["SPARSE_ATTN_BACKEND"] = "sdpa"
    os.environ["SPARSE_CONV_BACKEND"] = "none"
    sys.path.insert(0, str(source_root))
    from trellis2 import models
    from trellis2.modules import sparse as sp
    from trellis2.modules.image_feature_extractor import DinoV3FeatureExtractor

    output_dir.mkdir(parents=True, exist_ok=True)
    seed = int(config.get("seed", 20260902))
    steps = int(config.get("sampling_steps", 4))
    warmup_steps = int(config.get("warmup_steps", 0))
    measurement_steps = int(config.get("measurement_steps", 0))
    benchmark_enabled = bool(warmup_steps or measurement_steps)
    if benchmark_enabled:
        if steps != warmup_steps + measurement_steps:
            raise RuntimeError(
                "TRELLIS sampling_steps must equal warmup_steps plus measurement_steps"
            )
    guidance = float(config.get("guidance_strength", 3.0))
    torch.manual_seed(seed)
    torch.mlu.manual_seed_all(seed)
    torch.mlu.reset_peak_memory_stats()
    stage_timings: dict[str, float] = {}
    flow_step_records: dict[str, list[dict[str, float]]] = {
        "shape": [],
        "structure": [],
        "texture": [],
    }
    forward_devices: list[str] = []
    retain_models_on_mlu = bool(config.get("retain_models_on_mlu", False))
    resident_models: list[Any] = []

    def release_stage(model: Any) -> None:
        if retain_models_on_mlu:
            resident_models.append(model)
        else:
            _release(torch, model)

    image = Image.open(image_path)
    prepared = _prepare_rgba(image)
    prepared_path = output_dir / "input-prepared.png"
    prepared.save(prepared_path)

    started = perf_counter()
    extractor = DinoV3FeatureExtractor(
        str(dependency_root / "dinov3-vitl16-pretrain-lvd1689m"), image_size=512
    )
    extractor.to("mlu")
    with torch.no_grad(), torch.autocast(device_type="mlu", dtype=torch.bfloat16):
        condition = extractor([prepared]).to(torch.bfloat16)
    synchronize()
    stage_timings["mlu_image_condition_seconds"] = perf_counter() - started
    forward_devices.append(str(condition.device))
    release_stage(extractor)

    pipeline_config = json.loads((weights / "pipeline.json").read_text(encoding="utf-8"))["args"]
    negative_condition = torch.zeros_like(condition)

    started = perf_counter()
    structure_model = models.from_pretrained(str(weights / "ckpts" / "ss_flow_img_dit_1_3B_64_bf16"))
    structure_model.to("mlu").eval()
    structure_noise = torch.randn(
        1, structure_model.in_channels, structure_model.resolution,
        structure_model.resolution, structure_model.resolution,
        device="mlu", dtype=torch.bfloat16,
    )
    with torch.no_grad(), torch.autocast(device_type="mlu", dtype=torch.bfloat16):
        structure_latent = _flow_euler_sample(
            torch, structure_model, structure_noise, condition, negative_condition,
            steps=steps, rescale_t=5.0, guidance_strength=guidance,
            guidance_interval=(0.6, 1.0),
            step_records=flow_step_records["structure"] if benchmark_enabled else None,
        )
    synchronize()
    stage_timings["mlu_structure_flow_seconds"] = perf_counter() - started
    forward_devices.append(str(structure_latent.device))
    release_stage(structure_model)

    started = perf_counter()
    structure_decoder = models.from_pretrained(
        str(dependency_root / "trellis-image-large" / "ckpts" / "ss_dec_conv3d_16l8_fp16")
    )
    structure_decoder.to("mlu").eval()
    with torch.no_grad(), torch.autocast(device_type="mlu", dtype=torch.float16):
        decoded = structure_decoder(structure_latent.to(torch.float16))
    coords = _native_structure_coords(torch, decoded)
    native_coords = coords.cpu().numpy().copy()
    try:
        admit_native_support(native_coords, max_tokens, full_mesh=output_contract == FULL_MESH)
    except ValueError:
        # Preserve the rejected support without loading either sparse flow model.
        from ..trellis_cpu_texture_export import atomic_bytes, canonical
        import io

        buffer = io.BytesIO()
        np.savez_compressed(buffer, native=native_coords)
        rejected = output_dir / "trellis2-rejected-support.npz"
        atomic_bytes(rejected, buffer.getvalue())
        atomic_bytes(output_dir / "trellis2-support-rejection.json", canonical({
            "native_points": len(native_coords), "max_sparse_tokens": max_tokens,
            "requested_output_contract": output_contract, "native_artifact": _artifact(rejected),
        }))
        raise
    selected = torch.arange(coords.shape[0], device="mlu", dtype=torch.long)
    if output_contract != FULL_MESH and coords.shape[0] > max_tokens:
        selected = torch.linspace(0, coords.shape[0] - 1, max_tokens, device="mlu").long()
        coords = coords.index_select(0, selected)
    support_arrays = {
        "native": native_coords, "retained": coords.cpu().numpy().copy(),
        "selection": selected.cpu().numpy().copy(),
        "shape_input": coords.cpu().numpy().copy(),
    }
    synchronize()
    stage_timings["mlu_structure_decode_seconds"] = perf_counter() - started
    forward_devices.append(str(coords.device))
    release_stage(structure_decoder)

    started = perf_counter()
    shape_model = models.from_pretrained(
        str(weights / "ckpts" / "slat_flow_img2shape_dit_1_3B_512_bf16")
    )
    shape_model.to("mlu").eval()
    shape_noise = sp.SparseTensor(
        feats=torch.randn(coords.shape[0], 32, device="mlu", dtype=torch.bfloat16),
        coords=coords,
    )
    support_arrays["shape_input"] = shape_noise.coords.cpu().numpy().copy()
    require_stage_support(support_arrays["shape_input"], support_arrays["retained"], "shape_input")
    with torch.no_grad(), torch.autocast(device_type="mlu", dtype=torch.bfloat16):
        shape_normalized = _flow_euler_sample(
            torch, shape_model, shape_noise, condition, negative_condition,
            steps=steps, rescale_t=3.0, guidance_strength=guidance,
            guidance_interval=(0.6, 1.0),
            step_records=flow_step_records["shape"] if benchmark_enabled else None,
        )
    shape_mean = torch.tensor(
        pipeline_config["shape_slat_normalization"]["mean"], device="mlu", dtype=torch.bfloat16
    ).unsqueeze(0)
    shape_std = torch.tensor(
        pipeline_config["shape_slat_normalization"]["std"], device="mlu", dtype=torch.bfloat16
    ).unsqueeze(0)
    shape_latent = shape_normalized * shape_std + shape_mean
    support_arrays["shape_output"] = shape_latent.coords.cpu().numpy().copy()
    require_stage_support(support_arrays["shape_output"], support_arrays["retained"], "shape_output")
    synchronize()
    stage_timings["mlu_shape_flow_seconds"] = perf_counter() - started
    forward_devices.append(str(shape_latent.feats.device))
    release_stage(shape_model)

    started = perf_counter()
    texture_model = models.from_pretrained(
        str(weights / "ckpts" / "slat_flow_imgshape2tex_dit_1_3B_512_bf16")
    )
    texture_model.to("mlu").eval()
    texture_noise = sp.SparseTensor(
        feats=torch.randn(coords.shape[0], 32, device="mlu", dtype=torch.bfloat16),
        coords=coords,
    )
    support_arrays["texture_input"] = texture_noise.coords.cpu().numpy().copy()
    require_stage_support(support_arrays["texture_input"], support_arrays["retained"], "texture_input")
    with torch.no_grad(), torch.autocast(device_type="mlu", dtype=torch.bfloat16):
        texture_normalized = _flow_euler_sample(
            torch, texture_model, texture_noise, condition, negative_condition,
            concat_cond=shape_normalized, steps=steps, rescale_t=3.0,
            guidance_strength=1.0, guidance_interval=(0.6, 0.9),
            step_records=flow_step_records["texture"] if benchmark_enabled else None,
        )
    texture_mean = torch.tensor(
        pipeline_config["tex_slat_normalization"]["mean"], device="mlu", dtype=torch.bfloat16
    ).unsqueeze(0)
    texture_std = torch.tensor(
        pipeline_config["tex_slat_normalization"]["std"], device="mlu", dtype=torch.bfloat16
    ).unsqueeze(0)
    texture_latent = texture_normalized * texture_std + texture_mean
    support_arrays["texture_output"] = texture_latent.coords.cpu().numpy().copy()
    require_stage_support(support_arrays["texture_output"], support_arrays["retained"], "texture_output")
    synchronize()
    stage_timings["mlu_texture_flow_seconds"] = perf_counter() - started
    forward_devices.append(str(texture_latent.feats.device))

    arrays = {
        "condition": condition.float().cpu().numpy(),
        "coords": coords.cpu().numpy(),
        "shape_latent": shape_latent.feats.float().cpu().numpy(),
        "structure_latent": structure_latent.float().cpu().numpy(),
        "texture_latent": texture_latent.feats.float().cpu().numpy(),
    }
    if not all(np.isfinite(value).all() for value in arrays.values()):
        raise RuntimeError("TRELLIS inference produced non-finite tensors")
    rewards = voxel_reward_terms(arrays["coords"], arrays["texture_latent"])
    release_stage(texture_model)
    support_path = output_dir / "trellis2-sparse-support.npz"
    sparse_support = write_proof(support_path, support_arrays, full_mesh=output_contract == FULL_MESH)
    latent_path, output_artifacts, cpu_metrics, output_capability, semantic_sha, sidecar_seconds = (
        _write_output_artifacts(output_contract, arrays, output_dir)
    )
    sparse_support["latent"] = _artifact(latent_path)
    output_artifacts.append(_artifact(support_path))

    cpu_decoder_source_identity = None
    texture_export_report = None
    primary_path = latent_path
    if decode_cpu_fields:
        decoded_path, cpu_decode_report, cpu_decode_counts = _run_cpu_decoder_sidecar(
            input_path=latent_path,
            output_dir=output_dir,
            source_root=cpu_decoder_source_root,
            weights=weights,
            config=config,
        )
        output_artifacts.append(_artifact(decoded_path))
        cpu_metrics.update(cpu_decode_counts)
        cpu_metrics.update(
            {
                "cpu_decode_peak_rss_bytes": cpu_decode_report["runtime"]["peak_rss_bytes"],
                "cpu_decoder_key_counts": {
                    role: cpu_decode_report["decoders"][role]["strict_key_count"]
                    for role in ("shape", "material")
                },
                "cpu_decoder_stage_counts": {
                    role: len(cpu_decode_report["decoders"][role]["stages"])
                    for role in ("shape", "material")
                },
                "cpu_decoder_weights_sha256": {
                    role: cpu_decode_report["decoders"][role]["weights_sha256"]
                    for role in ("shape", "material")
                },
            }
        )
        stage_timings.update(cpu_decode_report["timings"])
        decoded_artifact = {
            "path": str(decoded_path),
            "sha256": sha256_path(decoded_path),
            "role": "decoded_fields_and_geometry",
        }
        output_capability.update(
            {
                "shape_decoder_executed": True,
                "texture_decoder_executed": True,
                "decoded_fields_artifact": decoded_artifact,
            }
        )
        cpu_decoder_source_identity = {
            "clean": True,
            "revision": cpu_decode_report["source_revision"],
            "source_sha256": cpu_decode_report["source_sha256"],
        }
        if output_contract == FULL_MESH:
            decode_report_path = output_dir / "trellis2-cpu-decode-report.json"
            texture_export.atomic_bytes(decode_report_path, texture_export.canonical(cpu_decode_report))
            primary_path = output_dir / "trellis2-textured.glb"
            payload = _run_cpu_texture_child(
                texture_config_path, output_dir, texture_config, preflight=False,
                extra=["--input", str(decoded_path.resolve()), "--input-sha256", sha256_path(decoded_path),
                       "--decode-report", str(decode_report_path.resolve()), "--decode-report-sha256", sha256_path(decode_report_path),
                       "--output", str(primary_path.resolve())],
            )
            expected_report = primary_path.with_suffix(".report.json")
            if set(payload) != {"path", "sha256"} or Path(payload["path"]).resolve() != expected_report.resolve():
                raise RuntimeError("CPU texture child report path differs")
            report = texture_export.validate_export(expected_report, payload["sha256"], texture_config, primary_path, decoded_path)
            texture_export_report = {"path": str(expected_report), "sha256": payload["sha256"]}
            output_artifacts.extend(_artifact(path) for path in (
                texture_config_path, decode_report_path, primary_path,
                primary_path.with_suffix(".correspondence.npz"), expected_report,
            ))
            output_capability.update(
                produced="textured_glb", full_mesh_available=True, formal_mesh_available=True,
                textured_glb_available=True, formal_output_contract=True,
                primary_artifact={"path": str(primary_path), "sha256": sha256_path(primary_path), "role": "textured_glb"},
            )
            cpu_metrics["cpu_texture_export"] = report["product"]
            cpu_metrics["cpu_texture_peak_rss_bytes"] = report["runtime"]["peak_rss_bytes"]
            stage_timings["cpu_texture_export_seconds"] = report["runtime"]["seconds"]

    if output_contract == DIAGNOSTIC_MULTIBOX:
        if sidecar_seconds is None:
            raise RuntimeError("TRELLIS diagnostic sidecar timing was not recorded")
        stage_timings["cpu_mesh_sidecar_seconds"] = sidecar_seconds
    logs: list[dict[str, str | None]] = []
    measured_seconds: list[float] = []
    if benchmark_enabled:
        benchmark_records = combined_flow_records(flow_step_records, warmup_steps)
        measured_records = benchmark_records[warmup_steps:]
        if len(measured_records) != measurement_steps:
            raise RuntimeError("TRELLIS inference produced an incomplete measurement window")
        step_path = output_dir / "steps.ndjson"
        step_path.write_text(
            "".join(json.dumps(record, sort_keys=True) + "\n" for record in benchmark_records),
            encoding="utf-8",
        )
        logs.append(_artifact(step_path))
        measured_seconds = [record["step_seconds"] for record in measured_records]
    metrics = {
        **cpu_metrics,
        "condition_tokens": int(arrays["condition"].shape[1]),
        "latent_semantic_sha256": semantic_sha,
        "measurement_steps": measurement_steps,
        "mlu_memory": memory_stats(),
        "peak_reserved_bytes": torch.mlu.max_memory_reserved(),
        "reward_terms": rewards,
        "sampling_steps": steps,
        "sparse_tokens": int(arrays["coords"].shape[0]),
        "native_sparse_tokens": sparse_support["native_points"],
        "dropped_sparse_tokens": sparse_support["dropped_points"],
        "retain_models_on_mlu": retain_models_on_mlu,
        "resident_model_count": len(resident_models),
        "warmup_steps": warmup_steps,
    }
    if measured_seconds:
        metrics.update(
            {
                "denoising_step_seconds_max": max(measured_seconds),
                "denoising_step_seconds_median": float(np.median(measured_seconds)),
                "denoising_step_seconds_min": min(measured_seconds),
                "denoising_steps_per_second": measurement_steps / sum(measured_seconds),
            }
        )
    checks = {
        "finite_tensors": True,
        "main_forward_device": all(device.startswith("mlu") for device in forward_devices),
        "formal_output_contract": output_contract == FULL_MESH,
        "requested_output_contract_satisfied": True,
    }
    evidence_path = output_dir / "inference-evidence.json"
    evidence_path.write_text(
        json.dumps(
            {"checks": checks, "forward_devices": forward_devices, "metrics": metrics,
             "output_capability": output_capability,
             "sparse_support": sparse_support,
             "stage_timings": stage_timings},
            indent=2, sort_keys=True,
        ) + "\n",
        encoding="utf-8",
    )
    result = {
        "artifact": primary_path,
        "artifacts": [
            *output_artifacts, _artifact(prepared_path), _artifact(evidence_path),
        ],
        "checks": checks,
        "observations": {"mlu_utilization_captured": False},
        "logs": logs,
        "metrics": metrics,
        "output_capability": output_capability,
        "sparse_support": sparse_support,
        "stage_timings": stage_timings,
    }
    if cpu_decoder_source_identity is not None:
        result["cpu_decoder_source_identity"] = cpu_decoder_source_identity
    if texture_export_report is not None:
        result["cpu_texture_export_report"] = texture_export_report
    return result
