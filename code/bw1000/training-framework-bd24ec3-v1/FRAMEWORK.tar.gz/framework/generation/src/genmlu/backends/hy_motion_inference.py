from __future__ import annotations

import hashlib
import json
import os
try:
    import resource
except ModuleNotFoundError:  # Windows can inspect the CLI but cannot run an MLU backend.
    resource = None
import statistics
import sys
from contextlib import contextmanager
from pathlib import Path
from time import perf_counter, time
from typing import Any, Iterator

import numpy as np
import yaml

from ..manifest import sha256_path
from ..runtime import memory_stats, require_mlu, synchronize


def motion_array_sha(arrays: dict[str, np.ndarray]) -> str:
    digest = hashlib.sha256()
    for name in sorted(arrays):
        value = np.ascontiguousarray(arrays[name])
        digest.update(name.encode("ascii"))
        digest.update(str(value.dtype).encode("ascii"))
        digest.update(np.asarray(value.shape, dtype=np.int64).tobytes())
        digest.update(value.tobytes())
    return digest.hexdigest()


def motion_arrays_finite(arrays: dict[str, np.ndarray]) -> bool:
    return bool(arrays) and all(np.isfinite(value).all() for value in arrays.values())


def _repeat_determinism(values: list[str], benchmark_mode: bool) -> bool | None:
    if benchmark_mode or len(values) < 2:
        return None
    return len(set(values)) == 1


def _checks_pass(checks: dict[str, bool | None]) -> bool:
    return all(value is None or bool(value) for value in checks.values())


@contextmanager
def working_directory(path: Path) -> Iterator[None]:
    previous = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(previous)


def _motion_arrays(output: dict[str, Any]) -> dict[str, np.ndarray]:
    names = ("latent_denorm", "keypoints3d", "rot6d", "transl", "root_rotations_mat")
    arrays = {
        name: output[name].detach().cpu().float().numpy()
        for name in names
        if name in output and hasattr(output[name], "detach")
    }
    if set(arrays) != set(names):
        missing = sorted(set(names) - set(arrays))
        raise RuntimeError(f"HY-Motion output is missing tensors: {missing}")
    if not motion_arrays_finite(arrays):
        raise RuntimeError("HY-Motion returned non-finite motion tensors")
    return arrays


def run_hy_motion_inference(
    weights: Path,
    config: dict[str, Any],
    output_dir: Path,
    source_root: Path,
) -> dict[str, Any]:
    if not weights.is_dir():
        raise RuntimeError(f"HY-Motion weights are missing: {weights}")
    if not source_root.is_dir():
        raise RuntimeError(f"HY-Motion source is missing: {source_root}")
    qwen_path = Path(str(config["qwen_path"]))
    clip_path = Path(str(config["clip_path"]))
    for dependency in (qwen_path, clip_path):
        if not dependency.is_dir():
            raise RuntimeError(f"HY-Motion text encoder is missing: {dependency}")

    variant = str(config.get("variant", "HY-Motion-1.0-Lite"))
    variant_root = weights / variant
    model_config_path = variant_root / "config.yml"
    checkpoint_path = variant_root / "latest.ckpt"
    if not model_config_path.is_file() or not checkpoint_path.is_file():
        raise RuntimeError(f"incomplete HY-Motion variant: {variant_root}")

    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    os.environ["HY_MOTION_QWEN_PATH"] = str(qwen_path)
    os.environ["HY_MOTION_CLIP_PATH"] = str(clip_path)
    torch = require_mlu()
    output_dir.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(source_root))

    from hymotion.utils.loaders import load_object

    with working_directory(source_root):
        model_config = dict(yaml.safe_load(model_config_path.read_text(encoding="utf-8")))
        pipeline_args = dict(model_config["train_pipeline_args"])
        pipeline_args["mean_std_dir"] = str(source_root / "stats")
        pipeline_args["random_generator_on_gpu"] = False
        infer_scheduler = dict(pipeline_args.get("infer_noise_scheduler_cfg", {}))
        infer_scheduler["validation_steps"] = int(config.get("num_inference_steps", 50))
        pipeline_args["infer_noise_scheduler_cfg"] = infer_scheduler

        torch.mlu.reset_peak_memory_stats()
        device = torch.device("mlu")
        load_started = perf_counter()
        pipeline = load_object(
            model_config["train_pipeline"],
            pipeline_args,
            network_module=model_config["network_module"],
            network_module_args=model_config["network_module_args"],
        )
        pipeline.to(device=device, dtype=torch.bfloat16)
        pipeline.load_in_demo(str(checkpoint_path), build_text_encoder=True)
        pipeline.text_encoder.to(device=device, dtype=torch.bfloat16)
        pipeline.eval()
        synchronize()
        load_seconds = perf_counter() - load_started

        prompt = str(config["prompt"])
        encode_started = perf_counter()
        hidden_state = pipeline.encode_text({"text": [prompt]})
        synchronize()
        text_encode_seconds = perf_counter() - encode_started
        pipeline.text_encoder.to("cpu")
        del pipeline.text_encoder
        torch.mlu.empty_cache()

        input_devices: list[str] = []
        output_devices: list[str] = []

        def capture_input(_module: Any, _args: tuple[Any, ...], kwargs: dict[str, Any]) -> None:
            input_devices.append(str(getattr(kwargs.get("x"), "device", "missing")))

        def capture_output(_module: Any, _args: tuple[Any, ...], output: Any) -> None:
            output_devices.append(str(getattr(output, "device", "missing")))

        pre_handle = pipeline.motion_transformer.register_forward_pre_hook(capture_input, with_kwargs=True)
        post_handle = pipeline.motion_transformer.register_forward_hook(capture_output)
        warmup_steps = int(config.get("warmup_iterations", 0))
        measure_steps = int(config.get("measure_iterations", 0))
        benchmark_mode = measure_steps > 0
        repeat_count = warmup_steps + measure_steps if benchmark_mode else int(config.get("repeats", 2))
        seed = int(config.get("seed", 42))
        runs: list[dict[str, Any]] = []
        artifacts: list[dict[str, Any]] = []
        semantic_shas: list[str] = []

        for index in range(repeat_count):
            synchronize()
            started_unix = time()
            started = perf_counter()
            output = pipeline.generate(
                text=prompt,
                seed_input=[seed],
                duration_slider=float(config.get("duration_seconds", 2.0)),
                cfg_scale=float(config.get("cfg_scale", 5.0)),
                hidden_state_dict=hidden_state,
            )
            synchronize()
            generation_seconds = perf_counter() - started
            ended_unix = time()
            arrays = _motion_arrays(output)
            semantic_sha = motion_array_sha(arrays)
            semantic_shas.append(semantic_sha)
            artifact_path = output_dir / f"motion-{index + 1}.npz"
            sidecar_started = perf_counter()
            np.savez_compressed(artifact_path, **arrays)
            sidecar_seconds = perf_counter() - sidecar_started
            artifact = {"path": str(artifact_path), "sha256": sha256_path(artifact_path)}
            artifacts.append(artifact)
            runs.append(
                {
                    "index": index,
                    "started_unix": started_unix,
                    "ended_unix": ended_unix,
                    "generation_seconds": generation_seconds,
                    "cpu_npz_seconds": sidecar_seconds,
                    "semantic_sha256": semantic_sha,
                    "shapes": {name: list(value.shape) for name, value in arrays.items()},
                    "artifact": artifact,
                }
            )

        pre_handle.remove()
        post_handle.remove()
        measured = runs[warmup_steps:] if benchmark_mode else runs
        generation_times = [run["generation_seconds"] for run in measured]
        deterministic = _repeat_determinism(semantic_shas, benchmark_mode)
        summary = {
            "variant": variant,
            "prompt": prompt,
            "seed": seed,
            "num_inference_steps": int(config.get("num_inference_steps", 50)),
            "forward_input_devices": input_devices,
            "forward_output_devices": output_devices,
            "deterministic": deterministic,
            "runs": runs,
        }
        summary_path = output_dir / "summary.json"
        summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        artifacts.append({"path": str(summary_path), "sha256": sha256_path(summary_path)})
        step_log = output_dir / "steps.ndjson"
        step_log.write_text("".join(json.dumps(run, sort_keys=True) + "\n" for run in runs), encoding="utf-8")

        main_forward_device = bool(input_devices) and all(
            "mlu" in item for item in input_devices + output_devices
        )
        checks = {
            "finite_tensors": True,
            "main_forward_device": main_forward_device,
            "attention_mlu_sdpa_fallback": True,
            "valid_artifact": all(Path(item["path"]).stat().st_size > 0 for item in artifacts),
            "deterministic_repeat": deterministic,
        }
        if benchmark_mode:
            checks["benchmark_measurement_count"] = len(measured) == measure_steps
        if not _checks_pass(checks):
            raise RuntimeError(f"HY-Motion inference checks failed: {checks}")

        metrics = {
            "variant": variant,
            "model_load_seconds": load_seconds,
            "text_encode_seconds": text_encode_seconds,
            "warmup_steps": warmup_steps,
            "measure_steps": len(measured),
            "generation_seconds": generation_times,
            "sample_seconds_median": statistics.median(generation_times),
            "sample_seconds_min": min(generation_times),
            "sample_seconds_max": max(generation_times),
            "samples_per_second": 1.0 / statistics.median(generation_times),
            "peak_cpu_rss_bytes": int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024),
            "mlu_memory": memory_stats(),
            "mlu_utilization": None,
        }
        return {
            "artifact": Path(artifacts[0]["path"]),
            "artifacts": artifacts,
            "metrics": metrics,
            "stage_timings": {
                "model_load_seconds": load_seconds,
                "text_encode_seconds": text_encode_seconds,
                "generation_seconds": generation_times,
                "cpu_npz_seconds": [run["cpu_npz_seconds"] for run in measured],
            },
            "checks": checks,
            "logs": [
                {"path": str(step_log), "sha256": sha256_path(step_log)},
                {"path": str(summary_path), "sha256": sha256_path(summary_path)},
            ],
        }
