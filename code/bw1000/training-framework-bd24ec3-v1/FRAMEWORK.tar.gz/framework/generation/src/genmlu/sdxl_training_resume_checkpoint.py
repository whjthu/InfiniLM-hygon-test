"""Single-process native SDXL LoRA checkpoint and data-boundary contract."""

from __future__ import annotations

import hashlib
import importlib
import inspect
import json
import math
import random
import re
from pathlib import Path
from typing import Any


SCHEMA = "sdxl-native-lora-full-step-v1"
MANIFEST = "genmlu-checkpoint.json"
STATE = "genmlu-state.pt"
NATIVE_FILES = {"pytorch_lora_weights.safetensors", "optimizer.bin", "scheduler.bin", "random_states_0.pkl"}
FILES = NATIVE_FILES | {STATE}
DIFFUSERS_REVISION = "a3608b512ed7248499a44c61d954965ed9bdae4d"


class CheckpointError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise CheckpointError(message)


def file_sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def json_sha(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _is_sha(value: Any) -> bool:
    return type(value) is str and re.fullmatch("[0-9a-f]{64}", value) is not None


def tree_identity(root: Path, *, python_only: bool = False) -> str:
    root = root.resolve()
    records = []
    for path in sorted(root.rglob("*.py" if python_only else "*")):
        if not path.is_file() or "__pycache__" in path.parts:
            continue
        require(path.resolve().is_relative_to(root), "identity file escapes its root")
        records.append({"path": path.relative_to(root).as_posix(), "bytes": path.stat().st_size, "sha256": file_sha(path)})
    require(bool(records), "empty model, source, or data inventory")
    return json_sha(records)


def _atomic_json(path: Path, value: Any) -> None:
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def validate_contract(value: Any, *, expected: dict[str, Any] | None = None) -> None:
    """Validate the bounded producer identity without importing the model stack."""
    require(type(value) is dict and set(value) == {
        "plan", "weights_sha256", "data", "diffusers_revision", "source_sha256", "helper_sha256",
        "backend_sha256", "imports", "parameters", "buffers", "optimizer", "scheduler", "lora_policy", "mlu",
    }, "native contract field inventory mismatch")
    require(type(value["mlu"]) is bool and value["mlu"], "native contract requires MLU")
    for key in ("weights_sha256", "source_sha256", "helper_sha256", "backend_sha256"):
        require(_is_sha(value[key]), f"invalid native contract hash: {key}")
    require(value["diffusers_revision"] == DIFFUSERS_REVISION, "native Diffusers revision mismatch")
    plan = value["plan"]
    require(type(plan) is dict, "native plan must be a mapping")
    fixed = {"mixed_precision": "bf16", "gradient_accumulation_steps": 1, "train_batch_size": 1,
             "dataloader_num_workers": 0, "center_crop": True, "random_flip": False,
             "train_text_encoder": False, "use_8bit_adam": False, "validation_prompt": None,
             "lr_scheduler": "constant", "lr_warmup_steps": 0, "genmlu_full_checkpoint": True}
    require(all(key in plan and type(plan[key]) is type(item) and plan[key] == item
                for key, item in fixed.items()), "unsupported native full-checkpoint plan")
    require(type(plan.get("seed")) is int and type(plan.get("max_train_steps")) is int
            and plan["max_train_steps"] > 0 and type(plan.get("genmlu_measurement_warmup_steps")) is int
            and 0 <= plan["genmlu_measurement_warmup_steps"] < plan["max_train_steps"], "invalid native step/seed plan")
    require(type(plan.get("learning_rate")) in (int, float) and math.isfinite(plan["learning_rate"])
            and plan["learning_rate"] > 0 and type(plan.get("rank")) is int and plan["rank"] > 0
            and type(plan.get("resolution")) is int and plan["resolution"] > 0, "invalid native numeric plan")
    require(type(plan.get("genmlu_runtime_image_id")) is str
            and re.fullmatch("sha256:[0-9a-f]{64}", plan["genmlu_runtime_image_id"]) is not None,
            "runtime image digest is required")
    data = value["data"]
    require(type(data) is dict and set(data) == {"records", "tree_sha256", "ordered_sha256"}
            and _is_sha(data["tree_sha256"]) and _is_sha(data["ordered_sha256"]), "invalid native data identity")
    records = data["records"]
    require(type(records) is list and bool(records), "empty native dataset")
    paths = []
    for index, row in enumerate(records):
        require(type(row) is dict and set(row) == {"id", "path", "sha256", "caption_sha256"}
                and type(row["id"]) is int and row["id"] == index and _is_sha(row["sha256"])
                and _is_sha(row["caption_sha256"]), "invalid ordered native data row")
        path = row["path"]
        require(type(path) is str and bool(path) and "\\" not in path and ":" not in path
                and not path.startswith("/") and all(part not in ("", ".", "..") for part in path.split("/")),
                "native data row path escapes its root")
        paths.append(path)
    require(len(paths) == len(set(paths)) and json_sha(records) == data["ordered_sha256"], "native data order/hash mismatch")
    for key in ("parameters", "buffers"):
        schema = value[key]
        require(type(schema) is list and (bool(schema) or key == "buffers"), "empty native parameter schema")
        names = []
        for entry in schema:
            require(type(entry) is dict and set(entry) == {"name", "dtype", "shape"}
                    and type(entry["name"]) is str and bool(entry["name"]) and type(entry["dtype"]) is str
                    and entry["dtype"].startswith("torch.") and type(entry["shape"]) is list
                    and all(type(size) is int and size >= 0 for size in entry["shape"]), "invalid native tensor schema")
            names.append(entry["name"])
        require(len(names) == len(set(names)), "duplicate native tensor name")
    for key in ("optimizer", "scheduler"):
        entry = value[key]
        require(type(entry) is dict and set(entry) == {"module", "class", "source_sha256"}
                and all(type(entry[field]) is str and bool(entry[field]) for field in ("module", "class"))
                and _is_sha(entry["source_sha256"]), "invalid native state implementation identity")
    require(value["optimizer"]["module"] == "torch.optim.adamw" and value["optimizer"]["class"] == "AdamW",
            "native full checkpoint requires ordinary AdamW")
    require(type(value["lora_policy"]) is dict, "invalid native LoRA policy")
    imports = value["imports"]
    require(type(imports) is dict and set(imports) == {
        "torch", "numpy", "accelerate", "diffusers", "peft", "transformers", "datasets", "torchvision", "torch_mlu",
    }, "native dependency inventory mismatch")
    for entry in imports.values():
        require(type(entry) is dict and set(entry) == {"origin", "sha256", "version"}
                and type(entry["origin"]) is str and bool(entry["origin"]) and _is_sha(entry["sha256"])
                and type(entry["version"]) is str and bool(entry["version"]), "invalid native dependency identity")
    json_sha(value)
    if expected is not None:
        require(json_sha(value) == json_sha(expected), "native checkpoint plan/source/data/runtime mismatch")


def preflight(checkpoint: Path) -> dict[str, Any]:
    """Verify the completion marker and every file before any pickle is read."""
    root = checkpoint.resolve()
    try:
        document = json.loads((root / MANIFEST).read_text(encoding="utf-8"))
        require(type(document) is dict and set(document) == {
            "schema", "boundary", "step", "next_step", "contract", "state_sha256", "files", "integrity_sha256",
        }, "incomplete native checkpoint manifest")
        require(document["schema"] == SCHEMA and document["boundary"] == "after-complete-optimizer-scheduler-update",
                "unsupported native checkpoint boundary")
        step = document["step"]
        require(type(step) is int and step > 0 and type(document["next_step"]) is int and document["next_step"] == step + 1
                and root.name == f"checkpoint-{step}", "native checkpoint step/path mismatch")
        require(type(document["contract"]) is dict and _is_sha(document["state_sha256"]), "invalid native checkpoint contract")
        validate_contract(document["contract"])
        require(step <= document["contract"]["plan"]["max_train_steps"], "native checkpoint exceeds its original plan")
        require(_is_sha(document["integrity_sha256"]) and document["integrity_sha256"] == json_sha({
            key: value for key, value in document.items() if key != "integrity_sha256"
        }), "native checkpoint manifest integrity mismatch")
        require(type(document["files"]) is dict and set(document["files"]) == FILES,
                "incomplete native checkpoint file inventory")
        require({p.name for p in root.iterdir()} == FILES | {MANIFEST}, "unexpected native checkpoint files")
        for name, entry in document["files"].items():
            path = root / name
            require(type(entry) is dict and set(entry) == {"bytes", "sha256"}
                    and type(entry["bytes"]) is int and entry["bytes"] > 0 and _is_sha(entry["sha256"]),
                    "invalid native checkpoint file record")
            require(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(root)
                    and path.stat().st_size == entry["bytes"] and file_sha(path) == entry["sha256"],
                    f"native checkpoint file integrity mismatch: {name}")
        return document
    except CheckpointError:
        raise
    except Exception as error:
        raise CheckpointError("missing or malformed native full-checkpoint manifest") from error


def restricted_load(path: Path, *, numpy_rng: bool = False) -> Any:
    import torch

    try:
        if not numpy_rng:
            return torch.load(path, map_location="cpu", weights_only=True)
        import numpy as np

        reconstruct = importlib.import_module("numpy.core.multiarray")._reconstruct
        with torch.serialization.safe_globals([
            (reconstruct, "numpy.core.multiarray._reconstruct"),
            (reconstruct, "numpy._core.multiarray._reconstruct"),
            np.ndarray, np.dtype, type(np.dtype(np.uint32)),
        ]):
            return torch.load(path, map_location="cpu", weights_only=True)
    except Exception as error:
        raise CheckpointError(f"restricted native checkpoint load failed: {path.name}") from error


def cpu_tree(value: Any) -> Any:
    import numpy as np
    import torch

    if isinstance(value, torch.Tensor):
        require(value.layout == torch.strided, "unsupported checkpoint tensor layout")
        result = value.detach().cpu().clone()
        require(not (result.is_floating_point() or result.is_complex()) or bool(torch.isfinite(result).all()),
                "non-finite checkpoint tensor")
        return result
    if type(value) is np.ndarray:
        require(value.dtype == np.dtype(np.uint32) and value.shape == (624,), "unsupported NumPy RNG array")
        return value.copy()
    if isinstance(value, dict):
        require(all(type(key) in (str, int) for key in value), "unsupported checkpoint key")
        return {key: cpu_tree(item) for key, item in value.items()}
    if type(value) in (list, tuple):
        return type(value)(cpu_tree(item) for item in value)
    require(type(value) in (str, int, float, bool, type(None)), "unsupported checkpoint value")
    require(type(value) is not float or math.isfinite(value), "non-finite checkpoint scalar")
    return value


def state_sha(value: Any) -> str:
    """Type-tagged raw bytes preserve dtype, signed zero and tensor layout."""
    import numpy as np
    import torch

    digest = hashlib.sha256()

    def token(data: bytes) -> None:
        digest.update(len(data).to_bytes(8, "big"))
        digest.update(data)

    def visit(item: Any) -> None:
        token(f"{type(item).__module__}.{type(item).__qualname__}".encode())
        if type(item) is dict:
            token(str(len(item)).encode())
            for key in sorted(item, key=lambda key: (type(key).__name__, repr(key))):
                visit(key)
                visit(item[key])
        elif type(item) in (list, tuple):
            token(str(len(item)).encode())
            for child in item:
                visit(child)
        elif type(item) is torch.Tensor:
            token(str((item.dtype, tuple(item.shape), tuple(item.stride()))).encode())
            token(item.detach().cpu().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes())
        elif type(item) is np.ndarray:
            token(str((item.dtype, item.shape, item.strides)).encode())
            token(item.tobytes(order="C"))
        else:
            token(repr(item).encode())

    visit(cpu_tree(value))
    return digest.hexdigest()


def capture_rng(mlu: bool) -> dict[str, Any]:
    import numpy as np
    import torch

    return cpu_tree({"python": random.getstate(), "numpy": np.random.get_state(),
                     "torch_cpu": torch.get_rng_state(), "mlu": torch.mlu.get_rng_state_all() if mlu else []})


def validate_rng(value: Any, mlu: bool) -> None:
    import numpy as np
    import torch

    require(type(value) is dict and set(value) == {"python", "numpy", "torch_cpu", "mlu"}, "RNG stream inventory mismatch")
    state = value["numpy"]
    require(type(state) is tuple and len(state) == 5 and state[0] == "MT19937"
            and type(state[1]) is np.ndarray and state[1].dtype == np.dtype(np.uint32) and state[1].shape == (624,)
            and type(state[2]) is int and 0 <= state[2] <= 624
            and type(state[3]) is int and state[3] in (0, 1)
            and type(state[4]) is float and math.isfinite(state[4]), "malformed MT19937 state")
    random.Random().setstate(value["python"])
    np.random.RandomState(0).set_state(state)
    torch.Generator().set_state(value["torch_cpu"])
    require(type(value["mlu"]) is list and len(value["mlu"]) == (1 if mlu else 0), "native single-device RNG inventory mismatch")
    for tensor in value["mlu"]:
        require(type(tensor) is torch.Tensor and tensor.device.type == "cpu" and tensor.dtype == torch.uint8
                and tensor.ndim == 1 and tensor.numel() > 0, "invalid MLU RNG byte state")
        try:
            live = torch.mlu.default_generators[0]
            probe = live.clone_state()
            require(probe is not live, "MLU RNG clone aliases the global generator")
            probe.set_state(tensor.clone())
            require(torch.equal(probe.get_state().cpu(), tensor), "MLU RNG private clone roundtrip mismatch")
        except CheckpointError:
            raise
        except Exception as error:
            raise CheckpointError("cannot validate MLU RNG independently before applying state") from error


def restore_rng(value: dict[str, Any], mlu: bool) -> None:
    import numpy as np
    import torch

    validate_rng(value, mlu)
    random.setstate(value["python"])
    np.random.set_state(value["numpy"])
    torch.set_rng_state(value["torch_cpu"])
    if mlu:
        torch.mlu.set_rng_state_all(value["mlu"])


def validate_cursor(state: Any, count: int) -> None:
    require(type(count) is int and count > 0, "invalid native dataset row count")
    require(type(state) is dict and set(state) == {"epoch", "consumed", "order", "generator"}, "data cursor fields mismatch")
    require(type(state["epoch"]) is int and state["epoch"] >= 0
            and type(state["consumed"]) is int and 0 <= state["consumed"] <= count, "invalid data cursor")
    order = state["order"]
    require(type(order) is list and len(order) == count
            and all(type(index) is int for index in order) and sorted(order) == list(range(count)),
            "sampler order is incomplete or duplicated")


def make_batch_sampler(original: Any, generator: Any, torch: Any) -> Any:
    """Keep the native shuffle order; count consumed updates, not prefetched batches."""
    require(original.batch_size == 1 and not original.drop_last, "native full resume requires batch1 without drop_last")

    class ResumeBatchSampler(torch.utils.data.BatchSampler):
        def __init__(self):
            super().__init__(original.sampler, 1, False)
            self.epoch = 0
            self.consumed = 0
            self.order = None

        def __iter__(self):
            if self.order is None:
                self.order = [batch[0] for batch in original]
            for index in self.order[self.consumed:]:
                yield [index]

        def __len__(self):
            return len(original)

        def set_epoch(self, epoch):
            if epoch != self.epoch:
                require(epoch == self.epoch + 1 and self.consumed == len(original), "data epoch advanced before exhaustion")
                self.epoch, self.consumed, self.order = epoch, 0, None

        def state_dict(self):
            require(self.order is not None, "sampler has not produced an epoch order")
            return {"epoch": self.epoch, "consumed": self.consumed, "order": list(self.order),
                    "generator": generator.get_state().clone()}

        def load_state_dict(self, state):
            validate_cursor(state, len(original))
            generator.set_state(state["generator"])
            self.epoch, self.consumed, self.order = state["epoch"], state["consumed"], list(state["order"])

        def consume(self, sample_ids):
            require(self.order is not None and self.consumed < len(original)
                    and type(sample_ids) is list and len(sample_ids) == 1 and type(sample_ids[0]) is int
                    and sample_ids == self.order[self.consumed:self.consumed + 1],
                    "actual sample does not match the restored data cursor")
            self.consumed += 1

    return ResumeBatchSampler()


def bind_dataset(dataset: Any, image_column: str, caption_column: str, root: Path) -> tuple[Any, dict[str, Any]]:
    from datasets import Image

    root = root.resolve()
    raw = dataset.cast_column(image_column, Image(decode=False))
    records = []
    for index in range(len(raw)):
        row = raw[index]
        require(type(row[caption_column]) is str, "native full resume requires a single deterministic caption")
        image = row[image_column]
        require(type(image) is dict and image.get("bytes") is None and type(image.get("path")) is str,
                "native full resume requires local image files")
        path = Path(image["path"]).resolve()
        require(path.is_file() and path.is_relative_to(root), "dataset image escapes train_data_dir")
        records.append({"id": index, "path": path.relative_to(root).as_posix(), "sha256": file_sha(path),
                        "caption_sha256": json_sha(row[caption_column])})
    require(records and len({entry["path"] for entry in records}) == len(records), "empty or duplicate native dataset")
    return dataset.add_column("genmlu_sample_id", list(range(len(records)))), {
        "records": records, "tree_sha256": tree_identity(root), "ordered_sha256": json_sha(records),
    }


def _implementation(value: Any) -> dict[str, str]:
    source = inspect.getsourcefile(type(value))
    require(source is not None, "cannot identify native state implementation")
    return {"module": type(value).__module__, "class": type(value).__qualname__, "source_sha256": file_sha(Path(source))}


def _schema(named: Any) -> list[dict[str, Any]]:
    return [{"name": name, "dtype": str(value.dtype), "shape": list(value.shape)} for name, value in named]


def _policy(model: Any) -> dict[str, Any]:
    result = {}
    for name, module in model.named_modules():
        fields = ("r", "lora_alpha", "scaling", "use_dora")
        policy = {key: getattr(module, key) for key in fields if hasattr(module, key)}
        if policy:
            require(set(policy) == set(fields), "incomplete native LoRA layer policy")
            adapters = set(policy["r"]) if type(policy["r"]) is dict else set()
            require(bool(adapters) and all(type(key) is str and bool(key) for key in adapters),
                    "invalid native LoRA adapter keys")
            for key, values in policy.items():
                require(type(values) is dict and set(values) == adapters, "native LoRA policy adapter mismatch")
                for value in values.values():
                    if key == "r":
                        require(type(value) is int and value > 0, "invalid native LoRA rank")
                    elif key == "use_dora":
                        require(type(value) is bool, "invalid native LoRA DoRA policy")
                    else:
                        require(type(value) in (int, float) and math.isfinite(value),
                                "invalid native LoRA alpha/scaling")
            # PEFT layers expose a read-only bool; the Diffusers root has a mutating method.
            disabled = getattr(module, "disable_adapters", None)
            require(type(disabled) is bool, "invalid native LoRA enabled state")
            policy["disable_adapters"] = disabled
            merged, merged_adapters = getattr(module, "merged", None), getattr(module, "merged_adapters", None)
            require(type(merged) is bool and merged is False
                    and type(merged_adapters) is list and not merged_adapters,
                    "native full checkpoint requires unmerged LoRA layers")
        if hasattr(module, "active_adapters"):
            active = module.active_adapters
            # Diffusers uses a getter method, whereas PEFT layers use a list property.
            active = active() if callable(active) else active
            active = [active] if type(active) is str else active
            require(type(active) is list and bool(active)
                    and all(type(adapter) is str and bool(adapter) for adapter in active)
                    and len(set(active)) == len(active), "invalid native active adapter selection")
            require(not policy or set(active).issubset(policy["r"]), "native active adapter missing layer policy")
            policy["active_adapters"] = list(active)
        elif policy:
            raise CheckpointError("native LoRA layer has no active adapter selection")
        if policy:
            json_sha(policy)
            result[name] = policy
    return json.loads(json.dumps(result, sort_keys=True, allow_nan=False))


def make_contract(args: Any, model: Any, optimizer: Any, scheduler: Any, data: dict[str, Any], mlu: bool) -> dict[str, Any]:
    require(args.mixed_precision == "bf16" and args.gradient_accumulation_steps == 1 and args.train_batch_size == 1
            and args.dataloader_num_workers == 0 and args.center_crop and not args.random_flip
            and not args.train_text_encoder and not args.use_8bit_adam and args.validation_prompt is None
            and args.lr_scheduler == "constant" and args.lr_warmup_steps == 0,
            "native full checkpoint supports only deterministic single-process BF16 UNet LoRA and constant LR")
    require(type(args.genmlu_runtime_image_id) is str
            and re.fullmatch("sha256:[0-9a-f]{64}", args.genmlu_runtime_image_id) is not None, "runtime image digest is required")
    invocation = {"output_dir", "logging_dir", "resume_from_checkpoint", "genmlu_external_resume_from_checkpoint",
                  "genmlu_metrics_path", "genmlu_initial_adapter_path", "genmlu_source_root", "local_rank",
                  "pretrained_model_name_or_path", "train_data_dir"}
    plan = {key: value for key, value in vars(args).items() if key not in invocation}
    imports = {}
    for name in ("torch", "numpy", "accelerate", "diffusers", "peft", "transformers", "datasets", "torchvision") + (("torch_mlu",) if mlu else ()):
        module = importlib.import_module(name)
        source = Path(module.__file__).resolve()
        imports[name] = {"origin": str(source), "sha256": file_sha(source), "version": str(getattr(module, "__version__", "unknown"))}
    source_root = Path(args.genmlu_source_root).resolve()
    require(Path(imports["diffusers"]["origin"]).is_relative_to(source_root), "Diffusers import shadows the requested source")
    native_optimizer = getattr(optimizer, "optimizer", optimizer)
    native_scheduler = getattr(scheduler, "scheduler", scheduler)
    import torch

    require(type(native_optimizer) is torch.optim.AdamW, "native full checkpoint requires ordinary AdamW")
    contract = {"plan": plan, "weights_sha256": tree_identity(Path(args.pretrained_model_name_or_path)),
            "data": data, "diffusers_revision": DIFFUSERS_REVISION, "source_sha256": tree_identity(source_root, python_only=True),
            "helper_sha256": file_sha(Path(__file__)), "backend_sha256": file_sha(Path(__file__).parent / "backends/sdxl_training.py"),
            "imports": imports, "parameters": _schema((n, p) for n, p in model.named_parameters() if p.requires_grad),
            "buffers": _schema(model.named_buffers()), "optimizer": _implementation(native_optimizer),
            "scheduler": _implementation(native_scheduler), "lora_policy": _policy(model), "mlu": mlu}
    validate_contract(contract)
    return contract


def native_training_device(accelerator: Any, torch: Any) -> Any:
    device = accelerator.device
    require(device.type == "mlu" and torch.mlu.device_count() == 1,
            "native full checkpoint requires one visible MLU")
    ordinal = torch.mlu.current_device()
    require(type(ordinal) is int and ordinal == 0 and device.index in (None, ordinal),
            "native accelerator device ordinal mismatch")
    # Accelerate can omit the ordinal while tensors report the explicit device.
    return torch.device("mlu", ordinal)


class NativeCheckpointSession:
    def __init__(self, args, model, optimizer, scheduler, accelerator, sampler, generator, data, adapter_state):
        import torch

        require(accelerator.num_processes == 1, "native full resume requires exactly one process")
        self.args, self.model, self.optimizer, self.scheduler = args, model, optimizer, scheduler
        self.accelerator, self.sampler, self.generator = accelerator, sampler, generator
        self.adapter_state = adapter_state
        self.mlu = accelerator.device.type == "mlu"
        device = native_training_device(accelerator, torch)
        self.named = [(name, parameter) for name, parameter in model.named_parameters() if parameter.requires_grad]
        require(self.named and all(p.device == device for _, p in self.named), "native trainable device mismatch")
        self.step = 0
        self.counts = {name: 0 for name, _ in self.named}
        self.contract = make_contract(args, model, optimizer, scheduler, data, self.mlu)
        self.restored = None
        self.batch_witness = None
        self.resumed_mid_epoch = False
        _atomic_json(Path(args.output_dir) / "native-contract.json", self.contract)

    def capture_state(self):
        optimizer = self.optimizer.state_dict()
        name_by_id = {id(parameter): name for name, parameter in self.named}
        groups = [[name_by_id[id(parameter)] for parameter in group["params"]] for group in self.optimizer.param_groups]
        flat_names = [name for group in groups for name in group]
        require(len(flat_names) == len(set(flat_names)) == len(self.named) and set(flat_names) == set(self.counts),
                "optimizer name mapping mismatch")
        placements = {}
        for saved_group, group in zip(optimizer["param_groups"], self.optimizer.param_groups):
            for identifier, parameter in zip(saved_group["params"], group["params"]):
                placements[identifier] = {key: str(value.device) for key, value in self.optimizer.state.get(parameter, {}).items()
                                         if hasattr(value, "device")}
        data = self.sampler.state_dict() if self.sampler.order is not None else {
            "epoch": 0, "consumed": 0, "order": None, "generator": self.generator.get_state(),
        }
        return cpu_tree({"parameters": dict(self.named), "buffers": dict(self.model.named_buffers()),
                         "adapter": self.adapter_state(), "optimizer": optimizer, "optimizer_names": groups,
                         "optimizer_placements": placements, "parameter_update_counts": self.counts,
                         "scheduler": self.scheduler.state_dict(), "accelerator_step": self.accelerator.step,
                         "rng": capture_rng(self.mlu), "data": data})

    def validate_state(self, state, step):
        import torch

        require(type(step) is int and step > 0, "invalid native completed step")
        live = self.capture_state()
        require(type(state) is dict and set(state) == set(live), "native full state inventory mismatch")
        for key in ("parameters", "buffers", "adapter"):
            require(type(state[key]) is dict and set(state[key]) == set(live[key]), f"native {key} names mismatch")
            for name, value in state[key].items():
                expected = live[key][name]
                require(type(value) is torch.Tensor and value.device.type == "cpu" and value.shape == expected.shape
                        and value.dtype == expected.dtype and tuple(value.stride()) == tuple(expected.stride()),
                        f"native {key} tensor schema mismatch")
                require(value.layout == torch.strided and bool(torch.isfinite(value).all()), "non-finite native tensor")
        optimizer = state["optimizer"]
        require(type(optimizer) is dict and set(optimizer) == {"state", "param_groups"}
                and type(optimizer["state"]) is dict and type(optimizer["param_groups"]) is list
                and state["optimizer_names"] == live["optimizer_names"], "native optimizer structure/name mapping mismatch")
        require(len(optimizer["param_groups"]) == len(live["optimizer"]["param_groups"]), "native optimizer group count mismatch")
        counts = state["parameter_update_counts"]
        require(type(counts) is dict and set(counts) == set(self.counts)
                and all(type(count) is int and 0 <= count <= step for count in counts.values()), "invalid native parameter update counts")
        identifiers = []
        parameters = dict(self.named)
        require(type(state["optimizer_placements"]) is dict, "invalid native optimizer placement mapping")
        for group, expected, names in zip(optimizer["param_groups"], live["optimizer"]["param_groups"], state["optimizer_names"]):
            require(type(group) is dict and set(group) == set(expected) and type(group["params"]) is list
                    and all(type(identifier) is int for identifier in group["params"])
                    and group["params"] == expected["params"] and len(group["params"]) == len(names),
                    "native optimizer group layout mismatch")
            require(all(type(group[key]) is type(expected[key]) and json_sha(group[key]) == json_sha(expected[key])
                        for key in group if key != "params"), "native optimizer policy mismatch")
            require(group.get("amsgrad") is False, "native full checkpoint does not support AMSGrad")
            identifiers.extend(group["params"])
            for identifier, name in zip(group["params"], names):
                slots = optimizer["state"].get(identifier, {})
                require(type(slots) is dict and bool(slots) == (counts[name] > 0), "missing native optimizer slots")
                if slots:
                    require(set(slots) == {"step", "exp_avg", "exp_avg_sq"}, "unsupported native AdamW slots")
                    require(type(slots["step"]) is torch.Tensor and slots["step"].numel() == 1
                            and slots["step"].device.type == "cpu" and slots["step"].dtype in (torch.float32, torch.float64)
                            and bool(torch.isfinite(slots["step"]).all())
                            and float(slots["step"].item()) == counts[name], "native optimizer step mismatch")
                    for key in ("exp_avg", "exp_avg_sq"):
                        value = slots[key]
                        require(type(value) is torch.Tensor and value.shape == state["parameters"][name].shape
                                and value.dtype == state["parameters"][name].dtype and value.device.type == "cpu"
                                and value.layout == torch.strided and bool(torch.isfinite(value).all()),
                                "native optimizer moment mismatch")
                        require(key != "exp_avg_sq" or bool((value >= 0).all()), "negative native AdamW second moment")
                placement = state["optimizer_placements"].get(identifier)
                require(type(placement) is dict and set(placement) == set(slots)
                        and all(device in ("cpu", str(parameters[name].device)) for device in placement.values()),
                        "native optimizer placement inventory mismatch")
        require(len(identifiers) == len(set(identifiers)) and set(optimizer["state"]) <= set(identifiers)
                and all(type(identifier) is int for identifier in optimizer["state"])
                and set(state["optimizer_placements"]) == set(identifiers), "native optimizer identifier inventory mismatch")
        scheduler = state["scheduler"]
        require(type(scheduler) is dict and set(scheduler) == set(live["scheduler"])
                and type(scheduler.get("last_epoch")) is int and scheduler["last_epoch"] == step
                and type(scheduler.get("_step_count")) is int and scheduler["_step_count"] == step + 1,
                "native scheduler step mismatch")
        require(all(scheduler[key] == live["scheduler"][key] for key in scheduler
                    if key not in ("last_epoch", "_step_count", "_last_lr")), "native scheduler static state mismatch")
        require(scheduler["base_lrs"] == live["scheduler"]["base_lrs"]
                and scheduler["_last_lr"] == [group["lr"] for group in optimizer["param_groups"]]
                and scheduler["lr_lambdas"] == live["scheduler"]["lr_lambdas"], "native scheduler policy mismatch")
        require(type(state["accelerator_step"]) is int and state["accelerator_step"] >= 0, "native Accelerator counter mismatch")
        validate_rng(state["rng"], self.mlu)
        validate_cursor(state["data"], len(self.sampler))
        torch.Generator().set_state(state["data"]["generator"])
        require(state["data"]["epoch"] * len(self.sampler) + state["data"]["consumed"] == step,
                "native data cursor/global step mismatch")

    def _verify_native_files(self, checkpoint, state):
        from safetensors.torch import load_file

        require(state_sha(load_file(str(checkpoint / "pytorch_lora_weights.safetensors"))) == state_sha(state["adapter"]),
                "native adapter differs from named full state")
        for name, key in (("optimizer.bin", "optimizer"), ("scheduler.bin", "scheduler")):
            require(state_sha(restricted_load(checkpoint / name)) == state_sha(state[key]), f"native {key} file differs from full state")
        rng = restricted_load(checkpoint / "random_states_0.pkl", numpy_rng=True)
        require(type(rng) is dict and set(rng) == {
            "step", "random_state", "numpy_random_seed", "torch_manual_seed", "torch_mlu_manual_seed",
        }, "unsupported native Accelerate RNG producer")
        translated = {"python": rng["random_state"], "numpy": rng["numpy_random_seed"],
                      "torch_cpu": rng["torch_manual_seed"], "mlu": rng["torch_mlu_manual_seed"]}
        validate_rng(translated, self.mlu)
        require(rng["step"] == state["accelerator_step"] and state_sha(translated) == state_sha(state["rng"]),
                "native RNG file differs from complete boundary")

    def save_checkpoint(self, checkpoint, step, before_save):
        import torch

        require(step == self.step and not (checkpoint / MANIFEST).exists(), "native checkpoint boundary already exists or differs")
        require(state_sha(self.capture_state()) == state_sha(before_save), "native save changed live state or RNG")
        self.validate_state(before_save, step)
        self._verify_native_files(checkpoint, before_save)
        payload = {"contract": self.contract, "step": step, "state": before_save}
        temporary = checkpoint / (STATE + ".tmp")
        torch.save(payload, temporary)
        temporary.replace(checkpoint / STATE)
        document = {"schema": SCHEMA, "boundary": "after-complete-optimizer-scheduler-update", "step": step,
                    "next_step": step + 1, "contract": self.contract, "state_sha256": state_sha(before_save),
                    "files": {name: {"bytes": (checkpoint / name).stat().st_size, "sha256": file_sha(checkpoint / name)}
                              for name in sorted(FILES)}}
        document["integrity_sha256"] = json_sha(document)
        _atomic_json(checkpoint / MANIFEST, document)
        preflight(checkpoint)

    def restore_checkpoint(self, checkpoint):
        import torch

        checkpoint = checkpoint.resolve()
        document = preflight(checkpoint)
        manifest_sha = file_sha(checkpoint / MANIFEST)
        validate_contract(document["contract"], expected=self.contract)
        require(document["step"] < self.args.max_train_steps,
                "native checkpoint plan/source/data/runtime mismatch or completed plan")
        payload = restricted_load(checkpoint / STATE, numpy_rng=True)
        require(type(payload) is dict and set(payload) == {"contract", "step", "state"}
                and json_sha(payload["contract"]) == json_sha(self.contract) and type(payload["step"]) is int
                and payload["step"] == document["step"], "native full payload identity mismatch")
        state = cpu_tree(payload["state"])
        require(state_sha(state) == document["state_sha256"], "native full state integrity mismatch")
        self.validate_state(state, document["step"])
        self._verify_native_files(checkpoint, state)
        # All files and private state validation precede mutations of live training state.
        require(preflight(checkpoint) == document and file_sha(checkpoint / MANIFEST) == manifest_sha,
                "native checkpoint changed during load")
        try:
            with torch.no_grad():
                for key, named in (("parameters", self.named), ("buffers", self.model.named_buffers())):
                    for name, value in named:
                        value.copy_(state[key][name])
            self.optimizer.load_state_dict(state["optimizer"])
            for saved_group, group in zip(state["optimizer"]["param_groups"], self.optimizer.param_groups):
                for identifier, parameter in zip(saved_group["params"], group["params"]):
                    for key, device in state["optimizer_placements"][identifier].items():
                        self.optimizer.state[parameter][key] = self.optimizer.state[parameter][key].to(device)
            self.scheduler.load_state_dict(state["scheduler"])
            self.accelerator.step = state["accelerator_step"]
            self.counts = dict(state["parameter_update_counts"])
            self.sampler.load_state_dict(state["data"])
            restore_rng(state["rng"], self.mlu)
            require(state_sha(self.capture_state()) == document["state_sha256"], "native applied full state differs before first update")
        except Exception as error:
            raise CheckpointError("native checkpoint application failed; terminate this worker") from error
        self.step = document["step"]
        self.restored = {"path": str(checkpoint), "manifest_sha256": manifest_sha, "state_sha256": document["state_sha256"]}
        self.resumed_mid_epoch = 0 < self.sampler.consumed < len(self.sampler)
        return self.step

    def preupdate_witness(self):
        import torch

        state = self.capture_state()
        observed = state_sha(state)
        if self.restored:
            require(observed == self.restored["state_sha256"], "preupdate restored full-state witness differs")
        path = Path(self.args.output_dir) / "preupdate-state.pt"
        require(not path.exists(), "preupdate witness must be fresh")
        torch.save(state, path)
        _atomic_json(path.with_name("preupdate-witness.json"), {
            "schema": SCHEMA, "completed_step": self.step, "next_step": self.step + 1,
            "contract_sha256": json_sha(self.contract), "restored": self.restored,
            "state_sha256": observed, "file_sha256": file_sha(path),
            "restored_full_state_exact": True if self.restored else None,
            "fresh_recovery_verified": False, "performance_accepted": False,
        })

    def iterator(self, dataloader):
        rng = capture_rng(self.mlu)
        generator = self.generator.get_state().clone()
        iterator = iter(dataloader)
        if self.resumed_mid_epoch:
            # Deterministic transforms permit replaying the iterator's prefetched batch.
            try:
                first = next(iterator)
            finally:
                self.generator.set_state(generator)
                restore_rng(rng, self.mlu)
            self.resumed_mid_epoch = False
            yield first
        yield from iterator

    def observe_batch(self, batch):
        ids = batch["genmlu_sample_ids"]
        require(type(ids) is list and all(type(index) is int for index in ids), "actual sample IDs are missing")
        require(self.sampler.order is not None and ids == self.sampler.order[self.sampler.consumed:self.sampler.consumed + 1],
                "actual batch differs from saved sampler order")
        self.batch_witness = {
            "epoch": self.sampler.epoch, "batch_index": self.sampler.consumed, "sample_ids": ids,
            "samples": [self.contract["data"]["records"][index] for index in ids],
            "tensors": {key: state_sha(batch[key]) for key in ("pixel_values", "input_ids_one", "input_ids_two")},
            "original_sizes": batch["original_sizes"], "crop_top_lefts": batch["crop_top_lefts"],
        }

    def advance(self, batch, next_step):
        require(next_step == self.step + 1 and self.batch_witness is not None, "native update boundary is not consecutive")
        require(not self.optimizer.step_was_skipped, "native full checkpoint rejects skipped AdamW updates")
        for name, parameter in self.named:
            self.counts[name] += int(parameter.grad is not None)
        self.sampler.consume(batch["genmlu_sample_ids"])
        self.step = next_step
