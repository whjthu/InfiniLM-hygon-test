#!/usr/bin/env python3
"""Host-local resource admission and owned-process lifecycle controller."""

from __future__ import annotations

import argparse
from decimal import Decimal, InvalidOperation, ROUND_CEILING
import errno
import json
import os
import re
import signal
import socket
import subprocess
import tempfile
import time
import uuid
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator, Sequence

from .lease import parse_cards


DEFAULT_LOCK_ROOT = Path("/mnt/afs/outputs")
DEFAULT_PROJECT = "generative-mlu"
MAX_RUNTIME_SECONDS = 8 * 60 * 60
MAX_WATCH_INTERVAL_SECONDS = 60
LOCK_ACQUIRE_TIMEOUT_SECONDS = 5.0
LOCK_RETRY_INTERVAL_SECONDS = 0.05
ALL_MLU_CARDS = tuple(range(8))
CARD_HEADER = re.compile(r"^Card\s+(\d+)\s*$")
PERCENT = re.compile(r"MLU Average\s*:\s*(\d+)\s*%")
MEMORY = re.compile(r"Used\s*:\s*(\d+)\s*MiB")
CNMON_PROCESS_HEADER = re.compile(r"\|\s*Card\s+MI\s+PID\s+Command Line\s+MLU Memory Usage\s*\|")
CNMON_PROCESS_ROW = re.compile(
    r"^\|\s*(?P<card>\d+)\s+\S+\s+(?P<pid>\d+)\s+"
    r"(?P<command>.*?)\s+(?P<memory>(?:0|[1-9]\d*)(?:\.\d+)?)\s+(?P<unit>KiB|MiB|GiB)\s*\|\s*$"
)
ANSI_ESCAPE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
PS_ROW = re.compile(r"^\s*(\d+)\s+(\d+)\s+(\d+)\s*$")
CONTAINER_NAME = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,100}$")


@dataclass(frozen=True)
class CardState:
    index: int
    utilization_percent: int | None
    used_mib: int | None

    @property
    def idle(self) -> bool:
        return (
            self.utilization_percent is not None
            and self.used_mib is not None
            and self.utilization_percent == 0
            and self.used_mib <= 2048
        )


@dataclass(frozen=True)
class CnmonProcess:
    card: int
    pid: int
    command: str
    used_mib: int


@dataclass(frozen=True)
class ContainerIdentity:
    name: str
    container_id: str
    pid: int


@dataclass(frozen=True)
class LeaseHandle:
    path: Path
    lease_id: str
    host_lock: Path
    host: object = None
    cards: tuple[int, ...] = ()
    pid: object = None


@dataclass(frozen=True)
class PreflightResult:
    host: str
    cards: tuple[int, ...]
    card_states: tuple[CardState, ...]
    foreign_accelerator_processes: tuple[str, ...]
    checked_at_utc: str

    @property
    def ready(self) -> bool:
        return not self.foreign_accelerator_processes and all(card.idle for card in self.card_states)


class RunInterrupted(Exception):
    def __init__(self, signum: int) -> None:
        super().__init__(f"received signal {signum}")
        self.signum = signum


class CommandFailure(RuntimeError):
    """Keep command failure metadata so missing objects can be checked exactly."""

    def __init__(self, command: Sequence[str], completed: subprocess.CompletedProcess):
        self.command = tuple(command)
        self.returncode = completed.returncode
        self.stdout = completed.stdout
        self.stderr = completed.stderr
        detail = completed.stderr.strip() or completed.stdout.strip()
        super().__init__(detail or f"command failed: {' '.join(command)}")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _run(command: Sequence[str], timeout: int = 20) -> str:
    completed = subprocess.run(
        command,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
        check=False,
    )
    if completed.returncode:
        raise CommandFailure(command, completed)
    return completed.stdout


def _write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
        json.dump(payload, handle, ensure_ascii=True, indent=2, sort_keys=True)
        handle.write("\n")
        temporary = Path(handle.name)
    temporary.replace(path)


def parse_cnmon_info(text: str, cards: tuple[int, ...]) -> tuple[CardState, ...]:
    active: int | None = None
    utilization: dict[int, int] = {}
    memory: dict[int, int] = {}
    for line in text.splitlines():
        header = CARD_HEADER.match(line.strip())
        if header:
            active = int(header.group(1))
            continue
        if active is None:
            continue
        percent = PERCENT.search(line)
        if percent:
            utilization[active] = int(percent.group(1))
            continue
        used = MEMORY.search(line)
        if used and active not in memory:
            memory[active] = int(used.group(1))
    return tuple(CardState(card, utilization.get(card), memory.get(card)) for card in cards)


def _cnmon_memory_mib(value: str, unit: str) -> int:
    try:
        amount = Decimal(value)
    except InvalidOperation as exc:
        raise RuntimeError("invalid cnmon process memory") from exc
    if not amount.is_finite() or amount < 0:
        raise RuntimeError("invalid cnmon process memory")
    scale = {"KiB": Decimal(1) / Decimal(1024), "MiB": Decimal(1), "GiB": Decimal(1024)}.get(unit)
    if scale is None:
        raise RuntimeError("invalid cnmon process memory unit")
    return int((amount * scale).to_integral_value(rounding=ROUND_CEILING))


def _parse_cnmon_process_row(line: str) -> CnmonProcess | None:
    """Parse both aligned and whitespace-collapsed cnmon process rows."""
    clean = ANSI_ESCAPE.sub("", line).strip()
    match = CNMON_PROCESS_ROW.match(clean)
    if match:
        return CnmonProcess(
            card=int(match.group("card")),
            pid=int(match.group("pid")),
            command=match.group("command").strip(),
            used_mib=_cnmon_memory_mib(match.group("memory"), match.group("unit")),
        )

    fields = clean.strip("|").split()
    if len(fields) < 6 or not clean.startswith("|") or not clean.endswith("|"):
        return None
    try:
        card = int(fields[0])
        pid = int(fields[2])
    except ValueError:
        return None
    memory, unit = fields[-2:]
    if unit not in {"KiB", "MiB", "GiB"} or not re.fullmatch(r"(?:0|[1-9]\d*)(?:\.\d+)?", memory):
        return None
    command = " ".join(fields[3:-2])
    if not command:
        return None
    return CnmonProcess(card, pid, command, _cnmon_memory_mib(memory, unit))


def parse_cnmon_processes(text: str) -> tuple[CnmonProcess, ...]:
    in_process_table = False
    saw_terminal_evidence = False
    processes: list[CnmonProcess] = []
    for line in text.splitlines():
        clean = ANSI_ESCAPE.sub("", line)
        if CNMON_PROCESS_HEADER.search(clean):
            in_process_table = True
            continue
        if not in_process_table:
            continue
        if "No running processes found" in clean:
            saw_terminal_evidence = True
            continue
        process = _parse_cnmon_process_row(clean)
        if process:
            saw_terminal_evidence = True
            processes.append(process)
            continue
        stripped = clean.strip()
        if not stripped or set(stripped).issubset(set("|=+- ")):
            continue
        raise RuntimeError(f"unable to parse cnmon process row: {stripped}")
    if not in_process_table or not saw_terminal_evidence:
        raise RuntimeError("unable to parse the cnmon process table")
    return tuple(processes)


def accelerator_processes(owned_pgid: int | None = None) -> tuple[str, ...]:
    """Compatibility helper; admission uses only cnmon PID/card ownership."""

    launcher = re.compile(r"(?:torchrun|deepspeed|vllm|ray::|swift|verl)", re.I)
    text = _run(("ps", "-eo", "pid=,pgid=,stat=,args="))
    found: list[str] = []
    for raw in text.splitlines():
        fields = raw.strip().split(maxsplit=3)
        if len(fields) != 4:
            continue
        pid, pgid, state, command = fields
        if "Z" in state or not launcher.search(command):
            continue
        if owned_pgid is not None and int(pgid) == owned_pgid:
            continue
        found.append(f"{pid} {state} {command}")
    return tuple(found)


def sample_preflight(
    cards: tuple[int, ...],
    *,
    runner=_run,
    host: str | None = None,
    owned_pids: frozenset[int] = frozenset(),
    owned_pgid: int | None = None,
) -> PreflightResult:
    del owned_pgid  # Source compatibility; real cnmon PIDs are authoritative.
    info = runner(("cnmon", "info"), timeout=20)
    states = parse_cnmon_info(info, cards)
    processes = parse_cnmon_processes(runner(("cnmon", "all"), timeout=20))
    selected = set(cards)
    foreign = tuple(
        f"card={process.card} pid={process.pid} memory_mib={process.used_mib} command={process.command}"
        for process in processes
        if process.card in selected and process.pid not in owned_pids
    )
    return PreflightResult(
        host=host or socket.gethostname(),
        cards=cards,
        card_states=states,
        foreign_accelerator_processes=foreign,
        checked_at_utc=_utc_now(),
    )


def require_idle(
    cards: tuple[int, ...], interval_seconds: int, *, runner=_run, sleeper=time.sleep
) -> tuple[PreflightResult, PreflightResult]:
    first = sample_preflight(cards, runner=runner)
    if interval_seconds:
        sleeper(interval_seconds)
    second = sample_preflight(cards, runner=runner)
    if not first.ready or not second.ready:
        detail = {"first": asdict(first), "second": asdict(second)}
        raise RuntimeError(f"accelerator host is not idle: {json.dumps(detail, ensure_ascii=False)}")
    return first, second


def lease_path(root: Path, project: str, host_label: str, cards: tuple[int, ...]) -> Path:
    return root / project / host_label / ".leases" / ("cards-" + "-".join(str(card) for card in cards) + ".json")


def create_lease(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(payload, ensure_ascii=True, indent=2, sort_keys=True) + "\n").encode("utf-8")
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    except FileExistsError as exc:
        raise RuntimeError(f"lease already exists: {path}") from exc
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(encoded)


def remove_lease(path: Path) -> None:
    """Remove a lease explicitly; automated cleanup uses release_lease()."""

    path.unlink(missing_ok=True)


def host_lock_path(root: Path, host_label: str) -> Path:
    return root / ".benchctl" / f"{host_label}.lock"


def normalized_output_root(root: Path, project: str) -> Path:
    """Return the multi-project root for both supported output-root forms."""

    return root.parent if root.name == project else root


@contextmanager
def exclusive_file_lock(
    path: Path,
    *,
    timeout_seconds: float = LOCK_ACQUIRE_TIMEOUT_SECONDS,
    retry_interval_seconds: float = LOCK_RETRY_INTERVAL_SECONDS,
    clock=time.monotonic,
    sleeper=time.sleep,
) -> Iterator[None]:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a+b") as handle:
        if os.name == "nt":
            import msvcrt

            handle.seek(0)
            if not handle.read(1):
                handle.write(b"0")
                handle.flush()
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
            try:
                yield
            finally:
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl

            deadline = clock() + timeout_seconds
            while True:
                try:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except OSError as exc:
                    if exc.errno not in {errno.EAGAIN, errno.EWOULDBLOCK}:
                        raise
                    remaining = deadline - clock()
                    if remaining <= 0:
                        raise TimeoutError(f"timed out acquiring lock: {path}") from exc
                    sleeper(min(retry_interval_seconds, remaining))
            try:
                yield
            finally:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _host_lease_paths(root: Path, host_label: str) -> tuple[Path, ...]:
    if not root.is_dir():
        return ()
    leases: list[Path] = []
    for project_root in root.iterdir():
        if not project_root.is_dir() or project_root.name == ".benchctl":
            continue
        leases.extend((project_root / host_label / ".leases").glob("*.json"))
    return tuple(leases)


def acquire_lease(
    root: Path,
    project: str,
    host_label: str,
    cards: tuple[int, ...],
    payload: dict[str, object],
) -> LeaseHandle:
    lock = host_lock_path(root, host_label)
    lease_id = str(payload.get("lease_id") or uuid.uuid4().hex)
    payload["lease_id"] = lease_id
    requested = set(cards)
    path = lease_path(root, project, host_label, cards)
    handle = LeaseHandle(
        path=path,
        lease_id=lease_id,
        host_lock=lock,
        host=payload.get("host"),
        cards=tuple(int(card) for card in payload.get("cards", cards)),
        pid=payload.get("pid"),
    )
    created = False
    try:
        with exclusive_file_lock(lock):
            for existing_path in _host_lease_paths(root, host_label):
                try:
                    existing = json.loads(existing_path.read_text(encoding="utf-8"))
                    existing_cards = {int(card) for card in existing["cards"]}
                except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
                    raise RuntimeError(f"unknown lease blocks acquisition: {existing_path}: {exc}") from exc
                if requested.intersection(existing_cards):
                    raise RuntimeError(f"overlapping lease exists: {existing_path}")
            create_lease(path, payload)
            created = True
    except BaseException:
        if created:
            with exclusive_file_lock(lock):
                try:
                    current = json.loads(path.read_text(encoding="utf-8"))
                except (FileNotFoundError, OSError, json.JSONDecodeError):
                    current = {}
                if _owned_lease(handle, current):
                    path.unlink()
        raise
    return handle


def _owned_lease(handle: LeaseHandle, current: object) -> bool:
    return (
        isinstance(current, dict)
        and current.get("lease_id") == handle.lease_id
        and current.get("host") == handle.host
        and tuple(current.get("cards", ())) == handle.cards
        and current.get("pid") == handle.pid
    )


def release_lease(handle: LeaseHandle) -> bool:
    with exclusive_file_lock(handle.host_lock):
        try:
            current = json.loads(handle.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return False
        except (OSError, json.JSONDecodeError):
            return False
        if not _owned_lease(handle, current):
            return False
        handle.path.unlink()
        return True


def normalized_command(command: Sequence[str]) -> list[str]:
    result = list(command)
    if result[:1] == ["--"]:
        result.pop(0)
    if not result:
        raise ValueError("benchctl run requires a command after '--'")
    return result


def without_process_ids(processes: Sequence[str], process_ids: set[int]) -> tuple[str, ...]:
    filtered: list[str] = []
    for process in processes:
        try:
            pid = int(process.split(maxsplit=1)[0])
        except (IndexError, ValueError):
            filtered.append(process)
            continue
        if pid not in process_ids:
            filtered.append(process)
    return tuple(filtered)


def process_tree_pids(root_pids: set[int], pgid: int, *, runner=_run) -> frozenset[int]:
    text = runner(("ps", "-eo", "pid=,ppid=,pgid="), timeout=20)
    rows: list[tuple[int, int, int]] = []
    owned = set(root_pids)
    for line in text.splitlines():
        match = PS_ROW.match(line)
        if not match:
            continue
        pid, ppid, process_group = (int(value) for value in match.groups())
        rows.append((pid, ppid, process_group))
        if process_group == pgid:
            owned.add(pid)
    changed = True
    while changed:
        changed = False
        for pid, ppid, _ in rows:
            if ppid in owned and pid not in owned:
                owned.add(pid)
                changed = True
    return frozenset(owned)


def inspect_owned_container(
    name: str,
    run_id: str,
    *,
    lease_id: str | None = None,
    require_lease_id: bool = False,
    runner=_run,
    missing_ok: bool = True,
) -> ContainerIdentity | None:
    try:
        raw = runner(("docker", "inspect", name), timeout=20)
    except CommandFailure as exc:
        if (missing_ok and exc.command == ("docker", "inspect", name)
                and type(exc.returncode) is int and exc.returncode == 1
                and isinstance(exc.stdout, str) and exc.stdout.strip() in ("", "[]")
                and isinstance(exc.stderr, str) and re.fullmatch(
                    r"(?:error:|error response from daemon:) no such (?:object|container): "
                    + re.escape(name), exc.stderr.strip(), flags=re.IGNORECASE)):
            return None
        raise
    try:
        entries = json.loads(raw)
        entry = entries[0]
        labels = entry["Config"].get("Labels") or {}
        container_id = str(entry["Id"])
        pid = int(entry["State"]["Pid"])
    except (IndexError, KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"unable to parse docker inspect for {name}") from exc
    if labels.get("genmlu.run_id") != run_id:
        raise RuntimeError(f"container ownership label mismatch for {name}")
    if require_lease_id and (not lease_id or labels.get("genmlu.lease_id") != lease_id):
        raise RuntimeError(f"container lease label mismatch for {name}")
    return ContainerIdentity(name=name, container_id=container_id, pid=pid)


def normalize_container_names(value: str | Sequence[str] | None) -> tuple[str, ...]:
    if value is None:
        return ()
    names = (value,) if isinstance(value, str) else tuple(value)
    if len(names) > len(ALL_MLU_CARDS):
        raise ValueError("at most eight owned containers may be declared")
    if len(names) != len(set(names)):
        raise ValueError("container names must be unique")
    if any(not CONTAINER_NAME.fullmatch(name) for name in names):
        raise ValueError("container names must be path-safe Docker names")
    return names


class _DockerRunParser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        raise ValueError(f"unsupported docker run options: {message}")


def _docker_run_options(command: Sequence[str]) -> argparse.Namespace:
    parser = _DockerRunParser(add_help=False, allow_abbrev=False)
    parser.add_argument("--name", action="append", default=[])
    parser.add_argument("--label", "-l", action="append", default=[])
    for flags in (
        ("--runtime",), ("--network", "--net"), ("--pull",), ("--user", "-u"),
        ("--cpus",), ("--memory", "-m"), ("--memory-swap",), ("--pids-limit",),
        ("--ipc",), ("--shm-size",), ("--cap-drop",), ("--security-opt",),
        ("--tmpfs",), ("--device",), ("--env", "-e"), ("--volume", "-v"),
        ("--mount",), ("--workdir", "-w"), ("--entrypoint",), ("--hostname", "-h"),
        ("--publish", "-p"), ("--expose",), ("--ulimit",), ("--stop-timeout",),
        ("--log-driver",), ("--log-opt",), ("--cpuset-cpus",),
    ):
        parser.add_argument(*flags, action="append")
    for flags in (("--rm",), ("--read-only",), ("--init",), ("--interactive", "-i"),
                  ("--tty", "-t")):
        parser.add_argument(*flags, action="store_true")
    parser.add_argument("image")
    parser.add_argument("payload", nargs=argparse.REMAINDER)
    # Image marks the boundary; payload options never become Docker labels.
    return parser.parse_args(list(command[2:]))


def prepare_command(command: list[str], container_name: str | None, run_id: str) -> tuple[list[str], str | None]:
    executable = Path(command[0]).name.lower()
    if executable not in {"docker", "docker.exe"} or len(command) < 2 or command[1] != "run":
        return command, container_name
    result = list(command)
    options = _docker_run_options(command)
    if len(options.name) > 1:
        raise ValueError("docker run must not repeat --name")
    existing_name = options.name[0] if options.name else None
    effective_name = container_name or existing_name or f"genmlu-{re.sub(r'[^a-zA-Z0-9_.-]+', '-', run_id)}"
    if not CONTAINER_NAME.fullmatch(effective_name):
        raise ValueError("invalid Docker container name")
    if existing_name and existing_name != effective_name:
        raise ValueError("docker --name does not match benchctl --container-name")
    if not existing_name:
        result[2:2] = ["--name", effective_name]
    ownership_label = f"genmlu.run_id={run_id}"
    run_labels = [label for label in options.label if label.partition("=")[0] == "genmlu.run_id"]
    if run_labels and run_labels != [ownership_label]:
        raise ValueError("docker genmlu.run_id label does not match benchctl run-id")
    if not run_labels:
        result[2:2] = ["--label", ownership_label]
    return result, effective_name


def prepare_managed_command(
    command: list[str], container_names: tuple[str, ...], run_id: str,
    lease_id: str | None = None,
) -> tuple[list[str], tuple[str, ...]]:
    direct_docker = (
        Path(command[0]).name.lower() in {"docker", "docker.exe"}
        and len(command) >= 2
        and command[1] == "run"
    )
    if direct_docker and len(container_names) > 1:
        raise ValueError("one direct docker run command cannot own multiple container names")
    if not direct_docker:
        return command, container_names
    prepared, effective_name = prepare_command(
        command, container_names[0] if container_names else None, run_id
    )
    if lease_id is not None:
        if not re.fullmatch(r"[0-9a-f]{32}", lease_id):
            raise ValueError("invalid controller lease ID")
        labels = _docker_run_options(prepared).label
        if any(label.partition("=")[0] == "genmlu.lease_id" for label in labels):
            raise ValueError("the controller supplies the container lease label")
        prepared[2:2] = ["--label", f"genmlu.lease_id={lease_id}"]
    return prepared, (effective_name,) if effective_name else ()


def refresh_owned_containers(
    container_names: tuple[str, ...],
    run_id: str,
    lease_id: str,
    bindings: dict[str, ContainerIdentity],
    *,
    require_lease_id: bool,
    runner=_run,
) -> dict[str, ContainerIdentity]:
    current: dict[str, ContainerIdentity] = {}
    for name in container_names:
        identity = inspect_owned_container(
            name,
            run_id,
            lease_id=lease_id,
            require_lease_id=require_lease_id,
            runner=runner,
        )
        if identity is None:
            continue
        previous = bindings.get(name)
        if previous is not None and previous.container_id != identity.container_id:
            raise RuntimeError(
                f"registered container identity changed for {name}: "
                f"{previous.container_id} -> {identity.container_id}"
            )
        bindings[name] = identity
        current[name] = identity
    return current


def container_registry_payload(
    container_names: tuple[str, ...],
    bindings: dict[str, ContainerIdentity],
    current: dict[str, ContainerIdentity],
) -> list[dict[str, object]]:
    records: list[dict[str, object]] = []
    for name in container_names:
        bound = bindings.get(name)
        active = current.get(name)
        record: dict[str, object] = {
            "name": name,
            "state": "running" if active is not None else "exited" if bound is not None else "declared",
        }
        if bound is not None:
            record["container_id"] = bound.container_id
            record["last_pid"] = bound.pid
        if active is not None:
            record["pid"] = active.pid
        records.append(record)
    return records


def _stop_owned_identity(
    identity: ContainerIdentity,
    run_id: str,
    lease_id: str,
    *,
    require_lease_id: bool,
    runner=_run,
) -> None:
    current = inspect_owned_container(
        identity.name,
        run_id,
        lease_id=lease_id,
        require_lease_id=require_lease_id,
        runner=runner,
    )
    if current is None:
        return
    if current.container_id != identity.container_id:
        raise RuntimeError(f"refusing to stop replacement container for {identity.name}")
    if current.pid <= 0:
        return
    try:
        runner(("docker", "stop", "--time", "30", identity.container_id), timeout=45)
    except RuntimeError:
        same = inspect_owned_container(
            identity.container_id,
            run_id,
            lease_id=lease_id,
            require_lease_id=require_lease_id,
            runner=runner,
        )
        if same is not None and same.container_id == identity.container_id:
            runner(("docker", "kill", identity.container_id), timeout=20)
    remaining = inspect_owned_container(
        identity.container_id,
        run_id,
        lease_id=lease_id,
        require_lease_id=require_lease_id,
        runner=runner,
    )
    if remaining is not None and remaining.pid > 0:
        raise RuntimeError(f"owned container is still running after cleanup: {identity.name}")


def cleanup_owned_containers(
    container_names: tuple[str, ...],
    run_id: str,
    lease_id: str,
    bindings: dict[str, ContainerIdentity],
    *,
    require_lease_id: bool,
    runner=_run,
) -> tuple[str, ...]:
    errors: list[str] = []
    for name in container_names:
        try:
            current = refresh_owned_containers(
                (name,),
                run_id,
                lease_id,
                bindings,
                require_lease_id=require_lease_id,
                runner=runner,
            )
            identity = current.get(name)
            if identity is not None:
                _stop_owned_identity(
                    identity,
                    run_id,
                    lease_id,
                    require_lease_id=require_lease_id,
                    runner=runner,
                )
        except Exception as exc:
            errors.append(f"{name}: {exc}")
    return tuple(errors)


def _stop_owned_container(name: str, run_id: str, *, runner=_run) -> None:
    identity = inspect_owned_container(name, run_id, runner=runner)
    if identity is None or identity.pid <= 0:
        return
    _stop_owned_identity(identity, run_id, "", require_lease_id=False, runner=runner)


def _live_process_group_pids(pgid: int) -> tuple[int, ...]:
    proc = Path("/proc")
    if not proc.is_dir():
        try:
            os.killpg(pgid, 0)
        except ProcessLookupError:
            return ()
        return (pgid,)
    live: list[int] = []
    for entry in proc.iterdir():
        if not entry.name.isdigit():
            continue
        try:
            stat = (entry / "stat").read_text(encoding="utf-8")
            fields = stat[stat.rfind(")") + 2 :].split()
            state = fields[0]
            process_group = int(fields[2])
        except (FileNotFoundError, ProcessLookupError, PermissionError, IndexError, ValueError):
            continue
        if process_group == pgid and state != "Z":
            live.append(int(entry.name))
    return tuple(sorted(live))


def _terminate_process_group(
    child: subprocess.Popen[str],
    grace_seconds: int = 60,
    *,
    sleeper=time.sleep,
    clock=time.monotonic,
) -> None:
    pgid = child.pid
    if not _live_process_group_pids(pgid):
        return
    try:
        os.killpg(pgid, signal.SIGTERM)
    except ProcessLookupError:
        return
    deadline = clock() + grace_seconds
    while _live_process_group_pids(pgid):
        now = clock()
        if now >= deadline:
            break
        sleeper(min(0.2, deadline - now))
    if not _live_process_group_pids(pgid):
        return
    try:
        os.killpg(pgid, signal.SIGKILL)
    except ProcessLookupError:
        return
    kill_deadline = clock() + 1
    while _live_process_group_pids(pgid):
        now = clock()
        if now >= kill_deadline:
            remaining = _live_process_group_pids(pgid)
            raise RuntimeError(f"process group {pgid} still has live members: {remaining}")
        sleeper(min(0.05, kill_deadline - now))
    try:
        child.wait(timeout=1)
    except subprocess.TimeoutExpired:
        return


@contextmanager
def _signal_guard() -> Iterator[None]:
    previous: dict[int, object] = {}

    def handler(signum: int, _frame: object) -> None:
        raise RunInterrupted(signum)

    for signum in (signal.SIGINT, signal.SIGTERM):
        previous[signum] = signal.getsignal(signum)
        signal.signal(signum, handler)
    try:
        yield
    finally:
        for signum, old_handler in previous.items():
            signal.signal(signum, old_handler)


def _validate_run_args(args: argparse.Namespace, cards: tuple[int, ...]) -> None:
    if args.project in {"", ".", ".."} or Path(args.project).name != args.project:
        raise ValueError("project must be one output-root directory name")
    if args.run_id and (args.run_id in {".", ".."} or Path(args.run_id).name != args.run_id):
        raise ValueError("run-id must be one output directory name")
    if not set(cards).issubset(ALL_MLU_CARDS):
        raise ValueError("cards must be selected from 0-7")
    if not 0 < args.timeout_seconds <= MAX_RUNTIME_SECONDS:
        raise ValueError(f"timeout must be between 1 and {MAX_RUNTIME_SECONDS} seconds")
    if not 0 < args.watch_interval <= MAX_WATCH_INTERVAL_SECONDS:
        raise ValueError(f"watch interval must be between 1 and {MAX_WATCH_INTERVAL_SECONDS} seconds")
    if args.host_label == "mlu-10001" and (cards != ALL_MLU_CARDS or args.sample_interval != 300):
        raise ValueError("mlu-10001 requires all cards 0-7 and two idle samples 300 seconds apart")


def _resume_checkpoint(args: argparse.Namespace, command: Sequence[str]) -> str | None:
    value = getattr(args, "checkpoint", None)
    if value is None:
        return None
    path = Path(value)
    if not path.is_absolute():
        raise ValueError("resume checkpoint must be an absolute path")
    resolved = path.resolve(strict=True)
    if resolved != path or str(path) not in command:
        raise ValueError("resume command must contain the exact, non-symlink checkpoint path")
    return str(path)


def _update_run_files(handle: LeaseHandle, run_lease: Path, payload: dict[str, object]) -> None:
    with exclusive_file_lock(handle.host_lock):
        try:
            current = json.loads(handle.path.read_text(encoding="utf-8"))
        except (FileNotFoundError, OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"owned lease disappeared or became unreadable: {handle.path}") from exc
        if not _owned_lease(handle, current):
            raise RuntimeError(f"owned lease was replaced: {handle.path}")
        _write_json(handle.path, payload)
    _write_json(run_lease, payload)


def _best_effort_run_update(
    handle: LeaseHandle,
    run_lease: Path,
    payload: dict[str, object],
    context: str,
    errors: list[str],
) -> bool:
    try:
        _update_run_files(handle, run_lease, payload)
        return True
    except BaseException as exc:
        errors.append(f"{context}: {type(exc).__name__}: {exc}")
        payload["record_update_errors"] = list(errors)
        try:
            _write_json(run_lease, payload)
        except BaseException as durable_exc:
            errors.append(
                f"durable run record: {type(durable_exc).__name__}: {durable_exc}"
            )
            payload["record_update_errors"] = list(errors)
        return False


def command_run(args: argparse.Namespace) -> int:
    cards = parse_cards(str(args.card) if getattr(args, "card", None) is not None else args.cards)
    _validate_run_args(args, cards)
    root = normalized_output_root(Path(args.output_root), args.project)
    run_id = args.run_id or datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    requested_command = normalized_command(args.command)
    resume_from = _resume_checkpoint(args, requested_command)
    requested_container_names = normalize_container_names(args.container_name)
    lease_id = uuid.uuid4().hex
    effective_command, container_names = prepare_managed_command(
        requested_command, requested_container_names, run_id, lease_id
    )
    require_container_lease_id = bool(container_names)
    run_dir = root / args.project / args.host_label / run_id
    run_lease = run_dir / "lease.json"
    payload: dict[str, object] = {
        "schema_version": 2,
        "lease_id": lease_id,
        "host": socket.gethostname(),
        "host_label": args.host_label,
        "project": args.project,
        "run_id": run_id,
        "cards": cards,
        "pid": os.getpid(),
        "started_at_utc": _utc_now(),
        "command": effective_command,
        "requested_command": requested_command,
        "container_name": container_names[0] if len(container_names) == 1 else None,
        "container_names": container_names,
        "containers": [
            {"name": name, "state": "declared"} for name in container_names
        ],
        "container_lease_label_required": require_container_lease_id,
        "resume_from": resume_from,
        "timeout_seconds": args.timeout_seconds,
        "watch_interval_seconds": args.watch_interval,
        "startup_contract": {
            "runner_may_start_on_state": "starting",
            "starting_written_before_spawn": True,
            "running_written_after_spawn": True,
        },
        "state": "acquiring",
    }
    handle: LeaseHandle | None = None
    child: subprocess.Popen[str] | None = None
    container_bindings: dict[str, ContainerIdentity] = {}
    containers_absent_before_launch = False
    created_run_dir = False
    state_written = False
    record_update_errors: list[str] = []
    signal_context = _signal_guard()
    signal_context.__enter__()
    try:
        handle = acquire_lease(root, args.project, args.host_label, cards, payload)
        run_dir.mkdir(parents=True, exist_ok=False)
        created_run_dir = True
        for name in container_names:
            existing = inspect_owned_container(
                name,
                run_id,
                lease_id=lease_id,
                require_lease_id=require_container_lease_id,
            )
            if existing is not None:
                raise RuntimeError(f"container already exists before launch: {name}")
        containers_absent_before_launch = True
        first, second = require_idle(cards, args.sample_interval)
        payload["preflight"] = {"first": asdict(first), "second": asdict(second)}
        payload["state"] = "starting"
        _update_run_files(handle, run_lease, payload)
        log_path = run_dir / "command.log"
        with log_path.open("w", encoding="utf-8") as log:
            try:
                child = subprocess.Popen(
                    effective_command,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    text=True,
                    start_new_session=True,
                    env={**os.environ, "GENMLU_RUN_ID": run_id, "GENMLU_LEASE_ID": lease_id},
                )
            except OSError as exc:
                payload.update(state="failed_to_start", error=str(exc), finished_at_utc=_utc_now())
                _update_run_files(handle, run_lease, payload)
                state_written = True
                return 127
            payload.update(state="running", child_pgid=child.pid)
            _update_run_files(handle, run_lease, payload)
            started = time.monotonic()
            deadline = started + args.timeout_seconds
            next_watch = started + args.watch_interval
            while True:
                now = time.monotonic()
                wait_seconds = max(0.0, min(deadline, next_watch) - now)
                try:
                    returncode = child.wait(timeout=wait_seconds)
                    payload.update(
                        state="completed" if returncode == 0 else "failed",
                        returncode=returncode,
                        finished_at_utc=_utc_now(),
                    )
                    _update_run_files(handle, run_lease, payload)
                    state_written = True
                    return int(returncode)
                except subprocess.TimeoutExpired:
                    now = time.monotonic()
                if now >= deadline:
                    payload.update(state="timed_out", finished_at_utc=_utc_now())
                    _update_run_files(handle, run_lease, payload)
                    state_written = True
                    return 124
                if now < next_watch:
                    continue
                current_containers = refresh_owned_containers(
                    container_names,
                    run_id,
                    lease_id,
                    container_bindings,
                    require_lease_id=require_container_lease_id,
                )
                payload["containers"] = container_registry_payload(
                    container_names, container_bindings, current_containers
                )
                _update_run_files(handle, run_lease, payload)
                roots = {os.getpid(), child.pid}
                roots.update(identity.pid for identity in current_containers.values() if identity.pid > 0)
                owned_pids = process_tree_pids(roots, child.pid)
                active = sample_preflight(cards, owned_pids=owned_pids)
                if any(
                    state.utilization_percent is None or state.used_mib is None
                    for state in active.card_states
                ):
                    raise RuntimeError("cnmon selected-card metrics became incomplete")
                if active.foreign_accelerator_processes:
                    payload.update(
                        state="yielded_for_conflict",
                        conflicts=active.foreign_accelerator_processes,
                        finished_at_utc=_utc_now(),
                    )
                    _update_run_files(handle, run_lease, payload)
                    state_written = True
                    return 75
                next_watch = now + args.watch_interval
    except RunInterrupted as exc:
        payload.update(state="interrupted", signal=exc.signum, finished_at_utc=_utc_now())
        if handle is not None and created_run_dir:
            state_written = _best_effort_run_update(
                handle,
                run_lease,
                payload,
                "record interrupted state",
                record_update_errors,
            )
        return 128 + exc.signum
    except BaseException as exc:
        payload.update(state="failed_controller", error=str(exc), finished_at_utc=_utc_now())
        if handle is not None and created_run_dir:
            state_written = _best_effort_run_update(
                handle,
                run_lease,
                payload,
                "record controller failure",
                record_update_errors,
            )
        raise
    finally:
        resource_cleanup_errors: list[str] = []
        cleanup_errors: list[str] = []
        lease_released = False
        try:
            if child is not None:
                try:
                    _terminate_process_group(child)
                except Exception as exc:
                    resource_cleanup_errors.append(f"process cleanup: {exc}")
            if container_names and child is not None and containers_absent_before_launch:
                errors = cleanup_owned_containers(
                    container_names,
                    run_id,
                    lease_id,
                    container_bindings,
                    require_lease_id=require_container_lease_id,
                )
                resource_cleanup_errors.extend(f"container cleanup: {error}" for error in errors)
                payload["containers"] = container_registry_payload(
                    container_names, container_bindings, {}
                )
                errors_by_name = {
                    error.partition(": ")[0]: error.partition(": ")[2] or error
                    for error in errors
                }
                for record in payload["containers"]:
                    name = str(record["name"])
                    if name in errors_by_name:
                        record.update(
                            state="cleanup_failed",
                            cleanup_error=errors_by_name[name],
                        )
            if resource_cleanup_errors:
                payload.update(
                    state="cleanup_failed",
                    cleanup_error="; ".join(resource_cleanup_errors),
                    finished_at_utc=_utc_now(),
                )
            if handle is not None and created_run_dir:
                before = len(record_update_errors)
                if not _best_effort_run_update(
                    handle,
                    run_lease,
                    payload,
                    "record final state",
                    record_update_errors,
                ):
                    cleanup_errors.extend(record_update_errors[before:])
            cleanup_errors.extend(resource_cleanup_errors)
            if handle is not None and not resource_cleanup_errors:
                try:
                    lease_released = release_lease(handle)
                    if not lease_released:
                        cleanup_errors.append(
                            "lease release: owned lease is missing or its identity changed"
                        )
                except BaseException as exc:
                    cleanup_errors.append(
                        f"lease release: {type(exc).__name__}: {exc}"
                    )
            if cleanup_errors:
                payload.update(
                    state="cleanup_failed",
                    cleanup_error="; ".join(cleanup_errors),
                    finished_at_utc=_utc_now(),
                )
                if created_run_dir:
                    try:
                        _write_json(run_lease, payload)
                    except BaseException as exc:
                        cleanup_errors.append(
                            f"durable cleanup record: {type(exc).__name__}: {exc}"
                        )
        finally:
            signal_context.__exit__(None, None, None)
        if cleanup_errors:
            disposition = "after lease release" if lease_released else "lease retained"
            raise RuntimeError(
                f"run cleanup failed {disposition}: {'; '.join(cleanup_errors)}"
            )


def command_preflight(args: argparse.Namespace) -> int:
    cards = parse_cards(str(args.card) if getattr(args, "card", None) is not None else args.cards)
    first, second = require_idle(cards, args.sample_interval)
    print(json.dumps({"ready": True, "first": asdict(first), "second": asdict(second)}, ensure_ascii=False, indent=2))
    return 0

def _add_run_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--host-label", required=True, choices=("mlu-10000", "mlu-10001"))
    card_selection = parser.add_mutually_exclusive_group()
    card_selection.add_argument("--cards", default="0,1,2,3,4,5,6,7")
    card_selection.add_argument("--card", type=int)
    parser.add_argument("--sample-interval", type=int, default=300)
    parser.add_argument("--watch-interval", type=int, default=60)
    parser.add_argument("--timeout-seconds", type=int, default=MAX_RUNTIME_SECONDS)
    parser.add_argument("--run-id")
    parser.add_argument("--container-name", action="append")
    parser.add_argument("command", nargs=argparse.REMAINDER)
    parser.set_defaults(handler=command_run)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="benchctl")
    parser.add_argument("--output-root", default=str(DEFAULT_LOCK_ROOT))
    parser.add_argument("--project", default=DEFAULT_PROJECT)
    subparsers = parser.add_subparsers(dest="subcommand", required=True)
    preflight = subparsers.add_parser("preflight")
    cards = preflight.add_mutually_exclusive_group()
    cards.add_argument("--cards", default="0,1,2,3,4,5,6,7")
    cards.add_argument("--card", type=int)
    preflight.add_argument("--sample-interval", type=int, default=300)
    preflight.set_defaults(handler=command_preflight)
    run = subparsers.add_parser("run")
    _add_run_arguments(run)
    resume = subparsers.add_parser("resume")
    resume.add_argument("--checkpoint", required=True)
    _add_run_arguments(resume)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        if args.subcommand in {"run", "resume"}:
            normalized_command(args.command)
        return int(args.handler(args))
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc


if __name__ == "__main__":
    raise SystemExit(main())
