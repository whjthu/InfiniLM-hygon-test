from __future__ import annotations

import hashlib
import importlib.metadata
import inspect
import json
import math
import os
import platform
import random
try:
    import resource
except ModuleNotFoundError:  # Windows can inspect the CLI but cannot run an MLU backend.
    resource = None
import statistics
import sys
from pathlib import Path
from time import perf_counter, time
from typing import Any

import numpy as np
import yaml

from ..manifest import sha256_path
from ..recovery_validation import validate_recovery_enabled
from ..runtime import memory_stats, require_mlu, synchronize
from .. import hy_resume_checkpoint as hy_resume
from .hy_motion_training import (
    _adapter_sha,
    _adapter_state,
    _apply_gradient_checkpointing,
    _apply_lora,
    _as_batch,
    _save_adapter,
    _working_directory,
    validate_hy_motion_cache,
)
from .sdxl_ddpo import ppo_clipped_loss


DEFAULT_VALIDATION_TRACE_MAX_STEPS = 20
DEFAULT_VALIDATION_TRACE_MAX_BYTES = 64 * 1024 * 1024


class _ValidationTraceCollector:
    """Retain complete diagnostic records only while their configured budget permits."""

    def __init__(self, max_steps: int, max_bytes: int) -> None:
        self.max_steps = max_steps
        self.max_bytes = max_bytes
        self.records: list[dict[str, Any]] = []
        self.bytes_used = 0
        self.dropped_records = 0

    def can_retain(self, record_bytes: int) -> bool:
        return (
            len(self.records) < self.max_steps
            and record_bytes <= self.max_bytes - self.bytes_used
        )

    def append(self, record: dict[str, Any]) -> bool:
        record_bytes = _trace_bytes(record)
        if not self.can_retain(record_bytes):
            self.dropped_records += 1
            return False
        self.records.append(record)
        self.bytes_used += record_bytes
        return True


def _validation_trace_options(config: dict[str, Any]) -> tuple[bool, int, int]:
    enabled = config.get("write_validation_trace", False)
    max_steps = config.get("validation_trace_max_steps", DEFAULT_VALIDATION_TRACE_MAX_STEPS)
    max_bytes = config.get("validation_trace_max_bytes", DEFAULT_VALIDATION_TRACE_MAX_BYTES)
    if type(enabled) is not bool:
        raise ValueError("write_validation_trace must be a boolean")
    if type(max_steps) is not int or max_steps <= 0:
        raise ValueError("validation_trace_max_steps must be a positive integer")
    if type(max_bytes) is not int or max_bytes <= 0:
        raise ValueError("validation_trace_max_bytes must be a positive integer")
    return enabled, max_steps, max_bytes


def _trace_bytes(value: Any) -> int:
    if hasattr(value, "numel") and hasattr(value, "element_size"):
        return int(value.numel()) * int(value.element_size())
    if isinstance(value, dict):
        return sum(_trace_bytes(item) for item in value.values())
    if isinstance(value, (list, tuple)):
        return sum(_trace_bytes(item) for item in value)
    return 0


def _gradient_trace_bytes(parameters: list[Any]) -> int:
    return sum(
        int(parameter.grad.numel()) * 4
        for parameter in parameters
        if parameter.grad is not None
    )


def _execution_metadata(final_global_step: int, records: list[dict[str, Any]]) -> dict[str, int]:
    if type(final_global_step) is not int or final_global_step < 0:
        raise ValueError("final_global_step must be a non-negative integer")
    return {
        "global_optimizer_step": final_global_step,
        "executed_optimizer_steps": len(records),
    }


def _result_logs(
    step_log: Path, step_log_sha: str, summary_path: Path, summary_sha: str,
    executed_steps: int,
) -> list[dict[str, str]]:
    logs = [{"path": str(summary_path), "sha256": summary_sha}]
    if step_log.is_file() and step_log.stat().st_size > 0:
        logs.insert(0, {"path": str(step_log), "sha256": step_log_sha})
    elif executed_steps:
        raise RuntimeError("HY-Motion executed updates without a step log")
    return logs


def infer_motion_reward_config(state_dict: dict[str, Any], saved: dict[str, Any]) -> dict[str, Any]:
    config = dict(saved)
    config["latent_dim"] = int(state_dict["global_text_token"].shape[-1])
    config["unified_dim"] = int(state_dict["global_motion_token"].shape[-1])
    config["use_unified_dim"] = True
    config["proj_hidden_dim"] = int(state_dict["proj_135.proj.0.weight"].shape[0])
    projection_indices = {
        int(key.split(".")[2])
        for key in state_dict
        if key.startswith("proj_135.proj.") and key.endswith(".weight")
    }
    config["proj_num_layers"] = max(projection_indices) // 3 + 1
    return config


def gaussian_transition_log_prob(
    next_latent: Any,
    mean: Any,
    std: float,
    temporal_mask: Any,
) -> Any:
    variance = float(std) ** 2
    values = -0.5 * (
        (next_latent.float() - mean.float()).square() / variance
        + math.log(2.0 * math.pi * variance)
    )
    mask = temporal_mask.unsqueeze(-1).expand_as(values)
    return (values * mask).sum(dim=(1, 2)) / mask.sum(dim=(1, 2)).clamp_min(1)


def normalize_policy_motion_for_reward(
    normalized_motion: Any,
    policy_mean: Any,
    policy_std: Any,
    reward_mean: Any,
    reward_std: Any,
) -> Any:
    raw_motion = normalized_motion[..., :135].float() * policy_std[:135] + policy_mean[:135]
    return (raw_motion - reward_mean[:135]) / reward_std[:135].clamp_min(1e-6)


def _state_sha(state: dict[str, Any]) -> str:
    digest = hashlib.sha256()
    for name, tensor in sorted(state.items()):
        value = tensor.detach().float().cpu().contiguous()
        digest.update(name.encode("utf-8"))
        digest.update(str(tuple(value.shape)).encode("ascii"))
        digest.update(value.numpy().tobytes())
    return digest.hexdigest()


def _adapter_parameter_name(name: str) -> str:
    """Remove the transparent checkpoint wrapper from a LoRA parameter path."""
    return name.replace("._checkpoint_wrapped_module", "")


def _named_gradients_before_clip(
    module: Any, max_bytes: int | None = None
) -> dict[str, Any | None]:
    """Capture every trainable adapter gradient with checkpoint-stable names."""
    if max_bytes is not None:
        if type(max_bytes) is not int or max_bytes <= 0:
            raise ValueError("validation trace gradient budget must be a positive integer")
        required_bytes = _gradient_trace_bytes(
            [parameter for parameter in module.parameters() if parameter.requires_grad]
        )
        if required_bytes > max_bytes:
            raise ValueError("validation trace gradient snapshot exceeds its byte budget")
    gradients: dict[str, Any | None] = {}
    for name, parameter in module.named_parameters():
        if not parameter.requires_grad:
            continue
        canonical_name = _adapter_parameter_name(name)
        if canonical_name in gradients:
            raise RuntimeError(
                "HY-Motion adapter parameter names collide after checkpoint-wrapper normalization"
            )
        gradients[canonical_name] = (
            parameter.grad.detach().float().cpu().clone()
            if parameter.grad is not None
            else None
        )
    return {name: gradients[name] for name in sorted(gradients)}


def _resolve_adapter_parameter_names(
    state_names: set[str], parameter_names: set[str]
) -> dict[str, str]:
    parameters_by_canonical_name: dict[str, str] = {}
    for name in parameter_names:
        canonical_name = _adapter_parameter_name(name)
        if canonical_name in parameters_by_canonical_name:
            raise RuntimeError(
                "HY-Motion adapter parameter names collide after checkpoint-wrapper normalization"
            )
        parameters_by_canonical_name[canonical_name] = name

    resolved: dict[str, str] = {}
    missing: list[str] = []
    for name in state_names:
        parameter_name = parameters_by_canonical_name.get(_adapter_parameter_name(name))
        if parameter_name is None:
            missing.append(name)
        else:
            resolved[name] = parameter_name
    if missing:
        raise RuntimeError(f"HY-Motion adapter parameters are missing: {sorted(missing)[:4]}")
    return resolved


def _load_adapter_state(model: Any, state: dict[str, Any]) -> None:
    torch = require_mlu()
    parameters = dict(model.named_parameters())
    resolved = _resolve_adapter_parameter_names(set(state), set(parameters))
    with torch.no_grad():
        for name, tensor in state.items():
            parameter = parameters[resolved[name]]
            parameter.copy_(tensor.to(parameter.device, parameter.dtype))


def _load_adapter_file(path: Path, model: Any) -> str:
    from safetensors.torch import load_file

    if not path.is_file():
        raise RuntimeError(f"HY-Motion preset adapter is missing: {path}")
    state = load_file(path)
    _load_adapter_state(model, state)
    return sha256_path(path)


def _identity_file_map(paths: dict[str, Path]) -> dict[str, str]:
    result = {}
    for name, path in paths.items():
        if not path.is_file():
            raise RuntimeError(f"HY-Motion resume identity file is missing: {name}={path}")
        result[name] = sha256_path(path)
    return result


def _build_resume_contract(
    *,
    torch: Any,
    config: dict[str, Any],
    variant_root: Path,
    source_root: Path,
    motionrft_root: Path,
    cache_sha: str,
    preset_adapter: Path,
    reward_checkpoint: Path,
    scorer: Any,
    samples: list[dict[str, Any]],
    warmup_steps: int,
    max_steps: int,
    group_size: int,
) -> tuple[dict[str, Any], dict[str, Any]]:
    operational_keys = {"output_root", "run_name", "resume_from_checkpoint"}
    effective_config = {
        key: value for key, value in config.items() if key not in operational_keys
    }
    dataset_manifest = Path(str(config["dataset_manifest"]))
    dataset_sha = sha256_path(dataset_manifest)
    expected_dataset_sha = str(config.get("dataset_sha", ""))
    if expected_dataset_sha and dataset_sha != expected_dataset_sha:
        raise RuntimeError(f"HY-Motion dataset manifest SHA mismatch: {dataset_sha}")

    backend_path = Path(__file__).resolve()
    checkpoint_module_path = Path(inspect.getsourcefile(hy_resume) or "")
    training_helper_path = Path(inspect.getsourcefile(_adapter_sha) or "")
    loss_path = Path(inspect.getsourcefile(ppo_clipped_loss) or "")
    runtime_path = Path(inspect.getsourcefile(require_mlu) or "")
    source_files = _identity_file_map(
        {
            "backend": backend_path,
            "checkpoint": checkpoint_module_path,
            "training_helpers": training_helper_path,
            "ppo_loss": loss_path,
            "runtime": runtime_path,
            "hy_loader": source_root / "hymotion" / "utils" / "loaders.py",
            "hy_network": source_root / "hymotion" / "network" / "hymotion_mmdit.py",
            "motionreward": motionrft_root / "motionreward" / "models" / "lora_retrieval.py",
        }
    )
    model_files = _identity_file_map(
        {
            "variant_config": variant_root / "config.yml",
            "base_checkpoint": variant_root / "latest.ckpt",
            "preset_adapter": preset_adapter,
        }
    )
    model_files["declared_model_sha256"] = str(config["model_sha"])
    if len(model_files["declared_model_sha256"]) != 64 or any(
        character not in "0123456789abcdef"
        for character in model_files["declared_model_sha256"]
    ):
        raise RuntimeError("HY-Motion declared model SHA is missing or invalid")

    policy_stats_root = source_root / "stats"
    reward_stats_root = Path(
        str(config.get("motion_reward_stats", motionrft_root / "RFT_HY" / "stats"))
    )
    reward_files = _identity_file_map(
        {
            "checkpoint": reward_checkpoint,
            "sentence_t5": Path(str(config["motion_reward_t5_path"])) / "pytorch_model.bin",
            "policy_mean": policy_stats_root / "Mean.npy",
            "policy_std": policy_stats_root / "Std.npy",
            "reward_mean": reward_stats_root / "Mean.npy",
            "reward_std": reward_stats_root / "Std.npy",
        }
    )
    if reward_files["checkpoint"] != scorer.checkpoint_sha:
        raise RuntimeError("HY-Motion MotionReward checkpoint identity changed after load")
    if reward_files["sentence_t5"] != scorer.t5_sha:
        raise RuntimeError("HY-Motion Sentence-T5 identity changed after load")

    device_ids = [0]
    properties = []
    for device_id in device_ids:
        value = torch.mlu.get_device_properties(device_id)
        properties.append(
            {
                "logical_id": device_id,
                "name": str(getattr(value, "name", torch.mlu.get_device_name(device_id))),
                "total_memory": int(getattr(value, "total_memory", 0)),
            }
        )
    device_description = {
        "configured_cards": str(config.get("cards", "0")),
        "visible_device_count": int(torch.mlu.device_count()),
        "current_device": int(torch.mlu.current_device()),
        "properties": properties,
    }
    try:
        torch_mlu_version = importlib.metadata.version("torch_mlu")
    except importlib.metadata.PackageNotFoundError:
        try:
            torch_mlu_version = importlib.metadata.version("torch-mlu")
        except importlib.metadata.PackageNotFoundError:
            torch_mlu_version = "installed-without-package-metadata"
    runtime_description = {
        "python": platform.python_version(),
        "torch": str(torch.__version__),
        "torch_mlu": torch_mlu_version,
        "container": str(config.get("container", "")),
        "platform": platform.platform(),
    }
    evidence = {
        "config": effective_config,
        "source": source_files,
        "data": {
            "training_cache": cache_sha,
            "dataset_manifest": dataset_sha,
        },
        "model": model_files,
        "reward": reward_files,
        "device": device_description,
        "runtime": runtime_description,
    }
    identity = {key: hy_resume.json_sha256(value) for key, value in evidence.items()}
    sample_order = [str(sample["sample_id"]) for sample in samples]
    contract = hy_resume.build_contract(
        identity=identity,
        seed=int(config.get("seed", 20260902)),
        warmup_steps=warmup_steps,
        max_steps=max_steps,
        group_size=group_size,
        sample_order=sample_order,
        device_ids=device_ids,
    )
    return contract, evidence


def _validate_existing_step_log(path: Path, completed_global_step: int) -> str:
    if not path.exists():
        return "w"
    records = [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if not records:
        return "a"
    steps = [record.get("global_step") for record in records]
    if not all(type(step) is int for step in steps):
        raise RuntimeError("HY-Motion existing step log has an invalid global step")
    if len(steps) != len(set(steps)) or steps != sorted(steps):
        raise RuntimeError("HY-Motion existing step log is duplicated or out of order")
    if steps[-1] != completed_global_step:
        raise RuntimeError(
            "HY-Motion existing step log does not end at the resume checkpoint boundary"
        )
    return "a"


def _measurement_samples_per_second(
    measured_records: list[dict[str, Any]], group_size: int, wall_seconds: float
) -> float | None:
    if not measured_records or wall_seconds <= 0:
        return None
    return len(measured_records) * group_size / wall_seconds


class MotionRewardScorer:
    def __init__(
        self,
        source_root: Path,
        checkpoint_path: Path,
        t5_path: Path,
        policy_stats_root: Path,
        reward_stats_root: Path,
        text_weight: float,
        motion_weight: float,
    ) -> None:
        torch = require_mlu()
        sys.path.insert(0, str(source_root))
        from motionreward.models.lora_retrieval import MultiReprRetrievalWithLoRA

        checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        state_dict = checkpoint["state_dict"]
        inferred = infer_motion_reward_config(
            state_dict, dict(checkpoint.get("model_config", {}))
        )
        accepted = set(inspect.signature(MultiReprRetrievalWithLoRA.__init__).parameters)
        model_config = {
            key: value
            for key, value in inferred.items()
            if key in accepted and key not in {"self", "t5_path"}
        }
        self.model = MultiReprRetrievalWithLoRA(str(t5_path), **model_config)
        missing, unexpected = self.model.load_state_dict(state_dict, strict=False)
        meaningful_missing = [
            key
            for key in missing
            if not key.startswith(("clip.", "critic_", "ai_detection_"))
        ]
        if meaningful_missing or unexpected:
            raise RuntimeError(
                "MotionReward checkpoint mismatch: "
                f"missing={meaningful_missing}, unexpected={unexpected}"
            )
        self.model.to("mlu").eval()
        for parameter in self.model.parameters():
            parameter.requires_grad = False
        self.policy_mean = torch.from_numpy(
            np.load(policy_stats_root / "Mean.npy").astype(np.float32)
        ).to(
            "mlu", dtype=torch.float32
        )
        self.policy_std = torch.from_numpy(
            np.load(policy_stats_root / "Std.npy").astype(np.float32)
        ).to(
            "mlu", dtype=torch.float32
        )
        self.reward_mean = torch.from_numpy(
            np.load(reward_stats_root / "Mean.npy").astype(np.float32)
        ).to(
            "mlu", dtype=torch.float32
        )
        self.reward_std = torch.from_numpy(
            np.load(reward_stats_root / "Std.npy").astype(np.float32)
        ).to(
            "mlu", dtype=torch.float32
        )
        self.text_weight = float(text_weight)
        self.motion_weight = float(motion_weight)
        self.checkpoint_sha = sha256_path(checkpoint_path)
        self.t5_sha = sha256_path(t5_path / "pytorch_model.bin")
        self.model_config = model_config
        self.device_observations: list[str] = []

    def score(
        self,
        prompt: str,
        ground_truth: Any,
        predictions: Any,
        length: int,
    ) -> dict[str, Any]:
        torch = require_mlu()
        batch = int(predictions.shape[0])
        lengths = [length] * batch
        predicted_reward_space = normalize_policy_motion_for_reward(
            predictions,
            self.policy_mean,
            self.policy_std,
            self.reward_mean,
            self.reward_std,
        )
        ground_truth_reward_space = normalize_policy_motion_for_reward(
            ground_truth,
            self.policy_mean,
            self.policy_std,
            self.reward_mean,
            self.reward_std,
        )
        with torch.no_grad(), torch.autocast(device_type="mlu", dtype=torch.float16):
            text_embedding = self.model.get_text_embedding([prompt])
            ground_truth_embedding = self.model.get_motion_embedding(
                ground_truth_reward_space, [length], repr_type="135"
            )
            prediction_embedding = self.model.get_motion_embedding(
                predicted_reward_space, lengths, repr_type="135"
            )
            text_reward = torch.nn.functional.cosine_similarity(
                text_embedding.float().expand(batch, -1), prediction_embedding.float(), dim=-1
            )
            motion_reward = torch.nn.functional.cosine_similarity(
                ground_truth_embedding.float().expand(batch, -1),
                prediction_embedding.float(),
                dim=-1,
            )
            combined = self.text_weight * text_reward + self.motion_weight * motion_reward
        self.device_observations.extend(
            [str(text_embedding.device), str(ground_truth_embedding.device), str(prediction_embedding.device)]
        )
        return {
            "combined": combined.detach().float(),
            "text_motion": text_reward.detach().float(),
            "motion_motion": motion_reward.detach().float(),
        }


def _predict_velocity(
    transformer: Any,
    latent: Any,
    timestep: Any,
    vtxt_input: Any,
    ctxt_input: Any,
    x_mask: Any,
    ctxt_mask: Any,
) -> Any:
    torch = require_mlu()
    batch_size = int(latent.shape[0])
    timesteps = timestep.reshape(-1).float()
    if timesteps.numel() == 1 and batch_size != 1:
        timesteps = timesteps.expand(batch_size)
    if timesteps.numel() != batch_size:
        raise ValueError(
            f"HY-Motion timestep batch {timesteps.numel()} does not match latent batch {batch_size}"
        )
    with torch.autocast(device_type="mlu", dtype=torch.bfloat16):
        return transformer(
            x=latent.to(dtype=torch.bfloat16),
            ctxt_input=ctxt_input,
            vtxt_input=vtxt_input,
            timesteps=timesteps,
            x_mask_temporal=x_mask,
            ctxt_mask_temporal=ctxt_mask,
        )


def _sample_group(
    transformer: Any,
    sample: dict[str, Any],
    sampling_steps: int,
    group_size: int,
    seed: int,
    transition_std: float,
    batch_group: bool = False,
) -> dict[str, Any]:
    torch = require_mlu()
    frames = int(sample["motion"].shape[0])
    length = int(sample["length"])
    vtxt_input = _as_batch(sample["vtxt_input"]).to("mlu", dtype=torch.bfloat16)
    ctxt_input = _as_batch(sample["ctxt_input"]).to("mlu", dtype=torch.bfloat16)
    x_mask = torch.arange(frames, device="mlu").unsqueeze(0) < length
    ctxt_mask = torch.arange(ctxt_input.shape[1], device="mlu").unsqueeze(0) < int(
        sample["ctxt_length"]
    )
    dt = 1.0 / sampling_steps
    step_std = float(transition_std) * math.sqrt(dt)
    if batch_group:
        return _sample_group_batched(
            transformer,
            vtxt_input,
            ctxt_input,
            x_mask,
            ctxt_mask,
            frames,
            sampling_steps,
            group_size,
            seed,
            dt,
            step_std,
        )

    all_states = []
    all_next_states = []
    all_noises = []
    all_log_probs = []
    for sample_index in range(group_size):
        generator = torch.Generator(device="cpu").manual_seed(seed + sample_index)
        latent = torch.randn((1, frames, 201), generator=generator).to("mlu")
        states = []
        next_states = []
        noises = []
        log_probs = []
        with torch.no_grad():
            for index in range(sampling_steps):
                timestep = torch.tensor(index * dt, device="mlu", dtype=torch.float32)
                states.append(latent)
                velocity = _predict_velocity(
                    transformer,
                    latent,
                    timestep,
                    vtxt_input,
                    ctxt_input,
                    x_mask,
                    ctxt_mask,
                )
                mean = latent.float() + dt * velocity.float()
                noise = torch.randn((1, frames, 201), generator=generator).to("mlu")
                next_latent = mean + step_std * noise
                log_prob = gaussian_transition_log_prob(next_latent, mean, step_std, x_mask)
                next_states.append(next_latent)
                noises.append(noise)
                log_probs.append(log_prob.reshape(()))
                latent = next_latent
        all_states.append(torch.stack([value.squeeze(0) for value in states]))
        all_next_states.append(torch.stack([value.squeeze(0) for value in next_states]))
        all_noises.append(torch.stack([value.squeeze(0) for value in noises]))
        all_log_probs.append(torch.stack(log_probs))
    return {
        "latents": torch.stack(all_states),
        "next_latents": torch.stack(all_next_states),
        "noise": torch.stack(all_noises),
        "log_probs": torch.stack(all_log_probs),
        "timesteps": torch.arange(sampling_steps, device="mlu", dtype=torch.float32) * dt,
        "final_motion": torch.stack([states[-1] for states in all_next_states]),
        "vtxt_input": vtxt_input,
        "ctxt_input": ctxt_input,
        "x_mask": x_mask,
        "ctxt_mask": ctxt_mask,
        "step_std": step_std,
    }


def _sample_group_batched(
    transformer: Any,
    vtxt_input: Any,
    ctxt_input: Any,
    x_mask: Any,
    ctxt_mask: Any,
    frames: int,
    sampling_steps: int,
    group_size: int,
    seed: int,
    dt: float,
    step_std: float,
) -> dict[str, Any]:
    """Sample a group in one model call per transition without changing per-sample RNG seeds."""
    torch = require_mlu()
    generators = [torch.Generator(device="cpu").manual_seed(seed + index) for index in range(group_size)]
    latent = torch.stack(
        [torch.randn((frames, 201), generator=generator) for generator in generators]
    ).to("mlu")
    vtxt_input = vtxt_input.repeat(group_size, *([1] * (vtxt_input.ndim - 1)))
    ctxt_input = ctxt_input.repeat(group_size, *([1] * (ctxt_input.ndim - 1)))
    x_mask = x_mask.repeat(group_size, 1)
    ctxt_mask = ctxt_mask.repeat(group_size, 1)
    states = []
    next_states = []
    noises = []
    log_probs = []
    with torch.no_grad():
        for index in range(sampling_steps):
            timestep = torch.full((group_size,), index * dt, device="mlu", dtype=torch.float32)
            states.append(latent)
            velocity = _predict_velocity(
                transformer, latent, timestep, vtxt_input, ctxt_input, x_mask, ctxt_mask
            )
            mean = latent.float() + dt * velocity.float()
            noise = torch.stack(
                [torch.randn((frames, 201), generator=generator) for generator in generators]
            ).to("mlu")
            next_latent = mean + step_std * noise
            next_states.append(next_latent)
            noises.append(noise)
            log_probs.append(gaussian_transition_log_prob(next_latent, mean, step_std, x_mask))
            latent = next_latent
    return {
        "latents": torch.stack(states, dim=1),
        "next_latents": torch.stack(next_states, dim=1),
        "noise": torch.stack(noises, dim=1),
        "log_probs": torch.stack(log_probs, dim=1),
        "timesteps": torch.arange(sampling_steps, device="mlu", dtype=torch.float32) * dt,
        "final_motion": next_states[-1],
        "vtxt_input": vtxt_input,
        "ctxt_input": ctxt_input,
        "x_mask": x_mask,
        "ctxt_mask": ctxt_mask,
        "step_std": step_std,
    }


def _write_trajectory(
    directory: Path,
    rollout: dict[str, Any],
    rewards: Any,
    prompt: str,
    seed: int,
    adapter_sha: str,
    global_step: int,
) -> list[dict[str, str]]:
    torch = require_mlu()
    directory.mkdir(parents=True, exist_ok=True)
    tensor_path = directory / "trajectory.pt"
    torch.save(
        {
            key: rollout[key].detach().cpu()
            for key in ("latents", "next_latents", "noise", "log_probs", "timesteps")
        },
        tensor_path,
    )
    tensor_sha = sha256_path(tensor_path)
    artifacts = [{"path": str(tensor_path), "sha256": tensor_sha}]
    for index, reward in enumerate(rewards.detach().cpu().tolist()):
        record = {
            "adapter_sha": adapter_sha,
            "global_step": global_step,
            "latent": {"path": str(tensor_path), "sample": index, "sha256": tensor_sha},
            "log_prob": rollout["log_probs"][index].detach().cpu().tolist(),
            "noise": {"path": str(tensor_path), "sample": index, "sha256": tensor_sha},
            "prompt": prompt,
            "reward": float(reward),
            "seed": seed + index,
            "timestep": rollout["timesteps"].detach().cpu().tolist(),
        }
        path = directory / f"sample-{index}.json"
        path.write_text(json.dumps(record, sort_keys=True) + "\n", encoding="utf-8")
        artifacts.append({"path": str(path), "sha256": sha256_path(path)})
    return artifacts


def run_hy_motion_motionrft(
    weights: Path,
    config: dict[str, Any],
    output_dir: Path,
    source_root: Path,
    motionrft_root: Path,
) -> dict[str, Any]:
    torch = require_mlu()
    cache_path = Path(str(config["training_cache"]))
    checkpoint_path = Path(str(config["motion_reward_checkpoint"]))
    t5_path = Path(str(config["motion_reward_t5_path"]))
    required = (weights, source_root, motionrft_root, t5_path)
    if not all(path.is_dir() for path in required) or not all(
        path.is_file() for path in (cache_path, checkpoint_path)
    ):
        raise RuntimeError("HY-Motion MotionRFT model, reward, source, or cache is missing")
    cache_sha = sha256_path(cache_path)
    expected_cache_sha = str(config.get("training_cache_sha", ""))
    if expected_cache_sha and expected_cache_sha != cache_sha:
        raise RuntimeError(f"HY-Motion MotionRFT cache SHA mismatch: {cache_sha}")

    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    os.environ["HY_MOTION_QWEN_PATH"] = str(config["qwen_path"])
    os.environ["HY_MOTION_CLIP_PATH"] = str(config["clip_path"])
    sys.path.insert(0, str(source_root))
    from hymotion.utils.loaders import load_object

    output_dir.mkdir(parents=True, exist_ok=True)
    with _working_directory(source_root):
        seed = int(config.get("seed", 20260902))
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.mlu.manual_seed_all(seed)
        torch.mlu.reset_peak_memory_stats()
        cache = torch.load(cache_path, map_location="cpu", weights_only=False)
        validate_hy_motion_cache(cache)
        samples = cache["samples"]

        variant = str(config.get("variant", "HY-Motion-1.0"))
        variant_root = weights / variant
        model_config = dict(
            yaml.safe_load((variant_root / "config.yml").read_text(encoding="utf-8"))
        )
        pipeline_args = dict(model_config["train_pipeline_args"])
        pipeline_args["mean_std_dir"] = str(source_root / "stats")
        pipeline_args["random_generator_on_gpu"] = False
        pipeline_args["train_frames"] = int(cache["frames"])

        load_started = perf_counter()
        pipeline = load_object(
            model_config["train_pipeline"],
            pipeline_args,
            network_module=model_config["network_module"],
            network_module_args=model_config["network_module_args"],
        )
        pipeline.to(device="mlu", dtype=torch.bfloat16)
        pipeline.load_in_demo(str(variant_root / "latest.ckpt"), build_text_encoder=False)
        transformer = pipeline.motion_transformer
        lora_layers = _apply_lora(
            transformer,
            torch,
            rank=int(config.get("lora_rank", 4)),
            alpha=float(config.get("lora_alpha", 8.0)),
            target_fragments=list(
                config.get("lora_target_modules", ["qkv", "proj", "fc1", "fc2"])
            ),
        )
        if bool(config.get("gradient_checkpointing", True)):
            _apply_gradient_checkpointing(transformer)
        preset_adapter = Path(str(config["preset_adapter_path"]))
        preset_adapter_file_sha = _load_adapter_file(preset_adapter, transformer)
        transformer.eval()
        trainable = [parameter for parameter in transformer.parameters() if parameter.requires_grad]
        optimizer = torch.optim.AdamW(
            trainable,
            lr=float(config.get("learning_rate", 5e-5)),
            weight_decay=float(config.get("weight_decay", 0.01)),
        )
        optimizer_progress = hy_resume.initial_optimizer_progress(
            transformer, optimizer
        )
        scorer = MotionRewardScorer(
            motionrft_root,
            checkpoint_path,
            t5_path,
            source_root / "stats",
            Path(str(config.get("motion_reward_stats", motionrft_root / "RFT_HY" / "stats"))),
            float(config.get("text_reward_weight", 0.5)),
            float(config.get("motion_reward_weight", 0.5)),
        )
        synchronize()
        load_seconds = perf_counter() - load_started

        observed_devices: list[str] = []

        def observe_forward(_module: Any, args: tuple[Any, ...], kwargs: dict[str, Any]) -> None:
            value = kwargs.get("x") if kwargs else (args[0] if args else None)
            observed_devices.append(str(getattr(value, "device", "missing")))

        hook = transformer.register_forward_pre_hook(observe_forward, with_kwargs=True)
        anchor_state = _adapter_state(transformer)
        group_size = int(config.get("group_size", 4))
        batch_group = bool(config.get("batch_group_rollout", False))
        batch_anchor = batch_group and bool(config.get("batch_group_anchor", False))
        batch_actor_update = batch_group and bool(
            config.get("batch_group_actor_update", False)
        )
        (
            write_validation_trace,
            validation_trace_max_steps,
            validation_trace_max_bytes,
        ) = _validation_trace_options(config)
        validation_traces = _ValidationTraceCollector(
            validation_trace_max_steps, validation_trace_max_bytes
        )
        sampling_steps = int(config.get("sampling_steps", 4))
        transition_std = float(config.get("transition_std", 0.04))
        clip_range = float(config.get("clip_range", 0.2))
        kl_weight = float(config.get("kl_weight", 0.01))
        max_grad_norm = float(config.get("max_grad_norm", 1.0))
        save_trajectories = bool(config.get("save_trajectories", True))
        warmup_steps = int(config.get("warmup_steps", 0))
        max_steps = int(config.get("max_steps", 20))
        checkpoint_steps = {
            int(value) for value in config.get("checkpoint_steps", [10, 20])
        }
        checkpoint_step_basis = str(config.get("checkpoint_step_basis", "measured"))
        if checkpoint_step_basis not in {"global", "measured"}:
            raise ValueError("checkpoint_step_basis must be global or measured")
        final_global_step = warmup_steps + max_steps
        minimum_checkpoint_step = (
            warmup_steps + 1 if checkpoint_step_basis == "global" else 1
        )
        maximum_checkpoint_step = (
            final_global_step if checkpoint_step_basis == "global" else max_steps
        )
        if not checkpoint_steps or any(
            value < minimum_checkpoint_step or value > maximum_checkpoint_step
            for value in checkpoint_steps
        ):
            raise ValueError("checkpoint_steps must be within the configured schedule")
        resume_contract, resume_identity_evidence = _build_resume_contract(
            torch=torch,
            config=config,
            variant_root=variant_root,
            source_root=source_root,
            motionrft_root=motionrft_root,
            cache_sha=cache_sha,
            preset_adapter=preset_adapter,
            reward_checkpoint=checkpoint_path,
            scorer=scorer,
            samples=samples,
            warmup_steps=warmup_steps,
            max_steps=max_steps,
            group_size=group_size,
        )
        completed_global_step = 0
        completed_measured_steps = 0
        resume_validation_seconds = 0.0
        resume_checkpoint_sha = None
        resume_rng_validation = None
        resume_boundary_validated = False
        resume_value = config.get("resume_from_checkpoint")
        resume_path = Path(str(resume_value)) if resume_value else None
        step_log = output_dir / "steps.ndjson"
        step_log_mode = "w"
        if resume_path is not None:
            resume_started = perf_counter()
            if not resume_path.is_file():
                raise RuntimeError(f"HY-Motion resume checkpoint is missing: {resume_path}")
            resume_payload = hy_resume.load_checkpoint(resume_path)
            preflight = hy_resume.validate_checkpoint(
                resume_payload,
                resume_contract,
                transformer,
                optimizer,
                native_rng=True,
                expected_anchor=anchor_state,
            )
            completed_global_step = int(preflight["metadata"]["global_step"])
            completed_measured_steps = int(preflight["metadata"]["measured_step"])
            step_log_mode = _validate_existing_step_log(
                step_log, completed_global_step
            )
            anchor_state, optimizer_progress, restored = hy_resume.restore_checkpoint(
                resume_payload,
                resume_contract,
                transformer,
                optimizer,
                anchor_state,
            )
            hy_resume.assert_restored_boundary(
                resume_payload,
                resume_contract,
                transformer,
                optimizer,
                anchor_state,
                optimizer_progress,
            )
            resume_boundary_validated = True
            resume_rng_validation = restored["rng_validation"]
            resume_checkpoint_sha = sha256_path(resume_path)
            resume_validation_seconds = perf_counter() - resume_started
        adapter_before = _adapter_sha(transformer)
        anchor_sha = _state_sha(anchor_state)
        trajectory_artifacts: list[dict[str, str]] = []

        def policy_step(global_step: int, save_outputs: bool) -> dict[str, Any]:
            nonlocal optimizer_progress
            sample = samples[(global_step - 1) % len(samples)]
            rollout_seed = seed + global_step * 1000
            rollout_adapter_sha = _adapter_sha(transformer)
            rollout_started = perf_counter()
            rollout = _sample_group(
                transformer,
                sample,
                sampling_steps,
                group_size,
                rollout_seed,
                transition_std,
                batch_group=batch_group,
            )
            synchronize()
            rollout_seconds = perf_counter() - rollout_started

            reward_started = perf_counter()
            ground_truth = sample["motion"].unsqueeze(0).to("mlu", dtype=torch.float32)
            reward_parts = scorer.score(
                sample["prompt"], ground_truth, rollout["final_motion"], int(sample["length"])
            )
            rewards = reward_parts["combined"]
            reward_variance = float(rewards.var(unbiased=False).cpu())
            synchronize()
            reward_seconds = perf_counter() - reward_started
            if reward_variance <= 0.0:
                raise RuntimeError(f"zero HY-Motion MotionReward variance at step {global_step}")
            if save_outputs and save_trajectories:
                trajectory_artifacts.extend(
                    _write_trajectory(
                        output_dir / "trajectories" / f"step-{global_step:04d}",
                        rollout,
                        rewards,
                        sample["prompt"],
                        rollout_seed,
                        rollout_adapter_sha,
                        global_step,
                    )
                )

            advantages = (rewards - rewards.mean()) / (rewards.std(unbiased=False) + 1e-6)
            transition_index = (global_step - 1) % sampling_steps
            timestep = rollout["timesteps"][transition_index]

            def condition_for(index: int, key: str) -> Any:
                value = rollout[key]
                return value[index : index + 1] if batch_group else value

            current_state = _adapter_state(transformer)
            _load_adapter_state(transformer, anchor_state)
            with torch.no_grad():
                if batch_anchor:
                    latent = rollout["latents"][:, transition_index]
                    velocity = _predict_velocity(
                        transformer,
                        latent,
                        timestep,
                        rollout["vtxt_input"],
                        rollout["ctxt_input"],
                        rollout["x_mask"],
                        rollout["ctxt_mask"],
                    )
                    anchor_means = latent.float() + (1.0 / sampling_steps) * velocity.float()
                else:
                    anchor_means = []
                    for index in range(group_size):
                        latent = rollout["latents"][index, transition_index].unsqueeze(0)
                        velocity = _predict_velocity(
                            transformer,
                            latent,
                            timestep,
                            condition_for(index, "vtxt_input"),
                            condition_for(index, "ctxt_input"),
                            condition_for(index, "x_mask"),
                            condition_for(index, "ctxt_mask"),
                        )
                        anchor_means.append(
                            latent.float() + (1.0 / sampling_steps) * velocity.float()
                        )
            _load_adapter_state(transformer, current_state)

            actor_start_sha = _adapter_sha(transformer)
            optimizer.zero_grad(set_to_none=True)
            update_started = perf_counter()
            if batch_actor_update:
                latent = rollout["latents"][:, transition_index]
                next_latent = rollout["next_latents"][:, transition_index]
                old_log_prob = rollout["log_probs"][:, transition_index]
                velocity = _predict_velocity(
                    transformer,
                    latent,
                    timestep,
                    rollout["vtxt_input"],
                    rollout["ctxt_input"],
                    rollout["x_mask"],
                    rollout["ctxt_mask"],
                )
                mean = latent.float() + (1.0 / sampling_steps) * velocity.float()
                new_log_prob = gaussian_transition_log_prob(
                    next_latent,
                    mean,
                    float(rollout["step_std"]),
                    rollout["x_mask"],
                )
                policy_loss, _, approx_kl = ppo_clipped_loss(
                    new_log_prob,
                    old_log_prob,
                    advantages,
                    clip_range,
                )
                moving_kls = (
                    (mean - anchor_means).square().mean(dim=(1, 2))
                    / (2.0 * float(rollout["step_std"]) ** 2 + 1e-6)
                )
                loss = policy_loss + kl_weight * moving_kls.mean()
                loss.backward()
                losses = [loss.detach()]
                ratios = (new_log_prob.detach() - old_log_prob).exp()
                kls = [approx_kl.detach()]
                errors = (new_log_prob.detach() - old_log_prob).abs()
                new_log_probs = new_log_prob.detach()
            else:
                losses = []
                ratios = []
                kls = []
                moving_kls = []
                errors = []
                new_log_probs = []
                for index in range(group_size):
                    latent = rollout["latents"][index, transition_index].unsqueeze(0)
                    next_latent = rollout["next_latents"][index, transition_index].unsqueeze(0)
                    old_log_prob = rollout["log_probs"][index, transition_index].reshape(1)
                    velocity = _predict_velocity(
                        transformer,
                        latent,
                        timestep,
                        condition_for(index, "vtxt_input"),
                        condition_for(index, "ctxt_input"),
                        condition_for(index, "x_mask"),
                        condition_for(index, "ctxt_mask"),
                    )
                    mean = latent.float() + (1.0 / sampling_steps) * velocity.float()
                    new_log_prob = gaussian_transition_log_prob(
                        next_latent,
                        mean,
                        float(rollout["step_std"]),
                        condition_for(index, "x_mask"),
                    )
                    policy_loss, ratio, approx_kl = ppo_clipped_loss(
                        new_log_prob,
                        old_log_prob,
                        advantages[index].reshape(1),
                        clip_range,
                    )
                    moving_kl = (
                        (mean - anchor_means[index]).square().mean()
                        / (2.0 * float(rollout["step_std"]) ** 2 + 1e-6)
                    )
                    loss = policy_loss + kl_weight * moving_kl
                    (loss / group_size).backward()
                    losses.append(loss.detach())
                    ratios.append(ratio.detach())
                    kls.append(approx_kl.detach())
                    moving_kls.append(moving_kl.detach())
                    errors.append((new_log_prob.detach() - old_log_prob).abs())
                    new_log_probs.append(new_log_prob.detach())
            validation_trace: dict[str, Any] | None = None
            trace_gradient_bytes = 0
            if write_validation_trace:
                validation_trace = {
                    "global_step": global_step,
                    "loss": torch.stack(losses).mean().detach().float().cpu(),
                    "old_log_prob": rollout["log_probs"][:, transition_index].detach().float().cpu(),
                    "new_log_prob": (
                        new_log_probs
                        if batch_actor_update
                        else torch.cat(new_log_probs)
                    ).float().cpu(),
                    "rewards": rewards.detach().float().cpu(),
                    "trajectory_mean": rollout["latents"].detach().float().mean().cpu(),
                    "trajectory_std": rollout["latents"].detach().float().std(unbiased=False).cpu(),
                }
                named_gradient_bytes = _gradient_trace_bytes(
                    [parameter for parameter in transformer.parameters() if parameter.requires_grad]
                )
                trace_gradient_bytes = _gradient_trace_bytes(trainable)
                trace_record_bytes = (
                    _trace_bytes(validation_trace)
                    + named_gradient_bytes
                    + trace_gradient_bytes
                )
                if validation_traces.can_retain(trace_record_bytes):
                    validation_trace["named_gradients_before_clip"] = _named_gradients_before_clip(
                        transformer, named_gradient_bytes or 1
                    )
                else:
                    validation_trace = None
                    validation_traces.dropped_records += 1
            grad_norm = torch.nn.utils.clip_grad_norm_(trainable, max_grad_norm)
            if validation_trace is not None:
                if trace_gradient_bytes:
                    gradients = [
                        parameter.grad.detach().float().reshape(-1).cpu()
                        for parameter in trainable
                        if parameter.grad is not None
                    ]
                    validation_trace["gradient"] = torch.cat(gradients)
                else:
                    validation_trace["gradient"] = torch.empty(0, dtype=torch.float32)
            optimizer.step()
            optimizer_progress = hy_resume.advance_optimizer_progress(
                optimizer_progress, transformer, optimizer
            )
            synchronize()
            update_seconds = perf_counter() - update_started
            grad_value = float(grad_norm.detach().cpu())
            if not math.isfinite(grad_value) or grad_value <= 0.0:
                raise RuntimeError(f"invalid HY-Motion MotionRFT gradient: {grad_value}")
            adapter_after = _adapter_sha(transformer)
            if adapter_after == actor_start_sha:
                raise RuntimeError("HY-Motion MotionRFT adapter did not change")
            if validation_trace is not None:
                validation_trace["adapter_sha_after"] = adapter_after
                validation_traces.append(validation_trace)
            difference = errors if batch_actor_update else torch.cat(errors)
            ratio_values = ratios if batch_actor_update else torch.stack(ratios)
            return {
                "global_step": global_step,
                "sample_id": sample["sample_id"],
                "prompt": sample["prompt"],
                "started_unix": time() - rollout_seconds - reward_seconds - update_seconds,
                "ended_unix": time(),
                "rollout_seconds": rollout_seconds,
                "reward_seconds": reward_seconds,
                "update_seconds": update_seconds,
                "step_seconds": rollout_seconds + reward_seconds + update_seconds,
                "reward": {key: value.detach().cpu().tolist() for key, value in reward_parts.items()},
                "reward_variance": reward_variance,
                "grad_norm": grad_value,
                "policy_loss": float(torch.stack(losses).mean().cpu()),
                "approx_kl": float(torch.stack(kls).mean().cpu()),
                "moving_kl": float(
                    (
                        moving_kls.mean()
                        if batch_actor_update
                        else torch.stack(moving_kls).mean()
                    ).cpu()
                ),
                "ratio_mean": float(ratio_values.mean().cpu()),
                "ratio_min": float(ratio_values.min().cpu()),
                "ratio_max": float(ratio_values.max().cpu()),
                "log_prob_mae": float(difference.mean().cpu()),
                "log_prob_p99": float(torch.quantile(difference, 0.99).cpu()),
                "rollout_adapter_sha": rollout_adapter_sha,
                "actor_start_adapter_sha": actor_start_sha,
                "adapter_sha_after": adapter_after,
                "anchor_sha": anchor_sha,
            }

        records: list[dict[str, Any]] = []
        measured: list[dict[str, Any]] = []
        artifacts: list[dict[str, Any]] = []
        written_checkpoint_paths: set[Path] = set()
        training_started = perf_counter()
        measured_training_started = None
        start_global_step = completed_global_step + 1
        if start_global_step > warmup_steps:
            synchronize()
            measured_training_started = perf_counter()
        with step_log.open(step_log_mode, encoding="utf-8") as handle:
            for global_step in range(start_global_step, final_global_step + 1):
                if global_step == warmup_steps + 1:
                    synchronize()
                    measured_training_started = perf_counter()
                record = policy_step(global_step, global_step > warmup_steps)
                records.append(record)
                handle.write(json.dumps(record, sort_keys=True) + "\n")
                handle.flush()
                if global_step > warmup_steps:
                    measured_step = global_step - warmup_steps
                    measured.append(record)
                    checkpoint_coordinate = (
                        global_step
                        if checkpoint_step_basis == "global"
                        else measured_step
                    )
                    if checkpoint_coordinate in checkpoint_steps:
                        path = (
                            output_dir
                            / f"checkpoint-{checkpoint_coordinate}"
                            / "state.pt"
                        )
                        payload = hy_resume.make_payload(
                            contract=resume_contract,
                            global_step=global_step,
                            model=transformer,
                            optimizer=optimizer,
                            optimizer_progress=optimizer_progress,
                            anchor=anchor_state,
                        )
                        hy_resume.save_atomic(path, payload)
                        written_checkpoint_paths.add(path)
                        artifacts.append({"path": str(path), "sha256": sha256_path(path)})
        if measured_training_started is None:
            measured_training_started = training_started

        final_checkpoint_coordinate = (
            final_global_step if checkpoint_step_basis == "global" else max_steps
        )
        checkpoint = output_dir / f"checkpoint-{final_checkpoint_coordinate}" / "state.pt"
        if checkpoint not in written_checkpoint_paths:
            if completed_measured_steps == max_steps and resume_path is not None:
                checkpoint = resume_path
            else:
                payload = hy_resume.make_payload(
                    contract=resume_contract,
                    global_step=final_global_step,
                    model=transformer,
                    optimizer=optimizer,
                    optimizer_progress=optimizer_progress,
                    anchor=anchor_state,
                )
                hy_resume.save_atomic(checkpoint, payload)
                written_checkpoint_paths.add(checkpoint)
                artifacts.append(
                    {"path": str(checkpoint), "sha256": sha256_path(checkpoint)}
                )
        adapter_after = _adapter_sha(transformer)
        adapter_path = output_dir / "adapter-final.safetensors"
        _save_adapter(adapter_path, transformer)
        if write_validation_trace:
            trace_path = output_dir / "validation-trace.pt"
            torch.save(
                {
                    "schema_version": 1,
                    "batch_group_rollout": batch_group,
                    "group_size": group_size,
                    "sampling_steps": sampling_steps,
                    "trace_max_steps": validation_traces.max_steps,
                    "trace_max_bytes": validation_traces.max_bytes,
                    "trace_bytes": validation_traces.bytes_used,
                    "dropped_records": validation_traces.dropped_records,
                    "records": validation_traces.records,
                },
                trace_path,
            )
            artifacts.append({"path": str(trace_path), "sha256": sha256_path(trace_path)})
        artifacts.extend(trajectory_artifacts)
        artifacts.append({"path": str(adapter_path), "sha256": sha256_path(adapter_path)})
        synchronize()
        training_ended = perf_counter()
        training_seconds = training_ended - training_started
        measured_training_seconds = training_ended - measured_training_started
        hook.remove()

        step_seconds = [float(item["step_seconds"]) for item in measured]
        rollout_seconds = [float(item["rollout_seconds"]) for item in measured]
        reward_seconds = [float(item["reward_seconds"]) for item in measured]
        update_seconds = [float(item["update_seconds"]) for item in measured]
        reward_variances = [float(item["reward_variance"]) for item in measured]
        grad_norms = [float(item["grad_norm"]) for item in measured]
        ratios = [float(item["ratio_mean"]) for item in measured]
        log_prob_mae = [float(item["log_prob_mae"]) for item in measured]
        log_prob_p99 = [float(item["log_prob_p99"]) for item in measured]
        moving_kls = [float(item["moving_kl"]) for item in measured]
        executed_steps = len(measured)
        has_new_updates = executed_steps > 0

        def minimum(values: list[float]) -> float | None:
            return min(values) if values else None

        def maximum(values: list[float]) -> float | None:
            return max(values) if values else None

        def median(values: list[float]) -> float | None:
            return statistics.median(values) if values else None

        def mean(values: list[float]) -> float | None:
            return statistics.mean(values) if values else None

        memory = memory_stats()
        checks = {
            "finite_tensors": all(
                math.isfinite(value) for value in step_seconds + ratios + moving_kls
            ),
            "nonzero_finite_gradients": all(
                value > 0.0 and math.isfinite(value) for value in grad_norms
            ),
            "completed_step_checkpoint": bool(written_checkpoint_paths)
            or resume_boundary_validated,
            "resume_boundary": resume_path is None or resume_boundary_validated,
            "current_adapter": all(
                item["rollout_adapter_sha"] == item["actor_start_adapter_sha"]
                for item in measured
            ),
            "main_forward_device": (not has_new_updates)
            or (bool(observed_devices) and all("mlu" in value for value in observed_devices)),
            "reward_forward_device": (not has_new_updates)
            or (
                bool(scorer.device_observations)
                and all("mlu" in value for value in scorer.device_observations)
            ),
            "reward_variance_nonzero": all(value > 0.0 for value in reward_variances),
            "log_prob_alignment": (not has_new_updates)
            or (max(log_prob_mae) <= 0.02 and max(log_prob_p99) <= 0.10),
            "ratio_finite": all(value > 0.0 and math.isfinite(value) for value in ratios),
            "peak_reserved_below_75gb": memory["reserved"] <= 75_000_000_000,
            "official_motionreward_stage1": True,
            "stochastic_flow_trajectory": True,
        }
        if not all(checks.values()):
            raise RuntimeError(f"HY-Motion MotionRFT checks failed: {checks}")
        checkpoint_final_sha = sha256_path(checkpoint)
        summary = {
            "algorithm": "MotionRFT-compatible stochastic flow GRPO",
            "reward_backend": "official MotionReward Stage-1 retrieval backbone",
            "reward_checkpoint_sha256": scorer.checkpoint_sha,
            "sentence_t5_sha256": scorer.t5_sha,
            "reward_model_config": scorer.model_config,
            "preset_adapter_file_sha256": preset_adapter_file_sha,
            "adapter_sha_before": adapter_before,
            "adapter_sha_after": adapter_after,
            "anchor_sha": anchor_sha,
            "lora_layers": sorted(lora_layers),
            "resume": {
                "used": resume_path is not None,
                "source": str(resume_path) if resume_path is not None else None,
                "source_sha256": resume_checkpoint_sha,
                "completed_global_step": completed_global_step,
                "completed_measured_steps": completed_measured_steps,
                "boundary_validated": resume_boundary_validated,
                "rng_validation": resume_rng_validation,
            },
            "checkpoint": {
                "schema": hy_resume.SCHEMA,
                "final_path": str(checkpoint),
                "final_sha256": checkpoint_final_sha,
                "identity": resume_contract["identity"],
                "identity_evidence": resume_identity_evidence,
            },
            "execution": {
                "planned_warmup_steps": warmup_steps,
                "planned_measured_steps": max_steps,
                "checkpoint_step_basis": checkpoint_step_basis,
                "completed_global_step_before_resume": completed_global_step,
                "completed_measured_steps_before_resume": completed_measured_steps,
                "executed_steps_in_process": executed_steps,
            },
            "checks": checks,
        }
        summary_path = output_dir / "summary.json"
        summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
        summary_sha = sha256_path(summary_path)
        step_log_sha = sha256_path(step_log)
        artifacts.append({"path": str(summary_path), "sha256": summary_sha})
        full_measurement_ended = perf_counter()
        full_measurement_wall_seconds = (
            full_measurement_ended - measured_training_started
        )
        result = {
            "artifacts": artifacts,
            "logs": _result_logs(
                step_log, step_log_sha, summary_path, summary_sha, executed_steps
            ),
            "metrics": {
                "steps": max_steps,
                **_execution_metadata(final_global_step, records),
                "executed_steps": executed_steps,
                "completed_steps_before_resume": completed_measured_steps,
                "warmup_steps": warmup_steps,
                "num_generations": group_size,
                "sampling_steps": sampling_steps,
                "reward_variance_min": minimum(reward_variances),
                "reward_variance_median": median(reward_variances),
                "grad_norm_min": minimum(grad_norms),
                "grad_norm_max": maximum(grad_norms),
                "ratio_mean": mean(ratios),
                "moving_kl_mean": mean(moving_kls),
                "log_prob_mae_max": maximum(log_prob_mae),
                "log_prob_p99_max": maximum(log_prob_p99),
                "step_seconds_min": minimum(step_seconds),
                "step_seconds_median": median(step_seconds),
                "step_seconds_max": maximum(step_seconds),
                "measured_step_seconds_sum": sum(step_seconds),
                "updates_per_second": (
                    1.0 / statistics.median(step_seconds) if step_seconds else None
                ),
                "measured_updates_per_second_including_checkpoints": (
                    executed_steps / measured_training_seconds
                    if executed_steps and measured_training_seconds > 0
                    else None
                ),
                "measured_samples_per_second_including_checkpoints": (
                    executed_steps * group_size / measured_training_seconds
                    if executed_steps and measured_training_seconds > 0
                    else None
                ),
                "measured_training_seconds_including_checkpoints": measured_training_seconds,
                "full_measurement_wall_seconds": full_measurement_wall_seconds,
                "measurement_samples_per_second": _measurement_samples_per_second(
                    measured, group_size, full_measurement_wall_seconds
                ),
                "adapter_sha_before": adapter_before,
                "adapter_sha_after": adapter_after,
                "training_cache_sha": cache_sha,
                "mlu_memory": memory,
                "peak_cpu_rss_bytes": int(
                    resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
                ),
                "mlu_utilization": None,
            },
            "stage_timings": {
                "model_load_seconds": load_seconds,
                "training_seconds": training_seconds,
                "measured_training_seconds_including_checkpoints": measured_training_seconds,
                "full_measurement_wall_seconds": full_measurement_wall_seconds,
                "resume_validation_seconds": resume_validation_seconds,
                "rollout_seconds": rollout_seconds,
                "reward_seconds": reward_seconds,
                "update_seconds": update_seconds,
            },
            "checks": checks,
        }
        if not validate_recovery_enabled(config) and measured:
            result["measurement_window"] = {
                "start_monotonic": measured_training_started,
                "work_units": len(measured),
                "unit": "optimizer_steps",
            }
        return result
