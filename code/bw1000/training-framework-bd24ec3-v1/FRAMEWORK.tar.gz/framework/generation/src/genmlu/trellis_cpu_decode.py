"""Bounded CPU decoding of TRELLIS.2 sparse latents into fields and geometry."""
from __future__ import annotations

import argparse
import gc
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
from pathlib import Path
from time import perf_counter
from types import ModuleType
from typing import Any

import numpy as np
import torch
from safetensors import safe_open


PINNED_TRELLIS2_REVISION = "75fbf0183001ed9876c8dbb35de6b68552ee08bd"
RESULT_PREFIX = "GENMLU_TRELLIS_CPU_DECODE_RESULT="
EXPECTED_KEYS = {"coords", "shape_fields", "material_attrs", "vertices", "faces"}
EXPECTED_KEY_COUNTS = {"shape": 292, "material": 284}
SUPPORTED_GEOMETRY_RESOLUTIONS = {256, 512, 1024}
DECODER_FILENAMES = {
    "shape": "shape_dec_next_dc_f16c32_fp16",
    "material": "tex_dec_next_dc_f16c32_fp16",
}
MISSING_COORDINATE = 0xFFFFFFFF


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _tensor_sha256(value: torch.Tensor) -> str:
    tensor = value.detach().cpu().contiguous()
    digest = hashlib.sha256()
    digest.update(str(tuple(tensor.shape)).encode("ascii"))
    digest.update(str(tensor.dtype).encode("ascii"))
    digest.update(tensor.reshape(-1).view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()


def _peak_rss_bytes() -> int | None:
    try:
        import resource
    except ImportError:
        return None
    peak = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    return peak if sys.platform == "darwin" else peak * 1024


def _run_git(source_root: Path, *args: str) -> str:
    completed = subprocess.run(
        ["git", "-C", str(source_root), *args],
        check=False,
        capture_output=True,
        text=True,
        timeout=30,
    )
    if completed.returncode != 0:
        raise RuntimeError(f"cannot verify TRELLIS.2 source: {' '.join(args)}")
    return completed.stdout.strip()


def _verify_source(source_root: Path) -> dict[str, str]:
    revision = _run_git(source_root, "rev-parse", "HEAD")
    if revision != PINNED_TRELLIS2_REVISION:
        raise RuntimeError(
            f"source root must be pinned TRELLIS.2 {PINNED_TRELLIS2_REVISION}; found {revision}"
        )
    if _run_git(source_root, "status", "--porcelain", "--untracked-files=normal"):
        raise RuntimeError("pinned TRELLIS.2 source must be clean")
    paths = {
        "decoder": source_root / "trellis2" / "models" / "sc_vaes" / "sparse_unet_vae.py",
        "geometry": source_root / "o-voxel" / "o_voxel" / "convert" / "flexible_dual_grid.py",
    }
    if any(not path.is_file() for path in paths.values()):
        raise RuntimeError("pinned TRELLIS.2 decoder or geometry source is missing")
    return {name: _sha256(path) for name, path in paths.items()}


def _install_namespace_package(name: str, path: Path) -> None:
    package = ModuleType(name)
    package.__package__ = name
    package.__path__ = [str(path)]
    sys.modules[name] = package


def _load_official_decoder(source_root: Path) -> tuple[type[Any], Any, Path]:
    trellis_root = source_root / "trellis2"
    decoder_path = trellis_root / "models" / "sc_vaes" / "sparse_unet_vae.py"
    if any(name == "trellis2" or name.startswith("trellis2.") for name in sys.modules):
        raise RuntimeError("TRELLIS.2 was imported before isolated CPU decoder setup")
    if os.environ.get("TORCH_DEVICE_BACKEND_AUTOLOAD") != "0":
        raise RuntimeError("CPU decoder requires TORCH_DEVICE_BACKEND_AUTOLOAD=0")
    os.environ["SPARSE_CONV_BACKEND"] = "flex_gemm"
    sys.path.insert(0, str(source_root))
    _install_namespace_package("trellis2", trellis_root)
    _install_namespace_package("trellis2.models", trellis_root / "models")
    _install_namespace_package("trellis2.models.sc_vaes", trellis_root / "models" / "sc_vaes")

    from trellis2.models.sc_vaes import sparse_unet_vae
    from trellis2.modules import sparse as sp
    from genmlu.trellis_sparse_cpu_adapter import install_trellis_cpu_sparse_conv_adapter

    if Path(sparse_unet_vae.__file__).resolve() != decoder_path.resolve():
        raise RuntimeError("official decoder import escaped the pinned source root")
    if "trellis2.models.sc_vaes.fdg_vae" in sys.modules:
        raise RuntimeError("isolated decoder import unexpectedly loaded fdg_vae")
    install_trellis_cpu_sparse_conv_adapter()
    return sparse_unet_vae.SparseUnetVaeDecoder, sp, decoder_path


def _decoder_config(
    prefix: Path, role: str
) -> tuple[dict[str, Any], dict[str, Any], int | None]:
    config_path = prefix.with_suffix(".json")
    weights_path = prefix.with_suffix(".safetensors")
    if not config_path.is_file() or not weights_path.is_file():
        raise RuntimeError(f"{role} decoder requires matching JSON and safetensors files")
    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise RuntimeError(f"cannot read {role} decoder configuration") from error
    if not isinstance(config, dict) or not isinstance(config.get("args"), dict):
        raise RuntimeError(f"invalid {role} decoder configuration")
    args = dict(config["args"])
    common = (
        args.get("use_fp16") is True
        and args.get("latent_channels") == 32
        and isinstance(args.get("model_channels"), list)
        and isinstance(args.get("num_blocks"), list)
        and len(args["model_channels"]) == len(args["num_blocks"]) == 5
        and len(args.get("block_type", [])) == 5
        and all(value == "SparseConvNeXtBlock3d" for value in args["block_type"])
    )
    if not common or len(args["num_blocks"]) - 1 != 4:
        raise RuntimeError(f"unsupported {role} decoder architecture")
    checkpoint_resolution = args.pop("resolution", None)
    if role == "shape":
        if config.get("name") != "FlexiDualGridVaeDecoder":
            raise RuntimeError("unexpected shape decoder configuration")
        if checkpoint_resolution not in SUPPORTED_GEOMETRY_RESOLUTIONS:
            raise RuntimeError("shape decoder checkpoint resolution is unsupported")
        args.pop("voxel_margin", None)
        if args.get("out_channels", 7) != 7 or args.get("pred_subdiv", True) is not True:
            raise RuntimeError("shape decoder must expose seven fields and predict subdivisions")
        args["out_channels"] = 7
        args["pred_subdiv"] = True
    else:
        if config.get("name") != "SparseUnetVaeDecoder":
            raise RuntimeError("unexpected material decoder configuration")
        if args.get("out_channels") != 6 or args.get("pred_subdiv") is not False:
            raise RuntimeError("material decoder must expose six guided PBR attributes")
        if checkpoint_resolution is not None:
            raise RuntimeError("material decoder unexpectedly declares a geometry resolution")
    return config, args, checkpoint_resolution


def _validate_parameter_contract(model: Any, role: str) -> dict[str, int]:
    counts = {"fp16_torso": 0, "fp32_norm": 0, "fp32_head": 0}
    for name, parameter in model.named_parameters():
        if parameter.device.type != "cpu" or not torch.isfinite(parameter).all():
            raise RuntimeError(f"invalid loaded CPU parameter: {role}.{name}")
        if name.startswith("blocks."):
            expected = torch.float32 if ".norm" in name else torch.float16
            key = "fp32_norm" if expected == torch.float32 else "fp16_torso"
        else:
            expected = torch.float32
            key = "fp32_head"
        if parameter.dtype != expected:
            raise RuntimeError(f"decoder precision differs: {role}.{name}")
        counts[key] += 1
    if not all(counts.values()):
        raise RuntimeError(f"decoder precision classes are incomplete: {role}")
    return counts


def _load_decoder(
    prefix: Path,
    role: str,
    resolution: int,
    decoder_class: type[Any],
    expected_weights_sha256: str | None,
) -> tuple[Any, dict[str, Any], dict[str, Any]]:
    config, args, checkpoint_resolution = _decoder_config(prefix, role)
    model = decoder_class(**args).cpu().eval()
    expected = model.state_dict()
    expected_count = EXPECTED_KEY_COUNTS[role]
    if len(expected) != expected_count:
        raise RuntimeError(f"unexpected {role} decoder parameter schema")

    weights_path = prefix.with_suffix(".safetensors")
    weights_sha256 = _sha256(weights_path)
    if expected_weights_sha256 is not None and weights_sha256 != expected_weights_sha256:
        raise RuntimeError(f"{role} decoder safetensors SHA256 differs from configuration")
    with safe_open(str(weights_path), framework="pt", device="cpu") as handle:
        keys = set(handle.keys())
        if len(keys) != expected_count or keys != set(expected):
            raise RuntimeError(f"strict {role} decoder checkpoint keys differ")
        state: dict[str, torch.Tensor] = {}
        for name, reference in expected.items():
            if tuple(handle.get_slice(name).get_shape()) != tuple(reference.shape):
                raise RuntimeError(f"checkpoint shape differs: {role}.{name}")
            value = handle.get_tensor(name)
            if value.device.type != "cpu" or not torch.isfinite(value).all():
                raise RuntimeError(f"invalid checkpoint tensor: {role}.{name}")
            state[name] = value
    model.load_state_dict(state, strict=True)
    del state
    gc.collect()
    precision_counts = _validate_parameter_contract(model, role)
    record = {
        "config_sha256": _sha256(prefix.with_suffix(".json")),
        "checkpoint_resolution": checkpoint_resolution,
        "expected_weights_sha256": expected_weights_sha256,
        "precision_parameter_counts": precision_counts,
        "strict_key_count": expected_count,
        "requested_geometry_resolution": resolution,
        "weights_sha256": weights_sha256,
    }
    return model, config, record


def _validate_coordinates(coords: torch.Tensor, *, resolution: int, label: str) -> None:
    if coords.device.type != "cpu" or coords.ndim != 2 or coords.shape[1] != 4:
        raise RuntimeError(f"{label} coordinates must be CPU [N, 4]")
    if coords.dtype == torch.bool or torch.is_floating_point(coords) or torch.is_complex(coords):
        raise RuntimeError(f"{label} coordinates must use an integer dtype")
    if not len(coords):
        raise RuntimeError(f"{label} coordinates are empty")
    if not (coords[:, 0] == 0).all():
        raise RuntimeError(f"{label} coordinates must be single-batch zero")
    spatial = coords[:, 1:]
    if (spatial < 0).any() or (spatial >= resolution).any():
        raise RuntimeError(f"{label} coordinates are outside the decoder grid")
    if torch.unique(coords, dim=0).shape[0] != len(coords):
        raise RuntimeError(f"{label} coordinates must be unique")


def _validate_sparse(
    value: Any,
    *,
    channels: int | None,
    max_points: int,
    resolution: int,
    label: str,
) -> dict[str, Any]:
    if value.feats.device.type != "cpu" or not torch.isfinite(value.feats).all():
        raise RuntimeError(f"{label} features must be finite CPU data")
    if len(value.coords) > max_points:
        raise RuntimeError(f"{label} point budget exceeded; truncation is forbidden")
    _validate_coordinates(value.coords, resolution=resolution, label=label)
    if value.feats.ndim != 2 or value.feats.shape[0] != len(value.coords):
        raise RuntimeError(f"{label} sparse feature shape differs from coordinates")
    if channels is not None and value.feats.shape[1] != channels:
        raise RuntimeError(f"{label} sparse feature channel count differs")
    return {
        "channels": int(value.feats.shape[1]),
        "coords_sha256": _tensor_sha256(value.coords),
        "dtype": str(value.feats.dtype),
        "features_sha256": _tensor_sha256(value.feats),
        "rows": len(value.coords),
    }


def _load_latents(
    path: Path, expected_sha256: str, *, max_points: int, resolution: int
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    if not path.is_file() or _sha256(path) != expected_sha256:
        raise RuntimeError("latent input SHA256 differs from the parent request")
    with np.load(path, allow_pickle=False) as data:
        missing = {"coords", "shape_latent", "texture_latent"} - set(data.files)
        if missing:
            raise RuntimeError(f"latent input is missing {sorted(missing)}")
        coords_array = np.array(data["coords"], copy=True)
        feature_arrays = {
            "shape": np.array(data["shape_latent"], copy=True),
            "material": np.array(data["texture_latent"], copy=True),
        }
    if coords_array.dtype.kind not in "iu":
        raise RuntimeError("latent coordinates must be integer before tensor conversion")
    if coords_array.ndim != 2 or coords_array.shape[1] != 4 or not len(coords_array):
        raise RuntimeError("latent coordinates must be nonempty [N, 4]")
    if len(coords_array) > max_points:
        raise RuntimeError("latent input point budget exceeded; truncation is forbidden")
    if np.any(coords_array[:, 0] != 0):
        raise RuntimeError("latent input coordinates must be single-batch zero")
    spatial = coords_array[:, 1:]
    if np.any(spatial < 0) or np.any(spatial >= resolution):
        raise RuntimeError("latent input coordinates are outside the decoder grid")
    if len(np.unique(coords_array, axis=0)) != len(coords_array):
        raise RuntimeError("latent input coordinates must be unique")
    coords = torch.from_numpy(coords_array).to(device="cpu", dtype=torch.int32)
    _validate_coordinates(coords, resolution=resolution, label="latent input")
    features: dict[str, torch.Tensor] = {}
    for role, array in feature_arrays.items():
        if array.dtype != np.float32 or array.shape != (len(coords), 32) or not np.isfinite(array).all():
            raise RuntimeError(f"{role} latent features must be finite float32 [N, 32]")
        features[role] = torch.from_numpy(array).to(device="cpu", dtype=torch.float32)
    return coords, features


class CPUCoordinateLookup:
    def __init__(self) -> None:
        self.table: dict[tuple[int, int, int], int] = {}

    def hashmap_insert_3d_idx_as_val_cuda(self, keys, values, coordinates, *grid_size) -> None:
        _validate_coordinates(
            coordinates,
            resolution=max(int(value) for value in grid_size),
            label="geometry lookup",
        )
        self.table = {}
        for index, row in enumerate(coordinates.tolist()):
            batch, *xyz = map(int, row)
            if batch != 0 or any(value < 0 or value >= bound for value, bound in zip(xyz, grid_size)):
                raise ValueError("coordinates outside the single-batch geometry grid")
            point = tuple(xyz)
            if point in self.table:
                raise ValueError("duplicate geometry grid coordinates")
            self.table[point] = index

    def hashmap_lookup_3d_cuda(self, keys, values, coordinates, *grid_size) -> torch.Tensor:
        if coordinates.device.type != "cpu" or coordinates.ndim != 2 or coordinates.shape[1] != 4:
            raise ValueError("CPU lookup requires [N, 4] CPU coordinates")
        result = []
        for row in coordinates.tolist():
            batch, *xyz = map(int, row)
            valid = batch == 0 and all(0 <= value < bound for value, bound in zip(xyz, grid_size))
            result.append(self.table.get(tuple(xyz), MISSING_COORDINATE) if valid else MISSING_COORDINATE)
        return torch.tensor(result, dtype=torch.uint32, device="cpu")


def _load_official_geometry(source_root: Path):
    relative = Path("o-voxel/o_voxel/convert/flexible_dual_grid.py")
    path = source_root / relative
    if _run_git(source_root, "diff", "--exit-code", "HEAD", "--", relative.as_posix()):
        raise RuntimeError("official dual-grid source differs from the pinned revision")
    lookup = CPUCoordinateLookup()
    namespace = "_genmlu_cpu_dual_grid"
    names = (namespace, namespace + ".convert", namespace + ".convert.flexible_dual_grid")
    if any(name in sys.modules for name in names):
        raise RuntimeError("CPU dual-grid namespace is already active")
    package = ModuleType(names[0])
    package.__path__ = []
    package._C = lookup
    convert_package = ModuleType(names[1])
    convert_package.__path__ = []
    try:
        sys.modules[names[0]] = package
        sys.modules[names[1]] = convert_package
        spec = importlib.util.spec_from_file_location(names[2], path)
        if spec is None or spec.loader is None:
            raise RuntimeError("cannot load official dual-grid source")
        module = importlib.util.module_from_spec(spec)
        sys.modules[names[2]] = module
        spec.loader.exec_module(module)
        return module.flexible_dual_grid_to_mesh
    finally:
        for name in reversed(names):
            sys.modules.pop(name, None)


def _geometry(
    source_root: Path,
    coordinates: torch.Tensor,
    dual_vertices: torch.Tensor,
    intersected: torch.Tensor,
    split_weight: torch.Tensor | None,
    *,
    resolution: int,
    max_points: int,
) -> tuple[torch.Tensor, torch.Tensor]:
    tensors = (coordinates, dual_vertices, intersected)
    if split_weight is not None:
        tensors = (*tensors, split_weight)
    if any(value.device.type != "cpu" for value in tensors):
        raise RuntimeError("geometry requires explicit CPU tensors")
    if coordinates.shape != (len(coordinates), 3) or coordinates.dtype not in (torch.int32, torch.int64):
        raise RuntimeError("geometry coordinates must be integer [N, 3]")
    if dual_vertices.shape != (len(coordinates), 3) or intersected.shape != (len(coordinates), 3):
        raise RuntimeError("geometry fields do not match coordinates")
    if split_weight is not None and (
        split_weight.shape != (len(coordinates), 1)
        or not torch.isfinite(split_weight).all()
        or not (split_weight > 0).all()
    ):
        raise RuntimeError("geometry split weights must be positive finite [N, 1]")
    if not torch.isfinite(dual_vertices).all():
        raise RuntimeError("geometry fields must be finite")
    converter = _load_official_geometry(source_root)
    vertices, faces = converter(
        coordinates,
        dual_vertices,
        intersected,
        split_weight,
        aabb=[[-0.5, -0.5, -0.5], [0.5, 0.5, 0.5]],
        grid_size=resolution,
        train=False,
    )
    if vertices.device.type != "cpu" or faces.device.type != "cpu":
        raise RuntimeError("geometry converter returned a non-CPU tensor")
    if not len(vertices) or not len(faces) or len(vertices) > max_points:
        raise RuntimeError("decoded geometry is empty or exceeds the point budget")
    if vertices.ndim != 2 or vertices.shape[1] != 3 or not torch.isfinite(vertices).all():
        raise RuntimeError("decoded vertices are invalid")
    if faces.ndim != 2 or faces.shape[1] != 3 or faces.dtype not in (torch.int32, torch.int64):
        raise RuntimeError("decoded faces are invalid")
    if int(faces.min()) < 0 or int(faces.max()) >= len(vertices):
        raise RuntimeError("decoded face index is outside the vertex array")
    return vertices, faces


def _stage_modules(model: Any) -> list[Any]:
    stages = [stage[-1] for stage in model.blocks[:-1] if len(stage)]
    if len(stages) != 4:
        raise RuntimeError("decoder must expose exactly four upsampling stages")
    return stages


@torch.no_grad()
def decode(
    *,
    source_root: Path,
    weights_root: Path,
    input_path: Path,
    input_sha256: str,
    output_path: Path,
    resolution: int,
    max_points: int,
    threads: int,
    expected_weight_hashes: dict[str, str | None],
) -> dict[str, Any]:
    if output_path.exists() or output_path.suffix != ".npz":
        raise RuntimeError("CPU decoder output must be a new NPZ path")
    if resolution not in SUPPORTED_GEOMETRY_RESOLUTIONS:
        raise RuntimeError("CPU decoder resolution must be one of 256, 512, or 1024")
    if min(max_points, threads) < 1:
        raise RuntimeError("CPU decoder bounds and thread count must be positive")
    torch.set_num_threads(threads)
    torch.set_default_dtype(torch.float32)
    if hasattr(torch, "set_default_device"):
        torch.set_default_device("cpu")
    source_hashes = _verify_source(source_root)
    decoder_class, sp, decoder_path = _load_official_decoder(source_root)
    if _sha256(decoder_path) != source_hashes["decoder"]:
        raise RuntimeError("official decoder source changed during child setup")
    coords, features = _load_latents(
        input_path, input_sha256, max_points=max_points, resolution=resolution
    )

    timings: dict[str, float] = {}
    decoder_records: dict[str, Any] = {}
    shape_stage_coords: list[torch.Tensor] = []
    shape_stage_records: list[dict[str, Any]] = []
    decoded: dict[str, Any] = {}
    guides: list[Any] | None = None

    for role in ("shape", "material"):
        prefix = weights_root / "ckpts" / DECODER_FILENAMES[role]
        started = perf_counter()
        model, config, record = _load_decoder(
            prefix,
            role,
            resolution,
            decoder_class,
            expected_weight_hashes[role],
        )
        timings[f"cpu_{role}_decoder_load_seconds"] = perf_counter() - started
        handles = []
        stage_records: list[dict[str, Any]] = []
        stages = _stage_modules(model)

        for index, stage in enumerate(stages):
            def stage_hook(_module, inputs, result, *, index=index, role=role):
                stage_input = inputs[0]
                if role == "shape":
                    if not isinstance(result, tuple) or len(result) != 2:
                        raise RuntimeError("shape upsampling stage did not return a raw guide")
                    stage_output, raw_guide = result
                    _validate_sparse(
                        raw_guide,
                        channels=8,
                        max_points=max_points,
                        resolution=resolution,
                        label=f"shape guide {index}",
                    )
                    if not torch.equal(raw_guide.coords, stage_input.coords):
                        raise RuntimeError("shape raw guide coordinates differ from stage input")
                    shape_stage_coords.append(stage_output.coords.detach().clone())
                    stage_record = {
                        "guided_coords_sha256": _tensor_sha256(raw_guide.coords),
                        "input_coords_sha256": _tensor_sha256(stage_input.coords),
                        "output": _validate_sparse(
                            stage_output,
                            channels=None,
                            max_points=max_points,
                            resolution=resolution,
                            label=f"shape stage {index}",
                        ),
                        "raw_guide_sha256": _tensor_sha256(raw_guide.feats),
                    }
                    shape_stage_records.append(stage_record)
                else:
                    if guides is None:
                        raise RuntimeError("material decoder has no shape guides")
                    if not torch.equal(stage_input.coords, guides[index].coords):
                        raise RuntimeError("material stage input coordinates differ from its raw guide")
                    if isinstance(result, tuple):
                        raise RuntimeError("guided material stage unexpectedly predicted a guide")
                    if not torch.equal(result.coords, shape_stage_coords[index]):
                        raise RuntimeError("material stage output coordinates differ from shape")
                    stage_record = {
                        "guided_coords_sha256": _tensor_sha256(guides[index].coords),
                        "input_coords_sha256": _tensor_sha256(stage_input.coords),
                        "output": _validate_sparse(
                            result,
                            channels=None,
                            max_points=max_points,
                            resolution=resolution,
                            label=f"material stage {index}",
                        ),
                        "raw_guide_sha256": _tensor_sha256(guides[index].feats),
                    }
                stage_records.append(stage_record)

            handles.append(stage.register_forward_hook(stage_hook))

        value = sp.SparseTensor(feats=features[role], coords=coords)
        started = perf_counter()
        try:
            if role == "shape":
                result, guides = model(value, return_subs=True)
            else:
                guide_hashes_before = [
                    (_tensor_sha256(guide.coords), _tensor_sha256(guide.feats)) for guide in guides or []
                ]
                result = model(value, guide_subs=guides)
                guide_hashes_after = [
                    (_tensor_sha256(guide.coords), _tensor_sha256(guide.feats)) for guide in guides or []
                ]
                if guide_hashes_after != guide_hashes_before:
                    raise RuntimeError("guided material decoding mutated raw shape guides")
        finally:
            for handle in handles:
                handle.remove()
        timings[f"cpu_{role}_decoder_forward_seconds"] = perf_counter() - started
        if len(stage_records) != 4:
            raise RuntimeError(f"{role} decoder did not execute exactly four upsampling stages")
        channels = 7 if role == "shape" else 6
        output_record = _validate_sparse(
            result,
            channels=channels,
            max_points=max_points,
            resolution=resolution,
            label=f"{role} decoder output",
        )
        if result.feats.dtype != torch.float32:
            raise RuntimeError(f"{role} decoder head did not return float32")
        if role == "shape":
            if guides is None or len(guides) != 4 or len(shape_stage_records) != 4:
                raise RuntimeError("shape decoder did not return four raw guides")
            for index, guide in enumerate(guides):
                if (
                    _tensor_sha256(guide.coords) != shape_stage_records[index]["guided_coords_sha256"]
                    or _tensor_sha256(guide.feats) != shape_stage_records[index]["raw_guide_sha256"]
                ):
                    raise RuntimeError("returned raw guide differs from its stage capture")
            shape_config = config
        elif not torch.equal(result.coords, decoded["shape"].coords):
            raise RuntimeError("material output coordinates differ exactly from shape output")
        decoded[role] = result
        record["output"] = output_record
        record["stages"] = stage_records
        decoder_records[role] = record
        del model, value
        gc.collect()

    shape = decoded["shape"]
    material = decoded["material"]
    margin = float(shape_config["args"].get("voxel_margin", 0.5))
    dual_vertices = (1 + 2 * margin) * torch.sigmoid(shape.feats[:, :3]) - margin
    intersected = shape.feats[:, 3:6] > 0
    split_weights = torch.nn.functional.softplus(shape.feats[:, 6:7])
    started = perf_counter()
    vertices, faces = _geometry(
        source_root,
        shape.coords[:, 1:],
        dual_vertices,
        intersected,
        split_weights,
        resolution=resolution,
        max_points=max_points,
    )
    timings["cpu_geometry_seconds"] = perf_counter() - started

    arrays = {
        "coords": shape.coords.detach().cpu().numpy(),
        "shape_fields": shape.feats.detach().cpu().numpy(),
        "material_attrs": (material.feats * 0.5 + 0.5).detach().cpu().numpy(),
        "vertices": vertices.detach().cpu().numpy(),
        "faces": faces.detach().cpu().numpy(),
    }
    if set(arrays) != EXPECTED_KEYS or not all(np.isfinite(value).all() for value in arrays.values()):
        raise RuntimeError("decoded output arrays are incomplete or non-finite")
    if _verify_source(source_root) != source_hashes:
        raise RuntimeError("pinned TRELLIS.2 source changed during CPU decoding")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(output_path, **arrays)
    output_sha256 = _sha256(output_path)
    return {
        "schema": "genmlu-trellis-cpu-decode-v1",
        "source_revision": PINNED_TRELLIS2_REVISION,
        "source_clean": True,
        "source_sha256": source_hashes,
        "sidecar_sha256": _sha256(Path(__file__)),
        "input": {"path": str(input_path.resolve()), "sha256": input_sha256},
        "output": {
            "path": str(output_path.resolve()),
            "sha256": output_sha256,
            "keys": sorted(EXPECTED_KEYS),
        },
        "decoders": decoder_records,
        "geometry": {"faces": len(faces), "vertices": len(vertices)},
        "runtime": {
            "device": "cpu",
            "peak_rss_bytes": _peak_rss_bytes(),
            "threads": threads,
            "torch_device_backend_autoload": os.environ.get("TORCH_DEVICE_BACKEND_AUTOLOAD"),
        },
        "timings": timings,
    }


def _optional_sha256(value: str | None) -> str | None:
    if value is None:
        return None
    if len(value) != 64 or any(character not in "0123456789abcdef" for character in value):
        raise argparse.ArgumentTypeError("expected a lowercase SHA256 digest")
    return value


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--weights-root", type=Path, required=True)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--input-sha256", type=_optional_sha256, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--resolution", type=int, required=True)
    parser.add_argument("--max-points", type=int, required=True)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--shape-weights-sha256", type=_optional_sha256)
    parser.add_argument("--material-weights-sha256", type=_optional_sha256)
    args = parser.parse_args()
    result = decode(
        source_root=args.source_root,
        weights_root=args.weights_root,
        input_path=args.input,
        input_sha256=args.input_sha256,
        output_path=args.output,
        resolution=args.resolution,
        max_points=args.max_points,
        threads=args.threads,
        expected_weight_hashes={
            "shape": args.shape_weights_sha256,
            "material": args.material_weights_sha256,
        },
    )
    print(RESULT_PREFIX + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
