from __future__ import annotations

import hashlib
import importlib
import inspect
import json
import math
import os
import random
from dataclasses import dataclass
try:
    import resource
except ModuleNotFoundError:  # Windows can inspect the CLI but cannot run an MLU backend.
    resource = None
import statistics
import sys
from pathlib import Path
from time import perf_counter, time
from typing import Any

import numpy as np

from .. import hy_resume_checkpoint as resume_common
from .. import runtime as runtime_helpers
from ..manifest import sha256_path
from ..recovery_validation import run_recovery_validation, validate_recovery_enabled
from ..runtime import autocast_bf16, memory_stats, require_mlu, synchronize
from .sf3d_reconstruction import _prepare_batch


SF3D_CHECKPOINT_SCHEMA = "sf3d-material-head-full-optimizer-step-v4"
_SF3D_IDENTITY_FIELDS = {"backend", "weights", "sources", "runtime", "imports"}
_SF3D_CACHE_KEYS = (
    "triplane_features", "image_features", "albedo", "roughness", "metallic",
)
_SF3D_MAX_CHECKPOINT_CACHE_BYTES = 1 << 30


class SF3DCheckpointValidationError(ValueError):
    """The Stable Fast 3D checkpoint is incomplete or incompatible with this run."""


class SF3DResumeApplyFatal(RuntimeError):
    """Checkpoint application failed after validation; do not continue training."""


@dataclass(frozen=True)
class _SF3DPreparedCheckpoint:
    payload: dict[str, Any]
    checked: dict[str, Any]


def _sf3d_require(condition: bool, message: str) -> None:
    if not condition:
        raise SF3DCheckpointValidationError(message)


def foreground_material_targets(rgba: np.ndarray) -> dict[str, np.ndarray | float]:
    if rgba.ndim != 3 or rgba.shape[-1] != 4:
        raise ValueError("expected an RGBA image array")
    pixels = rgba[..., :3].astype(np.float32) / 255.0
    mask = rgba[..., 3] > 0
    if not np.any(mask):
        raise ValueError("material supervision requires a non-empty alpha mask")
    foreground = pixels[mask]
    maximum = foreground.max(axis=-1)
    minimum = foreground.min(axis=-1)
    saturation = np.divide(
        maximum - minimum,
        np.maximum(maximum, 1e-6),
    ).mean()
    luminance = (
        foreground[:, 0] * 0.2126
        + foreground[:, 1] * 0.7152
        + foreground[:, 2] * 0.0722
    ).mean()
    return {
        "albedo": foreground.mean(axis=0),
        "roughness": float(np.clip(0.85 - 0.45 * saturation + 0.10 * (1 - luminance), 0.05, 0.95)),
        "metallic": float(np.clip(0.05 + 0.25 * saturation * maximum.mean(), 0.01, 0.40)),
    }


def _selected_named_parameters(model: Any) -> list[tuple[str, Any]]:
    prefixes = (
        "decoder.heads.features.",
        "image_estimator.heads.roughness.",
        "image_estimator.heads.metallic.",
    )
    return [
        (name, parameter)
        for name, parameter in model.named_parameters()
        if name.startswith(prefixes)
    ]


def _parameter_sha(named_parameters: list[tuple[str, Any]]) -> str:
    digest = hashlib.sha256()
    for name, parameter in named_parameters:
        value = parameter.detach().cpu().float().contiguous()
        digest.update(name.encode("utf-8"))
        digest.update(str(tuple(value.shape)).encode("ascii"))
        digest.update(value.numpy().tobytes())
    return digest.hexdigest()


def _state_dict(named_parameters: list[tuple[str, Any]]) -> dict[str, Any]:
    return {name: parameter.detach().cpu() for name, parameter in named_parameters}


def _load_state(torch: Any, named_parameters: list[tuple[str, Any]], state: dict[str, Any]) -> None:
    expected = {name for name, _ in named_parameters}
    if set(state) != expected:
        raise RuntimeError("Stable Fast 3D material checkpoint parameter set mismatch")
    with torch.no_grad():
        for name, parameter in named_parameters:
            parameter.copy_(state[name].to(device=parameter.device, dtype=parameter.dtype))


def _beta_mean(torch: Any, head: Any, image_features: Any) -> Any:
    shared, first, second = head
    shared_features = shared(image_features)
    alpha = torch.nn.functional.softplus(first(shared_features).squeeze(-1) + 1.0)
    beta = torch.nn.functional.softplus(second(shared_features).squeeze(-1) + 1.0)
    return alpha / (alpha + beta)


def _image_features(torch: Any, model: Any, batch: dict[str, Any]) -> Any:
    import open_clip

    cond_image = batch["rgb_cond"] * batch["mask_cond"]
    if cond_image.ndim == 4:
        cond_image = cond_image.unsqueeze(1)
    cond_image = torch.nn.functional.interpolate(
        cond_image.flatten(0, 1).permute(0, 3, 1, 2).contiguous(),
        size=(224, 224),
        mode="bilinear",
        align_corners=False,
    )
    mean = torch.tensor(
        open_clip.constants.OPENAI_DATASET_MEAN,
        device=cond_image.device,
        dtype=cond_image.dtype,
    ).view(1, 3, 1, 1)
    std = torch.tensor(
        open_clip.constants.OPENAI_DATASET_STD,
        device=cond_image.device,
        dtype=cond_image.dtype,
    ).view(1, 3, 1, 1)
    return model.image_estimator.model.encode_image((cond_image - mean) / std)


def _sf3d_json_sha256(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    ).hexdigest()


def _sf3d_paths_sha256(
    paths: list[Path], root: Path | None = None, *, include_paths: bool = True
) -> str:
    entries: list[dict[str, str]] = []
    for path in paths:
        digest = sha256_path(path)
        if digest is None:
            raise RuntimeError(f"cannot hash required Stable Fast 3D resume input: {path}")
        entry = {"sha256": digest}
        if include_paths:
            name = str(path.relative_to(root)) if root is not None else path.name
            entry["path"] = name.replace("\\", "/")
        entries.append(entry)
    return _sf3d_json_sha256(entries)


def _sf3d_source_sha256(value: Any, label: str) -> str:
    source = inspect.getsourcefile(value)
    if source is None or not Path(source).is_file():
        raise RuntimeError(f"cannot identify Stable Fast 3D resume dependency source: {label}")
    digest = sha256_path(Path(source))
    if digest is None:
        raise RuntimeError(f"cannot hash Stable Fast 3D resume dependency source: {label}")
    return digest


def _sf3d_imported_package_sha256(source_root: Path) -> str:
    pinned_root = source_root.resolve()
    package_root = (source_root / "sf3d").resolve()
    try:
        package_root.relative_to(pinned_root)
    except ValueError as error:
        raise RuntimeError("Stable Fast 3D package root escapes the requested source tree") from error
    if not package_root.is_dir():
        raise RuntimeError(f"cannot identify Stable Fast 3D source package: {package_root}")

    imported: list[dict[str, str]] = []
    for name, module in sorted(sys.modules.items()):
        if name != "sf3d" and not name.startswith("sf3d."):
            continue
        file_name = getattr(module, "__file__", None)
        if isinstance(file_name, str) and file_name:
            resolved = Path(file_name).resolve()
            try:
                relative = resolved.relative_to(package_root)
            except ValueError as error:
                raise RuntimeError(
                    f"Stable Fast 3D imported module escapes the requested source tree: {name}"
                ) from error
            digest = sha256_path(resolved)
            if digest is None:
                raise RuntimeError(f"cannot hash Stable Fast 3D imported module: {name}")
            imported.append({"module": name, "path": str(relative).replace("\\", "/"), "sha256": digest})
            continue

        # Upstream sf3d is a namespace package. Its import locations are part of
        # the execution identity even though namespace packages have no file to hash.
        locations = getattr(module, "__path__", None)
        if file_name is not None or locations is None:
            raise RuntimeError(f"Stable Fast 3D imported module has no source file or namespace path: {name}")
        try:
            namespace_paths = list(locations)
        except TypeError as error:
            raise RuntimeError(f"Stable Fast 3D namespace path is invalid: {name}") from error
        if not namespace_paths:
            raise RuntimeError(f"Stable Fast 3D namespace path is empty: {name}")
        for location in namespace_paths:
            if not isinstance(location, str) or not location:
                raise RuntimeError(f"Stable Fast 3D namespace path is invalid: {name}")
            resolved = Path(location).resolve()
            try:
                relative = resolved.relative_to(package_root)
            except ValueError as error:
                raise RuntimeError(
                    f"Stable Fast 3D namespace path escapes the requested source tree: {name}"
                ) from error
            if not resolved.is_dir():
                raise RuntimeError(f"Stable Fast 3D namespace path is not a directory: {name}")
            imported.append(
                {"module": name, "namespace_path": str(relative).replace("\\", "/")}
            )
    if not imported:
        raise RuntimeError("Stable Fast 3D package was not imported from the requested source tree")
    return _sf3d_json_sha256(imported)


def _sf3d_resume_identity(
    weights: Path, source_root: Path, torch: Any, sf3d_class: Any
) -> dict[str, str]:
    weight_files = [weights / "config.yaml", weights / "model.safetensors"]
    pinned_root = source_root.resolve()
    source_package = (source_root / "sf3d").resolve()
    try:
        source_package.relative_to(pinned_root)
    except ValueError as error:
        raise RuntimeError("Stable Fast 3D package root escapes the requested source tree") from error
    source_files = sorted(path.resolve() for path in source_package.rglob("*.py") if path.is_file())
    for path in source_files:
        try:
            path.relative_to(source_package)
        except ValueError as error:
            raise RuntimeError(f"Stable Fast 3D source file escapes the requested source tree: {path}") from error
    if not source_files:
        raise RuntimeError(f"cannot identify Stable Fast 3D source package: {source_package}")
    return {
        "backend": _sf3d_paths_sha256([Path(__file__)], Path(__file__).parent),
        "weights": _sf3d_paths_sha256(weight_files, weights),
        "sources": _sf3d_paths_sha256(source_files, pinned_root),
        "runtime": _sf3d_json_sha256(
            {
                "torch": str(torch.__version__),
                "runtime_helpers": _sf3d_source_sha256(runtime_helpers, "runtime helpers"),
                "batch_preparation": _sf3d_source_sha256(_prepare_batch, "batch preparation"),
                "sf3d_import": _sf3d_source_sha256(sf3d_class, "executing sf3d import"),
                "resume_common": _sf3d_source_sha256(resume_common, "shared resume helper"),
            }
        ),
        "imports": _sf3d_imported_package_sha256(source_root),
    }


def _sf3d_training_config_sha256(config: dict[str, Any]) -> str:
    # This excludes invocation-only settings and hashes every value that changes an update.
    values = {
        "seed": int(config.get("seed", 20260901)),
        "query_points": int(config.get("query_points", 2048)),
        "learning_rate": float(config.get("learning_rate", 1e-4)),
        "weight_decay": float(config.get("weight_decay", 0.0)),
        "scalar_loss_weight": float(config.get("scalar_loss_weight", 0.25)),
        "max_grad_norm": float(config.get("max_grad_norm", 1.0)),
        "warmup_steps": int(config.get("warmup_steps", 0)),
        "max_steps": int(config.get("max_steps", 20)),
    }
    return _sf3d_json_sha256(values)


def _sf3d_contract(
    *,
    identity: dict[str, str],
    config_sha256: str,
    input_sha256: str,
    seed: int,
    warmup_steps: int,
    max_steps: int,
    batch_count: int,
    device_ids: list[int],
) -> dict[str, Any]:
    contract = {
        "backend": "stable-fast-3d-material-head-training",
        "identity": dict(identity),
        "config_sha256": config_sha256,
        "input_sha256": input_sha256,
        "seed": seed,
        "warmup_steps": warmup_steps,
        "max_steps": max_steps,
        "batch_count": batch_count,
        "device_ids": list(device_ids),
    }
    _sf3d_validate_contract(contract)
    return contract


def _sf3d_validate_contract(contract: dict[str, Any]) -> None:
    expected = {
        "backend", "identity", "config_sha256", "input_sha256", "seed", "warmup_steps",
        "max_steps", "batch_count", "device_ids",
    }
    _sf3d_require(type(contract) is dict and set(contract) == expected, "checkpoint contract fields mismatch")
    _sf3d_require(contract["backend"] == "stable-fast-3d-material-head-training", "checkpoint backend mismatch")
    identity = contract["identity"]
    _sf3d_require(type(identity) is dict and set(identity) == _SF3D_IDENTITY_FIELDS, "checkpoint identity fields mismatch")
    for value in list(identity.values()) + [contract["config_sha256"], contract["input_sha256"]]:
        _sf3d_require(
            type(value) is str and len(value) == 64 and all(char in "0123456789abcdef" for char in value),
            "checkpoint identity, config, or input hash is invalid",
        )
    for key in ("seed", "warmup_steps", "max_steps", "batch_count"):
        minimum = 1 if key in ("max_steps", "batch_count") else 0
        _sf3d_require(type(contract[key]) is int and contract[key] >= minimum, f"invalid {key}")
    _sf3d_require(
        type(contract["device_ids"]) is list
        and len(set(contract["device_ids"])) == len(contract["device_ids"])
        and all(type(value) is int and value >= 0 for value in contract["device_ids"]),
        "invalid device IDs",
    )


def _sf3d_checkpoint_metadata(contract: dict[str, Any], global_optimizer_step: int) -> dict[str, Any]:
    _sf3d_validate_contract(contract)
    final_global_step = contract["warmup_steps"] + contract["max_steps"]
    _sf3d_require(
        type(global_optimizer_step) is int
        and contract["warmup_steps"] < global_optimizer_step <= final_global_step,
        "checkpoint is not at a completed measured optimizer step",
    )
    measured_step = global_optimizer_step - contract["warmup_steps"]
    return {
        "schema": SF3D_CHECKPOINT_SCHEMA,
        "boundary": "after-complete-optimizer-update",
        "contract": contract,
        "global_optimizer_step": global_optimizer_step,
        "completed_measured_steps": measured_step,
        "next_global_optimizer_step": global_optimizer_step + 1,
        "next_data_cursor": global_optimizer_step % contract["batch_count"],
    }


def _sf3d_next_coordinate(metadata: dict[str, Any]) -> dict[str, int] | None:
    contract = metadata["contract"]
    if metadata["completed_measured_steps"] == contract["max_steps"]:
        return None
    return {
        "global_optimizer_step": metadata["next_global_optimizer_step"],
        "data_cursor": metadata["next_data_cursor"],
    }


def _sf3d_capture_cached_batches(cached_batches: list[dict[str, Any]]) -> list[dict[str, Any]]:
    total_bytes = sum(
        batch[key].numel() * batch[key].element_size()
        for batch in cached_batches
        for key in _SF3D_CACHE_KEYS
    )
    _sf3d_require(
        total_bytes <= _SF3D_MAX_CHECKPOINT_CACHE_BYTES,
        "Stable Fast 3D checkpoint cached feature payload exceeds the size limit",
    )
    return [
        {key: batch[key].detach().cpu().clone() for key in _SF3D_CACHE_KEYS}
        for batch in cached_batches
    ]


def _sf3d_module_input_width(module: Any, label: str) -> int:
    for child in module.modules():
        width = getattr(child, "in_features", None)
        if type(width) is int and width > 0:
            return width
    raise RuntimeError(f"cannot identify Stable Fast 3D {label} input width")


def _sf3d_cache_feature_spec(model: Any) -> dict[str, int]:
    return {
        "triplane_width": _sf3d_module_input_width(
            model.decoder.heads["features"], "triplane material head"
        ),
        "image_width": _sf3d_module_input_width(
            model.image_estimator.heads["roughness"][0], "image material head"
        ),
    }


def _sf3d_validate_cached_batches(
    saved_batches: Any, batch_count: int, feature_spec: dict[str, int], torch: Any
) -> None:
    supported_dtypes = {
        "triplane_features": {torch.bfloat16, torch.float32},
        "image_features": {torch.bfloat16, torch.float32},
        "albedo": {torch.float32},
        "roughness": {torch.float32},
        "metallic": {torch.float32},
    }
    _sf3d_require(
        type(feature_spec) is dict
        and set(feature_spec) == {"triplane_width", "image_width"}
        and all(type(width) is int and width > 0 for width in feature_spec.values()),
        "invalid live Stable Fast 3D cache feature specification",
    )
    _sf3d_require(
        type(saved_batches) is list and len(saved_batches) == batch_count and saved_batches,
        "checkpoint cached batch count mismatch",
    )
    total_bytes = 0
    for index, saved in enumerate(saved_batches):
        _sf3d_require(
            type(saved) is dict and set(saved) == set(_SF3D_CACHE_KEYS),
            f"checkpoint cached batch structure mismatch at index {index}",
        )
        for key in _SF3D_CACHE_KEYS:
            value = saved[key]
            _sf3d_require(
                isinstance(value, torch.Tensor)
                and value.device.type == "cpu"
                and not value.requires_grad
                and value.is_floating_point()
                and bool(torch.isfinite(value).all()),
                f"invalid cached {key} tensor at batch {index}",
            )
            _sf3d_require(
                value.dtype in supported_dtypes[key],
                f"unsupported cached {key} dtype at batch {index}",
            )
            total_bytes += value.numel() * value.element_size()
            _sf3d_require(
                total_bytes <= _SF3D_MAX_CHECKPOINT_CACHE_BYTES,
                "Stable Fast 3D checkpoint cached feature payload exceeds the size limit",
            )
        _sf3d_require(
            saved["triplane_features"].ndim == 2
            and saved["triplane_features"].shape[0] > 0
            and saved["triplane_features"].shape[1] == feature_spec["triplane_width"],
            f"invalid cached triplane feature shape at batch {index}",
        )
        _sf3d_require(
            saved["image_features"].ndim == 2
            and saved["image_features"].shape[0] > 0
            and saved["image_features"].shape[1] == feature_spec["image_width"],
            f"invalid cached image feature shape at batch {index}",
        )
        _sf3d_require(
            tuple(saved["albedo"].shape) == (1, 3)
            and tuple(saved["roughness"].shape) == (1,)
            and tuple(saved["metallic"].shape) == (1,),
            f"invalid cached material target shape at batch {index}",
        )


def _sf3d_restore_cached_batches(
    saved_batches: list[dict[str, Any]], device: Any
) -> list[dict[str, Any]]:
    return [
        {
            key: saved[key].to(device=device).detach()
            for key in _SF3D_CACHE_KEYS
        }
        for saved in saved_batches
    ]


def _sf3d_optimizer_parameter_names(
    named_parameters: list[tuple[str, Any]], optimizer: Any
) -> list[list[str]]:
    names_by_id = {id(parameter): name for name, parameter in named_parameters}
    groups: list[list[str]] = []
    for group in optimizer.param_groups:
        _sf3d_require(
            all(id(parameter) in names_by_id for parameter in group["params"]),
            "optimizer contains a parameter outside the material heads",
        )
        groups.append([names_by_id[id(parameter)] for parameter in group["params"]])
    flattened = [name for group in groups for name in group]
    _sf3d_require(len(flattened) == len(set(flattened)) == len(named_parameters), "optimizer parameter order mismatch")
    return groups


def _sf3d_initial_optimizer_progress(
    named_parameters: list[tuple[str, Any]], optimizer: Any
) -> dict[str, int]:
    return {
        name: 0
        for group in _sf3d_optimizer_parameter_names(named_parameters, optimizer)
        for name in group
    }


def _sf3d_advance_optimizer_progress(
    progress: dict[str, int], named_parameters: list[tuple[str, Any]], optimizer: Any
) -> dict[str, int]:
    groups = _sf3d_optimizer_parameter_names(named_parameters, optimizer)
    _sf3d_require(set(progress) == {name for group in groups for name in group}, "optimizer progress keys mismatch")
    advanced = dict(progress)
    for names, group in zip(groups, optimizer.param_groups):
        for name, parameter in zip(names, group["params"]):
            if parameter.grad is not None:
                advanced[name] += 1
    return advanced


def _sf3d_capture_state(
    named_parameters: list[tuple[str, Any]], optimizer: Any, optimizer_progress: dict[str, int],
    cached_batches: list[dict[str, Any]],
) -> dict[str, Any]:
    optimizer_state = optimizer.state_dict()
    placements: dict[int, dict[str, str]] = {}
    for saved_group, live_group in zip(optimizer_state["param_groups"], optimizer.param_groups):
        for parameter_id, parameter in zip(saved_group["params"], live_group["params"]):
            slots = optimizer.state.get(parameter, {})
            if slots:
                placements[parameter_id] = {
                    key: str(value.device) for key, value in slots.items() if hasattr(value, "device")
                }
    return {
        "material_heads": resume_common.cpu_tree(_state_dict(named_parameters)),
        "optimizer": resume_common.cpu_tree(optimizer_state),
        "optimizer_placements": placements,
        "optimizer_parameter_names": _sf3d_optimizer_parameter_names(named_parameters, optimizer),
        "optimizer_implementation": resume_common._optimizer_implementation(optimizer),
        "optimizer_progress": resume_common.cpu_tree(optimizer_progress),
        "cached_batches": _sf3d_capture_cached_batches(cached_batches),
    }


def _sf3d_private_cpu_snapshot(value: Any, torch: Any) -> Any:
    """Copy only the checkpoint's canonical, inert CPU value tree."""
    value_type = type(value)
    if value_type is dict:
        _sf3d_require(
            all(type(key) in (str, int) for key in value),
            "checkpoint mapping has a non-canonical key type",
        )
        return {key: _sf3d_private_cpu_snapshot(item, torch) for key, item in value.items()}
    if value_type is list:
        return [_sf3d_private_cpu_snapshot(item, torch) for item in value]
    if value_type is tuple:
        return tuple(_sf3d_private_cpu_snapshot(item, torch) for item in value)
    if value_type is torch.Tensor:
        _sf3d_require(
            value.device.type == "cpu" and value.layout == torch.strided and not value.requires_grad,
            "checkpoint tensor must be an exact CPU strided tensor without gradients",
        )
        return value.detach().clone()
    if value_type is np.ndarray:
        _sf3d_require(not value.dtype.hasobject, "checkpoint NumPy array has object values")
        if np.issubdtype(value.dtype, np.inexact):
            _sf3d_require(bool(np.isfinite(value).all()), "checkpoint NumPy array is non-finite")
        return value.copy(order="K")
    if value_type is float:
        _sf3d_require(math.isfinite(value), "checkpoint float is non-finite")
        return value
    _sf3d_require(
        value_type in (str, int, bool, type(None)),
        f"checkpoint value has unsupported type: {value_type.__module__}.{value_type.__qualname__}",
    )
    return value


def _sf3d_type_tree_sha256(value: Any) -> str:
    """Hash canonical checkpoint values with type tags, not pickle semantics."""
    digest = hashlib.sha256()

    def add_text(text: str) -> None:
        encoded = text.encode("utf-8")
        digest.update(len(encoded).to_bytes(8, "big"))
        digest.update(encoded)

    def walk(item: Any) -> None:
        item_type = type(item)
        add_text(f"{item_type.__module__}.{item_type.__qualname__}")
        if item_type is dict:
            keys = sorted(item, key=lambda key: (type(key).__name__, repr(key)))
            digest.update(len(keys).to_bytes(8, "big"))
            for key in keys:
                walk(key)
                walk(item[key])
        elif item_type in (list, tuple):
            digest.update(len(item).to_bytes(8, "big"))
            for child in item:
                walk(child)
        elif item_type is torch.Tensor:
            add_text(str(item.dtype))
            add_text(str(tuple(item.shape)))
            add_text(str(tuple(item.stride())))
            digest.update(item.detach().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes())
        elif item_type is np.ndarray:
            add_text(str(item.dtype))
            add_text(str(item.shape))
            add_text(str(item.strides))
            digest.update(np.ascontiguousarray(item).tobytes())
        else:
            add_text(repr(item))

    import torch

    walk(value)
    return digest.hexdigest()


def _sf3d_checkpoint_integrity(payload: dict[str, Any]) -> str:
    import torch

    snapshot = _sf3d_private_cpu_snapshot(payload, torch)
    return _sf3d_type_tree_sha256(snapshot)


def _sf3d_exact_int_keys(mapping: Any, expected: set[int], label: str) -> None:
    _sf3d_require(
        type(mapping) is dict and all(type(key) is int for key in mapping) and set(mapping) == expected,
        f"{label} keys mismatch",
    )


def _sf3d_validate_state(
    state: dict[str, Any], named_parameters: list[tuple[str, Any]], optimizer: Any,
    global_optimizer_step: int, batch_count: int, feature_spec: dict[str, int], torch: Any,
) -> None:
    _sf3d_require(
        type(state) is dict
        and set(state) == {
            "material_heads", "optimizer", "optimizer_placements", "optimizer_parameter_names",
            "optimizer_implementation", "optimizer_progress", "cached_batches",
        },
        "checkpoint state fields mismatch",
    )
    _sf3d_validate_cached_batches(state["cached_batches"], batch_count, feature_spec, torch)
    expected_parameters = dict(named_parameters)
    expected_optimizer_names = _sf3d_optimizer_parameter_names(named_parameters, optimizer)
    _sf3d_require(
        type(state["optimizer_parameter_names"]) is list and state["optimizer_parameter_names"] == expected_optimizer_names,
        "optimizer parameter names or order mismatch",
    )
    try:
        expected_optimizer_implementation = resume_common._optimizer_implementation(optimizer)
    except Exception as error:
        raise SF3DCheckpointValidationError("cannot validate Stable Fast 3D AdamW implementation") from error
    _sf3d_require(
        state["optimizer_implementation"] == expected_optimizer_implementation,
        "AdamW implementation mismatch",
    )
    optimizer_progress = state["optimizer_progress"]
    expected_progress_names = {name for group in expected_optimizer_names for name in group}
    _sf3d_require(
        type(optimizer_progress) is dict
        and set(optimizer_progress) == expected_progress_names
        and all(type(value) is int and 0 <= value <= global_optimizer_step for value in optimizer_progress.values()),
        "invalid optimizer progress",
    )
    saved_parameters = state["material_heads"]
    _sf3d_require(type(saved_parameters) is dict and set(saved_parameters) == set(expected_parameters), "material head parameter set mismatch")
    for name, value in saved_parameters.items():
        parameter = expected_parameters[name]
        _sf3d_require(
            type(value) is torch.Tensor
            and value.device.type == "cpu"
            and value.layout == torch.strided
            and value.shape == parameter.shape
            and value.dtype == parameter.dtype
            and not value.requires_grad
            and bool(torch.isfinite(value).all()),
            f"invalid material head tensor: {name}",
        )

    saved_optimizer = state["optimizer"]
    live_optimizer = optimizer.state_dict()
    _sf3d_require(type(saved_optimizer) is dict and set(saved_optimizer) == {"state", "param_groups"}, "optimizer state fields mismatch")
    _sf3d_require(
        type(saved_optimizer["param_groups"]) is list
        and len(saved_optimizer["param_groups"]) == len(live_optimizer["param_groups"]),
        "optimizer group count mismatch",
    )
    parameter_by_id: dict[int, tuple[Any, str]] = {}
    canonical_ids: list[int] = []
    for saved_group, live_group, live_parameters, group_names in zip(
        saved_optimizer["param_groups"], live_optimizer["param_groups"], optimizer.param_groups,
        expected_optimizer_names,
    ):
        _sf3d_require(type(saved_group) is dict and set(saved_group) == set(live_group), "optimizer group fields mismatch")
        _sf3d_require(
            _sf3d_type_tree_sha256({key: value for key, value in saved_group.items() if key != "params"})
            == _sf3d_type_tree_sha256(_sf3d_private_cpu_snapshot(
                {key: value for key, value in live_group.items() if key != "params"}, torch
            )),
            "optimizer hyperparameters mismatch",
        )
        identifiers = saved_group["params"]
        _sf3d_require(
            type(identifiers) is list
            and all(type(value) is int and value >= 0 for value in identifiers)
            and identifiers == live_group["params"],
            "optimizer parameter order mismatch",
        )
        canonical_ids.extend(identifiers)
        parameter_by_id.update(zip(identifiers, zip(live_parameters["params"], group_names)))
    _sf3d_require(
        len(canonical_ids) == len(set(canonical_ids)) == len(named_parameters)
        and len(parameter_by_id) == len(named_parameters),
        "optimizer parameter mapping mismatch",
    )
    saved_slots = saved_optimizer["state"]
    active_ids = {
        identifier
        for identifiers, names in zip((group["params"] for group in saved_optimizer["param_groups"]), expected_optimizer_names)
        for identifier, name in zip(identifiers, names)
        if optimizer_progress[name] > 0
    }
    _sf3d_exact_int_keys(saved_slots, active_ids, "optimizer slots")
    placements = state["optimizer_placements"]
    _sf3d_exact_int_keys(placements, active_ids, "optimizer placement")
    for parameter_id, slots in saved_slots.items():
        parameter, parameter_name = parameter_by_id[parameter_id]
        _sf3d_require(type(slots) is dict and set(slots) == {"step", "exp_avg", "exp_avg_sq"}, "AdamW slot fields mismatch")
        _sf3d_require(
            type(placements[parameter_id]) is dict
            and set(placements[parameter_id]) == set(slots)
            and all(type(key) is str and type(value) is str for key, value in placements[parameter_id].items()),
            "optimizer placement fields mismatch",
        )
        step = slots["step"]
        try:
            observed_step = resume_common._integer_optimizer_step(step)
        except Exception as error:
            raise SF3DCheckpointValidationError("invalid AdamW step") from error
        _sf3d_require(
            observed_step == optimizer_progress[parameter_name],
            "AdamW step differs from observed optimizer progress",
        )
        expected_device = str(parameter.device)
        _sf3d_require(placements[parameter_id]["step"] in ("cpu", expected_device), "invalid AdamW step placement")
        for key in ("exp_avg", "exp_avg_sq"):
            value = slots[key]
            _sf3d_require(
                type(value) is torch.Tensor and value.device.type == "cpu" and value.layout == torch.strided
                and value.shape == parameter.shape
                and value.dtype == parameter.dtype and not value.requires_grad and bool(torch.isfinite(value).all())
                and placements[parameter_id][key] == expected_device,
                f"invalid AdamW {key}",
            )
        _sf3d_require(bool((slots["exp_avg_sq"] >= 0).all()), "negative AdamW second moment")


def _sf3d_validate_optimizer_roundtrip(
    state: dict[str, Any], named_parameters: list[tuple[str, Any]], optimizer: Any, torch: Any,
) -> None:
    """Prove the serialized optimizer can be loaded by a CPU AdamW twin before live apply."""
    try:
        probe_groups = []
        for group in optimizer.param_groups:
            copied = {key: value for key, value in group.items() if key != "params"}
            copied["params"] = [
                torch.nn.Parameter(parameter.detach().cpu().clone(), requires_grad=True)
                for parameter in group["params"]
            ]
            probe_groups.append(copied)
        probe = torch.optim.AdamW(probe_groups)
        probe.load_state_dict(state["optimizer"])
        emitted = _sf3d_private_cpu_snapshot(probe.state_dict(), torch)
    except Exception as error:
        raise SF3DCheckpointValidationError("AdamW CPU roundtrip validation failed") from error
    _sf3d_require(
        _sf3d_type_tree_sha256(emitted) == _sf3d_type_tree_sha256(state["optimizer"]),
        "AdamW CPU roundtrip state hash mismatch",
    )


def _sf3d_validate_material_heads_roundtrip(
    state: dict[str, Any], named_parameters: list[tuple[str, Any]], torch: Any,
) -> None:
    """Reject head layouts whose exact CPU copy result would differ after apply."""
    try:
        probe = [
            (
                name,
                torch.nn.Parameter(parameter.detach().cpu().clone(), requires_grad=True),
            )
            for name, parameter in named_parameters
        ]
        _load_state(torch, probe, state["material_heads"])
        emitted = _sf3d_private_cpu_snapshot(_state_dict(probe), torch)
    except Exception as error:
        raise SF3DCheckpointValidationError("material head CPU copy roundtrip validation failed") from error
    _sf3d_require(
        _sf3d_type_tree_sha256(emitted) == _sf3d_type_tree_sha256(state["material_heads"]),
        "material head CPU copy roundtrip hash mismatch",
    )


def _sf3d_validate_rng_roundtrip(
    state: dict[str, Any], device_ids: list[int], *, native: bool, torch: Any,
) -> None:
    """Prove each private RNG restore preserves the checkpoint representation exactly."""
    try:
        python_probe = random.Random()
        python_probe.setstate(state["python"])
        numpy_probe = np.random.RandomState(0)
        numpy_probe.set_state(state["numpy"])
        torch_probe = torch.Generator(device="cpu")
        torch_probe.set_state(state["torch_cpu"])
        emitted: dict[str, Any] = {
            "python": python_probe.getstate(),
            "numpy": numpy_probe.get_state(),
            "torch_cpu": torch_probe.get_state().cpu().clone(),
            "mlu": {},
        }
        for device_id in device_ids:
            _sf3d_require(native, "cannot validate MLU RNG roundtrip without the native runtime")
            probe = torch.mlu.default_generators[device_id].clone_state()
            probe.set_state(state["mlu"][device_id].clone())
            emitted["mlu"][device_id] = probe.get_state().cpu().clone()
        emitted = _sf3d_private_cpu_snapshot(emitted, torch)
    except SF3DCheckpointValidationError:
        raise
    except Exception as error:
        raise SF3DCheckpointValidationError("private RNG roundtrip validation failed") from error
    _sf3d_require(
        _sf3d_type_tree_sha256(emitted) == _sf3d_type_tree_sha256(state),
        "private RNG roundtrip hash mismatch",
    )


def _sf3d_make_checkpoint(
    *, contract: dict[str, Any], global_optimizer_step: int, named_parameters: list[tuple[str, Any]],
    optimizer: Any, optimizer_progress: dict[str, int], cached_batches: list[dict[str, Any]],
) -> dict[str, Any]:
    import torch

    payload = _sf3d_private_cpu_snapshot({
        "metadata": _sf3d_checkpoint_metadata(contract, global_optimizer_step),
        "state": _sf3d_capture_state(
            named_parameters, optimizer, optimizer_progress, cached_batches
        ),
        "rng": resume_common.cpu_tree(resume_common.capture_rng(contract["device_ids"])),
    }, torch)
    payload["integrity_sha256"] = _sf3d_type_tree_sha256(payload)
    return payload


def _sf3d_prepare_checkpoint(
    payload: dict[str, Any], contract: dict[str, Any], named_parameters: list[tuple[str, Any]], optimizer: Any,
    feature_spec: dict[str, int], torch: Any, *, native_rng: bool, completion_policy: str,
) -> _SF3DPreparedCheckpoint:
    snapshot = _sf3d_private_cpu_snapshot(payload, torch)
    _sf3d_require(
        type(snapshot) is dict and set(snapshot) == {"metadata", "state", "rng", "integrity_sha256"},
        "not a full Stable Fast 3D checkpoint",
    )
    unsigned = {key: value for key, value in snapshot.items() if key != "integrity_sha256"}
    _sf3d_require(
        type(snapshot["integrity_sha256"]) is str
        and snapshot["integrity_sha256"] == _sf3d_type_tree_sha256(unsigned),
        "checkpoint integrity mismatch",
    )
    metadata = snapshot["metadata"]
    _sf3d_require(type(metadata) is dict and metadata.get("contract") == contract, "checkpoint identity, config, or input hash mismatch")
    _sf3d_require(
        metadata == _sf3d_checkpoint_metadata(contract, metadata.get("global_optimizer_step")),
        "checkpoint global optimizer step or data cursor mismatch",
    )
    _sf3d_validate_state(
        snapshot["state"], named_parameters, optimizer, metadata["global_optimizer_step"],
        contract["batch_count"], feature_spec, torch,
    )
    try:
        resume_common.validate_rng(snapshot["rng"], contract["device_ids"], native=native_rng)
    except Exception as error:
        raise SF3DCheckpointValidationError("invalid Stable Fast 3D RNG state") from error
    _sf3d_validate_material_heads_roundtrip(snapshot["state"], named_parameters, torch)
    _sf3d_validate_rng_roundtrip(
        snapshot["rng"], contract["device_ids"], native=native_rng, torch=torch
    )
    _sf3d_validate_optimizer_roundtrip(snapshot["state"], named_parameters, optimizer, torch)
    next_coordinate = _sf3d_next_coordinate(metadata)
    _sf3d_require(completion_policy in ("external", "internal"), "invalid resume completion policy")
    if completion_policy == "external":
        _sf3d_require(next_coordinate is not None, "external resume checkpoint already completed the configured schedule")
    return _SF3DPreparedCheckpoint(snapshot, {"metadata": metadata, "next": next_coordinate})


def _sf3d_validate_checkpoint(
    payload: dict[str, Any], contract: dict[str, Any], named_parameters: list[tuple[str, Any]], optimizer: Any,
    feature_spec: dict[str, int], torch: Any, *, native_rng: bool, completion_policy: str = "external",
) -> dict[str, Any]:
    return _sf3d_prepare_checkpoint(
        payload, contract, named_parameters, optimizer, feature_spec, torch,
        native_rng=native_rng, completion_policy=completion_policy,
    ).checked


def _sf3d_restore_optimizer_placements(optimizer: Any, saved_optimizer: dict[str, Any], placements: dict[int, dict[str, str]]) -> None:
    for saved_group, live_group in zip(saved_optimizer["param_groups"], optimizer.param_groups):
        for parameter_id, parameter in zip(saved_group["params"], live_group["params"]):
            active_placements = placements.get(parameter_id)
            if active_placements is None:
                continue
            for key, device in active_placements.items():
                optimizer.state[parameter][key] = optimizer.state[parameter][key].to(device)


def _sf3d_restore_checkpoint(
    payload: dict[str, Any], contract: dict[str, Any], named_parameters: list[tuple[str, Any]], optimizer: Any,
    feature_spec: dict[str, int], torch: Any, *, completion_policy: str = "external",
) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, int]]:
    prepared = _sf3d_prepare_checkpoint(
        payload, contract, named_parameters, optimizer, feature_spec, torch,
        native_rng=bool(contract["device_ids"]), completion_policy=completion_policy,
    )
    try:
        restored_state = prepared.payload["state"]
        restored_rng = prepared.payload["rng"]
        _load_state(torch, named_parameters, restored_state["material_heads"])
        optimizer.load_state_dict(restored_state["optimizer"])
        _sf3d_restore_optimizer_placements(
            optimizer, restored_state["optimizer"], restored_state["optimizer_placements"]
        )
        restored_cache = _sf3d_restore_cached_batches(
            restored_state["cached_batches"], named_parameters[0][1].device
        )
        resume_common._restore_rng(restored_rng, contract["device_ids"])
        _sf3d_assert_restored_boundary(
            prepared.payload, contract, named_parameters, optimizer,
            restored_state["optimizer_progress"], restored_cache, torch,
        )
    except Exception as error:
        raise SF3DResumeApplyFatal(
            "Stable Fast 3D checkpoint application failed; terminate this worker"
        ) from error
    return prepared.checked, restored_cache, dict(restored_state["optimizer_progress"])


def _sf3d_assert_restored_boundary(
    payload: dict[str, Any], contract: dict[str, Any], named_parameters: list[tuple[str, Any]], optimizer: Any,
    optimizer_progress: dict[str, int], cached_batches: list[dict[str, Any]], torch: Any,
) -> None:
    observed = _sf3d_private_cpu_snapshot({
        "state": _sf3d_capture_state(named_parameters, optimizer, optimizer_progress, cached_batches),
        "rng": resume_common.cpu_tree(resume_common.capture_rng(contract["device_ids"])),
    }, torch)
    expected = _sf3d_private_cpu_snapshot({key: payload[key] for key in ("state", "rng")}, torch)
    _sf3d_require(
        _sf3d_type_tree_sha256(observed) == _sf3d_type_tree_sha256(expected),
        "restored Stable Fast 3D boundary differs from checkpoint",
    )


def _sf3d_load_checkpoint(path: Path, torch: Any) -> dict[str, Any]:
    try:
        reconstruct = importlib.import_module("numpy.core.multiarray")._reconstruct
        allowed = [
            (reconstruct, "numpy.core.multiarray._reconstruct"),
            (reconstruct, "numpy._core.multiarray._reconstruct"),
            np.ndarray,
            np.dtype,
            type(np.dtype(np.uint32)),
        ]
        # MT19937's uint32 array is the only NumPy producer type needed here.
        with torch.serialization.safe_globals(allowed):
            payload = torch.load(path, map_location="cpu", weights_only=True)
    except Exception as error:
        raise SF3DCheckpointValidationError(f"cannot load Stable Fast 3D checkpoint: {path}") from error
    _sf3d_require(type(payload) is dict, "unsupported Stable Fast 3D checkpoint payload")
    return payload


def _sf3d_resume_checkpoint_path(config: dict[str, Any]) -> Path | None:
    value = config.get("resume_from_checkpoint")
    if value is None:
        return None
    if type(value) is not str or not value:
        raise ValueError("resume_from_checkpoint must be a non-empty external checkpoint path")
    path = Path(value).expanduser().resolve()
    if not path.is_file():
        raise SF3DCheckpointValidationError(f"Stable Fast 3D resume checkpoint does not exist: {path}")
    return path


def run_sf3d_training(
    weights: Path,
    config: dict[str, Any],
    output_dir: Path,
    source_root: Path,
) -> dict[str, Any]:
    os.environ.setdefault("SF3D_OFFLINE_INIT", "1")
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    torch = require_mlu()
    sys.path.insert(0, str(source_root))
    from PIL import Image
    from sf3d.system import SF3D

    seed = int(config.get("seed", 20260901))
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.mlu.manual_seed_all(seed)
    torch.mlu.reset_peak_memory_stats()

    input_paths = [Path(item) for item in config.get("input_images", [])]
    if len(input_paths) < 2 or any(not path.is_file() for path in input_paths):
        raise RuntimeError("Stable Fast 3D training requires at least two existing RGBA inputs")

    load_started = perf_counter()
    model = SF3D.from_pretrained(
        str(weights), config_name="config.yaml", weight_name="model.safetensors"
    )
    model.to("mlu").eval()
    model_load_seconds = perf_counter() - load_started
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for module in (
        model.decoder.heads["features"],
        model.image_estimator.heads["roughness"],
        model.image_estimator.heads["metallic"],
    ):
        module.train()
        for parameter in module.parameters():
            parameter.requires_grad_(True)
    named_parameters = _selected_named_parameters(model)
    trainable = [parameter for _, parameter in named_parameters]
    if not trainable:
        raise RuntimeError("Stable Fast 3D material heads contain no trainable parameters")
    cache_feature_spec = _sf3d_cache_feature_spec(model)
    optimizer = torch.optim.AdamW(
        trainable,
        lr=float(config.get("learning_rate", 1e-4)),
        weight_decay=float(config.get("weight_decay", 0.0)),
    )

    checkpoint_steps = {int(item) for item in config.get("checkpoint_steps", [10, 20])}
    max_steps = int(config.get("max_steps", 20))
    warmup_steps = int(config.get("warmup_steps", 0))
    total_global_steps = warmup_steps + max_steps
    resume_path = _sf3d_resume_checkpoint_path(config)
    contract = _sf3d_contract(
        identity=_sf3d_resume_identity(weights, source_root, torch, SF3D),
        config_sha256=_sf3d_training_config_sha256(config),
        input_sha256=_sf3d_paths_sha256(input_paths, include_paths=False),
        seed=seed,
        warmup_steps=warmup_steps,
        max_steps=max_steps,
        batch_count=len(input_paths),
        device_ids=[int(torch.mlu.current_device())],
    )
    completed_global_step = 0
    optimizer_progress = _sf3d_initial_optimizer_progress(named_parameters, optimizer)
    cache_started = perf_counter()
    if resume_path is not None:
        resume_payload = _sf3d_load_checkpoint(resume_path, torch)
        resume_checked, cached_batches, optimizer_progress = _sf3d_restore_checkpoint(
            resume_payload, contract, named_parameters, optimizer, cache_feature_spec, torch
        )
        completed_global_step = int(resume_checked["metadata"]["global_optimizer_step"])
        del resume_payload
    else:
        images = [Image.open(path).convert("RGBA") for path in input_paths]
        targets = [foreground_material_targets(np.asarray(image)) for image in images]
        point_count = int(config.get("query_points", 2048))
        point_generator = torch.Generator(device="cpu")
        point_generator.manual_seed(seed + 17)
        cached_batches = []
        with torch.no_grad(), autocast_bf16():
            for image, target in zip(images, targets):
                batch = _prepare_batch(model, image)
                scene_codes, _ = model.get_scene_codes(dict(batch))
                points = torch.rand((point_count, 3), generator=point_generator)
                points = (points * (2 * float(model.cfg.radius)) - float(model.cfg.radius)).to("mlu")
                triplane_features = model.query_triplane(points, scene_codes[0])[0]
                image_features = _image_features(torch, model, batch)
                cached_batches.append(
                    {
                        "triplane_features": triplane_features.detach(),
                        "image_features": image_features.detach(),
                        "albedo": torch.tensor(target["albedo"], device="mlu", dtype=torch.float32).view(1, 3),
                        "roughness": torch.tensor(float(target["roughness"]), device="mlu", dtype=torch.float32).view(1),
                        "metallic": torch.tensor(float(target["metallic"]), device="mlu", dtype=torch.float32).view(1),
                    }
                )
    synchronize()
    cache_seconds = perf_counter() - cache_started
    point_count = int(config.get("query_points", 2048))
    adapter_sha_before = _parameter_sha(named_parameters)

    output_dir.mkdir(parents=True, exist_ok=True)
    step_log = output_dir / "steps.ndjson"
    losses: list[float] = []
    albedo_losses: list[float] = []
    scalar_losses: list[float] = []
    grad_norms: list[float] = []
    measured_steps: list[dict[str, float]] = []
    artifacts: list[dict[str, Any]] = []
    observed_devices: list[str] = []

    def save_checkpoint(global_optimizer_step: int) -> Path:
        measured_step = global_optimizer_step - warmup_steps
        path = output_dir / f"checkpoint-{measured_step}.pt"
        payload = _sf3d_make_checkpoint(
            contract=contract,
            global_optimizer_step=global_optimizer_step,
            named_parameters=named_parameters,
            optimizer=optimizer,
            optimizer_progress=optimizer_progress,
            cached_batches=cached_batches,
        )
        resume_common.save_atomic(path, payload)
        return path

    def load_checkpoint(path: Path) -> int:
        nonlocal cached_batches, optimizer_progress
        checkpoint = _sf3d_load_checkpoint(path, torch)
        checked, cached_batches, optimizer_progress = _sf3d_restore_checkpoint(
            checkpoint, contract, named_parameters, optimizer, cache_feature_spec, torch,
            completion_policy="internal",
        )
        return int(checked["metadata"]["global_optimizer_step"])

    def train_step(step: int) -> dict[str, float]:
        nonlocal optimizer_progress
        batch = cached_batches[(step - 1) % len(cached_batches)]
        optimizer.zero_grad(set_to_none=True)
        synchronize()
        started_unix = time()
        step_started = perf_counter()
        forward_started = perf_counter()
        with autocast_bf16():
            albedo = torch.sigmoid(
                model.decoder.heads["features"](batch["triplane_features"])
            )
            roughness = _beta_mean(
                torch,
                model.image_estimator.heads["roughness"],
                batch["image_features"],
            )
            metallic = _beta_mean(
                torch,
                model.image_estimator.heads["metallic"],
                batch["image_features"],
            )
            albedo_loss = (albedo.float() - batch["albedo"]).square().mean()
            scalar_loss = (
                (roughness.float() - batch["roughness"]).square().mean()
                + (metallic.float() - batch["metallic"]).square().mean()
            )
            loss = albedo_loss + float(config.get("scalar_loss_weight", 0.25)) * scalar_loss
        synchronize()
        forward_seconds = perf_counter() - forward_started
        backward_started = perf_counter()
        loss.backward()
        grad_norm = torch.nn.utils.clip_grad_norm_(
            trainable, float(config.get("max_grad_norm", 1.0))
        )
        optimizer.step()
        optimizer_progress = _sf3d_advance_optimizer_progress(
            optimizer_progress, named_parameters, optimizer
        )
        synchronize()
        backward_seconds = perf_counter() - backward_started
        observed_devices.extend((str(albedo.device), str(roughness.device), str(metallic.device)))
        return {
            "step": float(step),
            "started_unix": started_unix,
            "ended_unix": time(),
            "loss": float(loss.detach().cpu()),
            "albedo_loss": float(albedo_loss.detach().cpu()),
            "scalar_loss": float(scalar_loss.detach().cpu()),
            "grad_norm": float(grad_norm.detach().cpu()),
            "forward_seconds": forward_seconds,
            "backward_update_seconds": backward_seconds,
            "step_seconds": perf_counter() - step_started,
        }

    training_started = perf_counter()
    with step_log.open("w", encoding="utf-8") as handle:
        for step in range(completed_global_step + 1, total_global_steps + 1):
            record = train_step(step)
            handle.write(json.dumps(record, sort_keys=True) + "\n")
            handle.flush()
            if step > warmup_steps:
                losses.append(record["loss"])
                albedo_losses.append(record["albedo_loss"])
                scalar_losses.append(record["scalar_loss"])
                grad_norms.append(record["grad_norm"])
                measured_steps.append(record)
                measured_step = step - warmup_steps
                if measured_step in checkpoint_steps:
                    checkpoint = save_checkpoint(step)
                    artifacts.append({"path": str(checkpoint), "sha256": sha256_path(checkpoint)})
    training_seconds = perf_counter() - training_started

    checkpoint_20 = output_dir / f"checkpoint-{max_steps}.pt"
    if not checkpoint_20.is_file():
        checkpoint_20 = save_checkpoint(total_global_steps)
        artifacts.append({"path": str(checkpoint_20), "sha256": sha256_path(checkpoint_20)})
    recovery = run_recovery_validation(
        enabled=validate_recovery_enabled(config),
        expected_step=total_global_steps,
        metric_names=("resume_loss_abs_error", "resume_parameter_sha_match"),
        update=lambda: train_step(total_global_steps + 1),
        restore=lambda: load_checkpoint(checkpoint_20),
        fingerprint=lambda: _parameter_sha(named_parameters),
        compare=lambda continuous, resumed, continuous_sha, resumed_sha: (
            abs(continuous["loss"] - resumed["loss"])
            <= float(config.get("resume_atol", 1e-6))
            and continuous_sha == resumed_sha,
            {
                "resume_loss_abs_error": abs(continuous["loss"] - resumed["loss"]),
                "resume_parameter_sha_match": continuous_sha == resumed_sha,
            },
        ),
    )

    adapter_path = output_dir / "material-heads.pt"
    torch.save(_state_dict(named_parameters), adapter_path)
    artifacts.append({"path": str(adapter_path), "sha256": sha256_path(adapter_path)})
    adapter_sha_after = _parameter_sha(named_parameters)
    finite_losses = bool(losses) and all(np.isfinite(losses))
    finite_gradients = bool(grad_norms) and all(np.isfinite(grad_norms)) and min(grad_norms) > 0
    step_seconds = [record["step_seconds"] for record in measured_steps]
    forward_seconds = [record["forward_seconds"] for record in measured_steps]
    update_seconds = [record["backward_update_seconds"] for record in measured_steps]
    metrics = {
        "steps": max_steps,
        "global_optimizer_step": total_global_steps,
        "measurement_steps": len(measured_steps),
        "measurement_scope": "current_invocation_remaining_post_warmup",
        "warmup_steps": warmup_steps,
        "input_count": len(input_paths),
        "query_points": point_count,
        "trainable_parameters": sum(parameter.numel() for parameter in trainable),
        "loss_min": min(losses),
        "loss_max": max(losses),
        "loss_final": losses[-1],
        "albedo_loss_final": albedo_losses[-1],
        "scalar_loss_final": scalar_losses[-1],
        "grad_norm_min": min(grad_norms),
        "grad_norm_max": max(grad_norms),
        "adapter_sha_before": adapter_sha_before,
        "adapter_sha_after": adapter_sha_after,
        "resume_loss_abs_error": recovery.metrics["resume_loss_abs_error"],
        "resume_parameter_sha_match": recovery.metrics["resume_parameter_sha_match"],
        "samples_per_second": 1.0 / statistics.median(step_seconds),
        "step_seconds_median": statistics.median(step_seconds),
        "step_seconds_min": min(step_seconds),
        "step_seconds_max": max(step_seconds),
        "forward_seconds_median": statistics.median(forward_seconds),
        "backward_update_seconds_median": statistics.median(update_seconds),
        "peak_cpu_rss_bytes": int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024),
        "mlu_memory": memory_stats(),
        "mlu_utilization": None,
    }
    checks = {
        "finite_tensors": finite_losses,
        "nonzero_finite_gradients": finite_gradients,
        "checkpoint_resume": recovery.passed,
        "current_adapter": adapter_sha_before != adapter_sha_after,
        "main_forward_device": bool(observed_devices) and all("mlu" in device for device in observed_devices),
        "weights_changed": adapter_sha_before != adapter_sha_after,
    }
    if not all(
        checks[key] is not False
        for key in (
            "finite_tensors",
            "nonzero_finite_gradients",
            "checkpoint_resume",
            "current_adapter",
            "main_forward_device",
            "weights_changed",
        )
    ):
        raise RuntimeError(f"Stable Fast 3D training acceptance checks failed: {checks}")
    return {
        "artifacts": artifacts,
        "logs": [{"path": str(step_log), "sha256": sha256_path(step_log)}],
        "metrics": metrics,
        "stage_timings": {
            "model_load_seconds": model_load_seconds,
            "feature_cache_seconds": cache_seconds,
            "training_seconds": training_seconds,
            "forward_seconds_median": statistics.median(forward_seconds),
            "backward_update_seconds_median": statistics.median(update_seconds),
        },
        "checks": checks,
        "observations": {"mlu_utilization_captured": False},
    }
