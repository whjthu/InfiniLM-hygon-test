"""Limit CPU snapshot work without changing the training thread policy."""
from contextlib import contextmanager
import threading


_LOCK = threading.RLock()


def validate_limit(limit):
    if limit is not None and (type(limit) is not int or not 1 <= limit <= 256):
        raise ValueError("checkpoint CPU thread limit must be None or an integer in [1, 256]")
    return limit


@contextmanager
def checkpoint_cpu_threads(torch, limit=None):
    """Use only at synchronous checkpoints with no concurrent Torch CPU work.

    Torch intra-op settings are process-wide. This lock coordinates callers of
    this helper, not arbitrary background Torch threads or other libraries.
    """
    validate_limit(limit)
    if limit is None:
        yield
        return
    if threading.current_thread() is not threading.main_thread():
        raise RuntimeError("checkpoint CPU thread scope requires the main thread")
    with _LOCK:
        original = torch.get_num_threads()
        if type(original) is not int or original < 1:
            raise RuntimeError("invalid original Torch CPU thread count")
        target = min(original, limit)
        if target == original:
            yield
            return
        try:
            torch.set_num_threads(target)
            if torch.get_num_threads() != target:
                raise RuntimeError("checkpoint CPU thread limit did not take effect")
            yield
        finally:
            # Restore even when setting the target changed state before failing.
            torch.set_num_threads(original)
            if torch.get_num_threads() != original:
                raise RuntimeError("training CPU thread count was not restored")
