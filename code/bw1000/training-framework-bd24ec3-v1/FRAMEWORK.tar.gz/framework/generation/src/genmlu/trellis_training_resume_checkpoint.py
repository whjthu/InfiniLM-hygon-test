"""Complete optimizer-step checkpoints for the bounded shape-flow component."""
from __future__ import annotations

import math
from pathlib import Path
from typing import Any

from . import hy_resume_checkpoint as common
from .trellis_training_contract import (
    COMPONENT, adapter_shapes, file_sha, is_sha, json_sha, require, training_config,
)

SCHEMA = "trellis-shape-training-complete-step-v1"
IDENTITIES = {"source", "weights", "cache", "package", "runtime"}
CheckpointValidationError = common.CheckpointValidationError


def make_optimizer(parameters: Any, config: dict[str, Any]) -> Any:
    import torch
    return torch.optim.AdamW(parameters, lr=float(config["learning_rate"]),
                             weight_decay=float(config["weight_decay"]), betas=(0.9, 0.999),
                             eps=1e-8, foreach=False, fused=False, capturable=False, amsgrad=False)


def build_contract(config: dict[str, Any], identities: dict[str, Any], device_ids: list[int]) -> dict[str, Any]:
    require(type(identities) is dict and set(identities) == IDENTITIES, "checkpoint identity fields differ")
    require(type(device_ids) is list and device_ids in ([], [0]) and all(type(x) is int for x in device_ids), "invalid checkpoint devices")
    require(all(type(v) is dict and v for v in identities.values()), "empty checkpoint identity")
    json_sha(identities)
    return {"component": COMPONENT, "config": training_config(config),
            "identities": common.cpu_tree(identities), "device_ids": list(device_ids),
            "sample_order": [config["training_cache_semantic_sha256"]],
            "objective": "uniform-t-flow-mse/sigma-min-1e-5/no-cfg-dropout/v1",
            "rng_policy": "continuous-streams"}


def boundary_metadata(contract: dict[str, Any], global_step: int) -> dict[str, Any]:
    require(type(global_step) is int and 1 <= global_step <= contract["config"]["max_steps"], "invalid completed global step")
    return {"schema": SCHEMA, "boundary": "after-complete-optimizer-step", "contract": contract,
            "global_step": global_step, "completed_optimizer_steps": global_step,
            "measured_steps": max(0, global_step - contract["config"]["warmup_steps"]),
            "next_global_step": global_step + 1, "next_data_cursor": 0,
            "samples_consumed": global_step, "completed_data_epochs": global_step}


def pack_rng(state: dict[str, Any]) -> dict[str, Any]:
    value = common.cpu_tree(state)
    algorithm, keys, position, has_gauss, cached = value["numpy"]
    value["numpy"] = {"algorithm": algorithm, "keys": [int(x) for x in keys],
                      "position": int(position), "has_gauss": int(has_gauss), "cached_gaussian": float(cached)}
    return value


def unpack_rng(state: dict[str, Any]) -> dict[str, Any]:
    import numpy as np
    require(type(state) is dict and set(state) == {"python", "numpy", "torch_cpu", "mlu"}, "missing RNG stream")
    n = state["numpy"]
    require(type(n) is dict and set(n) == {"algorithm", "keys", "position", "has_gauss", "cached_gaussian"}, "invalid primitive NumPy RNG")
    require(n["algorithm"] == "MT19937" and type(n["keys"]) is list and len(n["keys"]) == 624
            and all(type(x) is int and 0 <= x < 2**32 for x in n["keys"]), "invalid NumPy RNG keys")
    require(type(n["position"]) is int and 0 <= n["position"] <= 624, "invalid NumPy RNG position")
    require(type(n["has_gauss"]) is int and n["has_gauss"] in (0, 1), "invalid NumPy Gaussian flag")
    require(type(n["cached_gaussian"]) is float and math.isfinite(n["cached_gaussian"]), "invalid NumPy Gaussian state")
    return {**state, "numpy": (n["algorithm"], np.array(n["keys"], dtype=np.uint32),
                              n["position"], n["has_gauss"], n["cached_gaussian"])}


def _typed_finite(value: Any) -> None:
    import torch
    if type(value) is torch.Tensor:
        require(value.device.type == "cpu" and not value.requires_grad and value.layout == torch.strided, "checkpoint tensor must be detached dense CPU")
        require(bool(torch.isfinite(value).all()), "non-finite checkpoint tensor")
    elif type(value) is dict:
        require(all(type(k) in (str, int) for k in value), "invalid checkpoint key")
        for item in value.values():
            _typed_finite(item)
    elif type(value) in (list, tuple):
        for item in value:
            _typed_finite(item)
    else:
        require(value is None or type(value) in (str, int, float, bool), "checkpoint contains unsupported value")
        require(type(value) is not float or math.isfinite(value), "non-finite checkpoint scalar")


def preflight_checkpoint(payload: Any, *, requested_config: dict[str, Any]) -> None:
    import torch
    require(type(payload) is dict and set(payload) == {"metadata", "state", "rng", "lr_scheduler", "adapter_sha256", "integrity_sha256"}, "not a complete shape-flow checkpoint")
    _typed_finite(payload)
    unsigned = {k: v for k, v in payload.items() if k != "integrity_sha256"}
    require(payload["integrity_sha256"] == common.tree_sha256(unsigned), "checkpoint integrity differs")
    metadata = payload["metadata"]
    require(type(metadata) is dict and type(metadata.get("contract")) is dict, "invalid checkpoint metadata")
    contract = metadata["contract"]
    expected = build_contract(requested_config, contract.get("identities"), contract.get("device_ids"))
    require(common.tree_sha256(contract) == common.tree_sha256(expected), "checkpoint configuration or contract differs")
    require(common.tree_sha256(metadata) == common.tree_sha256(boundary_metadata(contract, metadata.get("global_step"))), "checkpoint global step or data cursor differs")
    step = metadata["global_step"]
    require(payload["lr_scheduler"] is None, "learning-rate scheduler is unsupported")
    state = payload["state"]
    fields = {"trainable", "buffers", "modes", "optimizer", "optimizer_parameter_names",
              "optimizer_placements", "optimizer_implementation", "optimizer_progress"}
    require(type(state) is dict and set(state) == fields, "incomplete checkpoint model state")
    shapes = adapter_shapes()
    require(type(state["trainable"]) is dict and set(state["trainable"]) == set(shapes), "adapter target set differs")
    for name, shape in shapes.items():
        tensor = state["trainable"][name]
        require(type(tensor) is torch.Tensor and tuple(tensor.shape) == shape and tensor.dtype == torch.float32, f"adapter schema differs: {name}")
    require(payload["adapter_sha256"] == common.tree_sha256(state["trainable"]), "adapter SHA differs")
    require(state["optimizer_parameter_names"] == [list(shapes)], "optimizer parameter order differs")
    require(state["optimizer_progress"] == {name: step for name in shapes}
            and all(type(v) is int for v in state["optimizer_progress"].values()), "incomplete optimizer participation")
    require(type(state["buffers"]) is dict and all(type(k) is str and type(v) is torch.Tensor for k, v in state["buffers"].items()), "invalid buffers")
    require(type(state["modes"]) is dict and "" in state["modes"]
            and all(type(k) is str and v is True for k, v in state["modes"].items()), "invalid training modes")
    optimizer = state["optimizer"]
    require(type(optimizer) is dict and set(optimizer) == {"state", "param_groups"}, "incomplete AdamW state")
    groups = optimizer["param_groups"]
    require(type(groups) is list and len(groups) == 1 and type(groups[0]) is dict, "invalid AdamW groups")
    template = make_optimizer([torch.nn.Parameter(torch.empty(0))], requested_config)
    require(state["optimizer_implementation"] == common._optimizer_implementation(template), "AdamW implementation differs")
    expected_group = {k: v for k, v in template.state_dict()["param_groups"][0].items() if k != "params"}
    require(common.tree_sha256({k: v for k, v in groups[0].items() if k != "params"}) == common.tree_sha256(expected_group), "AdamW hyperparameters differ")
    ids = groups[0].get("params")
    require(type(ids) is list and len(ids) == len(shapes) and all(type(x) is int and x >= 0 for x in ids) and len(set(ids)) == len(ids), "invalid AdamW parameter IDs")
    require(type(optimizer["state"]) is dict and set(optimizer["state"]) == set(ids), "missing AdamW moments")
    placements = state["optimizer_placements"]
    require(type(placements) is dict and set(placements) == set(ids), "missing optimizer placements")
    device = "mlu:0" if contract["device_ids"] else "cpu"
    for index, name in zip(ids, shapes):
        values, placement = optimizer["state"][index], placements[index]
        keys = {"step", "exp_avg", "exp_avg_sq"}
        require(type(values) is dict and set(values) == keys and type(placement) is dict and set(placement) == keys, "incomplete AdamW moments or placement")
        require(common._integer_optimizer_step(values["step"]) == step, "AdamW step differs")
        require(placement["step"] in ("cpu", device), "invalid AdamW step placement")
        for key in ("exp_avg", "exp_avg_sq"):
            tensor = values[key]
            require(type(tensor) is torch.Tensor and tuple(tensor.shape) == shapes[name] and tensor.dtype == torch.float32 and placement[key] == device, "invalid AdamW moment")
        require(bool((values["exp_avg_sq"] >= 0).all()), "negative AdamW second moment")
    common.validate_rng(unpack_rng(payload["rng"]), contract["device_ids"], native=False)


def validate_checkpoint(payload: dict[str, Any], contract: dict[str, Any], model: Any, optimizer: Any, *, native_rng: bool) -> None:
    preflight_checkpoint(payload, requested_config=contract["config"])
    require(common.tree_sha256(payload["metadata"]["contract"]) == common.tree_sha256(contract), "checkpoint actual identities differ")
    require(payload["state"]["modes"] == {n: m.training for n, m in model.named_modules()}, "checkpoint mode topology differs")
    common.validate_model_state(payload["state"], model, optimizer, payload["metadata"]["global_step"])
    common.validate_rng(unpack_rng(payload["rng"]), contract["device_ids"], native=native_rng)


def make_payload(contract: dict[str, Any], global_step: int, model: Any, optimizer: Any, progress: dict[str, int]) -> dict[str, Any]:
    payload = {"metadata": common.cpu_tree(boundary_metadata(contract, global_step)),
               "state": common.capture_model_state(model, optimizer, progress),
               "rng": pack_rng(common.capture_rng(contract["device_ids"])), "lr_scheduler": None}
    payload["adapter_sha256"] = common.tree_sha256(payload["state"]["trainable"])
    payload["integrity_sha256"] = common.tree_sha256(payload)
    validate_checkpoint(payload, contract, model, optimizer, native_rng=False)
    return payload


def restore_checkpoint(payload: dict[str, Any], contract: dict[str, Any], model: Any, optimizer: Any) -> dict[str, int]:
    validate_checkpoint(payload, contract, model, optimizer, native_rng=bool(contract["device_ids"]))
    progress = dict(payload["state"]["optimizer_progress"])
    try:
        common._copy_model_state(payload["state"], model, optimizer)
        common._restore_rng(unpack_rng(payload["rng"]), contract["device_ids"])
        observed = {"state": common.capture_model_state(model, optimizer, progress),
                    "rng": pack_rng(common.capture_rng(contract["device_ids"]))}
        require(common.tree_sha256(observed) == common.tree_sha256({k: payload[k] for k in observed}), "restored boundary differs")
    except Exception as error:
        model._trellis_resume_poisoned = True
        raise common.ResumeApplyFatal("checkpoint application failed; terminate this worker") from error
    return progress


def save_checkpoint(path: Path, payload: dict[str, Any]) -> None:
    require(not path.exists(), "refusing to overwrite checkpoint")
    common.save_atomic(path, payload)


def load_checkpoint(path: Path, *, requested_config: dict[str, Any]) -> dict[str, Any]:
    payload, _identity = load_checkpoint_with_identity(path, requested_config=requested_config)
    return payload


def load_checkpoint_with_identity(path: Path, *, requested_config: dict[str, Any]) -> tuple[dict[str, Any], dict[str, str]]:
    import torch
    path = path.expanduser()
    path = path / "state.pt" if path.is_dir() else path
    sha = file_sha(path)
    expected = requested_config.get("resume_checkpoint_sha256")
    require(is_sha(expected) and sha == expected, "resume checkpoint file SHA missing or differs")
    payload = torch.load(path, map_location="cpu", weights_only=True)
    require(file_sha(path) == sha, "checkpoint changed during load")
    preflight_checkpoint(payload, requested_config=requested_config)
    return payload, {"path": str(path.resolve()), "sha256": sha}
