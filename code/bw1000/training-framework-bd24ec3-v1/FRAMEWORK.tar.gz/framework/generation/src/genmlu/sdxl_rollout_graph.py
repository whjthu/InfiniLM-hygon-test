from __future__ import annotations

import hashlib
from time import perf_counter
from typing import Any


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def tensor_metadata(value: Any) -> dict[str, Any]:
    return {
        "shape": list(value.shape),
        "stride": list(value.stride()),
        "dtype": str(value.dtype),
        "device": str(value.device),
        "layout": str(value.layout),
        "requires_grad": bool(value.requires_grad),
    }


def _active_adapters(module: Any) -> list[str]:
    active = getattr(module, "active_adapters", [])
    active = active() if callable(active) else active
    active = [active] if isinstance(active, str) else active
    _require(
        isinstance(active, (list, tuple)) and all(isinstance(name, str) for name in active),
        "unknown adapter metadata",
    )
    return list(active)


def _optional_bool(module: Any, name: str) -> bool | None:
    value = getattr(module, name, None)
    return value if type(value) is bool else None


def _policy_copy(value: Any) -> Any:
    if value is None or type(value) in (bool, int, float, str):
        return value
    if isinstance(value, dict):
        _require(all(isinstance(key, str) for key in value), "invalid LoRA policy key")
        return {key: _policy_copy(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return tuple(_policy_copy(item) for item in value)
    raise RuntimeError("LoRA policy contains a non-primitive value")


def _lora_policy(module: Any) -> dict[str, Any] | None:
    if not hasattr(module, "lora_A"):
        return None
    return {
        name: _policy_copy(getattr(module, name))
        for name in ("scaling", "r", "lora_alpha", "use_dora")
        if hasattr(module, name)
    }


def _callable_id(value: Any, label: str, *, optional: bool = False) -> int | None:
    if value is None and optional:
        return None
    _require(callable(value), f"invalid UNet callable: {label}")
    return id(getattr(value, "__func__", value))


def _tensor_byte_sha256(torch: Any, value: Any) -> str:
    cpu = value.detach().cpu().contiguous()
    raw = cpu.reshape(-1).view(torch.uint8).numpy()
    digest = hashlib.sha256(memoryview(raw)).hexdigest()
    del raw, cpu
    return digest


class _PersistentInput:
    def __init__(self, torch: Any, source: Any) -> None:
        self.torch = torch
        self.metadata = tensor_metadata(source)
        self.owner = None
        stride = tuple(source.stride())
        if source.ndim == 1 and stride == (0,):
            self.owner = source[0].clone()
            self.value = self.owner.expand_as(source)
        else:
            _require(all(item > 0 for item in stride), "unsupported graph input stride")
            self.value = torch.empty_strided(
                source.shape, stride, dtype=source.dtype, device=source.device
            )
        _require(tensor_metadata(self.value) == self.metadata, "persistent input metadata differs")
        self.copy_from(source)

    def copy_from(self, source: Any) -> None:
        _require(tensor_metadata(source) == self.metadata, "graph input metadata changed")
        if self.owner is not None:
            self.owner.copy_(source[0])
        else:
            self.value.copy_(source)


class SDXLRolloutGraph:
    """One fixed-shape raw-UNet MLU graph used only by rollout sampling."""

    def __init__(self, torch: Any) -> None:
        required = {
            "torch": ("autocast", "empty_strided", "equal", "get_rng_state", "no_grad"),
            "torch.mlu": (
                "MLUGraph",
                "Stream",
                "current_stream",
                "get_rng_state",
                "graph",
                "stream",
                "synchronize",
            ),
        }
        owners = {"torch": torch, "torch.mlu": getattr(torch, "mlu", None)}
        missing = [
            f"{owner_name}.{name}"
            for owner_name, names in required.items()
            for name in names
            if not callable(getattr(owners[owner_name], name, None))
        ]
        _require(
            not missing,
            "rollout_graph requires torch_mlu graph APIs: " + ", ".join(missing),
        )
        module_api = getattr(
            getattr(getattr(torch, "nn", None), "modules", None), "module", None
        )
        _require(
            module_api is not None
            and hasattr(module_api, "_global_forward_pre_hooks")
            and hasattr(module_api, "_global_forward_hooks"),
            "rollout_graph requires PyTorch forward hook registries",
        )
        self.torch = torch
        self.module_api = module_api
        self.unet = None
        self.graph = None
        self.output = None
        self.inputs: list[_PersistentInput] = []
        self.structure = None
        self.setup_versions = None
        self.rollout_versions = None
        self.setup_adapter_sha = None
        self.rollout_adapter_sha = None
        self.setup_seconds = 0.0
        self.warmup_seconds = 0.0
        self.capture_seconds = 0.0
        self.value_validation_seconds = 0.0
        self.replays = 0

    def _rng(self) -> tuple[Any, Any]:
        return self.torch.get_rng_state().clone(), self.torch.mlu.get_rng_state().clone()

    def _state(self, unet: Any) -> tuple[dict[str, Any], dict[str, int]]:
        global_hooks = self.module_api
        _require(
            not global_hooks._global_forward_pre_hooks
            and not global_hooks._global_forward_hooks,
            "rollout graph does not support global forward hooks",
        )
        tensors = [("parameter:" + name, value) for name, value in unet.named_parameters()]
        tensors += [("buffer:" + name, value) for name, value in unet.named_buffers()]
        modules = list(unet.named_modules())
        for name, module in modules:
            _require(
                not module._forward_pre_hooks and not module._forward_hooks,
                f"rollout graph does not support local forward hooks: {name}",
            )
            _require(
                getattr(module, "_hf_hook", None) is None,
                f"rollout graph does not support dispatch/offload hooks: {name}",
            )
        structure = {
            "tensors": {
                name: {
                    **tensor_metadata(value),
                    "id": id(value),
                    "data_ptr": value.data_ptr(),
                    "storage_ptr": value.untyped_storage().data_ptr(),
                    "storage_offset": value.storage_offset(),
                    "trainable": bool(value.requires_grad),
                }
                for name, value in tensors
            },
            "modules": {
                name: {
                    "id": id(module),
                    "class": type(module).__module__ + "." + type(module).__qualname__,
                    "training": bool(module.training),
                    "active_adapters": _active_adapters(module),
                    "merged": _optional_bool(module, "merged"),
                    "disable_adapters": _optional_bool(module, "disable_adapters"),
                    "lora_policy": _lora_policy(module),
                    "processor_id": id(getattr(module, "processor", None)),
                    "forward_id": _callable_id(module.forward, f"{name}.forward"),
                    "call_impl_id": _callable_id(module._call_impl, f"{name}._call_impl"),
                    "compiled_call_impl_id": _callable_id(
                        getattr(module, "_compiled_call_impl", None),
                        f"{name}._compiled_call_impl",
                        optional=True,
                    ),
                }
                for name, module in modules
            },
        }
        versions = {name: int(value._version) for name, value in tensors}
        return structure, versions

    def _value_hashes(self, unet: Any) -> dict[str, str]:
        values = [("parameter:" + name, value) for name, value in unet.named_parameters()]
        values += [("buffer:" + name, value) for name, value in unet.named_buffers()]
        return {name: _tensor_byte_sha256(self.torch, value) for name, value in values}

    def _check_deterministic_modules(self, unet: Any) -> None:
        for name, module in unet.named_modules():
            class_name = type(module).__qualname__
            if "Dropout" in class_name and module.training and float(getattr(module, "p", 0.0)) > 0:
                raise RuntimeError(f"rollout graph requires deterministic dropout: {name}")

    def _raw(self) -> Any:
        values = [item.value for item in self.inputs]
        return self.unet(
            values[0],
            values[1],
            encoder_hidden_states=values[2],
            added_cond_kwargs={"text_embeds": values[3], "time_ids": values[4]},
            return_dict=False,
        )[0]

    def setup(self, unet: Any, values: list[Any], adapter_sha: str) -> None:
        _require(self.graph is None and len(values) == 5, "rollout graph setup is not one-shot")
        _require(
            isinstance(adapter_sha, str) and len(adapter_sha) == 64,
            "invalid rollout adapter identity",
        )
        started = perf_counter()
        before_rng = self._rng()
        self._check_deterministic_modules(unet)
        before_structure, before_versions = self._state(unet)
        value_check_started = perf_counter()
        before_value_hashes = self._value_hashes(unet)
        self.value_validation_seconds = perf_counter() - value_check_started
        trainable = [
            name for name, record in before_structure["tensors"].items() if record["trainable"]
        ]
        _require(trainable and all("lora_" in name for name in trainable), "unexpected trainables")
        _require(all(value.device.type == "mlu" for value in values), "graph inputs must be on MLU")
        self.unet = unet
        self.inputs = [_PersistentInput(self.torch, value) for value in values]
        side = self.torch.mlu.Stream()
        current = self.torch.mlu.current_stream()
        side.wait_stream(current)
        warmup_started = perf_counter()
        with self.torch.no_grad(), self.torch.mlu.stream(side), self.torch.autocast(
            "mlu", dtype=self.torch.bfloat16, cache_enabled=False
        ):
            for _ in range(3):
                self._raw()
        current.wait_stream(side)
        self.torch.mlu.synchronize()
        self.warmup_seconds = perf_counter() - warmup_started
        capture_started = perf_counter()
        self.graph = self.torch.mlu.MLUGraph()
        with self.torch.no_grad(), self.torch.autocast(
            "mlu", dtype=self.torch.bfloat16, cache_enabled=False
        ):
            with self.torch.mlu.graph(self.graph, stream=side, capture_error_mode="global"):
                self.output = self._raw()
        current.wait_stream(side)
        self.torch.mlu.synchronize()
        self.capture_seconds = perf_counter() - capture_started
        after_structure, after_versions = self._state(unet)
        after_rng = self._rng()
        value_check_started = perf_counter()
        after_value_hashes = self._value_hashes(unet)
        self.value_validation_seconds += perf_counter() - value_check_started
        _require(
            before_structure == after_structure
            and before_versions == after_versions
            and before_value_hashes == after_value_hashes,
            "rollout graph setup modified UNet state",
        )
        _require(
            all(self.torch.equal(left, right) for left, right in zip(before_rng, after_rng)),
            "rollout graph setup modified CPU or MLU RNG",
        )
        self.structure = before_structure
        self.setup_versions = before_versions
        self.setup_adapter_sha = adapter_sha
        self.setup_seconds = perf_counter() - started

    def begin_rollout(self, unet: Any, adapter_sha: str) -> None:
        _require(self.graph is not None and unet is self.unet, "rollout graph is not initialized")
        self._check_deterministic_modules(unet)
        structure, versions = self._state(unet)
        _require(structure == self.structure, "UNet topology, storage, mode, or adapter policy changed")
        prior_versions = self.rollout_versions or self.setup_versions
        prior_sha = self.rollout_adapter_sha or self.setup_adapter_sha
        if self.rollout_versions is None:
            _require(versions == prior_versions and adapter_sha == prior_sha, "first rollout boundary changed")
        else:
            advanced = False
            for name, version in versions.items():
                if self.structure["tensors"][name]["trainable"]:
                    _require(version >= prior_versions[name], "LoRA parameter version regressed")
                    advanced = advanced or version > prior_versions[name]
                else:
                    _require(version == prior_versions[name], "frozen UNet tensor changed")
            _require(advanced and adapter_sha != prior_sha, "LoRA update did not advance in place")
        self.rollout_versions = versions
        self.rollout_adapter_sha = adapter_sha

    def __call__(self, unet: Any, values: list[Any]) -> Any:
        _require(
            self.graph is not None and unet is self.unet and self.rollout_versions is not None,
            "rollout graph call is outside a rollout boundary",
        )
        metadata = [tensor_metadata(value) for value in values]
        _require(
            metadata == [item.metadata for item in self.inputs],
            "rollout graph call input metadata changed",
        )
        for target, source in zip(self.inputs, values):
            target.copy_from(source)
        with self.torch.no_grad(), self.torch.autocast(
            "mlu", dtype=self.torch.bfloat16, cache_enabled=False
        ):
            self.graph.replay()
            result = self.output.clone()
        self.replays += 1
        return result

    def report(self) -> dict[str, Any]:
        return {
            "enabled": True,
            "setup_seconds": self.setup_seconds,
            "warmup_seconds": self.warmup_seconds,
            "capture_seconds": self.capture_seconds,
            "value_validation_seconds": self.value_validation_seconds,
            "replays": self.replays,
            "setup_inputs": [item.metadata for item in self.inputs],
            "capture_error_mode": "global",
            "autocast_cache_enabled": False,
        }
