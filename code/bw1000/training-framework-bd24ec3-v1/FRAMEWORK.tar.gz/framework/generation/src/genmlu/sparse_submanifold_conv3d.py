"""CPU-friendly PyTorch sparse submanifold 3D convolution helpers."""
from __future__ import annotations

from contextlib import nullcontext

import torch


def _accumulation_dtype(dtype: torch.dtype) -> torch.dtype:
    if dtype in {torch.float16, torch.bfloat16}:
        return torch.float32
    return dtype


def _fp32_autocast_context(device_type: str, *, autocast_factory=torch.autocast):
    if device_type in {"cpu", "cuda", "mlu"}:
        return autocast_factory(device_type=device_type, enabled=False)
    return nullcontext()


def _matmul_without_autocast(left: torch.Tensor, right: torch.Tensor) -> torch.Tensor:
    with _fp32_autocast_context(left.device.type):
        return left.matmul(right)


def _validate_inputs(
    features: torch.Tensor,
    coordinates: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor | None,
) -> tuple[int, int, int, int]:
    if features.ndim != 2:
        raise ValueError("features must have shape [N, Ci]")
    if coordinates.ndim != 2 or coordinates.shape[1] != 4:
        raise ValueError("coordinates must have shape [N, 4] as [batch, z, y, x]")
    if coordinates.shape[0] != features.shape[0]:
        raise ValueError("coordinates and features must have the same N")
    if (
        coordinates.dtype == torch.bool
        or torch.is_floating_point(coordinates)
        or torch.is_complex(coordinates)
    ):
        raise ValueError("coordinates must use an integer dtype")
    if weight.ndim != 5:
        raise ValueError("weight must have shape [Co, Kd, Kh, Kw, Ci]")
    if weight.shape[-1] != features.shape[1]:
        raise ValueError("weight Ci must match features Ci")
    if weight.device != features.device or weight.dtype != features.dtype:
        raise ValueError("features and weight must have the same device and dtype")
    if bias is not None:
        if bias.ndim != 1 or bias.shape[0] != weight.shape[0]:
            raise ValueError("bias must have shape [Co]")
        if bias.device != features.device or bias.dtype != features.dtype:
            raise ValueError("bias must have the same device and dtype as features")

    _, kernel_depth, kernel_height, kernel_width, _ = weight.shape
    if min(kernel_depth, kernel_height, kernel_width) <= 0:
        raise ValueError("kernel dimensions must be positive")
    if any(size % 2 == 0 for size in (kernel_depth, kernel_height, kernel_width)):
        raise ValueError("submanifold convolution requires odd kernel dimensions")
    return kernel_depth, kernel_height, kernel_width, weight.shape[0]


def sparse_submanifold_conv3d(
    features: torch.Tensor,
    coordinates: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor | None = None,
) -> torch.Tensor:
    """Apply stride-one submanifold convolution at the active coordinates."""
    kernel_depth, kernel_height, kernel_width, output_channels = _validate_inputs(
        features, coordinates, weight, bias
    )

    coordinate_keys = []
    lookup: dict[tuple[int, int, int, int], int] = {}
    for index, coordinate in enumerate(coordinates.detach().cpu().tolist()):
        key = tuple(int(value) for value in coordinate)
        if key in lookup:
            raise ValueError(f"duplicate sparse coordinate: {key}")
        lookup[key] = index
        coordinate_keys.append(key)

    if not lookup:
        result = features.new_zeros((0, output_channels))
        zero = features.sum() * 0 + weight.sum() * 0
        if bias is not None:
            zero = zero + bias.sum() * 0
        return result + zero

    depth_center = kernel_depth // 2
    height_center = kernel_height // 2
    width_center = kernel_width // 2
    accumulation_dtype = _accumulation_dtype(features.dtype)
    accumulation_features = features.to(accumulation_dtype)
    accumulation_weight = weight.to(accumulation_dtype)
    if bias is None:
        output = torch.zeros(
            (len(coordinate_keys), output_channels),
            dtype=accumulation_dtype,
            device=features.device,
        )
    else:
        output = bias.to(accumulation_dtype).unsqueeze(0).expand(len(coordinate_keys), -1)

    for kernel_d in range(kernel_depth):
        depth_offset = kernel_d - depth_center
        for kernel_h in range(kernel_height):
            height_offset = kernel_h - height_center
            for kernel_w in range(kernel_width):
                width_offset = kernel_w - width_center
                output_indices = []
                input_indices = []
                for output_index, (batch, depth, height, width) in enumerate(coordinate_keys):
                    neighbor_index = lookup.get(
                        (batch, depth + depth_offset, height + height_offset, width + width_offset)
                    )
                    if neighbor_index is not None:
                        output_indices.append(output_index)
                        input_indices.append(neighbor_index)
                if not input_indices:
                    continue

                device_indices = torch.tensor(input_indices, device=features.device, dtype=torch.long)
                output_device_indices = torch.tensor(
                    output_indices, device=features.device, dtype=torch.long
                )
                selected_features = accumulation_features.index_select(0, device_indices)
                kernel = accumulation_weight[:, kernel_d, kernel_h, kernel_w, :].transpose(0, 1)
                product = _matmul_without_autocast(selected_features, kernel)
                output = output.index_add(0, output_device_indices, product)
    return output.to(features.dtype)
