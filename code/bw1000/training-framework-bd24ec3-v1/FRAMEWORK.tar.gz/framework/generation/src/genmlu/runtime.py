from __future__ import annotations

from dataclasses import dataclass
from typing import Any


MEMORY_LIMIT_BYTES = 75_000_000_000


def within_memory_limit(reserved_bytes: int, limit_bytes: int = MEMORY_LIMIT_BYTES) -> bool:
    return 0 <= reserved_bytes <= limit_bytes


@dataclass(frozen=True)
class RuntimeInfo:
    torch_version: str | None
    mlu_available: bool
    mlu_count: int
    device_name: str | None


def get_torch() -> Any:
    try:
        import torch
    except ImportError as exc:
        raise RuntimeError("PyTorch is required; install a torch_mlu-enabled image") from exc
    try:
        import torch_mlu  # noqa: F401
    except ImportError:
        pass
    return torch


def inspect_runtime() -> RuntimeInfo:
    try:
        torch = get_torch()
    except RuntimeError:
        return RuntimeInfo(None, False, 0, None)
    mlu = getattr(torch, "mlu", None)
    available = bool(mlu and mlu.is_available())
    count = int(mlu.device_count()) if available else 0
    name = str(mlu.get_device_name(0)) if available and count else None
    return RuntimeInfo(torch.__version__, available, count, name)


def require_mlu() -> Any:
    torch = get_torch()
    if not getattr(torch, "mlu", None) or not torch.mlu.is_available():
        raise RuntimeError("MLU is unavailable; run inside a torch_mlu container with assigned cards")
    return torch


def autocast_bf16() -> Any:
    torch = require_mlu()
    return torch.autocast(device_type="mlu", dtype=torch.bfloat16)


def synchronize() -> None:
    torch = require_mlu()
    torch.mlu.synchronize()


def memory_stats() -> dict[str, int]:
    torch = require_mlu()
    allocated = int(torch.mlu.max_memory_allocated())
    reserved = int(torch.mlu.max_memory_reserved())
    return {
        "allocated": allocated,
        "reserved": reserved,
        "peak_allocated_bytes": allocated,
        "peak_reserved_bytes": reserved,
    }
