from __future__ import annotations

import json
import statistics
from pathlib import Path
from time import perf_counter, time
from typing import Any

import numpy as np

from ..manifest import sha256_path
from ..runtime import autocast_bf16, require_mlu, synchronize


def _enable_zimage_mlu_rope(torch: Any) -> None:
    """Replace Z-Image's ComplexFloat RoPE with the equivalent real-valued form."""
    from diffusers.models.transformers import transformer_z_image as zimage

    if getattr(zimage, "_genmlu_mlu_rope_enabled", False):
        return

    def rope_call(self: Any, ids: Any) -> Any:
        if ids.ndim != 2 or ids.shape[-1] != len(self.axes_dims):
            raise ValueError("Z-Image RoPE ids have an unexpected shape")
        device = ids.device
        if self.freqs_cis is None:
            tables = []
            with torch.device("cpu"):
                for dim, end in zip(self.axes_dims, self.axes_lens):
                    freqs = 1.0 / (
                        self.theta ** (torch.arange(0, dim, 2, dtype=torch.float32) / dim)
                    )
                    phases = torch.outer(torch.arange(end, dtype=torch.float32), freqs)
                    tables.append(torch.stack((torch.cos(phases), torch.sin(phases)), dim=-1))
            self.freqs_cis = [table.to(device) for table in tables]
        elif self.freqs_cis[0].device != device:
            self.freqs_cis = [table.to(device) for table in self.freqs_cis]
        return torch.cat([self.freqs_cis[index][ids[:, index]] for index in range(len(self.axes_dims))], dim=-2)

    def processor_call(
        self: Any,
        attn: Any,
        hidden_states: Any,
        encoder_hidden_states: Any = None,
        attention_mask: Any = None,
        freqs_cis: Any = None,
    ) -> Any:
        query = attn.to_q(hidden_states).unflatten(-1, (attn.heads, -1))
        key = attn.to_k(hidden_states).unflatten(-1, (attn.heads, -1))
        value = attn.to_v(hidden_states).unflatten(-1, (attn.heads, -1))
        if attn.norm_q is not None:
            query = attn.norm_q(query)
        if attn.norm_k is not None:
            key = attn.norm_k(key)

        def apply_rotary(x_in: Any, frequencies: Any) -> Any:
            x_pair = x_in.float().reshape(*x_in.shape[:-1], -1, 2)
            freqs = frequencies.unsqueeze(2)
            real = x_pair[..., 0] * freqs[..., 0] - x_pair[..., 1] * freqs[..., 1]
            imag = x_pair[..., 0] * freqs[..., 1] + x_pair[..., 1] * freqs[..., 0]
            return torch.stack((real, imag), dim=-1).flatten(3).type_as(x_in)

        if freqs_cis is not None:
            query = apply_rotary(query, freqs_cis)
            key = apply_rotary(key, freqs_cis)
        if attention_mask is not None and attention_mask.ndim == 2:
            attention_mask = attention_mask[:, None, None, :]
        hidden_states = zimage.dispatch_attention_fn(
            query,
            key,
            value,
            attn_mask=attention_mask,
            dropout_p=0.0,
            is_causal=False,
            backend=self._attention_backend,
            parallel_config=self._parallel_config,
        )
        hidden_states = hidden_states.flatten(2, 3).to(query.dtype)
        output = attn.to_out[0](hidden_states)
        return attn.to_out[1](output) if len(attn.to_out) > 1 else output

    zimage.RopeEmbedder.__call__ = rope_call
    zimage.ZSingleStreamAttnProcessor.__call__ = processor_call
    zimage._genmlu_mlu_rope_enabled = True


def _benchmark_prompts(config: dict[str, Any], count: int) -> list[str]:
    manifest = config.get("sample_manifest")
    if not manifest:
        return [str(config["prompt"])] * count
    records = [
        json.loads(line)
        for line in Path(manifest).read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if len(records) < count:
        raise RuntimeError(f"image benchmark needs {count} prompts, found {len(records)}")
    return [str(record["caption"]) for record in records[:count]]


def run_image_inference(
    model: str, weights: Path, config: dict[str, Any], output_dir: Path
) -> dict[str, Any]:
    if model not in {"sdxl-1.0", "z-image-turbo"}:
        raise ValueError(f"diffusers image backend does not support {model}")
    if not weights.is_dir():
        raise RuntimeError(f"weights are missing: {weights}")
    try:
        from diffusers import DiffusionPipeline
    except ImportError as exc:
        raise RuntimeError("diffusers is required for image inference") from exc

    torch = require_mlu()
    seed = int(config.get("seed", 42))
    torch.manual_seed(seed)
    if model == "z-image-turbo":
        _enable_zimage_mlu_rope(torch)
    pipeline = DiffusionPipeline.from_pretrained(
        str(weights), torch_dtype=torch.bfloat16, local_files_only=True
    )
    pipeline.to("mlu")
    kwargs: dict[str, Any] = {
        "height": int(config.get("height", 512)),
        "width": int(config.get("width", 512)),
        "num_inference_steps": int(config.get("num_inference_steps", 20)),
    }
    if model == "z-image-turbo":
        kwargs["guidance_scale"] = 0.0
        kwargs["num_inference_steps"] = 9
    else:
        kwargs["guidance_scale"] = float(config.get("guidance_scale", 7.0))
    output_dir.mkdir(parents=True, exist_ok=True)
    warmup_samples = int(config.get("warmup_samples", 0))
    measurement_samples = int(config.get("measurement_samples", 1))
    if warmup_samples < 0 or measurement_samples < 1:
        raise ValueError("warmup_samples must be non-negative and measurement_samples must be positive")
    total_samples = warmup_samples + measurement_samples
    prompts = _benchmark_prompts(config, total_samples)
    measured_seconds: list[float] = []
    step_records: list[dict[str, Any]] = []
    artifacts: list[dict[str, str]] = []
    output_path = output_dir / "image.png"
    torch.mlu.reset_peak_memory_stats()
    for index, prompt in enumerate(prompts):
        torch.manual_seed(seed + index)
        torch.mlu.manual_seed_all(seed + index)
        synchronize()
        started_unix = time()
        started = perf_counter()
        with autocast_bf16():
            pixels = pipeline(prompt=prompt, output_type="np", **kwargs).images[0]
        if not np.isfinite(pixels).all():
            raise RuntimeError("image pipeline produced non-finite output pixels")
        image = pipeline.image_processor.numpy_to_pil(pixels)[0]
        synchronize()
        elapsed = perf_counter() - started
        step_records.append(
            {
                "ended_unix": time(),
                "index": index,
                "prompt": prompt,
                "seed": seed + index,
                "started_unix": started_unix,
                "step_seconds": elapsed,
                "warmup": index < warmup_samples,
            }
        )
        if index >= warmup_samples:
            measured_seconds.append(elapsed)
            sample_path = output_dir / (
                "image.png" if warmup_samples == 0 and measurement_samples == 1
                else f"sample-{index - warmup_samples:04d}.png"
            )
            image.save(sample_path)
            artifacts.append({"path": str(sample_path), "sha256": sha256_path(sample_path)})
            output_path = sample_path
    step_path = output_dir / "steps.ndjson"
    step_path.write_text(
        "".join(json.dumps(record, sort_keys=True) + "\n" for record in step_records),
        encoding="utf-8",
    )
    summary = {
        "generation_seconds": measured_seconds,
        "measurement_samples": measurement_samples,
        "model": model,
        "seconds_max": max(measured_seconds),
        "seconds_median": statistics.median(measured_seconds),
        "seconds_min": min(measured_seconds),
        "warmup_samples": warmup_samples,
    }
    summary_path = output_dir / "benchmark.json"
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    artifacts.append({"path": str(summary_path), "sha256": sha256_path(summary_path)})
    artifacts.append({"path": str(step_path), "sha256": sha256_path(step_path)})
    return {
        "artifact": output_path,
        "artifacts": artifacts,
        "checks": {
            "finite_tensors": True,
            "main_forward_device": "mlu",
        },
        "observations": {
            "unique_prompts": len(set(prompts)) == total_samples,
            "finite_tensor_scope": "decoded_output_pixels",
        },
        "logs": [
            {"path": str(step_path), "sha256": sha256_path(step_path)},
            {"path": str(summary_path), "sha256": sha256_path(summary_path)},
        ],
        "metrics": {
            "measurement_samples": measurement_samples,
            "peak_reserved_bytes": torch.mlu.max_memory_reserved(),
            "samples_per_second": measurement_samples / sum(measured_seconds),
            "seconds_max": max(measured_seconds),
            "seconds_median": statistics.median(measured_seconds),
            "seconds_min": min(measured_seconds),
            "warmup_samples": warmup_samples,
            "warmup_steps": warmup_samples,
        },
        "stage_timings": {"generation_seconds": measured_seconds},
    }
