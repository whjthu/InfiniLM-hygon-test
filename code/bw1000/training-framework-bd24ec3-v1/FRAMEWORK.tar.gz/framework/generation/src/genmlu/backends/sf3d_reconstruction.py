from __future__ import annotations

import hashlib
import json
import os
try:
    import resource
except ModuleNotFoundError:  # Windows can inspect the CLI but cannot run an MLU backend.
    resource = None
import statistics
import sys
from concurrent.futures import Future, ThreadPoolExecutor
from pathlib import Path
from time import perf_counter, time
from typing import Any, Callable

import numpy as np

from ..manifest import sha256_path
from ..runtime import autocast_bf16, memory_stats, require_mlu, synchronize
from ..sidecar_timing import SidecarTiming, record_sidecar_failure


def _tensor_sha(tensor: Any) -> str:
    value = tensor.detach().cpu().float().contiguous().numpy()
    return hashlib.sha256(value.tobytes()).hexdigest()


def _array_sha(value: Any) -> str:
    return hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()


def _repeat_determinism(
    inputs: list[str],
    scene_shas: list[str],
    mesh_vertex_shas: list[str],
    semantic_shas: list[dict[str, str]],
    texture_within_tolerance: bool,
    benchmark_mode: bool,
) -> bool | None:
    if benchmark_mode or len(inputs) < 2 or len(set(inputs)) != 1:
        return None
    return (
        len(set(scene_shas)) == 1
        and len(set(mesh_vertex_shas)) == 1
        and all(
            len({item[name] for item in semantic_shas}) == 1
            for name in ("vertices", "faces", "uv")
        )
        and texture_within_tolerance
    )


def _checks_pass(checks: dict[str, bool | None]) -> bool:
    return all(value is None or bool(value) for value in checks.values())


def _lossless_texture_image(pixels: Any) -> Any:
    from PIL import Image

    image = Image.fromarray(pixels).convert("RGB")
    # GLB embeds this image; keep it lossless like the standalone texture PNG.
    image.format = "PNG"
    return image


def _prepare_batch(model: Any, image: Any) -> dict[str, Any]:
    mask, rgb = model.prepare_image(image)
    from sf3d.utils import create_intrinsic_from_fov_deg, default_cond_c2w

    c2w = default_cond_c2w(model.cfg.default_distance).to("mlu")
    intrinsic, intrinsic_normed = create_intrinsic_from_fov_deg(
        model.cfg.default_fovy_deg,
        model.cfg.cond_image_size,
        model.cfg.cond_image_size,
    )
    batch = {
        "rgb_cond": rgb.unsqueeze(0),
        "mask_cond": mask.unsqueeze(0),
        "c2w_cond": c2w.view(1, 1, 4, 4),
        "intrinsic_cond": intrinsic.to("mlu").view(1, 1, 3, 3),
        "intrinsic_normed_cond": intrinsic_normed.to("mlu").view(1, 1, 3, 3),
    }
    batch["rgb_cond"] = model.image_processor(
        batch["rgb_cond"], model.cfg.cond_image_size
    )
    batch["mask_cond"] = model.image_processor(
        batch["mask_cond"], model.cfg.cond_image_size
    )
    return batch


def _cpu_mesh_sidecar(
    torch: Any,
    model: Any,
    scene_codes: Any,
    mesh: Any,
    global_dict: dict[str, Any],
    bake_resolution: int,
    output_path: Path,
) -> dict[str, Any]:
    sidecar_started = perf_counter()
    trace = SidecarTiming()
    try:
        mesh_vertices = mesh.v_pos.detach().cpu()
        mesh_faces = mesh.t_pos_idx.detach().cpu()
        trace.mark("mesh_transfer_and_construct", "mixed")
        prepared = _prepare_cpu_mesh_sidecar(
            mesh_vertices, mesh_faces, model.baker, bake_resolution, trace
        )
        result = _finish_cpu_mesh_sidecar(
            torch, model, scene_codes, global_dict, bake_resolution,
            output_path, trace, sidecar_started, *prepared,
        )
        result["sidecar_profile"] = trace.finish(status="completed")
        return result
    except BaseException as exc:
        record_sidecar_failure(trace, output_path.with_suffix(".timing-failed.json"), exc)
        raise


def _start_pipelined_cpu_mesh_sidecar(
    executor: ThreadPoolExecutor,
    model: Any,
    mesh: Any,
    scene_codes: Any,
    global_dict: dict[str, Any],
    bake_resolution: int,
    output_path: Path,
) -> dict[str, Any]:
    sidecar_started = perf_counter()
    trace = SidecarTiming()
    try:
        mesh_vertices = mesh.v_pos.detach().cpu()
        mesh_faces = mesh.t_pos_idx.detach().cpu()
        trace.mark("mesh_transfer_and_construct", "mixed")
        future: Future[Any] = executor.submit(
            _prepare_cpu_mesh_sidecar,
            mesh_vertices,
            mesh_faces,
            model.baker,
            bake_resolution,
            trace,
        )
        return {
            "future": future,
            "trace": trace,
            "sidecar_started": sidecar_started,
            "scene_codes": scene_codes,
            "global_dict": global_dict,
            "bake_resolution": bake_resolution,
            "output_path": output_path,
        }
    except BaseException as exc:
        record_sidecar_failure(trace, output_path.with_suffix(".timing-failed.json"), exc)
        raise


def _finish_pipelined_cpu_mesh_sidecar(
    torch: Any, model: Any, pending: dict[str, Any]
) -> dict[str, Any]:
    trace = pending["trace"]
    try:
        prepared = pending["future"].result()
        result = _finish_cpu_mesh_sidecar(
            torch,
            model,
            pending["scene_codes"],
            pending["global_dict"],
            pending["bake_resolution"],
            pending["output_path"],
            trace,
            pending["sidecar_started"],
            *prepared,
        )
        result["sidecar_profile"] = trace.finish(status="completed")
        return result
    except BaseException as exc:
        record_sidecar_failure(
            trace, pending["output_path"].with_suffix(".timing-failed.json"), exc
        )
        raise


def _clone_sidecar_snapshot(value: Any) -> Any:
    """Detach tensor values so a queued sidecar cannot observe later mutation."""
    if hasattr(value, "detach") and hasattr(value, "clone"):
        return value.detach().clone()
    if isinstance(value, dict):
        return {key: _clone_sidecar_snapshot(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_clone_sidecar_snapshot(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_clone_sidecar_snapshot(item) for item in value)
    return value


def _prepare_cpu_mesh_uv_sidecar(
    mesh_vertices: Any, mesh_faces: Any, trace: SidecarTiming,
) -> tuple[Any, float]:
    """The dual-worker payload: CPU mesh construction and UV unwrap only."""
    from sf3d.models.mesh import Mesh

    unwrap_started = perf_counter()
    cpu_mesh = Mesh(mesh_vertices, mesh_faces)
    cpu_mesh.unwrap_uv()
    unwrap_seconds = perf_counter() - unwrap_started
    trace.mark("uv_unwrap", "cpu")
    return cpu_mesh, unwrap_seconds


def _owner_bake_cpu_mesh_sidecar(
    baker: Any, cpu_mesh: Any, bake_resolution: int, trace: SidecarTiming,
) -> tuple[Any, Any, float]:
    """Run baker calls on the inference owner thread, never on a CPU worker."""
    bake_started = perf_counter()
    raster = baker.rasterize(cpu_mesh.v_tex, cpu_mesh.t_pos_idx, bake_resolution)
    bake_mask = baker.get_mask(raster)
    position_bake = baker.interpolate(cpu_mesh.v_pos, raster, cpu_mesh.t_pos_idx)
    sampled_positions = position_bake[bake_mask]
    bake_seconds = perf_counter() - bake_started
    trace.mark("rasterize_and_interpolate", "cpu")
    return bake_mask, sampled_positions, bake_seconds


def _start_dual_worker_cpu_mesh_sidecar(
    executor: ThreadPoolExecutor,
    mesh: Any,
    scene_codes: Any,
    global_dict: dict[str, Any],
    bake_resolution: int,
    output_path: Path,
) -> dict[str, Any]:
    """Snapshot owner state before one of at most two UV-only jobs is submitted."""
    sidecar_started = perf_counter()
    trace = SidecarTiming()
    try:
        # cpu() can retain an alias for an already-CPU tensor, so clone explicitly.
        mesh_vertices = mesh.v_pos.detach().cpu().clone()
        mesh_faces = mesh.t_pos_idx.detach().cpu().clone()
        scene_codes_snapshot = _clone_sidecar_snapshot(scene_codes)
        global_dict_snapshot = _clone_sidecar_snapshot(global_dict)
        trace.mark("mesh_transfer_and_construct", "mixed")
        future: Future[Any] = executor.submit(
            _prepare_cpu_mesh_uv_sidecar, mesh_vertices, mesh_faces, trace
        )
        return {
            "future": future,
            "trace": trace,
            "sidecar_started": sidecar_started,
            "scene_codes": scene_codes_snapshot,
            "global_dict": global_dict_snapshot,
            "bake_resolution": bake_resolution,
            "output_path": output_path,
        }
    except BaseException as exc:
        record_sidecar_failure(trace, output_path.with_suffix(".timing-failed.json"), exc)
        raise


def _finish_oldest_dual_sidecar(
    pending_sidecars: list[dict[str, Any]],
    finish: Callable[[dict[str, Any]], None],
) -> None:
    """Finalize and release the oldest snapshot before another inference starts."""
    pending = pending_sidecars.pop(0)
    try:
        finish(pending)
    finally:
        pending.clear()


def _drain_dual_sidecars_before_inference(
    pending_sidecars: list[dict[str, Any]],
    finish: Callable[[dict[str, Any]], None],
) -> None:
    """Keep at most two inferred-but-unfinished samples alive at a time."""
    while len(pending_sidecars) >= 2:
        _finish_oldest_dual_sidecar(pending_sidecars, finish)


def _finish_dual_worker_cpu_mesh_sidecar(
    torch: Any, model: Any, pending: dict[str, Any]
) -> dict[str, Any]:
    """Finish one dual-worker job on the owner thread in submission order."""
    trace = pending["trace"]
    try:
        cpu_mesh, unwrap_seconds = pending["future"].result()
        # This separates idle ready-queue time from owner-thread bake service.
        trace.mark("uv_ready_queue_wait", "cpu")
        bake_mask, sampled_positions, bake_seconds = _owner_bake_cpu_mesh_sidecar(
            model.baker, cpu_mesh, pending["bake_resolution"], trace
        )
        result = _finish_cpu_mesh_sidecar(
            torch,
            model,
            pending["scene_codes"],
            pending["global_dict"],
            pending["bake_resolution"],
            pending["output_path"],
            trace,
            pending["sidecar_started"],
            cpu_mesh,
            bake_mask,
            sampled_positions,
            unwrap_seconds,
            bake_seconds,
        )
        result["sidecar_profile"] = trace.finish(status="completed")
        return result
    except BaseException as exc:
        record_sidecar_failure(
            trace, pending["output_path"].with_suffix(".timing-failed.json"), exc
        )
        raise


def _prepare_cpu_mesh_sidecar(
    mesh_vertices: Any, mesh_faces: Any, baker: Any, bake_resolution: int,
    trace: SidecarTiming,
) -> tuple[Any, Any, Any, float, float]:
    from sf3d.models.mesh import Mesh

    unwrap_started = perf_counter()
    cpu_mesh = Mesh(mesh_vertices, mesh_faces)
    cpu_mesh.unwrap_uv()
    unwrap_seconds = perf_counter() - unwrap_started
    trace.mark("uv_unwrap", "cpu")

    bake_started = perf_counter()
    raster = baker.rasterize(
        cpu_mesh.v_tex, cpu_mesh.t_pos_idx, bake_resolution
    )
    bake_mask = baker.get_mask(raster)
    position_bake = baker.interpolate(
        cpu_mesh.v_pos, raster, cpu_mesh.t_pos_idx
    )
    sampled_positions = position_bake[bake_mask]
    bake_seconds = perf_counter() - bake_started
    trace.mark("rasterize_and_interpolate", "cpu")
    return cpu_mesh, bake_mask, sampled_positions, unwrap_seconds, bake_seconds


def _finish_cpu_mesh_sidecar(
    torch: Any, model: Any, scene_codes: Any, global_dict: dict[str, Any],
    bake_resolution: int, output_path: Path, trace: SidecarTiming,
    sidecar_started: float, cpu_mesh: Any, bake_mask: Any,
    sampled_positions: Any, unwrap_seconds: float, bake_seconds: float,
) -> dict[str, Any]:
    import trimesh
    from sf3d.models.utils import dilate_fill, float32_to_uint8_np

    decoder_started = perf_counter()
    with torch.no_grad(), autocast_bf16():
        triplane_features = model.query_triplane(
            sampled_positions.to("mlu"), scene_codes[0]
        )[0]
        decoded = model.decoder(
            triplane_features, exclude=["density", "vertex_offset"]
        )
    synchronize()
    decoder_seconds = perf_counter() - decoder_started
    trace.mark("texture_query_and_decode_with_input_transfer", "mlu")

    texture_started = perf_counter()
    albedo = decoded["features"].detach().cpu().float()
    trace.mark("decoded_albedo_transfer", "transfer")
    texture = torch.zeros(
        bake_resolution, bake_resolution, 3, dtype=albedo.dtype
    )
    texture[bake_mask] = albedo
    texture = (
        dilate_fill(
            texture.permute(2, 0, 1)[None].contiguous(),
            bake_mask[None, None],
            iterations=max(1, bake_resolution // 150),
        )
        .squeeze(0)
        .permute(1, 2, 0)
        .contiguous()
    )
    base_color = _lossless_texture_image(float32_to_uint8_np(texture.numpy()))
    trace.mark("texture_fill_and_image", "cpu")
    roughness = float(global_dict["decoder_roughness"][0].detach().cpu().squeeze())
    metallic = float(global_dict["decoder_metallic"][0].detach().cpu().squeeze())
    trace.mark("material_scalars_transfer", "transfer")
    material = trimesh.visual.material.PBRMaterial(
        baseColorTexture=base_color,
        roughnessFactor=roughness,
        metallicFactor=metallic,
    )
    exported = trimesh.Trimesh(
        vertices=cpu_mesh.v_pos.numpy(),
        faces=cpu_mesh.t_pos_idx.numpy(),
        visual=trimesh.visual.texture.TextureVisuals(
            uv=cpu_mesh.v_tex.numpy(), material=material
        ),
    )
    exported.apply_transform(
        trimesh.transformations.rotation_matrix(np.radians(-90), [1, 0, 0])
    )
    exported.apply_transform(
        trimesh.transformations.rotation_matrix(np.radians(90), [0, 1, 0])
    )
    exported.invert()
    trace.mark("material_mesh_and_transform", "cpu")
    semantic_sha = {
        "vertices": _array_sha(exported.vertices),
        "faces": _array_sha(exported.faces),
        "uv": _array_sha(exported.visual.uv),
        "texture": _array_sha(np.asarray(base_color)),
    }
    trace.mark("semantic_hash", "cpu")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    exported.export(output_path, include_normals=True)
    trace.mark("glb_export", "cpu")
    texture_path = output_path.with_name(output_path.stem + "-texture.png")
    base_color.save(texture_path, format="PNG")
    trace.mark("texture_png_export", "cpu")
    texture_seconds = perf_counter() - texture_started
    return {
        "artifact": output_path,
        "texture_artifact": texture_path,
        "vertices": int(len(exported.vertices)),
        "faces": int(len(exported.faces)),
        "sampled_texture_pixels": int(bake_mask.sum()),
        "roughness": roughness,
        "metallic": metallic,
        "unwrap_seconds": unwrap_seconds,
        "cpu_bake_seconds": bake_seconds,
        "mlu_texture_decoder_seconds": decoder_seconds,
        "cpu_export_seconds": texture_seconds,
        "cpu_sidecar_seconds": perf_counter() - sidecar_started,
        "semantic_sha256": semantic_sha,
        "_texture_array": np.asarray(base_color).copy(),
    }


def run_sf3d_inference(
    weights: Path,
    config: dict[str, Any],
    output_dir: Path,
    source_root: Path,
) -> dict[str, Any]:
    run_started = perf_counter()
    os.environ.setdefault("SF3D_OFFLINE_INIT", "1")
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    torch = require_mlu()
    sys.path.insert(0, str(source_root))
    from PIL import Image
    from sf3d.system import SF3D

    configured_inputs = config.get("input_images") or [config["input_image"]]
    input_paths = [Path(item) for item in configured_inputs]
    images = []
    for input_path in input_paths:
        if not input_path.is_file():
            raise RuntimeError(f"SF3D input image is missing: {input_path}")
        image = Image.open(input_path).convert("RGBA")
        alpha = np.asarray(image)[..., 3]
        if not np.any(alpha < 255):
            raise RuntimeError("SF3D acceptance input must contain a real alpha mask")
        images.append(image)

    load_started = perf_counter()
    model = SF3D.from_pretrained(
        str(weights), config_name="config.yaml", weight_name="model.safetensors"
    )
    model.to("mlu").eval()
    load_seconds = perf_counter() - load_started
    batches = [_prepare_batch(model, image) for image in images]
    bake_resolution = int(config.get("texture_resolution", 256))
    warmup_steps = int(config.get("warmup_iterations", 0))
    measure_steps = int(config.get("measure_iterations", 0))
    benchmark_mode = measure_steps > 0
    repeat_count = (
        warmup_steps + measure_steps
        if benchmark_mode
        else (2 if bool(config.get("repeat", True)) else 1)
    )
    torch.mlu.reset_peak_memory_stats()
    runs = []
    scene_shas = []
    mesh_vertex_shas = []
    output_dir.mkdir(parents=True, exist_ok=True)
    step_log = output_dir / "steps.ndjson"
    initialization_seconds = perf_counter() - run_started
    measurement_started = None
    pipeline_cpu_sidecar = bool(config.get("pipeline_cpu_sidecar", False))
    cpu_sidecar_workers = int(config.get("cpu_sidecar_workers", 1))
    if cpu_sidecar_workers not in (1, 2):
        raise ValueError("cpu_sidecar_workers must be 1 or 2")
    dual_worker_sidecar = pipeline_cpu_sidecar and cpu_sidecar_workers == 2
    # Preserve the established serial and one-worker implementation exactly.
    executor = ThreadPoolExecutor(max_workers=1) if pipeline_cpu_sidecar and not dual_worker_sidecar else None
    dual_executor = ThreadPoolExecutor(max_workers=2) if dual_worker_sidecar else None
    pending_sidecar: dict[str, Any] | None = None
    pending_dual_sidecars: list[dict[str, Any]] = []

    def append_completed_sidecar(pending: dict[str, Any]) -> None:
        sidecar = _finish_pipelined_cpu_mesh_sidecar(torch, model, pending)
        record = pending["record"]
        runs.append(
            {
                **sidecar,
                "network_seconds": record["network_seconds"],
                "mlu_geometry_seconds": record["geometry_seconds"],
                "scene_shape": record["scene_shape"],
                "direct_shape": record["direct_shape"],
                "scene_device": record["scene_device"],
                "mesh_device": record["mesh_device"],
                "scene_finite": bool(torch.isfinite(pending["scene_codes"]).all().cpu()),
                "input": record["input"],
                "started_unix": record["started_unix"],
                "ended_unix": time(),
            }
        )
        runs[-1]["full_iteration_seconds"] = perf_counter() - record["iteration_started"]

    def append_completed_dual_sidecar(pending: dict[str, Any]) -> None:
        sidecar = _finish_dual_worker_cpu_mesh_sidecar(torch, model, pending)
        record = pending["record"]
        runs.append(
            {
                **sidecar,
                "network_seconds": record["network_seconds"],
                "mlu_geometry_seconds": record["geometry_seconds"],
                "scene_shape": record["scene_shape"],
                "direct_shape": record["direct_shape"],
                "scene_device": record["scene_device"],
                "mesh_device": record["mesh_device"],
                "scene_finite": bool(torch.isfinite(pending["scene_codes"]).all().cpu()),
                "input": record["input"],
                "started_unix": record["started_unix"],
                "ended_unix": time(),
            }
        )
        runs[-1]["full_iteration_seconds"] = perf_counter() - record["iteration_started"]

    try:
        for repeat_index in range(repeat_count):
            if dual_worker_sidecar:
                _drain_dual_sidecars_before_inference(
                    pending_dual_sidecars, append_completed_dual_sidecar
                )
            iteration_started = perf_counter()
            if repeat_index == (warmup_steps if benchmark_mode else 0):
                if dual_worker_sidecar:
                    while pending_dual_sidecars:
                        _finish_oldest_dual_sidecar(
                            pending_dual_sidecars, append_completed_dual_sidecar
                        )
                elif pending_sidecar is not None:
                    append_completed_sidecar(pending_sidecar)
                    pending_sidecar = None
                measurement_started = perf_counter()
            batch = batches[repeat_index % len(batches)]
            started_unix = time()
            synchronize()
            network_started = perf_counter()
            with torch.no_grad(), autocast_bf16():
                scene_codes, direct_codes = model.get_scene_codes(dict(batch))
                global_dict = model.image_estimator(
                    batch["rgb_cond"] * batch["mask_cond"]
                )
            synchronize()
            network_seconds = perf_counter() - network_started

            geometry_started = perf_counter()
            with torch.no_grad(), autocast_bf16():
                meshes = model.triplane_to_meshes(scene_codes)
            synchronize()
            geometry_seconds = perf_counter() - geometry_started
            if not meshes or meshes[0].v_pos.numel() == 0:
                raise RuntimeError("SF3D produced an empty mesh")

            scene_shas.append(_tensor_sha(scene_codes))
            mesh_vertex_shas.append(_tensor_sha(meshes[0].v_pos))
            record = {
                "iteration_started": iteration_started,
                "started_unix": started_unix,
                "network_seconds": network_seconds,
                "geometry_seconds": geometry_seconds,
                "scene_shape": list(scene_codes.shape),
                "direct_shape": list(direct_codes.shape),
                "scene_device": str(scene_codes.device),
                "mesh_device": str(meshes[0].v_pos.device),
                "input": str(input_paths[repeat_index % len(input_paths)]),
            }
            output_path = output_dir / f"mesh-{repeat_index + 1}.glb"
            if dual_worker_sidecar:
                current_sidecar = _start_dual_worker_cpu_mesh_sidecar(
                    dual_executor, meshes[0], scene_codes, global_dict,
                    bake_resolution, output_path,
                )
                current_sidecar["record"] = record
                pending_dual_sidecars.append(current_sidecar)
                continue
            if executor is None:
                sidecar = _cpu_mesh_sidecar(
                    torch, model, scene_codes, meshes[0], global_dict,
                    bake_resolution, output_path,
                )
                runs.append(
                    {
                        **sidecar,
                        "network_seconds": network_seconds,
                        "mlu_geometry_seconds": geometry_seconds,
                        "scene_shape": record["scene_shape"],
                        "direct_shape": record["direct_shape"],
                        "scene_device": record["scene_device"],
                        "mesh_device": record["mesh_device"],
                        "scene_finite": bool(torch.isfinite(scene_codes).all().cpu()),
                        "input": record["input"],
                        "started_unix": started_unix,
                        "ended_unix": time(),
                    }
                )
                runs[-1]["full_iteration_seconds"] = perf_counter() - iteration_started
                continue

            current_sidecar = _start_pipelined_cpu_mesh_sidecar(
                executor, model, meshes[0], scene_codes, global_dict,
                bake_resolution, output_path,
            )
            current_sidecar["record"] = record
            if pending_sidecar is not None:
                append_completed_sidecar(pending_sidecar)
            pending_sidecar = current_sidecar

        if dual_worker_sidecar:
            while pending_dual_sidecars:
                _finish_oldest_dual_sidecar(
                    pending_dual_sidecars, append_completed_dual_sidecar
                )
        elif pending_sidecar is not None:
            append_completed_sidecar(pending_sidecar)
        if executor is not None:
            executor.shutdown(wait=True)
    finally:
        if dual_executor is not None:
            active_exception = sys.exc_info()[0] is not None
            for pending in pending_dual_sidecars:
                try:
                    pending["future"].cancel()
                except BaseException:
                    if not active_exception:
                        raise
            try:
                dual_executor.shutdown(wait=True, cancel_futures=True)
            except TypeError:  # Python < 3.9 lacks cancel_futures.
                dual_executor.shutdown(wait=True)
            except BaseException:
                if not active_exception:
                    raise

    artifact_shas = [sha256_path(run["artifact"]) for run in runs]
    semantic_shas = [run["semantic_sha256"] for run in runs]
    texture_arrays = [run.pop("_texture_array") for run in runs]
    if len(texture_arrays) > 1:
        texture_delta = np.abs(
            texture_arrays[0].astype(np.int16) - texture_arrays[1].astype(np.int16)
        )
        texture_repeat_mae = float(texture_delta.mean())
        texture_repeat_max = int(texture_delta.max())
    else:
        texture_repeat_mae = 0.0
        texture_repeat_max = 0
    texture_within_tolerance = (
        texture_repeat_mae <= float(config.get("texture_repeat_mae", 1.0))
        and texture_repeat_max <= int(config.get("texture_repeat_max", 8))
    )
    deterministic = _repeat_determinism(
        [run["input"] for run in runs],
        scene_shas,
        mesh_vertex_shas,
        semantic_shas,
        texture_within_tolerance,
        benchmark_mode,
    )
    summary_path = output_dir / "summary.json"
    serializable_runs = [
        {
            **run,
            "artifact": str(run["artifact"]),
            "texture_artifact": str(run["texture_artifact"]),
            "sha256": artifact_shas[index],
        }
        for index, run in enumerate(runs)
    ]
    summary = {
        "inputs": [str(path) for path in input_paths],
        "input_sha256": [sha256_path(path) for path in input_paths],
        "repeat_count": repeat_count,
        "pipeline_cpu_sidecar": pipeline_cpu_sidecar,
        "cpu_sidecar_workers": cpu_sidecar_workers,
        "deterministic": deterministic,
        "artifact_binary_identical": len(set(artifact_shas)) == 1,
        "texture_repeat_mae_8bit": texture_repeat_mae,
        "texture_repeat_max_8bit": texture_repeat_max,
        "texture_within_tolerance": texture_within_tolerance,
        "scene_sha256": scene_shas,
        "mesh_vertex_sha256": mesh_vertex_shas,
        "runs": serializable_runs,
    }
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    checks = {
        "finite_tensors": all(run["scene_finite"] for run in runs),
        "main_forward_device": all(
            "mlu" in run["scene_device"] and "mlu" in run["mesh_device"]
            for run in runs
        ),
        "valid_artifact": all(
            run["vertices"] > 0 and run["faces"] > 0 and run["artifact"].stat().st_size > 0
            for run in runs
        ),
        "cpu_sidecar_explicit": True,
        "deterministic_repeat": deterministic,
    }
    if benchmark_mode:
        checks["benchmark_measurement_count"] = measure_steps == len(runs[warmup_steps:])
        checks["benchmark_multiple_inputs"] = len(input_paths) > 1
    if not _checks_pass(checks):
        raise RuntimeError(f"SF3D inference checks failed: {checks}")
    measured_runs = runs[warmup_steps:] if benchmark_mode else runs
    sample_seconds = [
        run["network_seconds"]
        + run["mlu_geometry_seconds"]
        + run["cpu_sidecar_seconds"]
        for run in measured_runs
    ]
    metrics = {
        "model_load_seconds": load_seconds,
        "pipeline_cpu_sidecar": pipeline_cpu_sidecar,
        "cpu_sidecar_workers": cpu_sidecar_workers,
        "warmup_steps": warmup_steps,
        "measure_steps": len(measured_runs),
        "network_seconds": [run["network_seconds"] for run in measured_runs],
        "mlu_geometry_seconds": [run["mlu_geometry_seconds"] for run in measured_runs],
        "cpu_sidecar_seconds": [run["cpu_sidecar_seconds"] for run in measured_runs],
        "sample_seconds_median": statistics.median(sample_seconds),
        "sample_seconds_min": min(sample_seconds),
        "sample_seconds_max": max(sample_seconds),
        "samples_per_second": 1.0 / statistics.median(sample_seconds),
        "stage_sum_samples_per_second": 1.0 / statistics.median(sample_seconds),
        "vertices": runs[0]["vertices"],
        "faces": runs[0]["faces"],
        "sampled_texture_pixels": runs[0]["sampled_texture_pixels"],
        "peak_cpu_rss_bytes": int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024),
        "mlu_memory": memory_stats(),
        "mlu_utilization": None,
    }
    artifacts = [
        {"path": str(run["artifact"]), "sha256": artifact_shas[index]}
        for index, run in enumerate(runs)
    ]
    artifacts.extend(
        {
            "path": str(run["texture_artifact"]),
            "sha256": sha256_path(run["texture_artifact"]),
        }
        for run in runs
    )
    artifacts.append({"path": str(summary_path), "sha256": sha256_path(summary_path)})
    with step_log.open("w", encoding="utf-8") as handle:
        for index, run in enumerate(runs):
            handle.write(
                json.dumps(
                    {
                        "step": index + 1,
                        "started_unix": run["started_unix"],
                        "ended_unix": run["ended_unix"],
                        "input": run["input"],
                        "network_seconds": run["network_seconds"],
                        "mlu_geometry_seconds": run["mlu_geometry_seconds"],
                        "cpu_sidecar_seconds": run["cpu_sidecar_seconds"],
                        "sidecar_profile": run["sidecar_profile"],
                        "full_iteration_seconds": run["full_iteration_seconds"],
                        "sample_seconds": sample_seconds[index - warmup_steps]
                        if index >= warmup_steps
                        else None,
                    },
                    sort_keys=True,
                )
                + "\n"
            )
    result = {
        "artifact": runs[0]["artifact"],
        "artifacts": artifacts,
        "logs": [{"path": str(step_log), "sha256": sha256_path(step_log)}],
        "metrics": metrics,
        "stage_timings": {
            "model_load_seconds": load_seconds,
            "network_seconds_median": statistics.median(
                run["network_seconds"] for run in measured_runs
            ),
            "mlu_geometry_seconds_median": statistics.median(
                run["mlu_geometry_seconds"] for run in measured_runs
            ),
            "cpu_uv_bake_export_seconds_median": statistics.median(
                run["cpu_sidecar_seconds"] for run in measured_runs
            ),
        },
        "checks": checks,
    }
    measurement_seconds = perf_counter() - measurement_started
    metrics.update({
        "timing_scope_version": 2,
        "measurement_seconds": measurement_seconds,
        "measurement_samples": len(measured_runs),
        "samples_per_second": len(measured_runs) / measurement_seconds,
        "initialization_seconds": initialization_seconds,
        "run_total_seconds": perf_counter() - run_started,
        "measurement_scope": (
            "first measured iteration through all output hashes and step-log close; "
            "includes warmup-artifact finalization; excludes caller manifest write"
        ),
        "sidecar_scope": "CPU post-processing with an MLU texture decoder",
        "sidecar_pipeline": (
            "two CPU UV-only workers overlap preparation with the next sample "
            "MLU network stage" if dual_worker_sidecar else
            "one CPU preparation worker overlaps UV preparation with the next "
            "sample MLU network stage" if pipeline_cpu_sidecar else "disabled"
        ),
        "legacy_timing_fields": {
            "cpu_sidecar_seconds": "mixed CPU/MLU sidecar wall time, not CPU-only",
            "cpu_uv_bake_export_seconds_median": "mixed sidecar median retained for compatibility",
            "sample_seconds_median": "sum of selected stages; excludes evidence and gaps",
        },
    })
    per_sample_latency_sum = sum(
        run["full_iteration_seconds"] for run in measured_runs
    )
    result["stage_timings"].update({
        "measurement_seconds": measurement_seconds,
        "initialization_seconds": initialization_seconds,
        "measured_iterations_seconds": per_sample_latency_sum,
        "per_sample_latency_sum_seconds": per_sample_latency_sum,
        "unattributed_and_finalization_seconds": max(
            0.0, measurement_seconds - per_sample_latency_sum
        ),
        "pipeline_overlap_seconds": max(
            0.0, per_sample_latency_sum - measurement_seconds
        ),
        "mixed_sidecar_seconds_median": statistics.median(
            run["sidecar_profile"]["wall_seconds"] for run in measured_runs
        ),
    })
    if benchmark_mode and config.get("validate_recovery", False) is False:
        if measurement_started is None:
            raise RuntimeError("SF3D benchmark measurement window was not started")
        result["measurement_window"] = {
            "start_monotonic": measurement_started,
            "work_units": len(measured_runs),
            "unit": "reconstructions",
        }
    return result
