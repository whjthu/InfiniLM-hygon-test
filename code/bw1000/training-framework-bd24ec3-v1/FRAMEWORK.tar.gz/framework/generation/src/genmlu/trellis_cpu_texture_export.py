"""Bounded CPU UV/PBR export of verified TRELLIS decoded fields.

Sparse sampling follows FlexGEMM 6dd94a859c26ee8246888502eada3dd8ad85532e,
kernels/cuda/grid_sample/grid_sample.cu. Copyright (c) 2025 Jianfeng Xiang.
This is not a deployed CUDA parity claim.

The following MIT notice applies to the FlexGEMM-derived sampler:
Copyright (c) 2025 Jianfeng Xiang (belljig@outlook.com)
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import platform
import struct
import sys
import tempfile
from time import perf_counter
from typing import Any
import zipfile

import numpy as np


REFERENCE = "6dd94a859c26ee8246888502eada3dd8ad85532e"
SF3D_REFERENCE = "ff21fc491b4dc5314bf6734c7c0dabd86b5f5bb2"
TRELLIS_REFERENCE = "75fbf0183001ed9876c8dbb35de6b68552ee08bd"
PREFIX = "GENMLU_TRELLIS_CPU_TEXTURE_RESULT="
SCHEMA = "genmlu-trellis-cpu-texture-v1"
UV_IMPLEMENTATIONS = {
    "native": {
        "version": SF3D_REFERENCE,
        "implementation": "uv_unwrapper.Unwrapper",
        "official_unwrap": True,
        "seams": "selected by the pinned native unwrapper",
        "texel_density": "selected by the pinned native unwrapper",
        "distortion": "selected by the pinned native unwrapper",
    },
    "face_tiles": {
        "version": "face-tiles-v1",
        "implementation": "genmlu bounded per-face tile grid",
        "official_unwrap": False,
        "seams": "every triangle edge is a seam",
        "texel_density": "fixed atlas area per face; not uniform in world space",
        "distortion": "every face maps to the same right-triangle tile shape",
    },
}
POLICY = {
    "grid_size": 512, "origin": [-0.5, -0.5, -0.5], "voxel_size": 1 / 512,
    "channels": ["red", "green", "blue", "metallic", "roughness", "alpha"],
    "alpha_mode": "OPAQUE", "axes": "x,z,-y", "topology": "unchanged-triangle-corners",
    "uv_input_connectivity": "independent-triangle-corners",
    "normals": "flat-face-winding", "watertight_claimed": False,
    "sampler_reference": REFERENCE, "cuda_parity_claimed": False,
    "uv_reference": SF3D_REFERENCE, "image_encoding": "PNG",
    "color_space": "baseColor-sRGB/data-linear/no-added-gamma",
    "raster_convention": "u=column/size,v=1-row/size",
    "uv_layout_default": "native", "uv_implementations": UV_IMPLEMENTATIONS,
}
DEFAULTS = {
    "texture_size": 1024, "padding_pixels": 4, "island_padding": 0.02,
    "uv_layout": "native",
    "max_points": 1_000_000, "max_faces": 1_000_000,
    "max_bytes": 2_147_483_648, "max_raster_work": 50_000_000,
    "chunk_size": 65536, "threads": 4, "timeout_seconds": 1800,
}


def require(value: Any, message: str) -> None:
    if not value:
        raise ValueError(message)


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def json_sha(value: Any) -> str:
    return hashlib.sha256(canonical(value)).hexdigest()


def is_sha(value: Any) -> bool:
    return type(value) is str and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def settings(value: Any) -> dict[str, Any]:
    require(type(value) is dict, "cpu_texture_export must be an explicit mapping")
    require(set(value) <= {*DEFAULTS, "dependencies"}, "unknown CPU texture setting")
    result = {**DEFAULTS, **value}
    bounds = {
        "texture_size": (32, 4096), "padding_pixels": (0, 32),
        "max_points": (1, 4_000_000), "max_faces": (1, 4_000_000),
        "max_bytes": (1_048_576, 8_589_934_592), "max_raster_work": (1, 500_000_000),
        "chunk_size": (1, 262144), "threads": (1, 64), "timeout_seconds": (1, 14400),
    }
    for key, (low, high) in bounds.items():
        require(type(result[key]) is int and low <= result[key] <= high, f"invalid {key}")
    require(result["texture_size"] & (result["texture_size"] - 1) == 0, "texture_size must be a power of two")
    require(result["uv_layout"] in UV_IMPLEMENTATIONS, "uv_layout must be native or face_tiles")
    if result["uv_layout"] == "face_tiles":
        require(result["padding_pixels"] == 4, "face_tiles requires padding_pixels 4")
    padding = result["island_padding"]
    require(type(padding) in (float, int) and math.isfinite(padding) and 0 < padding < 0.25, "invalid island_padding")
    deps = result.get("dependencies")
    require(type(deps) is dict and set(deps) == {"root", "files", "versions"}, "explicit dependency identity required")
    require(type(deps["root"]) is str and bool(deps["root"]), "dependency root required")
    files = deps["files"]
    require(type(files) is dict and len(files) == 6, "exact six-file native dependency inventory required")
    for name, digest in files.items():
        require(type(name) is str and "\\" not in name, "dependency paths must be relative POSIX paths")
        parts = PurePosixPath(name).parts
        require(len(parts) == 2 and parts[0] in {"uv_unwrapper", "texture_baker"} and ".." not in parts, "dependency path escapes package")
        require(is_sha(digest), "invalid dependency SHA256")
    for package, module in (("uv_unwrapper", "unwrap"), ("texture_baker", "baker")):
        require(f"{package}/__init__.py" in files and f"{package}/{module}.py" in files, "dependency Python files missing")
        natives = [n for n in files if n.startswith(f"{package}/_C") and n.endswith((".so", ".pyd"))]
        require(len(natives) == 1, "one native extension per package required")
    versions = deps["versions"]
    require(type(versions) is dict and set(versions) == {"python", "torch", "numpy", "Pillow"}, "explicit runtime versions required")
    require(all(type(v) is str and bool(v) for v in versions.values()), "invalid runtime version")
    # Conservative working-array reservation; native allocation is also observed in the child.
    require(256 * result["texture_size"] ** 2 + 256 * result["chunk_size"] <= result["max_bytes"], "texture working set exceeds max_bytes")
    return result


def dependency_identity(config: dict[str, Any]) -> dict[str, Any]:
    expected = config["dependencies"]
    root = Path(expected["root"]).resolve(strict=True)
    actual = {}
    for package in ("uv_unwrapper", "texture_baker"):
        directory = root / package
        require(directory.is_dir() and not directory.is_symlink(), "native package directory missing or linked")
        for path in directory.rglob("*"):
            if path.is_file() and path.suffix in {".py", ".so", ".pyd"}:
                require(not path.is_symlink() and path.resolve().is_relative_to(directory), "dependency file escapes package")
                actual[path.relative_to(root).as_posix()] = sha(path)
    require(actual == expected["files"], "native dependency inventory/SHA mismatch")
    return {"root": str(root), "files": actual, "versions": expected["versions"], "source_reference": SF3D_REFERENCE}


def atomic_bytes(path: Path, data: bytes) -> None:
    require(not path.exists(), f"refusing existing output: {path.name}")
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def load_npz(path: Path, max_bytes: int, keys: set[str], *, max_dimensions: int = 3) -> dict[str, np.ndarray]:
    require(type(max_dimensions) is int and 1 <= max_dimensions <= 5, "invalid NPY dimension bound")
    require(path.stat().st_size <= max_bytes, "NPZ exceeds byte budget")
    with zipfile.ZipFile(path) as archive:
        info = archive.infolist()
        require(len(info) == len(keys) and {x.filename for x in info} == {k + ".npy" for k in keys}, "NPZ members differ")
        require(sum(x.file_size for x in info) <= max_bytes, "expanded NPZ exceeds byte budget")
        for member in info:
            with archive.open(member) as handle:
                version = np.lib.format.read_magic(handle)
                require(version in {(1, 0), (2, 0)}, "unsupported NPY header")
                reader = np.lib.format.read_array_header_1_0 if version == (1, 0) else np.lib.format.read_array_header_2_0
                shape, _, dtype = reader(handle)
                require(not dtype.hasobject and len(shape) <= max_dimensions, "invalid NPY dtype/dimensions")
                require(math.prod(shape) * dtype.itemsize == member.file_size - handle.tell(), "NPY declared allocation differs from data size")
    with np.load(path, allow_pickle=False) as values:
        return {k: values[k] for k in keys}


def load_fields(path: Path, expected_sha: str, config: dict[str, Any]) -> dict[str, np.ndarray]:
    require(is_sha(expected_sha) and sha(path) == expected_sha, "decoded fields SHA mismatch")
    a = load_npz(path, config["max_bytes"], {"coords", "shape_fields", "material_attrs", "vertices", "faces"})
    c, v, f = a["coords"], a["vertices"], a["faces"]
    require(c.dtype.kind in "iu" and c.ndim == 2 and c.shape[1] == 4 and 0 < len(c) <= config["max_points"], "invalid sparse coordinates")
    require(np.all(c[:, 0] == 0) and np.all((c[:, 1:] >= 0) & (c[:, 1:] < 512)), "coordinates outside single-batch 512 grid")
    require(len(np.unique(c, axis=0)) == len(c), "duplicate sparse coordinates")
    require(v.ndim == 2 and v.shape[1] == 3 and 0 < len(v) <= config["max_points"], "invalid vertices")
    require(f.dtype.kind in "iu" and f.ndim == 2 and f.shape[1] == 3 and 0 < len(f) <= config["max_faces"], "invalid faces")
    require(f.min() >= 0 and f.max() < len(v), "face index out of bounds")
    require(a["shape_fields"].shape == (len(c), 7) and a["material_attrs"].shape == (len(c), 6), "field layout mismatch")
    for name in ("vertices", "shape_fields", "material_attrs"):
        require(a[name].dtype == np.float32 and np.isfinite(a[name]).all(), f"{name} must be finite float32")
    if config["uv_layout"] == "face_tiles":
        face_tile_geometry(len(f), config["texture_size"], config["padding_pixels"])
    require(256 * config["texture_size"] ** 2 + 512 * len(f) + 256 * len(c) + sum(x.nbytes for x in a.values()) <= config["max_bytes"], "geometry/texture working set exceeds max_bytes")
    return a


class SparseSampler:
    """Single-batch sparse FP32 forward, with the pinned kernel's corner order."""

    def __init__(self, coords: np.ndarray, attrs: np.ndarray, resolution: int = 512):
        require(coords.ndim == 2 and coords.shape[1] == 4 and coords.dtype.kind in "iu", "invalid sampler coordinates")
        require(attrs.shape == (len(coords), 6) and attrs.dtype == np.float32 and np.isfinite(attrs).all(), "invalid sampler attributes")
        require(len(coords) > 0 and np.all(coords[:, 0] == 0) and np.all((coords[:, 1:] >= 0) & (coords[:, 1:] < resolution)), "invalid sampler grid")
        c = coords[:, 1:].astype(np.int64)
        keys = (c[:, 0] * resolution + c[:, 1]) * resolution + c[:, 2]
        order = np.argsort(keys)
        self.keys, self.attrs = keys[order], attrs[order]
        require(np.all(np.diff(self.keys) > 0), "duplicate sampler coordinates")
        self.resolution = resolution

    def sample(self, queries: np.ndarray, chunk_size: int) -> np.ndarray:
        q = np.asarray(queries, dtype=np.float32)
        require(q.ndim == 2 and q.shape[1] == 3 and np.isfinite(q).all(), "invalid material queries")
        require(type(chunk_size) is int and chunk_size > 0, "invalid sampler chunk size")
        require(np.all(np.abs(q) < 2**30), "material query outside numeric range")
        result = np.empty((len(q), 6), np.float32)
        for start in range(0, len(q), chunk_size):
            part = q[start:start + chunk_size]
            base = np.floor(part - np.float32(0.5)).astype(np.int64)
            indices, weights = [], []
            total = np.zeros(len(part), np.float32)
            for i in range(8):
                xyz = base + np.array([i & 1, (i >> 1) & 1, (i >> 2) & 1])
                inside = np.all((xyz >= 0) & (xyz < self.resolution), axis=1)
                key = (xyz[:, 0] * self.resolution + xyz[:, 1]) * self.resolution + xyz[:, 2]
                idx = np.searchsorted(self.keys, key).clip(0, len(self.keys) - 1)
                valid = inside & (self.keys[idx] == key)
                delta = np.float32(1) - np.abs(part - xyz.astype(np.float32) - np.float32(0.5))
                weight = np.where(valid, (delta[:, 0] * delta[:, 1]) * delta[:, 2], np.float32(0))
                indices.append(idx)
                weights.append(weight)
                total += weight
            require(np.all(total > 0), "surface texel has no supported material neighborhood")
            output = np.zeros((len(part), 6), np.float32)
            for idx, weight in zip(indices, weights):
                output += self.attrs[idx] * (weight / np.maximum(total, np.float32(1e-12)))[:, None]
            require(np.isfinite(output).all(), "nonfinite material sample")
            result[start:start + len(part)] = output
        return result


def corner_geometry(vertices: np.ndarray, faces: np.ndarray) -> tuple[np.ndarray, np.ndarray, dict[str, int]]:
    """Keep ordered surface triangles, isolating their indices before native UV."""
    require(vertices.dtype == np.float32 and vertices.ndim == 2 and vertices.shape[1] == 3 and np.isfinite(vertices).all(), "invalid geometry vertices")
    require(faces.dtype.kind in "iu" and faces.ndim == 2 and faces.shape[1] == 3 and len(faces) > 0, "invalid geometry faces")
    require(faces.min() >= 0 and faces.max() < len(vertices), "face index out of bounds")
    faces = faces.astype(np.int64)
    world = np.ascontiguousarray(vertices[faces].reshape(-1, 3))
    corners = world.reshape(-1, 3, 3).astype(np.float64)
    cross = np.cross(corners[:, 1] - corners[:, 0], corners[:, 2] - corners[:, 0])
    lengths = np.linalg.norm(cross, axis=1)
    require(np.isfinite(lengths).all() and np.all(lengths > 1e-15), "degenerate geometry triangle")
    normal = np.repeat((cross / lengths[:, None]).astype(np.float32), 3, axis=0)
    # Diagnose original connectivity; do not reject or weld its nonmanifold edges.
    edges = np.sort(np.concatenate([faces[:, [0, 1]], faces[:, [1, 2]], faces[:, [2, 0]]]), axis=1)
    counts = np.unique(edges, axis=0, return_counts=True)[1]
    referenced = len(np.unique(faces))
    original = {
        "vertices": len(vertices), "faces": len(faces),
        "referenced_vertices": referenced, "unreferenced_vertices": len(vertices) - referenced,
        "boundary_edges": int(np.count_nonzero(counts == 1)),
        "nonmanifold_edges": int(np.count_nonzero(counts > 2)),
        "maximum_edge_incidence": int(counts.max()), "degenerate_faces": 0,
    }
    return world, normal, original


def rotate(value: np.ndarray) -> np.ndarray:
    return np.ascontiguousarray(value[:, [0, 2, 1]] * np.array([1, 1, -1], np.float32), dtype=np.float32)


def validate_uv(uv: np.ndarray, face_count: int) -> None:
    require(uv.dtype == np.float32 and uv.shape == (face_count * 3, 2) and np.isfinite(uv).all(), "invalid UV corner layout")
    require(np.all((uv >= 0) & (uv <= 1)), "UV outside atlas")
    tri = uv.reshape(-1, 3, 2).astype(np.float64)
    ab, ac = tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0]
    require(np.all(np.abs(ab[:, 0] * ac[:, 1] - ab[:, 1] * ac[:, 0]) > 1e-12), "degenerate UV triangle")


def face_tile_geometry(face_count: int, size: int, padding_pixels: int) -> dict[str, int]:
    require(type(face_count) is int and face_count > 0, "face tile layout requires faces")
    require(type(size) is int and size > 0, "face tile layout requires a positive texture size")
    require(type(padding_pixels) is int and padding_pixels == 4,
            "face_tiles requires padding_pixels 4")
    grid = math.isqrt(face_count - 1) + 1
    pitch = size // grid
    margin = (size - grid * pitch) // 2
    inset = padding_pixels + 1
    require(pitch >= 2 * inset + 4, "texture_size is insufficient for face_tiles")
    return {"grid": grid, "pitch": pitch, "margin": margin, "inset": inset,
            "side": pitch - 2 * inset}


def face_tile_uv(face_count: int, size: int, padding_pixels: int) -> np.ndarray:
    layout = face_tile_geometry(face_count, size, padding_pixels)
    indices = np.arange(face_count, dtype=np.int64)
    left = layout["margin"] + (indices % layout["grid"]) * layout["pitch"] + layout["inset"]
    top = layout["margin"] + (indices // layout["grid"]) * layout["pitch"] + layout["inset"]
    right, bottom = left + layout["side"], top + layout["side"]
    uv = np.empty((face_count, 3, 2), dtype=np.float32)
    uv[:, 0] = np.stack((left, size - top), axis=1) / np.float32(size)
    uv[:, 1] = np.stack((right, size - top), axis=1) / np.float32(size)
    uv[:, 2] = np.stack((left, size - bottom), axis=1) / np.float32(size)
    return np.ascontiguousarray(uv.reshape(-1, 2))


def selected_uv_implementation(config: dict[str, Any], face_count: int) -> dict[str, Any]:
    result = {"layout": config["uv_layout"], **UV_IMPLEMENTATIONS[config["uv_layout"]]}
    if config["uv_layout"] == "face_tiles":
        result.update(face_tile_geometry(face_count, config["texture_size"], config["padding_pixels"]))
    return result


def interior_coverage(uv: np.ndarray, size: int, max_work: int) -> np.ndarray:
    """Independent bounded atlas check; shared triangle edges are excluded."""
    owner = np.full(size * size, -1, np.int32)
    work = 0
    for face, tri in enumerate(uv.reshape(-1, 3, 2).astype(np.float64)):
        low = np.maximum(np.floor(tri.min(0) * size).astype(int), 0)
        high = np.minimum(np.ceil(tri.max(0) * size).astype(int), size)
        count = (high[0] - low[0] + 1) * (high[1] - low[1] + 1)
        work += int(count)
        require(work <= max_work, "atlas validation exceeds max_raster_work")
        ab, ac = tri[1] - tri[0], tri[2] - tri[0]
        det = ab[0] * ac[1] - ab[1] * ac[0]
        columns = np.arange(low[0], min(high[0], size - 1) + 1)
        for row in range(max(0, size - high[1]), min(size, size - low[1] + 1)):
            p = np.stack((columns / size, np.full(len(columns), 1 - row / size)), axis=1) - tri[0]
            b = (p[:, 0] * ac[1] - p[:, 1] * ac[0]) / det
            c = (ab[0] * p[:, 1] - ab[1] * p[:, 0]) / det
            inside = (b > 2e-5) & (c > 2e-5) & (b + c < 1 - 2e-5)
            pixels = row * size + columns[inside]
            require(np.all(owner[pixels] < 0), "overlapping UV interiors")
            owner[pixels] = face
    counts = np.bincount(owner[owner >= 0], minlength=len(uv) // 3)
    require(len(counts) == len(uv) // 3 and np.all(counts > 0), "atlas lacks interior coverage for every face")
    return owner


def validate_layout_uv(uv: np.ndarray, face_count: int, config: dict[str, Any]) -> np.ndarray:
    validate_uv(uv, face_count)
    if config["uv_layout"] == "face_tiles":
        require(np.array_equal(uv, face_tile_uv(face_count, config["texture_size"],
                                                config["padding_pixels"])),
                "face_tiles UV layout differs")
    return interior_coverage(uv, config["texture_size"], config["max_raster_work"])


def correspondence(uv: np.ndarray, world: np.ndarray, evidence: dict[str, np.ndarray], config: dict[str, Any]) -> tuple[np.ndarray, np.ndarray]:
    size = config["texture_size"]
    pixels, face_ids, bary = (evidence[k] for k in ("pixels", "face_ids", "barycentric"))
    require(pixels.dtype == np.int64 and pixels.ndim == 1 and 0 < len(pixels) <= size * size, "invalid covered pixels")
    require(pixels.min() >= 0 and pixels.max() < size * size and np.all(np.diff(pixels) > 0), "covered pixels not ordered/unique")
    require(face_ids.dtype == np.int64 and face_ids.shape == pixels.shape and face_ids.min() >= 0 and face_ids.max() < len(world) // 3, "invalid raster face IDs")
    require(bary.dtype == np.float32 and bary.shape == (len(pixels), 3) and np.isfinite(bary).all(), "invalid barycentrics")
    require(np.all(bary >= -2e-6) and np.allclose(bary.sum(1), 1, rtol=0, atol=2e-6), "barycentrics outside triangle")
    expected = np.stack(((pixels % size) / size, 1 - (pixels // size) / size), axis=1)
    actual = (uv.reshape(-1, 3, 2)[face_ids] * bary[:, :, None]).sum(1)
    require(np.allclose(actual, expected, rtol=0, atol=2e-5), "UV/raster pixel correspondence differs")
    owner = interior_coverage(uv, size, config["max_raster_work"])
    mask = np.zeros(size * size, bool)
    mask[pixels] = True
    require(np.all(mask[owner >= 0]), "raster omits atlas interior")
    require(np.all((owner[pixels] < 0) | (owner[pixels] == face_ids)), "raster triangle ownership differs")
    positions = (world.reshape(-1, 3, 3)[face_ids] * bary[:, :, None]).sum(1)
    return positions, mask.reshape(size, size)


def pad_texture(pixels: np.ndarray, mask: np.ndarray, width: int) -> np.ndarray:
    result, filled = pixels.copy(), mask.copy()
    # Deterministic nearest frontier, without wrapping or modifying covered texels.
    for _ in range(width):
        previous, previous_mask = result.copy(), filled.copy()
        for dy, dx in ((-1, 0), (0, -1), (0, 1), (1, 0)):
            dst_y, src_y = (slice(1, None), slice(None, -1)) if dy == -1 else ((slice(None, -1), slice(1, None)) if dy == 1 else (slice(None), slice(None)))
            dst_x, src_x = (slice(1, None), slice(None, -1)) if dx == -1 else ((slice(None, -1), slice(1, None)) if dx == 1 else (slice(None), slice(None)))
            take = ~filled[dst_y, dst_x] & previous_mask[src_y, src_x]
            result[dst_y, dst_x][take] = previous[src_y, src_x][take]
            filled[dst_y, dst_x][take] = True
    return result


def textures(a: dict[str, np.ndarray], positions: np.ndarray, evidence: dict[str, np.ndarray], mask: np.ndarray, config: dict[str, Any]) -> tuple[np.ndarray, np.ndarray]:
    sampled = SparseSampler(a["coords"], a["material_attrs"]).sample((positions + np.float32(0.5)) * np.float32(512), config["chunk_size"])
    encoded = (np.clip(sampled, 0, 1) * np.float32(255)).astype(np.uint8)
    size = config["texture_size"]
    rgba, mr = np.zeros((size * size, 4), np.uint8), np.zeros((size * size, 3), np.uint8)
    rgba[evidence["pixels"]] = encoded[:, [0, 1, 2, 5]]
    mr[evidence["pixels"], 1] = encoded[:, 4]
    mr[evidence["pixels"], 2] = encoded[:, 3]
    return tuple(pad_texture(x.reshape(size, size, -1), mask, config["padding_pixels"]) for x in (rgba, mr))


def png_bytes(value: np.ndarray) -> bytes:
    from PIL import Image
    stream = io.BytesIO()
    Image.fromarray(value).save(stream, format="PNG")
    return stream.getvalue()


def glb_document(arrays: list[np.ndarray], images: list[bytes]) -> tuple[dict[str, Any], bytes]:
    blob = bytearray()
    views, accessors = [], []
    for i, data in enumerate([a.tobytes() for a in arrays] + images):
        blob.extend(b"\0" * (-len(blob) % 4))
        views.append({"buffer": 0, "byteOffset": len(blob), "byteLength": len(data)})
        blob.extend(data)
        if i < 4:
            array = arrays[i]
            accessor = {"bufferView": i, "componentType": 5125 if i == 3 else 5126, "count": len(array), "type": ("VEC3", "VEC3", "VEC2", "SCALAR")[i]}
            if i == 0:
                accessor.update(min=array.min(0).tolist(), max=array.max(0).tolist())
            accessors.append(accessor)
    length = len(blob)
    blob.extend(b"\0" * (-length % 4))
    doc = {
        "asset": {"version": "2.0", "generator": SCHEMA}, "scene": 0,
        "scenes": [{"nodes": [0]}], "nodes": [{"mesh": 0}],
        "meshes": [{"primitives": [{"attributes": {"POSITION": 0, "NORMAL": 1, "TEXCOORD_0": 2}, "indices": 3, "material": 0, "mode": 4}]}],
        "buffers": [{"byteLength": length}], "bufferViews": views, "accessors": accessors,
        "images": [{"bufferView": i, "mimeType": "image/png"} for i in (4, 5)],
        "samplers": [{"magFilter": 9729, "minFilter": 9729, "wrapS": 33071, "wrapT": 33071}],
        "textures": [{"source": i, "sampler": 0} for i in (0, 1)],
        "materials": [{"alphaMode": "OPAQUE", "doubleSided": True, "pbrMetallicRoughness": {
            "baseColorFactor": [1, 1, 1, 1], "metallicFactor": 1, "roughnessFactor": 1,
            "baseColorTexture": {"index": 0, "texCoord": 0}, "metallicRoughnessTexture": {"index": 1, "texCoord": 0},
        }}],
    }
    return doc, bytes(blob)


def encode_glb(world: np.ndarray, normal: np.ndarray, uv: np.ndarray, images: tuple[np.ndarray, np.ndarray]) -> bytes:
    texcoord = uv.copy()
    texcoord[:, 1] = 1 - texcoord[:, 1]
    arrays = [rotate(world).astype("<f4"), rotate(normal).astype("<f4"), texcoord.astype("<f4"), np.arange(len(world), dtype="<u4")]
    doc, blob = glb_document(arrays, [png_bytes(x) for x in images])
    metadata = canonical(doc)
    metadata += b" " * (-len(metadata) % 4)
    return struct.pack("<III", 0x46546C67, 2, 28 + len(metadata) + len(blob)) + struct.pack("<I4s", len(metadata), b"JSON") + metadata + struct.pack("<I4s", len(blob), b"BIN\0") + blob


def read_glb(path: Path, config: dict[str, Any]) -> tuple[list[np.ndarray], list[np.ndarray]]:
    from PIL import Image
    require(path.stat().st_size <= config["max_bytes"], "GLB exceeds byte budget")
    data = path.read_bytes()
    require(len(data) >= 28, "truncated GLB")
    require(struct.unpack_from("<III", data) == (0x46546C67, 2, len(data)), "invalid GLB header")
    length, kind = struct.unpack_from("<I4s", data, 12)
    require(kind == b"JSON" and length % 4 == 0 and 20 + length + 8 <= len(data), "invalid GLB JSON chunk")
    doc = json.loads(data[20:20 + length])
    offset = 20 + length
    binary_length, kind = struct.unpack_from("<I4s", data, offset)
    require(kind == b"BIN\0" and offset + 8 + binary_length == len(data), "invalid GLB binary chunk")
    blob = data[offset + 8:]
    require(type(doc) is dict and len(doc.get("bufferViews", [])) == 6 and len(doc.get("accessors", [])) == 4, "unsupported GLB layout")
    pieces = []
    for view in doc["bufferViews"]:
        start, count = view.get("byteOffset"), view.get("byteLength")
        require(type(start) is int and type(count) is int and start >= 0 and count > 0 and start + count <= len(blob), "GLB view bounds invalid")
        pieces.append(blob[start:start + count])
    arrays = []
    for i, width in enumerate((3, 3, 2, 1)):
        count = doc["accessors"][i].get("count")
        require(type(count) is int and 0 < count <= 3 * config["max_faces"] and len(pieces[i]) == count * width * 4, "GLB accessor size invalid")
        a = np.frombuffer(pieces[i], dtype="<u4" if i == 3 else "<f4").copy()
        arrays.append(a if i == 3 else a.reshape(-1, width))
    require(len(arrays[0]) % 3 == 0 and all(len(a) == len(arrays[0]) for a in arrays), "GLB attribute counts differ")
    require(np.array_equal(arrays[3], np.arange(len(arrays[0]), dtype=np.uint32)), "GLB topology differs")
    require(all(np.isfinite(a).all() for a in arrays[:3]), "nonfinite GLB attributes")
    expected_doc, expected_blob = glb_document(arrays, pieces[4:])
    require(doc == expected_doc and blob == expected_blob, "GLB schema/material/buffer layout differs")
    images = []
    for raw, mode in zip(pieces[4:], ("RGBA", "RGB")):
        with Image.open(io.BytesIO(raw)) as image:
            require(image.format == "PNG" and image.mode == mode and image.size == (config["texture_size"],) * 2, "invalid embedded PNG")
            images.append(np.asarray(image).copy())
    return arrays, images


def native_pipeline(a: dict[str, np.ndarray], config: dict[str, Any], torch: Any, unwrapper: Any, baker: Any) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    world, n, _ = corner_geometry(a["vertices"], a["faces"])
    f = np.arange(len(world), dtype=np.int64).reshape(-1, 3)
    tensor = lambda x: torch.from_numpy(np.array(x, copy=True, order="C")).to(device="cpu")
    if config["uv_layout"] == "native":
        uv, uv_faces = unwrapper(tensor(world), tensor(n), tensor(f), island_padding=config["island_padding"])
        require(uv.device.type == uv_faces.device.type == "cpu", "UV operation left CPU")
        uv_data, idx = uv.detach().numpy(), uv_faces.detach().numpy()
        require(idx.dtype.kind in "iu" and idx.shape == f.shape and idx.min() >= 0 and idx.max() < len(uv_data), "UV corner indices differ")
        corner_uv = np.array(uv_data[idx].reshape(-1, 2), dtype=np.float32, copy=True, order="C")
    else:
        corner_uv = face_tile_uv(len(f), config["texture_size"], config["padding_pixels"])
    validate_layout_uv(corner_uv, len(f), config)
    corner_faces = tensor(np.arange(3 * len(f), dtype=np.int32).reshape(-1, 3))
    rast = baker.rasterize(tensor(corner_uv), corner_faces, config["texture_size"])
    mask = baker.get_mask(rast)
    positions = baker.interpolate(tensor(world), rast, corner_faces)
    require(all(x.device.type == "cpu" for x in (rast, mask, positions)), "texture baker left CPU")
    r, m, pos = rast.detach().numpy(), mask.detach().numpy(), positions.detach().numpy()
    size = config["texture_size"]
    require(r.dtype == np.float32 and r.shape == (size, size, 4) and np.isfinite(r).all(), "invalid native raster")
    require(m.dtype == np.bool_ and np.array_equal(m, r[:, :, 3] >= 0), "native mask differs")
    ids = r[m, 3]
    require(np.all(ids == np.floor(ids)), "nonintegral native face IDs")
    evidence = {"pixels": np.flatnonzero(m).astype(np.int64), "face_ids": ids.astype(np.int64), "barycentric": np.ascontiguousarray(r[m, :3])}
    expected, _ = correspondence(corner_uv, world, evidence, config)
    require(pos.dtype == np.float32 and pos.shape == (size, size, 3) and np.isfinite(pos).all(), "invalid native position interpolation")
    require(np.allclose(pos[m], expected, rtol=0, atol=2e-6), "native interpolation lost original-world correspondence")
    return corner_uv, evidence


def load_native(config: dict[str, Any]) -> tuple[Any, Any, Any, dict[str, Any]]:
    require(os.environ.get("TORCH_DEVICE_BACKEND_AUTOLOAD") == "0", "CPU child requires disabled backend autoload")
    require(all(not os.environ.get(k) for k in ("MLU_VISIBLE_DEVICES", "CNRT_VISIBLE_DEVICES", "CUDA_VISIBLE_DEVICES")), "CPU child must hide accelerator devices")
    identity = dependency_identity(config)
    import torch
    import PIL
    actual = {"python": platform.python_version(), "torch": torch.__version__, "numpy": np.__version__, "Pillow": PIL.__version__}
    require(actual == identity["versions"], "CPU dependency runtime/ABI version mismatch")
    torch.set_num_threads(config["threads"])
    packages = ("uv_unwrapper", "texture_baker")
    require(not any(n.split(".")[0] in packages for n in sys.modules), "native packages already imported")
    sys.path.insert(0, identity["root"])
    uv = importlib.import_module("uv_unwrapper")
    baker = importlib.import_module("texture_baker")
    for name, module in list(sys.modules.items()):
        if name.split(".")[0] in packages:
            file = Path(getattr(module, "__file__", "")).resolve()
            require(file.is_relative_to(Path(identity["root"])), "foreign native module")
            require(file.relative_to(identity["root"]).as_posix() in identity["files"], "unverified native module")
    return torch, uv.Unwrapper(), baker.TextureBaker(), identity


def preflight(config: dict[str, Any]) -> tuple[Any, Any, Any, dict[str, Any]]:
    torch, uv, baker, identity = load_native(config)
    a = {"vertices": np.array([[0, 0, 0], [1.1, 0, 0], [0.1, 0.8, 0], [0.2, 0.3, 1.3]], np.float32), "faces": np.array([[0, 2, 1], [0, 1, 3], [1, 2, 3], [2, 0, 3]], np.int64)}
    preflight_size = 64
    if config["uv_layout"] == "face_tiles":
        # This sizes only the four-face dependency smoke. Export never enlarges its configured atlas.
        minimum = 4 * (config["padding_pixels"] + 3)
        while preflight_size < minimum:
            preflight_size *= 2
    native_pipeline(a, {**config, "texture_size": preflight_size}, torch, uv, baker)
    require(dependency_identity(config) == identity, "dependency changed during CPU preflight")
    return torch, uv, baker, identity


def decode_metadata(path: Path, digest: str, input_path: Path, input_sha: str) -> dict[str, Any]:
    require(is_sha(digest) and sha(path) == digest, "decode report SHA mismatch")
    report = json.loads(path.read_text(encoding="utf-8"))
    require(report["schema"] == "genmlu-trellis-cpu-decode-v1" and report["source_revision"] == TRELLIS_REFERENCE and report["source_clean"] is True, "unverified decoder source")
    require(Path(report["output"]["path"]).resolve() == input_path.resolve() and report["output"]["sha256"] == input_sha, "decoded artifact/report identity mismatch")
    require(report["runtime"]["device"] == "cpu", "decoder report is not CPU")
    for role in ("shape", "material"):
        require(report["decoders"][role]["requested_geometry_resolution"] == 512, "decode/export resolution mismatch")
    return report


def verify_product(glb: Path, mapping: Path, a: dict[str, np.ndarray], config: dict[str, Any]) -> dict[str, Any]:
    arrays, images = read_glb(glb, config)
    f = a["faces"].astype(np.int64)
    world, n, original = corner_geometry(a["vertices"], f)
    require(np.array_equal(arrays[0], rotate(world)) and np.array_equal(arrays[1], rotate(n)), "GLB geometry/normals differ from decoded geometry")
    uv = arrays[2].copy()
    uv[:, 1] = 1 - uv[:, 1]
    owner = validate_layout_uv(uv, len(f), config)
    interior_counts = np.bincount(owner[owner >= 0], minlength=len(f))
    evidence = load_npz(mapping, config["max_bytes"], {"pixels", "face_ids", "barycentric"})
    positions, mask = correspondence(uv, world, evidence, config)
    expected = textures(a, positions, evidence, mask, config)
    require(all(np.array_equal(x, y) for x, y in zip(images, expected)), "embedded textures differ from sparse material correspondence")
    return {"faces": len(f), "vertices": len(world), "original_geometry": original,
            "covered_texels": int(mask.sum()), "interior_covered_faces": int(np.count_nonzero(interior_counts)),
            "minimum_face_interior_texels": int(interior_counts.min()),
            "maximum_face_interior_texels": int(interior_counts.max()),
            "texture_size": config["texture_size"],
            "uv_implementation": selected_uv_implementation(config, len(f)),
            "image_sha256": [hashlib.sha256(x.tobytes()).hexdigest() for x in images]}


def peak_rss() -> int | None:
    if sys.platform == "linux":
        # ru_maxrss can retain the parent's pre-exec address-space peak.
        # VmHWM measures this executable's address space, including its imports.
        try:
            rows = [line.split() for line in Path("/proc/self/status").read_text(encoding="ascii").splitlines()
                    if line.startswith("VmHWM:")]
            if len(rows) != 1:
                return None
            row = rows[0]
            if len(row) != 3 or row[0] != "VmHWM:" or row[2] != "kB" or not row[1].isascii() or not row[1].isdecimal():
                return None
            value = int(row[1])
            return value * 1024 if value > 0 else None
        except (OSError, UnicodeError, ValueError):
            return None
    if sys.platform != "darwin":
        return None
    try:
        import resource
        value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        return value if type(value) is int and value > 0 else None
    except (ImportError, OSError):
        return None


def export(input_path: Path, input_sha: str, decode_report: Path, decode_sha: str, output: Path, config: dict[str, Any]) -> Path:
    started = perf_counter()
    decoded = decode_metadata(decode_report, decode_sha, input_path, input_sha)
    a = load_fields(input_path, input_sha, config)
    torch, uv, baker, identity = preflight(config)
    corner_uv, evidence = native_pipeline(a, config, torch, uv, baker)
    # Store exactly the UV precision that survives glTF's vertical convention conversion.
    corner_uv[:, 1] = 1 - (1 - corner_uv[:, 1])
    world, normal, _ = corner_geometry(a["vertices"], a["faces"])
    positions, mask = correspondence(corner_uv, world, evidence, config)
    images = textures(a, positions, evidence, mask, config)
    mapping = output.with_suffix(".correspondence.npz")
    stream = io.BytesIO()
    np.savez_compressed(stream, **evidence)
    atomic_bytes(mapping, stream.getvalue())
    atomic_bytes(output, encode_glb(world, normal, corner_uv, images))
    product = verify_product(output, mapping, a, config)
    require(sha(input_path) == input_sha and sha(decode_report) == decode_sha, "input changed during export")
    require(dependency_identity(config) == identity, "native dependency changed during export")
    rss = peak_rss()
    require(rss is not None and rss <= config["max_bytes"], "CPU peak RSS unavailable or exceeds max_bytes")
    report = {
        "schema": SCHEMA, "policy": POLICY, "config": config,
        "exporter_sha256": sha(Path(__file__)), "dependency_identity": identity,
        "input": {"path": str(input_path.resolve()), "sha256": input_sha},
        "decode_report": {"path": str(decode_report.resolve()), "sha256": decode_sha},
        "decoder_source": {"revision": decoded["source_revision"], "files": decoded["source_sha256"]},
        "output": {"path": str(output.resolve()), "sha256": sha(output)},
        "correspondence": {"path": str(mapping.resolve()), "sha256": sha(mapping)},
        "product": product,
        "runtime": {"device": "cpu", "native_preflight_executed": True, "peak_rss_bytes": rss, "seconds": perf_counter() - started},
    }
    report["payload_sha256"] = json_sha(report)
    report_path = output.with_suffix(".report.json")
    atomic_bytes(report_path, canonical(report) + b"\n")
    return report_path


def validate_export(report_path: Path, report_sha: str, config: dict[str, Any], output: Path, decoded_path: Path, *, decode_report_path: Path | None = None) -> dict[str, Any]:
    config = settings(config)
    require(is_sha(report_sha) and sha(report_path) == report_sha, "export report SHA mismatch")
    r = json.loads(report_path.read_text(encoding="utf-8"))
    require(set(r) == {"schema", "policy", "config", "exporter_sha256", "dependency_identity", "input", "decode_report", "decoder_source", "output", "correspondence", "product", "runtime", "payload_sha256"}, "export report fields differ")
    require(r["payload_sha256"] == json_sha({k: v for k, v in r.items() if k != "payload_sha256"}), "export report payload digest differs")
    require(r["schema"] == SCHEMA and canonical(r["policy"]) == canonical(POLICY) and canonical(r["config"]) == canonical(config), "export contract differs")
    require(r["exporter_sha256"] == sha(Path(__file__)), "exporter source differs")
    require(r["dependency_identity"] == dependency_identity(config), "export dependency identity differs")
    root = output.parent.resolve(strict=True)
    require(report_path.resolve() == output.with_suffix(".report.json").resolve(), "unexpected report path")
    decode_report_path = decode_report_path or root / "trellis2-cpu-decode-report.json"
    for name, expected in (("output", output), ("input", decoded_path), ("correspondence", output.with_suffix(".correspondence.npz")), ("decode_report", decode_report_path)):
        entry = r[name]
        require(set(entry) == {"path", "sha256"} and Path(entry["path"]).resolve(strict=True) == expected.resolve(strict=True), f"unexpected {name} path")
        if name in {"output", "correspondence"}:
            require(expected.resolve().is_relative_to(root), f"{name} path escapes output directory")
        require(is_sha(entry["sha256"]) and sha(expected) == entry["sha256"], f"{name} SHA/path mismatch")
    d = decode_metadata(Path(r["decode_report"]["path"]), r["decode_report"]["sha256"], decoded_path, r["input"]["sha256"])
    require(r["decoder_source"] == {"revision": d["source_revision"], "files": d["source_sha256"]}, "decoder source binding differs")
    runtime = r["runtime"]
    require(set(runtime) == {"device", "native_preflight_executed", "peak_rss_bytes", "seconds"}, "export runtime fields differ")
    require(runtime["device"] == "cpu" and runtime["native_preflight_executed"] is True, "CPU native execution missing")
    require(type(runtime["peak_rss_bytes"]) is int and 0 < runtime["peak_rss_bytes"] <= config["max_bytes"], "invalid CPU peak RSS")
    require(type(runtime["seconds"]) in (int, float) and math.isfinite(runtime["seconds"]) and runtime["seconds"] > 0, "invalid export duration")
    a = load_fields(decoded_path, r["input"]["sha256"], config)
    require(canonical(r["product"]) == canonical(verify_product(output, Path(r["correspondence"]["path"]), a, config)), "actual GLB/report product mismatch")
    for name in ("output", "input", "correspondence", "decode_report"):
        require(sha(Path(r[name]["path"])) == r[name]["sha256"], f"{name} changed during parent validation")
    require(sha(report_path) == report_sha, "export report changed during validation")
    return r


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--input", type=Path)
    parser.add_argument("--input-sha256")
    parser.add_argument("--decode-report", type=Path)
    parser.add_argument("--decode-report-sha256")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    config = settings(json.loads(args.config.read_text(encoding="utf-8")))
    if args.preflight:
        _, _, _, identity = preflight(config)
        result = {"schema": SCHEMA, "native_preflight_executed": True, "dependency_identity": identity, "exporter_sha256": sha(Path(__file__))}
    else:
        require(all((args.input, args.input_sha256, args.decode_report, args.decode_report_sha256, args.output)), "export inputs required")
        report = export(args.input, args.input_sha256, args.decode_report, args.decode_report_sha256, args.output, config)
        result = {"path": str(report.resolve()), "sha256": sha(report)}
    print(PREFIX + json.dumps(result, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
