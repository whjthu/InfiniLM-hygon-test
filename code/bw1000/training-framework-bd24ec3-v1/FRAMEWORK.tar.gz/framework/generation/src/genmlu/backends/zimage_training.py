from __future__ import annotations

import csv
import glob
import hashlib
import importlib.metadata
import importlib.util
import inspect
import json
import math
import platform
import statistics
import sys
import time
from pathlib import Path
from typing import Any

from ..checkpoint_cpu_threads import checkpoint_cpu_threads, validate_limit
from ..manifest import sha256_path
from ..recovery_validation import run_recovery_validation, validate_recovery_enabled
from ..runtime import memory_stats, require_mlu, synchronize
from .. import zimage_training_resume_checkpoint as z_resume


TURBO_REGRESSION_CONTRACT = "explicit-opt-in-v1"


def turbo_regression_options(
    config: dict[str, Any],
    *,
    default_prompt: str | None = None,
    default_size: int = 256,
) -> dict[str, int | str] | None:
    enabled = config.get("validate_turbo_regression", False)
    if type(enabled) is not bool:
        raise ValueError("validate_turbo_regression must be a boolean")
    if not enabled:
        return None
    prompt = config.get("regression_prompt", default_prompt)
    if type(prompt) is not str or not prompt.strip():
        raise ValueError("regression_prompt is required when validate_turbo_regression is true")
    seed = config.get("regression_seed", 20260901)
    size = config.get("regression_size", default_size)
    if type(seed) is not int:
        raise ValueError("regression_seed must be an integer")
    if type(size) is not int or size <= 0:
        raise ValueError("regression_size must be a positive integer")
    return {"prompt": prompt, "seed": seed, "size": size}


def render_turbo_regression_image(
    options: dict[str, int | str] | None,
    model: Any,
    path: Path,
    *,
    image_fn: Any = None,
) -> bool:
    if options is None:
        return False
    image_fn = _turbo_image if image_fn is None else image_fn
    image_fn(
        model,
        str(options["prompt"]),
        int(options["seed"]),
        int(options["size"]),
        path,
    )
    return True


def _render_turbo_preserving_training_boundary(
    options: dict[str, int | str] | None,
    model: Any,
    path: Path,
    scheduler_identity: dict[str, Any],
) -> bool:
    """Run an optional render without consuming the next optimizer-step boundary."""
    rng = z_resume.common.capture_rng([0])
    try:
        return render_turbo_regression_image(options, model, path)
    finally:
        try:
            z_resume.restore_scheduler(model.pipe.scheduler, scheduler_identity)
        finally:
            z_resume.common._restore_rng(rng, [0])


def turbo_regression_metrics(regression: dict[str, float | bool] | None) -> dict[str, float | None]:
    if regression is None:
        return {
            "turbo_8step_pixel_mae": None,
            "turbo_8step_output_std": None,
        }
    return {
        "turbo_8step_pixel_mae": float(regression["pixel_mae"]),
        "turbo_8step_output_std": float(regression["output_std"]),
    }


def turbo_regression_check(regression: dict[str, float | bool] | None) -> bool | None:
    return None if regression is None else bool(regression["passed"])


def _training_module_class(source_root: Path) -> Any:
    if not source_root.is_dir() or source_root.is_symlink():
        raise RuntimeError(f"Z-Image training source root is not a real directory: {source_root}")
    source_root = source_root.resolve()
    path = source_root / "examples" / "z_image" / "model_training" / "train.py"
    if path.is_symlink():
        raise RuntimeError(f"Z-Image training module is symlinked: {path}")
    spec = importlib.util.spec_from_file_location("genmlu_zimage_training", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load Z-Image training module: {path}")
    module = importlib.util.module_from_spec(spec)
    previous = sys.modules.get(spec.name)
    sys.modules[spec.name] = module
    sys.path.insert(0, str(source_root))
    try:
        spec.loader.exec_module(module)
    except Exception:
        if previous is None:
            sys.modules.pop(spec.name, None)
        else:
            sys.modules[spec.name] = previous
        raise
    finally:
        sys.path.remove(str(source_root))
    return module.ZImageTrainingModule


def local_model_paths(root: Path) -> str:
    paths: list[str | list[str]] = [
        sorted(glob.glob(str(root / "transformer" / "*.safetensors"))),
        sorted(glob.glob(str(root / "text_encoder" / "*.safetensors"))),
        str(root / "vae" / "diffusion_pytorch_model.safetensors"),
    ]
    if not paths[0] or not paths[1] or not Path(paths[2]).is_file():
        raise RuntimeError(f"incomplete local Z-Image model layout: {root}")
    return json.dumps(paths)


def _trainable_state(model: Any) -> dict[str, Any]:
    return {
        name: parameter.detach().cpu()
        for name, parameter in model.named_parameters()
        if parameter.requires_grad
    }


def _adapter_sha(model: Any) -> str:
    digest = hashlib.sha256()
    for name, parameter in sorted(model.named_parameters()):
        if not parameter.requires_grad:
            continue
        digest.update(name.encode("utf-8"))
        digest.update(parameter.detach().float().cpu().numpy().tobytes())
    return digest.hexdigest()


def _checkpoint_path(value: Any) -> Path | None:
    if value is None:
        return None
    if type(value) is not str or not value.strip():
        raise ValueError("resume_from_checkpoint must be a non-empty external checkpoint path")
    path = Path(value).expanduser().resolve()
    return path / "state.pt" if path.is_dir() else path


def _tree_sha256(root: Path) -> str:
    return _pinned_tree_sha256(root, "model")


def _pinned_tree_sha256(root: Path, label: str) -> str:
    if not root.is_dir() or root.is_symlink():
        raise RuntimeError(f"Z-Image resume {label} root is not a real directory: {root}")
    digest = hashlib.sha256()
    entries = sorted(root.rglob("*"))
    for path in entries:
        if path.is_symlink():
            raise RuntimeError(f"Z-Image resume identity rejects symlinked {label} path: {path}")
    files = [path for path in entries if path.is_file()]
    if label == "source":
        files = [
            path for path in files
            if ".git" not in path.relative_to(root).parts
            and "__pycache__" not in path.relative_to(root).parts
            and path.suffix != ".pyc"
        ]
    if not files:
        raise RuntimeError(f"Z-Image resume {label} root has no files: {root}")
    for path in files:
        relative = path.relative_to(root).as_posix().encode("utf-8")
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(path.stat().st_size.to_bytes(8, "big"))
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
    return digest.hexdigest()


def _source_sha256(path: Path, label: str) -> str:
    if not path.is_file():
        raise RuntimeError(f"Z-Image resume identity source is missing: {label}={path}")
    return sha256_path(path)


def _execution_source_sha256(value: Any, label: str, source_root: Path) -> str:
    try:
        path = Path(inspect.getsourcefile(value) or "")
    except (OSError, TypeError) as error:
        raise RuntimeError(f"cannot identify Z-Image execution dependency: {label}") from error
    if not path.is_file() or path.is_symlink():
        raise RuntimeError(f"cannot identify Z-Image execution dependency: {label}")
    try:
        path.resolve().relative_to(source_root.resolve())
    except ValueError as error:
        raise RuntimeError(
            f"Z-Image execution dependency was imported outside source_root: {label}={path}"
        ) from error
    return sha256_path(path)


def _imported_execution_module_sources(source_root: Path) -> dict[str, dict[str, Any]]:
    """Pin every loaded Diffsynth module to the supplied, symlink-free checkout."""
    root = source_root.resolve()
    result: dict[str, dict[str, Any]] = {}
    for name, module in sorted(sys.modules.items()):
        if name != "diffsynth" and not name.startswith("diffsynth."):
            continue
        path_value = getattr(module, "__file__", None)
        if path_value is None:
            paths = getattr(module, "__path__", None)
            try:
                namespace_paths = list(paths) if paths is not None else []
            except TypeError as error:
                raise RuntimeError(f"cannot identify Z-Image execution dependency module: {name}") from error
            if not namespace_paths:
                raise RuntimeError(f"cannot identify Z-Image execution dependency module: {name}")
            relative_paths: list[str] = []
            for namespace_path in namespace_paths:
                if type(namespace_path) is not str:
                    raise RuntimeError(f"cannot identify Z-Image execution dependency module: {name}")
                path = Path(namespace_path)
                if not path.is_dir() or path.is_symlink():
                    raise RuntimeError(f"cannot identify Z-Image execution dependency module: {name}")
                try:
                    relative_paths.append(path.resolve().relative_to(root).as_posix())
                except ValueError as error:
                    raise RuntimeError(
                        f"Z-Image execution dependency was imported outside source_root: {name}={path}"
                    ) from error
            result[name] = {"namespace_paths": sorted(relative_paths)}
            continue
        if type(path_value) is not str:
            raise RuntimeError(f"cannot identify Z-Image execution dependency module: {name}")
        path = Path(path_value)
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f"cannot identify Z-Image execution dependency module: {name}")
        try:
            relative = path.resolve().relative_to(root)
        except ValueError as error:
            raise RuntimeError(
                f"Z-Image execution dependency was imported outside source_root: {name}={path}"
            ) from error
        result[name] = {"path": relative.as_posix(), "sha256": sha256_path(path)}
    if not result:
        raise RuntimeError("no Diffsynth execution modules were imported from source_root")
    return result


def _reject_symlink_components(root: Path, path: Path, label: str) -> Path:
    root = root.resolve()
    candidate = path if path.is_absolute() else root / path
    try:
        relative = candidate.relative_to(root)
    except ValueError as error:
        raise RuntimeError(f"Z-Image resume {label} escapes dataset root: {path}") from error
    current = root
    for part in relative.parts:
        current = current / part
        if current.is_symlink():
            raise RuntimeError(f"Z-Image resume {label} uses a symlink: {current}")
    return candidate.resolve()


def _dataset_resume_evidence(dataset_root: Path, metadata_path: Path) -> tuple[dict[str, Any], list[str]]:
    if not dataset_root.is_dir() or dataset_root.is_symlink():
        raise RuntimeError(f"Z-Image resume dataset root is not a real directory: {dataset_root}")
    if not metadata_path.is_file() or metadata_path.is_symlink():
        raise RuntimeError(f"Z-Image resume metadata is missing or symlinked: {metadata_path}")
    with metadata_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None or "image" not in reader.fieldnames:
            raise RuntimeError("Z-Image external resume supports CSV metadata with an image column")
        rows = list(reader)
    if not rows:
        raise RuntimeError("Z-Image external resume requires at least one dataset row")
    images: list[dict[str, str]] = []
    for index, row in enumerate(rows):
        image = row.get("image")
        if type(image) is not str or not image:
            raise RuntimeError(f"Z-Image resume metadata row {index} has no image path")
        image_path = _reject_symlink_components(dataset_root, Path(image), "image")
        if not image_path.is_file():
            raise RuntimeError(f"Z-Image resume image is missing or symlinked: {image_path}")
        images.append({"path": image_path.relative_to(dataset_root.resolve()).as_posix(), "sha256": sha256_path(image_path)})
    metadata_sha = sha256_path(metadata_path)
    return {
        "metadata_sha256": metadata_sha,
        "images": images,
        "rows": len(rows),
        "format": "csv-image-column-v1",
    }, [f"{metadata_sha}:{index}" for index in range(len(rows))]


def _resume_effective_config(config: dict[str, Any]) -> dict[str, Any]:
    operational = {"output_root", "run_name", "resume_from_checkpoint", "validate_recovery", "resume_atol"}
    return {key: config[key] for key in sorted(config) if key not in operational}


def _build_resume_contract(
    *, torch: Any, weights: Path, config: dict[str, Any], source_root: Path,
    training_class: Any, dataset_type: Any, model: Any, scheduler: Any,
    data_evidence: dict[str, Any], sample_order: list[str], max_steps: int,
) -> tuple[dict[str, Any], dict[str, Any]]:
    try:
        torch_mlu_version = importlib.metadata.version("torch_mlu")
    except importlib.metadata.PackageNotFoundError:
        torch_mlu_version = "installed-without-package-metadata"
    source_evidence = {
        "backend": _source_sha256(Path(__file__), "backend"),
        "checkpoint": _source_sha256(Path(inspect.getsourcefile(z_resume) or ""), "checkpoint"),
        "checkpoint_common": _source_sha256(Path(inspect.getsourcefile(z_resume.common) or ""), "checkpoint common"),
        "checkpoint_cpu_threads": _source_sha256(
            Path(inspect.getsourcefile(inspect.unwrap(checkpoint_cpu_threads)) or ""), "checkpoint CPU threads"
        ),
        "pinned_execution_tree": _pinned_tree_sha256(source_root, "source"),
        "imported_execution_modules": _imported_execution_module_sources(source_root),
        "training_module": _execution_source_sha256(training_class, "training module", source_root),
        "dataset": _execution_source_sha256(dataset_type, "UnifiedDataset", source_root),
        "pipeline": _execution_source_sha256(type(model.pipe), "pipeline", source_root),
        "dit": _execution_source_sha256(type(model.pipe.dit), "DiT", source_root),
        "scheduler": _execution_source_sha256(type(scheduler), "scheduler", source_root),
        "runtime": _source_sha256(Path(inspect.getsourcefile(require_mlu) or ""), "runtime"),
    }
    evidence = {
        "config": _resume_effective_config(config),
        "source": source_evidence,
        "data": data_evidence,
        "model": {
            "weights_tree_sha256": _tree_sha256(weights),
            "preset_lora_sha256": sha256_path(Path(str(config["preset_lora_path"]))),
        },
        "runtime": {
            "python": platform.python_version(), "torch": str(torch.__version__),
            "torch_mlu": torch_mlu_version, "platform": platform.platform(), "device": "mlu:0",
        },
        "scheduler": z_resume.common.tree_sha256(z_resume.scheduler_spec(scheduler)),
    }
    identity = {key: z_resume.common.json_sha256(value) for key, value in evidence.items() if key != "scheduler"}
    identity["scheduler"] = evidence["scheduler"]
    return z_resume.build_contract(
        identity=identity, seed=int(config.get("seed", 42)), max_steps=max_steps,
        sample_order=sample_order, device_ids=[0],
    ), evidence


def _save_lora(path: Path, model: Any) -> None:
    from safetensors.torch import save_file

    state = model.export_trainable_state_dict(
        model.state_dict(),
        remove_prefix="pipe.dit.",
    )
    state = {name: tensor.detach().cpu().contiguous() for name, tensor in state.items()}
    path.parent.mkdir(parents=True, exist_ok=True)
    save_file(state, path)


def _train_step(
    model: Any,
    optimizer: Any,
    data: dict[str, Any],
    seed: int,
    max_grad_norm: float,
) -> dict[str, float]:
    torch = require_mlu()
    torch.manual_seed(seed)
    optimizer.zero_grad(set_to_none=True)
    started = time.perf_counter()
    started_unix = time.time()
    loss = model(data)
    loss.backward()
    parameters = [parameter for parameter in model.parameters() if parameter.requires_grad]
    grad_norm = torch.nn.utils.clip_grad_norm_(parameters, max_grad_norm)
    if not torch.isfinite(loss).item():
        raise RuntimeError(f"non-finite Z-Image loss: {float(loss.detach().cpu())}")
    if not torch.isfinite(grad_norm).item() or float(grad_norm.detach().cpu()) <= 0.0:
        raise RuntimeError(f"non-finite or zero Z-Image gradient: {float(grad_norm.detach().cpu())}")
    optimizer.step()
    synchronize()
    return {
        "loss": float(loss.detach().cpu()),
        "grad_norm": float(grad_norm.detach().cpu()),
        "step_seconds": time.perf_counter() - started,
        "started_unix": started_unix,
        "ended_unix": time.time(),
    }


def _turbo_image(model: Any, prompt: str, seed: int, size: int, path: Path) -> None:
    model.pipe.dit.eval()
    image = model.pipe(
        prompt=prompt,
        seed=seed,
        rand_device="mlu",
        height=size,
        width=size,
        num_inference_steps=8,
        cfg_scale=1.0,
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path)


def _image_regression(before: Path, after: Path) -> dict[str, float | bool]:
    import numpy as np
    from PIL import Image

    before_array = np.asarray(Image.open(before).convert("RGB"), dtype=np.float32) / 255.0
    after_array = np.asarray(Image.open(after).convert("RGB"), dtype=np.float32) / 255.0
    mae = float(np.abs(before_array - after_array).mean())
    std = float(after_array.std())
    return {
        "pixel_mae": mae,
        "output_std": std,
        "passed": bool(math.isfinite(mae) and math.isfinite(std) and std > 0.01 and mae <= 0.35),
    }


def run_zimage_training(
    weights: Path,
    config: dict[str, Any],
    output_dir: Path,
    source_root: Path,
) -> dict[str, Any]:
    checkpoint_thread_limit = validate_limit(config.get("checkpoint_cpu_threads"))
    resume_path = _checkpoint_path(config.get("resume_from_checkpoint"))
    resume_payload: dict[str, Any] | None = None
    if resume_path is not None and not resume_path.is_file():
        raise RuntimeError(f"Z-Image training resume checkpoint is missing: {resume_path}")
    if resume_path is not None:
        try:
            resume_payload = z_resume.load_checkpoint(resume_path)
        except Exception as error:
            raise z_resume.CheckpointValidationError(
                f"cannot load Z-Image training resume checkpoint: {resume_path}"
            ) from error
        z_resume.preflight_checkpoint(resume_payload, requested_config=config)

    torch = require_mlu()
    total_started = time.perf_counter()
    torch.manual_seed(int(config.get("seed", 42)))
    torch.mlu.reset_peak_memory_stats()
    load_started = time.perf_counter()
    training_class = _training_module_class(source_root)
    from diffsynth.core import UnifiedDataset

    adapter_path = Path(config["preset_lora_path"])
    if not adapter_path.is_file():
        raise RuntimeError(f"Z-Image differential adapter is missing: {adapter_path}")
    model = training_class(
        model_paths=local_model_paths(weights),
        tokenizer_path=str(weights / "tokenizer"),
        lora_base_model="dit",
        lora_target_modules=str(config["lora_target_modules"]),
        lora_rank=int(config.get("lora_rank", 4)),
        preset_lora_path=str(adapter_path),
        preset_lora_model="dit",
        use_gradient_checkpointing=bool(config.get("gradient_checkpointing", True)),
        device="mlu",
        task="sft",
    )
    if next(model.pipe.dit.parameters()).device.type != "mlu":
        raise RuntimeError("Z-Image DiT main forward is not on MLU")
    load_seconds = time.perf_counter() - load_started
    dataset_root = Path(config["dataset_root"])
    metadata_path = Path(str(config["dataset_metadata"]))
    data_evidence, sample_order = _dataset_resume_evidence(dataset_root, metadata_path)
    dataset = UnifiedDataset(
        base_path=str(dataset_root),
        metadata_path=str(metadata_path),
        data_file_keys=("image",),
        main_data_operator=UnifiedDataset.default_image_operator(
            base_path=str(dataset_root),
            height=int(config.get("height", 256)),
            width=int(config.get("width", 256)),
            height_division_factor=16,
            width_division_factor=16,
        ),
    )
    max_steps = int(config.get("max_steps", 20))
    if max_steps < 1:
        raise ValueError("Z-Image max_steps must be positive")
    if config.get("lr_scheduler") is not None:
        raise ValueError("Z-Image training resume does not support a learning-rate scheduler")
    if len(dataset) != len(sample_order):
        raise RuntimeError("Z-Image external resume requires one UnifiedDataset item per metadata row")
    default_checkpoints = [step for step in (10, 20) if step <= max_steps]
    checkpoint_steps = {int(value) for value in config.get("checkpoint_steps", default_checkpoints)}
    if any(step <= 0 or step > max_steps for step in checkpoint_steps):
        raise ValueError("checkpoint_steps must be completed Z-Image optimizer steps")
    checkpoint_steps.add(max_steps)
    parameters = list(model.trainable_modules())
    if not parameters:
        raise RuntimeError("Z-Image LoRA injection produced no trainable parameters")
    optimizer = torch.optim.AdamW(
        parameters,
        lr=float(config.get("learning_rate", 1e-4)),
        weight_decay=float(config.get("weight_decay", 0.01)),
    )
    optimizer_progress = z_resume.common.initial_optimizer_progress(model, optimizer)
    model.pipe.scheduler.set_timesteps(1000, training=True)
    scheduler_identity = z_resume.scheduler_spec(model.pipe.scheduler)
    resume_contract, resume_identity_evidence = _build_resume_contract(
        torch=torch, weights=weights, config=config, source_root=source_root,
        training_class=training_class, dataset_type=UnifiedDataset, model=model,
        scheduler=model.pipe.scheduler, data_evidence=data_evidence,
        sample_order=sample_order, max_steps=max_steps,
    )
    completed_global_step = 0
    resume_checkpoint_sha = None
    resume_rng_validation = None
    resume_boundary_validated = False
    if resume_payload is not None:
        preflight = z_resume.validate_checkpoint(
            resume_payload, resume_contract, model, optimizer, scheduler_identity, native_rng=True,
        )
        completed_global_step = int(preflight["metadata"]["global_step"])
        if completed_global_step >= max_steps:
            raise RuntimeError("Z-Image training checkpoint already completed the configured schedule")
        optimizer_progress, restored = z_resume.restore_checkpoint(
            resume_payload, resume_contract, model, optimizer, model.pipe.scheduler, scheduler_identity,
        )
        z_resume.assert_restored_boundary(
            resume_payload, model, optimizer, optimizer_progress, model.pipe.scheduler, [0],
        )
        coordinate = preflight["next"]
        if coordinate is None or coordinate["sample_cursor"] != completed_global_step % len(dataset):
            raise RuntimeError("Z-Image training resume checkpoint data cursor mismatch")
        resume_checkpoint_sha = sha256_path(resume_path)
        resume_rng_validation = restored["rng_validation"]
        resume_boundary_validated = True
    output_dir.mkdir(parents=True, exist_ok=True)
    raw_log = output_dir / "steps.jsonl"
    if raw_log.exists():
        raw_log.unlink()
    adapter_before = _adapter_sha(model)
    regression_options = turbo_regression_options(config)
    pre_image = output_dir / "turbo-before.png"
    post_image = output_dir / "turbo-after.png"
    if regression_options is not None:
        inference_started = time.perf_counter()
        _render_turbo_preserving_training_boundary(
            regression_options, model, pre_image, scheduler_identity
        )
        pre_inference_seconds: float | None = time.perf_counter() - inference_started
    else:
        pre_inference_seconds = None
    model.train()
    metrics: list[dict[str, Any]] = []
    update_started = time.perf_counter()
    written_checkpoint_paths: set[Path] = set()
    for global_step in range(completed_global_step + 1, max_steps + 1):
        if getattr(model, "_zimage_training_resume_poisoned", False):
            raise RuntimeError("Z-Image training checkpoint restore poisoned this worker")
        sample_index = (global_step - 1) % len(dataset)
        metric = {
            "global_step": global_step,
            "sample_index": sample_index,
            **_train_step(
                model,
                optimizer,
                dataset[sample_index],
                int(config.get("seed", 42)) + global_step,
                float(config.get("max_grad_norm", 1.0)),
            ),
        }
        optimizer_progress = z_resume.common.advance_optimizer_progress(
            optimizer_progress, model, optimizer
        )
        metrics.append(metric)
        with raw_log.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(metric, sort_keys=True) + "\n")
            handle.flush()
        if global_step in checkpoint_steps:
            checkpoint_path = output_dir / f"checkpoint-{global_step}" / "state.pt"
            with checkpoint_cpu_threads(torch, checkpoint_thread_limit):
                payload = z_resume.make_payload(
                    contract=resume_contract, global_step=global_step, model=model, optimizer=optimizer,
                    optimizer_progress=optimizer_progress, scheduler=model.pipe.scheduler,
                    expected_scheduler=scheduler_identity,
                )
            z_resume.save_atomic(checkpoint_path, payload)
            written_checkpoint_paths.add(checkpoint_path)
    update_seconds = time.perf_counter() - update_started
    checkpoint = output_dir / f"checkpoint-{max_steps}" / "state.pt"
    if checkpoint not in written_checkpoint_paths:
        raise RuntimeError("Z-Image training final checkpoint was not written")
    validation_data = dataset[0]
    validation_seed = int(config.get("seed", 42)) + max_steps + 1

    def recovery_update() -> dict[str, Any]:
        _train_step(
            model,
            optimizer,
            validation_data,
            validation_seed,
            float(config.get("max_grad_norm", 1.0)),
        )
        return _trainable_state(model)

    def compare_recovery(
        continuous: dict[str, Any],
        resumed: dict[str, Any],
        _continuous_fingerprint: str | None,
        _resumed_fingerprint: str | None,
    ) -> tuple[bool, dict[str, Any]]:
        resume_max_abs = max(
            float((resumed[name] - value).abs().max())
            for name, value in continuous.items()
        )
        return (
            resume_max_abs <= float(config.get("resume_atol", 1e-6)),
            {"resume_max_abs": resume_max_abs},
        )

    recovery = run_recovery_validation(
        enabled=validate_recovery_enabled(config),
        expected_step=max_steps,
        metric_names=("resume_max_abs",),
        update=recovery_update,
        restore=lambda: int(
            z_resume.restore_checkpoint(
                z_resume.load_checkpoint(checkpoint), resume_contract, model, optimizer,
                model.pipe.scheduler, scheduler_identity,
            )[1]["metadata"]["global_step"]
        ),
        fingerprint=None,
        compare=compare_recovery,
    )
    adapter_after = _adapter_sha(model)
    final_adapter = output_dir / "adapter-final.safetensors"
    _save_lora(final_adapter, model)
    if regression_options is not None:
        inference_started = time.perf_counter()
        render_turbo_regression_image(regression_options, model, post_image)
        post_inference_seconds: float | None = time.perf_counter() - inference_started
        regression = _image_regression(pre_image, post_image)
    else:
        post_inference_seconds = None
        regression = None
    warmup_steps = int(config.get("warmup_steps", 0))
    measured_metrics = [
        item for item in metrics if int(item["global_step"]) > warmup_steps
    ]
    if not measured_metrics:
        raise ValueError("warmup_steps must leave at least one measured Z-Image update")
    step_seconds = [float(item["step_seconds"]) for item in measured_metrics]
    losses = [float(item["loss"]) for item in metrics]
    gradients = [float(item["grad_norm"]) for item in metrics]
    artifacts = [
        *sorted(written_checkpoint_paths),
        checkpoint,
        final_adapter,
        *([pre_image, post_image] if regression is not None else []),
    ]
    return {
        "artifacts": [
            {"path": str(path), "sha256": sha256_path(path)}
            for path in artifacts
            if path.is_file()
        ],
        "logs": [{"path": str(raw_log), "sha256": sha256_path(raw_log)}],
        "metrics": {
            "steps": max_steps,
            "global_optimizer_step": max_steps,
            "completed_global_step_before_resume": completed_global_step,
            "external_resume": resume_path is not None,
            "checkpoint_schema": z_resume.SCHEMA,
            "checkpoint_identity": resume_contract["identity"],
            "checkpoint_identity_evidence": resume_identity_evidence,
            "checkpoint_final_sha256": sha256_path(checkpoint),
            "checkpoint_cpu_threads_limit": checkpoint_thread_limit,
            "resume_source_sha256": resume_checkpoint_sha,
            "resume_rng_validation": resume_rng_validation,
            "warmup_steps": warmup_steps,
            "measurement_steps": len(measured_metrics),
            "loss_min": min(losses),
            "loss_max": max(losses),
            "grad_norm_min": min(gradients),
            "step_seconds_median": statistics.median(step_seconds),
            "step_seconds_min": min(step_seconds),
            "step_seconds_max": max(step_seconds),
            "samples_per_second": len(measured_metrics) / sum(step_seconds),
            "resume_max_abs": recovery.metrics["resume_max_abs"],
            "adapter_sha_before": adapter_before,
            "adapter_sha_after": adapter_after,
            **turbo_regression_metrics(regression),
            "mlu_memory": memory_stats(),
        },
        "stage_timings": {
            "load": load_seconds,
            "update": update_seconds,
            "pre_training_inference": pre_inference_seconds,
            "post_training_inference": post_inference_seconds,
            "total": time.perf_counter() - total_started,
        },
        "checks": {
            "finite_tensors": all(math.isfinite(value) for value in losses),
            "nonzero_finite_gradients": all(
                math.isfinite(value) and value > 0.0 for value in gradients
            ),
            "checkpoint_resume": recovery.passed,
            "resume_boundary": resume_path is None or resume_boundary_validated,
            "completed_step_checkpoint": bool(written_checkpoint_paths),
            "current_adapter": adapter_before != adapter_after,
            "main_forward_device": "mlu",
            "turbo_8step_regression": turbo_regression_check(regression),
        },
    }
