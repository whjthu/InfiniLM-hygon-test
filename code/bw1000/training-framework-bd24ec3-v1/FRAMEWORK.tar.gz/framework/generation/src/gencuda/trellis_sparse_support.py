"""Ordered sparse-support checks for staged TRELLIS inference."""

from __future__ import annotations

import io
from pathlib import Path
from typing import Any, Mapping

import numpy as np

SUPPORT_KEYS = {
    "native", "retained", "selection", "shape_input", "shape_output",
    "texture_input", "texture_output",
}
LATENT_KEYS = {"condition", "coords", "shape_latent", "structure_latent", "texture_latent"}
MAX_GRID_POINTS = 32 ** 3


def validate_limit(value: Any) -> int:
    if type(value) is not int or not 8 <= value <= MAX_GRID_POINTS:
        raise ValueError("max_sparse_tokens must be an integer between 8 and 32768")
    return value


def validate_coords(value: np.ndarray) -> None:
    if (
        value.dtype != np.int32 or value.ndim != 2 or value.shape[1] != 4
        or not 8 <= len(value) <= MAX_GRID_POINTS
        or np.any(value[:, 0] != 0)
        or np.any(value[:, 1:] < 0) or np.any(value[:, 1:] >= 32)
        or len(np.unique(value, axis=0)) != len(value)
    ):
        raise ValueError("invalid single-batch TRELLIS 32-grid sparse coordinates")
    keys = (value[:, 1].astype(np.int64) * 32 + value[:, 2]) * 32 + value[:, 3]
    if np.any(np.diff(keys) <= 0):
        raise ValueError("sparse coordinates differ from ordered argwhere support")


def admit_native_support(native: np.ndarray, limit: int, *, full_mesh: bool) -> None:
    validate_limit(limit)
    validate_coords(native)
    if full_mesh and len(native) > limit:
        raise ValueError("native sparse support exceeds max_sparse_tokens; full_mesh cannot truncate")


def require_stage_support(value: np.ndarray, retained: np.ndarray, stage: str) -> None:
    validate_coords(value)
    if not np.array_equal(value, retained):
        raise ValueError(f"{stage} changed ordered sparse support")


def validate_arrays(arrays: Mapping[str, np.ndarray], *, full_mesh: bool) -> dict[str, Any]:
    if set(arrays) != SUPPORT_KEYS:
        raise ValueError("sparse support proof members differ")
    native, retained, selected = arrays["native"], arrays["retained"], arrays["selection"]
    validate_coords(native)
    validate_coords(retained)
    if (
        selected.dtype != np.int64 or selected.shape != (len(retained),)
        or np.any(selected < 0) or np.any(selected >= len(native))
        or np.any(np.diff(selected) <= 0)
        or not np.array_equal(native[selected], retained)
    ):
        raise ValueError("sparse selection does not match ordered native coordinates")
    for stage in ("shape_input", "shape_output", "texture_input", "texture_output"):
        require_stage_support(arrays[stage], retained, stage)
    preserved = np.array_equal(selected, np.arange(len(native), dtype=np.int64))
    if full_mesh and not preserved:
        raise ValueError("full_mesh requires all native coordinates in original order")
    return {
        "native_points": len(native), "retained_points": len(retained),
        "dropped_points": len(native) - len(retained), "native_preserved": bool(preserved),
    }


def write_proof(path: Path, arrays: Mapping[str, np.ndarray], *, full_mesh: bool) -> dict[str, Any]:
    from .trellis_cpu_texture_export import atomic_bytes, sha

    counts = validate_arrays(arrays, full_mesh=full_mesh)
    buffer = io.BytesIO()
    np.savez_compressed(buffer, **arrays)
    atomic_bytes(path, buffer.getvalue())
    return {
        "schema": "trellis-sparse-support-v1", "proof": {"path": str(path), "sha256": sha(path)},
        **counts,
    }


def validate_proof(
    evidence: Any, artifacts: list[dict[str, str]], *, full_mesh: bool, max_sparse_tokens: int = 1024
) -> dict[str, Any]:
    from .trellis_cpu_texture_export import load_npz, sha

    limit = validate_limit(max_sparse_tokens)
    fields = {"schema", "proof", "latent", "native_points", "retained_points", "dropped_points", "native_preserved"}
    if not isinstance(evidence, Mapping) or set(evidence) != fields:
        raise ValueError("TRELLIS sparse support evidence is missing or invalid")
    if evidence["schema"] != "trellis-sparse-support-v1":
        raise ValueError("unsupported TRELLIS sparse support schema")
    for role in ("proof", "latent"):
        entry = evidence[role]
        if not isinstance(entry, Mapping) or set(entry) != {"path", "sha256"} or dict(entry) not in artifacts:
            raise ValueError(f"sparse support {role} is not a verified artifact")
        if sha(Path(entry["path"])) != entry["sha256"]:
            raise ValueError(f"sparse support {role} SHA differs")
    arrays = load_npz(Path(evidence["proof"]["path"]), 4 * 1024 ** 2, SUPPORT_KEYS)
    counts = validate_arrays(arrays, full_mesh=full_mesh)
    if counts["retained_points"] > limit or (full_mesh and counts["native_points"] > limit):
        raise ValueError("sparse support proof exceeds configured max_sparse_tokens")
    if any(type(evidence[key]) is not type(value) or evidence[key] != value for key, value in counts.items()):
        raise ValueError("sparse support counts differ from verified arrays")
    latent = load_npz(Path(evidence["latent"]["path"]), 64 * 1024 ** 2, LATENT_KEYS, max_dimensions=5)
    validate_coords(latent["coords"])
    if not np.array_equal(latent["coords"], arrays["retained"]):
        raise ValueError("latent coordinates differ from sparse support proof")
    for key in ("shape_latent", "texture_latent"):
        if latent[key].ndim != 2 or len(latent[key]) != counts["retained_points"]:
            raise ValueError(f"{key} rows differ from sparse support")
    if latent["structure_latent"].ndim != 5 or latent["condition"].ndim != 3:
        raise ValueError("dense structure latent or condition dimensions differ")
    for role in ("proof", "latent"):
        if sha(Path(evidence[role]["path"])) != evidence[role]["sha256"]:
            raise ValueError(f"sparse support {role} changed during validation")
    return dict(evidence)
