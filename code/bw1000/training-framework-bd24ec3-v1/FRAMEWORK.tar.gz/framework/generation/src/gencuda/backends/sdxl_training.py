from __future__ import annotations

import hashlib
import json
import math
import os
import re
import statistics
import subprocess
import sys
from pathlib import Path
from typing import Any

from ..manifest import sha256_path
from ..runtime import within_memory_limit


def _records(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def _observed_unet_device(records: list[dict[str, Any]]) -> str:
    devices: set[str] = set()
    for record in records:
        proof = record.get("forward_devices")
        if type(proof) is not dict or set(proof) != {"input", "output", "trainable_parameters"}:
            raise RuntimeError("SDXL trainer is missing actual UNet forward-device evidence")
        device = proof["input"]
        parameters = proof["trainable_parameters"]
        if (
            type(device) is not str
            or re.fullmatch(r"cuda:\d+", device) is None
            or proof["output"] != device
            or type(parameters) is not list
            or parameters != [device]
        ):
            raise RuntimeError("SDXL UNet input, output and trainable parameters must share one CUDA")
        devices.add(device)
    if len(devices) != 1:
        raise RuntimeError("SDXL UNet device changed or was not observed during training")
    return next(iter(devices))


def _external_checkpoint(config: dict[str, Any]) -> tuple[Path | None, int, Path | None]:
    value = config.get("resume_from_checkpoint")
    if value is None:
        return None, 0, None
    checkpoint = Path(str(value)).expanduser()
    match = re.fullmatch(r"checkpoint-(\d+)", checkpoint.name)
    if not checkpoint.is_dir() or match is None:
        raise RuntimeError("SDXL resume_from_checkpoint must be an external checkpoint-N directory")
    adapter = checkpoint / "pytorch_lora_weights.safetensors"
    if not adapter.is_file():
        raise RuntimeError(f"SDXL external checkpoint is missing its adapter: {adapter}")
    return checkpoint.resolve(), int(match.group(1)), adapter


def _positive_config_int(config: dict[str, Any], key: str, default: int) -> int:
    value = config.get(key, default)
    if type(value) is not int or value <= 0:
        raise ValueError(f"SDXL {key} must be positive")
    return value


def _adapter_tensor_identity(
    path: Path,
) -> tuple[str, tuple[tuple[str, str, tuple[int, ...]], ...]]:
    try:
        import torch
        from safetensors import safe_open
    except ImportError as error:
        raise RuntimeError("SDXL adapter identity requires torch and safetensors") from error

    digest = hashlib.sha256()
    schema: list[tuple[str, str, tuple[int, ...]]] = []
    with safe_open(str(path), framework="pt", device="cpu") as adapter:
        for name in sorted(adapter.keys()):
            tensor = adapter.get_tensor(name).detach().cpu().contiguous()
            if (tensor.is_floating_point() or tensor.is_complex()) and not torch.isfinite(
                tensor
            ).all():
                raise RuntimeError(f"SDXL adapter contains non-finite tensor values: {path}")
            schema.append((name, str(tensor.dtype), tuple(tensor.shape)))
            for value in (
                name.encode("utf-8"),
                str(tensor.dtype).encode("ascii"),
                json.dumps(list(tensor.shape)).encode("ascii"),
                tensor.reshape(-1).view(torch.uint8).numpy().tobytes(),
            ):
                digest.update(len(value).to_bytes(8, "big"))
                digest.update(value)
    if not schema:
        raise RuntimeError(f"SDXL adapter contains no tensors: {path}")
    return digest.hexdigest(), tuple(schema)

def run_sdxl_training(
    weights: Path,
    config: dict[str, Any],
    output_dir: Path,
    source_root: Path,
) -> dict[str, Any]:
    script = source_root / "examples" / "text_to_image" / "train_text_to_image_lora_sdxl.py"
    legacy_keys = {"dataset_root", "dataset_metadata", "max_steps"}.intersection(config)
    if legacy_keys:
        names = ", ".join(sorted(legacy_keys))
        raise ValueError(f"SDXL training config uses obsolete keys: {names}")
    dataset = Path(str(config["train_data_dir"]))
    max_steps = int(config["max_train_steps"])
    if max_steps <= 0:
        raise ValueError("SDXL max_train_steps must be positive")
    checkpointing_steps = _positive_config_int(config, "checkpointing_steps", 10)
    checkpoints_total_limit = _positive_config_int(config, "checkpoints_total_limit", 3)
    if not weights.is_dir() or not script.is_file() or not dataset.is_dir():
        raise RuntimeError("SDXL model, official trainer, or training dataset is missing")
    resume_checkpoint, resume_step, previous_adapter = _external_checkpoint(config)
    if resume_step >= max_steps:
        raise ValueError("SDXL resume checkpoint must precede max_train_steps")
    output_dir.mkdir(parents=True, exist_ok=True)
    if resume_checkpoint:
        try:
            resume_checkpoint.relative_to(output_dir.resolve())
        except ValueError:
            pass
        else:
            raise ValueError("SDXL resume checkpoint must be outside the new output directory")
    metrics_path = output_dir / "steps.ndjson"
    log_path = output_dir / "run.log"
    expected = max_steps - resume_step
    warmup_steps = int(config.get("warmup_steps", min(5, expected - 1)))
    if resume_checkpoint is None and not 0 <= warmup_steps < expected:
        raise ValueError("SDXL warmup_steps must be within the requested training steps")
    initial_adapter = output_dir / "initial_adapter.safetensors"
    resume_input_adapter_file_sha256 = sha256_path(previous_adapter) if previous_adapter else None
    command = [
        sys.executable,
        str(script),
        "--pretrained_model_name_or_path",
        str(weights),
        "--train_data_dir",
        str(dataset),
        "--output_dir",
        str(output_dir),
        "--resolution",
        str(int(config.get("resolution", 512))),
        "--center_crop",
        "--train_batch_size",
        str(int(config.get("train_batch_size", 1))),
        "--gradient_accumulation_steps",
        "1",
        "--max_train_steps",
        str(max_steps),
        "--checkpointing_steps",
        str(checkpointing_steps),
        "--checkpoints_total_limit",
        str(checkpoints_total_limit),
        "--learning_rate",
        str(float(config.get("learning_rate", 1e-4))),
        "--lr_scheduler",
        "constant",
        "--lr_warmup_steps",
        "0",
        "--mixed_precision",
        "bf16",
        "--seed",
        str(int(config.get("seed", 20260911))),
        "--dataloader_num_workers",
        str(int(config.get("dataloader_num_workers", 2))),
        "--rank",
        str(int(config.get("lora_rank", 16))),
        "--report_to",
        "tensorboard",
        "--gencuda_metrics_path",
        str(metrics_path),
    ]
    command.extend(["--gencuda_initial_adapter_path", str(initial_adapter)])
    extra_checkpoint_steps = str(config.get("extra_checkpoint_steps", ""))
    if extra_checkpoint_steps:
        command.extend(["--gencuda_checkpoint_steps", extra_checkpoint_steps])
    if bool(config.get("gradient_checkpointing", False)):
        command.append("--gradient_checkpointing")
    if resume_checkpoint:
        command.extend(["--gencuda_external_resume_from_checkpoint", str(resume_checkpoint)])
    environment = dict(os.environ)
    environment.update(
        {
            "HF_DATASETS_CACHE": "/tmp/hf/datasets",
            "HF_HOME": "/tmp/hf",
            "TRANSFORMERS_CACHE": "/tmp/hf/transformers",
            "TRITON_CACHE_DIR": "/tmp/triton",
            "XDG_CACHE_HOME": "/tmp/xdg",
        }
    )
    with log_path.open("w", encoding="utf-8") as log:
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True, env=environment)

    records = _records(metrics_path)
    if len(records) != expected or any(type(record.get("global_step")) is not int for record in records) or [
        record["global_step"] for record in records
    ] != list(range(resume_step + 1, max_steps + 1)):
        raise RuntimeError(f"SDXL trainer recorded {len(records)} updates, expected {expected}")
    observed_device = _observed_unet_device(records)
    if not all(
        math.isfinite(float(record[field]))
        for record in records
        for field in ("loss", "grad_norm", "step_seconds")
    ):
        raise RuntimeError("SDXL training produced non-finite evidence")
    if min(float(record["grad_norm"]) for record in records) <= 0:
        raise RuntimeError("SDXL training produced a zero gradient norm")

    final_adapter = output_dir / "pytorch_lora_weights.safetensors"
    required = [initial_adapter, final_adapter]
    if not all(path.is_file() for path in required):
        raise RuntimeError(f"SDXL training artifacts are incomplete: {required}")
    adapter_before, initial_schema = _adapter_tensor_identity(initial_adapter)
    adapter_after, final_schema = _adapter_tensor_identity(final_adapter)
    if initial_schema != final_schema:
        raise RuntimeError("SDXL initial and final adapter tensor layouts differ")
    if adapter_before == adapter_after:
        raise RuntimeError("SDXL training did not change the adapter weights")
    measured = records if resume_checkpoint else records[warmup_steps:]
    seconds = [float(record["step_seconds"]) for record in measured]
    losses = [float(record["loss"]) for record in records]
    gradients = [float(record["grad_norm"]) for record in records]
    checkpoint_adapters = sorted(
        output_dir.glob("checkpoint-*/pytorch_lora_weights.safetensors"),
        key=lambda path: int(path.parent.name.removeprefix("checkpoint-")),
    )
    artifact_paths = list(dict.fromkeys([*required, *checkpoint_adapters]))
    artifacts = [{"path": str(path), "sha256": sha256_path(path)} for path in artifact_paths]
    return {
        "artifacts": artifacts,
        "checks": {
            "finite_tensors": True,
            "main_forward_device": observed_device,
            "nonzero_finite_gradients": True,
            "peak_reserved_below_75gb": within_memory_limit(
                max(int(record["peak_reserved_bytes"]) for record in records)
            ),
            "weight_sha_changed": adapter_before != adapter_after,
        },
        "logs": [
            {"path": str(metrics_path), "sha256": sha256_path(metrics_path)},
            {"path": str(log_path), "sha256": sha256_path(log_path)},
        ],
        "metrics": {
            "adapter_sha_after": adapter_after,
            "adapter_sha_before": adapter_before,
            "resume_input_adapter_file_sha256": resume_input_adapter_file_sha256,
            "grad_norm_max": max(gradients),
            "grad_norm_min": min(gradients),
            "loss_max": max(losses),
            "loss_median": statistics.median(losses),
            "loss_min": min(losses),
            "measurement_steps": len(measured),
            "peak_reserved_bytes": max(int(record["peak_reserved_bytes"]) for record in records),
            "resume_from_step": resume_step or None,
            "step_seconds_max": max(seconds),
            "step_seconds_median": statistics.median(seconds),
            "step_seconds_min": min(seconds),
            "steps": max_steps,
            "updates_per_second": 1.0 / statistics.median(seconds),
            "warmup_steps": 0 if resume_checkpoint else warmup_steps,
        },
        "stage_timings": {"training_seconds": sum(seconds)},
    }
