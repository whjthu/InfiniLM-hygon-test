"""Single-cache TRELLIS shape-flow component training contracts and identities."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import struct
import subprocess
from typing import Any
import zipfile

COMPONENT = "trellis-shape-flow-1.3b"
PREFIX = "slat_flow_img2shape_dit_1_3B_512_bf16"
PIN = "75fbf0183001ed9876c8dbb35de6b68552ee08bd"
CONFIG_SHA = "ddbd7a1d34ce9a8e7af2f6ef9ae686d9ab49f69e62dacb98d8409b511cdbd5e2"
PIPELINE_SHA = "222c359ab1ed9bc6735a640a34f95d47f8681b9bc4aaa101bfb80274676253c6"
WEIGHTS_SHA = "ec5e0917ef9b7e25ad51dffc7d19687a42019871f94239f2fa7f86264c55b70f"
WEIGHTS_BYTES = 2584574424
HEADER_SHA = "67606173488fc22d0db6bcd086787623fe6fd4a99e8686e0b651c4a15ece4cb8"
TARGETS = {
    "blocks.0.self_attn.to_qkv": (4608, 1536),
    "blocks.0.self_attn.to_out": (1536, 1536),
    "blocks.0.cross_attn.to_q": (1536, 1536),
    "blocks.0.cross_attn.to_kv": (3072, 1024),
    "blocks.0.cross_attn.to_out": (1536, 1536),
    "blocks.1.self_attn.to_qkv": (4608, 1536),
    "blocks.1.self_attn.to_out": (1536, 1536),
    "blocks.1.cross_attn.to_q": (1536, 1536),
    "blocks.1.cross_attn.to_kv": (3072, 1024),
    "blocks.1.cross_attn.to_out": (1536, 1536),
    "blocks.2.self_attn.to_qkv": (4608, 1536),
    "blocks.2.self_attn.to_out": (1536, 1536),
}
DEFAULTS = {
    "model": COMPONENT, "precision": "bfloat16", "seed": 42,
    "max_steps": 25, "warmup_steps": 5,
    "checkpoint_steps": [10, 20],
    "learning_rate": 1e-4, "weight_decay": 0.01, "max_grad_norm": 1.0,
    "lora_rank": 2, "lora_alpha": 4.0, "gradient_checkpointing": False,
    "cache_representation": "denormalized-shape-slat",
}
REQUIRED_FIELDS = {
    "training_cache", "training_cache_sha256", "training_cache_semantic_sha256",
    "cache_origin_kind", "dataset_id", "max_tokens", "max_condition_tokens",
    "source_root", "source_revision", "source_inventory_sha256",
}
INVOCATION_FIELDS = {
    "resume_from_checkpoint", "resume_checkpoint_sha256", "stop_after_global_step",
    "run_name", "output_root", "run_id", "host_label",
}
METADATA_FIELDS = {"cards", "container", "container_image", "recovery_validation"}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def file_sha(path: Path) -> str:
    require(path.is_file() and not path.is_symlink(), f"missing or symlink file: {path}")
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def json_sha(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def is_sha(value: Any) -> bool:
    return type(value) is str and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def resolve_config(config: dict[str, Any]) -> dict[str, Any]:
    require(type(config) is dict, "component config must be a mapping")
    require(REQUIRED_FIELDS <= set(config), "missing required cache/source identity or token budget")
    require(not (set(config) - set(DEFAULTS) - REQUIRED_FIELDS - INVOCATION_FIELDS - METADATA_FIELDS), "unknown component configuration field")
    value = {**DEFAULTS, **config}
    for key in ("model", "precision", "lora_rank", "lora_alpha", "cache_representation"):
        require(type(value[key]) is type(DEFAULTS[key]) and value[key] == DEFAULTS[key], f"frozen component setting differs: {key}")
    require(type(value["max_steps"]) is int and 0 < value["max_steps"] <= 2**24, "invalid max_steps")
    require(type(value["warmup_steps"]) is int and 0 <= value["warmup_steps"] < value["max_steps"], "invalid warmup_steps")
    if "checkpoint_steps" not in config:
        value["checkpoint_steps"] = [step for step in DEFAULTS["checkpoint_steps"] if step <= value["max_steps"]]
    milestones = value["checkpoint_steps"]
    require(type(milestones) is list and all(type(step) is int and 1 <= step <= value["max_steps"] for step in milestones), "invalid checkpoint_steps")
    require(len(milestones) == len(set(milestones)), "duplicate checkpoint_steps")
    value["checkpoint_steps"] = sorted(milestones)
    require(type(value["seed"]) is int and 0 <= value["seed"] < 2**63, "invalid seed")
    for key in ("learning_rate", "weight_decay", "max_grad_norm"):
        number = value[key]
        require(type(number) in (int, float) and math.isfinite(number), f"invalid {key}")
        require(number >= 0 if key == "weight_decay" else number > 0, f"invalid {key}")
    require(type(value["gradient_checkpointing"]) is bool, "gradient_checkpointing must be boolean")
    require(value.get("recovery_validation", False) is False, "in-process recovery validation is unsupported")
    for key in ("training_cache", "source_root", "dataset_id"):
        require(type(value[key]) is str and bool(value[key].strip()), f"invalid {key}")
    for key in ("training_cache_sha256", "training_cache_semantic_sha256", "source_inventory_sha256"):
        require(is_sha(value[key]), f"invalid {key}")
    revision = value["source_revision"]
    require(type(revision) is str and len(revision) == 40 and all(c in "0123456789abcdef" for c in revision), "invalid source_revision")
    require(value["cache_origin_kind"] in ("generated", "real"), "cache_origin_kind must be declared generated or real")
    for key in ("max_tokens", "max_condition_tokens"):
        require(type(value[key]) is int and 0 < value[key] <= 32768, f"invalid {key}")
    stop = value.get("stop_after_global_step", value["max_steps"])
    require(type(stop) is int and 1 <= stop <= value["max_steps"], "invalid stop_after_global_step")
    for key in ("resume_from_checkpoint",):
        require(value.get(key) is None or (type(value[key]) is str and bool(value[key].strip())), f"invalid {key}")
    require(value.get("resume_checkpoint_sha256") is None or is_sha(value["resume_checkpoint_sha256"]), "invalid resume checkpoint SHA")
    require(value.get("resume_from_checkpoint") is None or is_sha(value.get("resume_checkpoint_sha256")), "resume_checkpoint_sha256 is required for external resume")
    if "cards" in value:
        require(type(value["cards"]) is list and len(value["cards"]) == 1 and type(value["cards"][0]) is int and value["cards"][0] >= 0, "component requires one card")
    return value


def training_config(config: dict[str, Any]) -> dict[str, Any]:
    value = resolve_config(config)
    # Invocation placement and stopping do not change the full training trajectory.
    return {key: item for key, item in value.items() if key not in INVOCATION_FIELDS | METADATA_FIELDS}


def adapter_shapes() -> dict[str, tuple[int, int]]:
    return {name + "." + suffix: shape for name, (out_features, in_features) in TARGETS.items()
            for suffix, shape in (("lora_A", (2, in_features)), ("lora_B", (out_features, 2)))}


def semantic_sha(arrays: dict[str, Any]) -> str:
    import numpy as np
    digest = hashlib.sha256()
    for name, value in sorted(arrays.items()):
        array = np.ascontiguousarray(value)
        digest.update(name.encode())
        digest.update(str(array.shape).encode("ascii"))
        digest.update(str(array.dtype).encode("ascii"))
        digest.update(array.tobytes())
    return digest.hexdigest()


def validate_cache_arrays(arrays: dict[str, Any], *, max_tokens: int, max_condition_tokens: int) -> None:
    import numpy as np
    required = {"condition", "coords", "shape_latent"}
    require(required <= set(arrays) <= required | {"structure_latent", "texture_latent"}, "cache array schema differs")
    for key, value in arrays.items():
        dtype = np.int32 if key == "coords" else np.float32
        require(type(value) is np.ndarray and value.dtype == dtype, f"cache dtype differs: {key}")
        require(bool(np.isfinite(value).all()), f"non-finite cache: {key}")
    coords = arrays["coords"]
    require(coords.ndim == 2 and coords.shape[1] == 4 and 0 < len(coords) <= max_tokens, "coordinate shape or token budget exceeded; truncation is forbidden")
    require(arrays["shape_latent"].shape == (len(coords), 32), "shape latent must be N x 32")
    condition = arrays["condition"]
    require(condition.ndim == 3 and condition.shape[0] == 1 and condition.shape[2] == 1024 and 0 < condition.shape[1] <= max_condition_tokens, "condition must be 1 x L x 1024 within explicit budget")
    if "texture_latent" in arrays:
        require(arrays["texture_latent"].shape == (len(coords), 32), "texture latent alignment differs")
    if "structure_latent" in arrays:
        require(arrays["structure_latent"].shape == (1, 8, 16, 16, 16), "structure latent shape differs")
    require(bool((coords[:, 0] == 0).all()), "cache must be single-batch zero")
    require(bool(((coords[:, 1:] >= 0) & (coords[:, 1:] < 32)).all()), "cache coordinates outside 32 grid")
    require(len(np.unique(coords, axis=0)) == len(coords), "duplicate cache coordinates")


def load_cache(config: dict[str, Any], normalization: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    import numpy as np
    config = resolve_config(config)
    path = Path(config["training_cache"])
    sha = file_sha(path)
    require(sha == config["training_cache_sha256"], "cache file SHA differs")
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        names = [entry.filename for entry in entries]
        allowed = {name + ".npy" for name in ("condition", "coords", "shape_latent", "structure_latent", "texture_latent")}
        require(len(names) == len(set(names)) and set(names) <= allowed, "invalid NPZ members")
        byte_budget = 4 * (config["max_condition_tokens"] * 1024 + config["max_tokens"] * 68 + 8 * 16**3) + 5 * 65536
        require(sum(e.file_size for e in entries) <= byte_budget, "cache exceeds uncompressed byte budget")
    with np.load(path, allow_pickle=False) as data:
        require(len(data.files) == len(set(data.files)), "duplicate cache keys")
        arrays = {name: data[name].copy() for name in data.files}
    validate_cache_arrays(arrays, max_tokens=config["max_tokens"], max_condition_tokens=config["max_condition_tokens"])
    used = {name: arrays[name] for name in ("condition", "coords", "shape_latent")}
    semantic = semantic_sha(used)
    require(semantic == config["training_cache_semantic_sha256"], "cache semantic SHA differs")
    mean = np.asarray(normalization["mean"], dtype=np.float32)
    std = np.asarray(normalization["std"], dtype=np.float32)
    require(mean.shape == std.shape == (32,) and bool(np.isfinite(mean).all()) and bool(np.isfinite(std).all()) and bool((std > 0).all()), "invalid normalization")
    normalized = {**used, "shape_latent": (used["shape_latent"] - mean) / std}
    require(bool(np.isfinite(normalized["shape_latent"]).all()), "non-finite normalized cache")
    require(file_sha(path) == sha, "cache changed during load")
    return normalized, {"path": str(path.resolve()), "file_sha256": sha,
                        "semantic_sha256": semantic, "normalized_sha256": semantic_sha(normalized),
                        "normalization_sha256": semantic_sha({"mean": mean, "std": std}),
                        "sample_order": [semantic], "tokens": len(used["coords"]),
                        "condition_tokens": used["condition"].shape[1],
                        "origin_kind_declared": config["cache_origin_kind"], "dataset_id": config["dataset_id"]}


def verify_source(config: dict[str, Any]) -> dict[str, Any]:
    root = Path(config["source_root"]).resolve(strict=True)
    def git(*args: str) -> bytes:
        return subprocess.run(["git", "-C", str(root), *args], check=True, capture_output=True, timeout=30).stdout
    revision = git("rev-parse", "HEAD").decode().strip()
    require(revision == config["source_revision"], "TRELLIS source revision differs")
    tree = git("rev-parse", "HEAD^{tree}").decode().strip()
    diff_sha = hashlib.sha256(git("diff", "--binary", "HEAD", "--")).hexdigest()
    # Include untracked Python sources as well: a declared pin alone does not bind patches.
    require(not (root / "trellis2").is_symlink(), "symlink TRELLIS source directory")
    paths = sorted((root / "trellis2").rglob("*.py"))
    require(paths and all(not p.is_symlink() for p in (root / "trellis2").rglob("*")), "missing or symlink TRELLIS sources")
    inventory = {p.relative_to(root).as_posix(): file_sha(p) for p in paths}
    inventory_sha = json_sha(inventory)
    require(inventory_sha == config["source_inventory_sha256"], "TRELLIS source inventory SHA differs")
    return {"path": str(root), "revision": revision, "tree": tree,
            "patch_sha256": diff_sha, "python_inventory_sha256": inventory_sha, "files": inventory}


def inspect_weights(root: Path) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    prefix = root / "ckpts" / PREFIX
    config_path, weights_path = prefix.with_suffix(".json"), prefix.with_suffix(".safetensors")
    require(file_sha(config_path) == CONFIG_SHA, "component config SHA differs")
    require(file_sha(root / "pipeline.json") == PIPELINE_SHA, "pipeline SHA differs")
    require(weights_path.stat().st_size == WEIGHTS_BYTES and file_sha(weights_path) == WEIGHTS_SHA, "component full weights SHA differs")
    with weights_path.open("rb") as handle:
        length = struct.unpack("<Q", handle.read(8))[0]
        require(0 < length < 1024 * 1024, "invalid safetensors header size")
        raw = handle.read(length)
    require(hashlib.sha256(raw).hexdigest() == HEADER_SHA, "component header SHA differs")
    header = json.loads(raw)
    header.pop("__metadata__", None)
    require(len(header) == 640, "component must contain exactly 640 keys")
    config_bytes = config_path.read_bytes()
    pipeline_bytes = (root / "pipeline.json").read_bytes()
    require(hashlib.sha256(config_bytes).hexdigest() == CONFIG_SHA
            and hashlib.sha256(pipeline_bytes).hexdigest() == PIPELINE_SHA, "model configuration changed during read")
    model_config = json.loads(config_bytes)
    normalization = json.loads(pipeline_bytes)["args"]["shape_slat_normalization"]
    return model_config, normalization, {"path": str(weights_path.resolve()), "sha256": WEIGHTS_SHA,
                                        "config_sha256": CONFIG_SHA, "pipeline_sha256": PIPELINE_SHA,
                                        "header": header}
