"""Process-local CPU adapter for TRELLIS.2's flex_gemm SparseConv3d API."""
from __future__ import annotations

import math
from types import SimpleNamespace
from typing import Any

import torch
from torch import nn

from .sparse_submanifold_conv3d import sparse_submanifold_conv3d


_INSTALL_MARKER = "_gencuda_trellis_cpu_subm3d_adapter"


def _triple(value: int | tuple[int, int, int] | list[int], name: str) -> tuple[int, int, int]:
    if isinstance(value, int):
        return (value, value, value)
    if isinstance(value, (tuple, list)) and len(value) == 3 and all(
        isinstance(item, int) for item in value
    ):
        return tuple(value)
    raise NotImplementedError(f"TRELLIS CPU sparse adapter requires a 3D integer {name}")


def sparse_conv3d_init(
    module: nn.Module,
    in_channels: int,
    out_channels: int,
    kernel_size: int | tuple[int, int, int] | list[int],
    stride: int | tuple[int, int, int] | list[int] = 1,
    dilation: int | tuple[int, int, int] | list[int] = 1,
    padding: None = None,
    bias: bool = True,
    indice_key: str | None = None,
) -> None:
    """Initialize official SparseConv3d attributes for CPU submanifold use."""
    kernel = _triple(kernel_size, "kernel_size")
    if any(size <= 0 or size % 2 == 0 for size in kernel):
        raise NotImplementedError("TRELLIS CPU sparse adapter requires positive odd kernel_size")
    if _triple(stride, "stride") != (1, 1, 1):
        raise NotImplementedError("TRELLIS CPU sparse adapter only supports stride=1")
    if _triple(dilation, "dilation") != (1, 1, 1):
        raise NotImplementedError("TRELLIS CPU sparse adapter only supports dilation=1")
    if padding is not None:
        raise NotImplementedError("TRELLIS CPU sparse adapter only supports padding=None")
    if indice_key is not None:
        raise NotImplementedError("TRELLIS CPU sparse adapter does not support indice_key")

    module.in_channels = in_channels
    module.out_channels = out_channels
    module.kernel_size = kernel
    module.stride = (1, 1, 1)
    module.dilation = (1, 1, 1)
    module.padding = None
    module.weight = nn.Parameter(
        torch.empty((out_channels, in_channels, *kernel))
        .permute(0, 2, 3, 4, 1)
        .contiguous()
    )
    if bias:
        module.bias = nn.Parameter(torch.empty(out_channels))
    else:
        module.register_parameter("bias", None)
    nn.init.kaiming_uniform_(module.weight, a=math.sqrt(5))
    if module.bias is not None:
        fan_in, _ = nn.init._calculate_fan_in_and_fan_out(module.weight)
        if fan_in:
            bound = 1 / math.sqrt(fan_in)
            nn.init.uniform_(module.bias, -bound, bound)
    setattr(module, _INSTALL_MARKER, True)


def sparse_conv3d_forward(module: nn.Module, x: Any) -> Any:
    """Run an official SparseConv3d through the reference CPU implementation."""
    if not getattr(module, _INSTALL_MARKER, False):
        raise RuntimeError("TRELLIS CPU sparse adapter did not initialize this SparseConv3d")
    if x.feats.device.type != "cpu" or x.coords.device.type != "cpu":
        raise RuntimeError("TRELLIS CPU sparse adapter only accepts CPU SparseTensor data")
    output = sparse_submanifold_conv3d(x.feats, x.coords, module.weight, module.bias)
    return x.replace(output)


def install_trellis_cpu_sparse_conv_adapter() -> None:
    """Install the adapter before constructing an official decoder."""
    from trellis2.modules.sparse import config
    from trellis2.modules.sparse.conv import conv

    if config.CONV != "flex_gemm":
        raise RuntimeError(
            "set SPARSE_CONV_BACKEND=flex_gemm before importing TRELLIS.2"
        )
    backend = conv._backends.get("flex_gemm")
    if backend is not None and not getattr(backend, _INSTALL_MARKER, False):
        raise RuntimeError("TRELLIS flex_gemm backend was initialized before the CPU adapter")
    if backend is None:
        backend = SimpleNamespace(
            sparse_conv3d_init=sparse_conv3d_init,
            sparse_conv3d_forward=sparse_conv3d_forward,
        )
        setattr(backend, _INSTALL_MARKER, True)
        conv._backends["flex_gemm"] = backend
