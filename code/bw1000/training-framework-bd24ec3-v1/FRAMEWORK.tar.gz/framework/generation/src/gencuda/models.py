from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


@dataclass(frozen=True)
class ModelSpec:
    name: str
    family: str
    backend: str
    weights_subdir: str
    precision: str
    rl: str


def load_specs(config_path: Path) -> dict[str, ModelSpec]:
    paths = sorted(config_path.glob("*.yaml")) if config_path.is_dir() else [config_path]
    raw_models: dict[str, Any] = {}
    for path in paths:
        raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        entries = raw.get("models", {})
        if not isinstance(entries, dict):
            raise ValueError(f"models must be a mapping in {path}")
        duplicates = raw_models.keys() & entries.keys()
        if duplicates:
            raise ValueError(f"duplicate model registration: {sorted(duplicates)[0]}")
        raw_models.update(entries)
    return {
        name: ModelSpec(
            name=name,
            family=entry["family"],
            backend=entry["backend"],
            weights_subdir=str(entry["weights_subdir"]),
            precision=entry["precision"],
            rl=entry["rl"],
        )
        for name, entry in raw_models.items()
    }


def get_spec(config_path: Path, name: str) -> ModelSpec:
    specs = load_specs(config_path)
    try:
        return specs[name]
    except KeyError as exc:
        available = ", ".join(sorted(specs))
        raise ValueError(f"unknown model {name!r}; choose one of: {available}") from exc


def resolve_weights(spec: ModelSpec, model_root: Path | None, override: Path | None) -> Path:
    if override is not None:
        return override
    if model_root is None:
        raise RuntimeError("pass --model-root or an explicit --weights path")
    return model_root / spec.weights_subdir
