"""Full completed-optimizer-step checkpoints for Z-Image Turbo SFT training."""
from __future__ import annotations

import math
from typing import Any

from . import hy_resume_checkpoint as common


SCHEMA = "zimage-training-full-optimizer-step-v1"
BOUNDARY = "after-complete-optimizer-step"
IDENTITY_FIELDS = {"config", "source", "data", "model", "runtime", "scheduler"}


class CheckpointValidationError(ValueError):
    """The checkpoint is incompatible or incomplete and was not applied."""


class ResumeApplyFatal(RuntimeError):
    """Checkpoint application failed after preflight; terminate this worker."""


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise CheckpointValidationError(message)


def build_contract(
    *, identity: dict[str, str], seed: int, max_steps: int,
    sample_order: list[str], device_ids: list[int],
) -> dict[str, Any]:
    contract = {
        "backend": "zimage-turbo-training",
        "identity": dict(identity),
        "seed": seed,
        "max_steps": max_steps,
        "sample_order": list(sample_order),
        "device_ids": list(device_ids),
        "seed_formula": "base+global-optimizer-step/v1",
    }
    validate_contract(contract)
    return contract


def validate_contract(contract: dict[str, Any]) -> None:
    expected = {"backend", "identity", "seed", "max_steps", "sample_order", "device_ids", "seed_formula"}
    _require(type(contract) is dict and set(contract) == expected, "Z-Image training checkpoint contract fields mismatch")
    _require(contract["backend"] == "zimage-turbo-training", "checkpoint backend mismatch")
    _require(contract["seed_formula"] == "base+global-optimizer-step/v1", "checkpoint seed formula mismatch")
    _require(type(contract["seed"]) is int and 0 <= contract["seed"] < 2**63, "invalid seed")
    _require(type(contract["max_steps"]) is int and contract["max_steps"] > 0, "invalid max_steps")
    order = contract["sample_order"]
    _require(type(order) is list and order and all(type(item) is str and item for item in order), "invalid sample order")
    _require(len(set(order)) == len(order), "duplicate sample identifiers")
    _require(contract["device_ids"] in ([], [0]), "Z-Image training resume requires exactly CUDA device 0")
    identity = contract["identity"]
    _require(type(identity) is dict and set(identity) == IDENTITY_FIELDS, "identity fields mismatch")
    for value in identity.values():
        _require(type(value) is str and len(value) == 64 and all(item in "0123456789abcdef" for item in value), "invalid identity SHA")


def boundary_metadata(contract: dict[str, Any], global_step: int) -> dict[str, Any]:
    validate_contract(contract)
    _require(type(global_step) is int and 1 <= global_step <= contract["max_steps"], "checkpoint is not at a completed optimizer step")
    return {
        "schema": SCHEMA,
        "boundary": BOUNDARY,
        "contract": contract,
        "global_step": global_step,
        "completed_optimizer_steps": global_step,
        "next_global_step": global_step + 1,
        "next_data_cursor": global_step % len(contract["sample_order"]),
    }


def next_coordinate(metadata: dict[str, Any]) -> dict[str, Any] | None:
    contract = metadata["contract"]
    if metadata["global_step"] == contract["max_steps"]:
        return None
    cursor = metadata["next_data_cursor"]
    return {
        "global_step": metadata["next_global_step"],
        "sample_cursor": cursor,
        "sample_id": contract["sample_order"][cursor],
        "step_seed": contract["seed"] + metadata["next_global_step"],
    }


def _scheduler_value(value: Any) -> Any:
    if callable(value):
        return {"callable": [value.__module__, value.__qualname__]}
    return common.cpu_tree(value)


def _is_callable_description(value: Any) -> bool:
    return type(value) is dict and set(value) == {"callable"} and type(value["callable"]) is list


def scheduler_spec(scheduler: Any) -> dict[str, Any]:
    values = {name: _scheduler_value(value) for name, value in vars(scheduler).items()}
    _require(values, "Z-Image training scheduler has no state")
    return values


def _validate_scheduler(saved: dict[str, Any], expected: dict[str, Any]) -> None:
    _require(type(saved) is dict and set(saved) == set(expected), "scheduler fields mismatch")
    _require(common.tree_sha256(saved) == common.tree_sha256(expected), "scheduler state or implementation mismatch")


def restore_scheduler(scheduler: Any, expected: dict[str, Any]) -> None:
    """Restore the training scheduler after an inference-only Turbo render."""
    current = scheduler_spec(scheduler)
    for name, value in expected.items():
        if _is_callable_description(value):
            _require(current.get(name) == value, "scheduler callable implementation mismatch")
    for name in set(current) - set(expected):
        delattr(scheduler, name)
    for name, value in expected.items():
        if not _is_callable_description(value):
            setattr(scheduler, name, common.cpu_tree(value))
    _validate_scheduler(scheduler_spec(scheduler), expected)


def make_payload(
    *, contract: dict[str, Any], global_step: int, model: Any, optimizer: Any,
    optimizer_progress: dict[str, int], scheduler: Any, expected_scheduler: dict[str, Any],
) -> dict[str, Any]:
    scheduler = scheduler_spec(scheduler)
    _validate_scheduler(scheduler, expected_scheduler)
    payload = {
        "metadata": boundary_metadata(contract, global_step),
        "state": common.capture_model_state(model, optimizer, optimizer_progress),
        "scheduler": scheduler,
        "lr_scheduler": None,
        "rng": common.capture_rng(contract["device_ids"]),
    }
    payload["adapter_sha256"] = common.tree_sha256(payload["state"]["trainable"])
    payload["integrity_sha256"] = common.tree_sha256(payload)
    validate_checkpoint(payload, contract, model, optimizer, expected_scheduler, native_rng=False)
    return payload


def validate_checkpoint(
    payload: dict[str, Any], contract: dict[str, Any], model: Any, optimizer: Any,
    expected_scheduler: dict[str, Any], *, native_rng: bool,
) -> dict[str, Any]:
    expected_fields = {"metadata", "state", "scheduler", "lr_scheduler", "rng", "adapter_sha256", "integrity_sha256"}
    _require(type(payload) is dict and set(payload) == expected_fields, "not a full Z-Image training checkpoint")
    unsigned = {key: value for key, value in payload.items() if key != "integrity_sha256"}
    _require(payload["integrity_sha256"] == common.tree_sha256(unsigned), "checkpoint integrity mismatch")
    metadata = payload["metadata"]
    _require(type(metadata) is dict and metadata.get("contract") == contract, "checkpoint identity or schedule mismatch")
    _require(metadata == boundary_metadata(contract, metadata.get("global_step")), "checkpoint step or data cursor mismatch")
    common.validate_model_state(payload["state"], model, optimizer, metadata["global_step"])
    _validate_scheduler(payload["scheduler"], expected_scheduler)
    _require(payload["lr_scheduler"] is None, "Z-Image training does not support a learning-rate scheduler")
    _require(payload["adapter_sha256"] == common.tree_sha256(payload["state"]["trainable"]), "adapter SHA mismatch")
    rng_validation = common.validate_rng(payload["rng"], contract["device_ids"], native=native_rng)
    return {"metadata": metadata, "next": next_coordinate(metadata), "rng_validation": rng_validation}


def restore_checkpoint(
    payload: dict[str, Any], contract: dict[str, Any], model: Any, optimizer: Any,
    scheduler: Any, expected_scheduler: dict[str, Any],
) -> tuple[dict[str, int], dict[str, Any]]:
    checked = validate_checkpoint(payload, contract, model, optimizer, expected_scheduler, native_rng=True)
    try:
        common._copy_model_state(payload["state"], model, optimizer)
        restore_scheduler(scheduler, payload["scheduler"])
        common._restore_rng(payload["rng"], contract["device_ids"])
    except Exception as error:
        setattr(model, "_zimage_training_resume_poisoned", True)
        raise ResumeApplyFatal("checkpoint application failed; terminate this worker") from error
    return dict(payload["state"]["optimizer_progress"]), checked


def assert_restored_boundary(
    payload: dict[str, Any], model: Any, optimizer: Any, optimizer_progress: dict[str, int],
    scheduler: Any, device_ids: list[int],
) -> None:
    observed = {
        "state": common.capture_model_state(model, optimizer, optimizer_progress),
        "scheduler": scheduler_spec(scheduler),
        "lr_scheduler": None,
        "rng": common.capture_rng(device_ids),
    }
    expected = {key: payload[key] for key in observed}
    _require(common.tree_sha256(observed) == common.tree_sha256(expected), "restored boundary differs from checkpoint")


def save_atomic(path: Any, payload: dict[str, Any]) -> None:
    common.save_atomic(path, payload)


def load_checkpoint(path: Any) -> dict[str, Any]:
    return common.load_checkpoint(path)


def _require_sha256(value: Any, message: str) -> None:
    _require(
        type(value) is str
        and len(value) == 64
        and all(character in "0123456789abcdef" for character in value),
        message,
    )


def _validate_cpu_tensor(value: Any, label: str, *, shape: Any = None, dtype: Any = None) -> None:
    import torch

    _require(
        isinstance(value, torch.Tensor)
        and value.device.type == "cpu"
        and not value.requires_grad
        and value.layout == torch.strided,
        f"invalid {label} tensor",
    )
    if shape is not None:
        _require(value.shape == shape and value.dtype == dtype, f"{label} shape or dtype mismatch")
    if value.is_floating_point() or value.is_complex():
        _require(bool(torch.isfinite(value).all()), f"non-finite {label} tensor")


def _validate_preflight_tensor_mapping(value: Any, label: str, *, nonempty: bool) -> dict[str, Any]:
    _require(type(value) is dict and (value or not nonempty), f"checkpoint {label} is empty or malformed")
    _require(all(type(name) is str and name for name in value), f"checkpoint {label} names are malformed")
    for name, tensor in value.items():
        _validate_cpu_tensor(tensor, f"{label}/{name}")
    return value


def _adamw_group_template(config: dict[str, Any]) -> dict[str, Any]:
    import torch

    learning_rate = config.get("learning_rate", 1e-4)
    weight_decay = config.get("weight_decay", 0.01)
    _require(
        type(learning_rate) in (int, float)
        and math.isfinite(float(learning_rate))
        and float(learning_rate) >= 0.0,
        "requested Z-Image learning_rate is invalid",
    )
    _require(
        type(weight_decay) in (int, float)
        and math.isfinite(float(weight_decay))
        and float(weight_decay) >= 0.0,
        "requested Z-Image weight_decay is invalid",
    )
    parameter = torch.nn.Parameter(torch.zeros((), dtype=torch.float32))
    group = torch.optim.AdamW(
        [parameter], lr=float(learning_rate), weight_decay=float(weight_decay)
    ).state_dict()["param_groups"][0]
    return {key: value for key, value in group.items() if key != "params"}


def _validate_preflight_model_state(
    state: Any, global_step: int, expected_group: dict[str, Any], device_ids: list[int]
) -> None:
    """Validate checkpoint-internal state without importing the training stack."""
    import torch

    expected_fields = {
        "trainable",
        "buffers",
        "modes",
        "optimizer",
        "optimizer_parameter_names",
        "optimizer_placements",
        "optimizer_implementation",
        "optimizer_progress",
    }
    _require(type(state) is dict and set(state) == expected_fields, "checkpoint model state fields mismatch")
    trainable = _validate_preflight_tensor_mapping(state["trainable"], "trainable state", nonempty=True)
    _validate_preflight_tensor_mapping(state["buffers"], "buffer state", nonempty=False)
    modes = state["modes"]
    _require(type(modes) is dict and modes and all(type(name) is str and type(value) is bool for name, value in modes.items()), "checkpoint module modes are malformed")

    implementation = state["optimizer_implementation"]
    _require(
        type(implementation) is dict
        and set(implementation) == {"module", "qualname", "source_sha256", "torch_version"}
        and all(type(implementation[name]) is str and implementation[name] for name in ("module", "qualname", "torch_version")),
        "checkpoint AdamW implementation is malformed",
    )
    _require_sha256(implementation["source_sha256"], "checkpoint AdamW source SHA is malformed")

    names = state["optimizer_parameter_names"]
    _require(type(names) is list and names and all(type(group) is list and group for group in names), "checkpoint optimizer parameter names are malformed")
    flattened_names = [name for group in names for name in group]
    _require(
        all(type(name) is str and name for name in flattened_names)
        and len(flattened_names) == len(set(flattened_names))
        and set(flattened_names) == set(trainable),
        "checkpoint optimizer parameter names do not match trainable state",
    )
    progress = state["optimizer_progress"]
    _require(
        type(progress) is dict
        and set(progress) == set(flattened_names)
        and all(type(value) is int and 0 <= value <= global_step for value in progress.values()),
        "checkpoint optimizer progress is malformed",
    )

    optimizer = state["optimizer"]
    _require(type(optimizer) is dict and set(optimizer) == {"state", "param_groups"}, "checkpoint optimizer state is malformed")
    groups = optimizer["param_groups"]
    _require(type(groups) is list and len(groups) == len(names), "checkpoint optimizer group count mismatch")
    parameter_by_id: dict[int, tuple[str, Any]] = {}
    for group, group_names in zip(groups, names):
        _require(
            type(group) is dict and set(group) == set(expected_group) | {"params"},
            "checkpoint AdamW parameter-group fields mismatch",
        )
        _require(
            common.tree_sha256({key: value for key, value in group.items() if key != "params"})
            == common.tree_sha256(expected_group),
            "checkpoint AdamW hyperparameters differ from requested configuration",
        )
        parameter_ids = group["params"]
        _require(
            type(parameter_ids) is list
            and len(parameter_ids) == len(group_names)
            and all(type(item) is int and item >= 0 for item in parameter_ids),
            "checkpoint AdamW parameter IDs are malformed",
        )
        for parameter_id, name in zip(parameter_ids, group_names):
            _require(parameter_id not in parameter_by_id, "checkpoint AdamW has duplicate parameter IDs")
            parameter_by_id[parameter_id] = (name, trainable[name])
    expected_state_ids = {
        parameter_id
        for parameter_id, (name, _tensor) in parameter_by_id.items()
        if progress[name] > 0
    }
    saved_state = optimizer["state"]
    _require(type(saved_state) is dict and set(saved_state) == expected_state_ids, "checkpoint AdamW moment entries mismatch")
    placements = state["optimizer_placements"]
    _require(type(placements) is dict and set(placements) == expected_state_ids, "checkpoint AdamW placement entries mismatch")
    for parameter_id, values in saved_state.items():
        _require(type(values) is dict, "checkpoint AdamW moment entry is malformed")
        group = next(group for group in groups if parameter_id in group["params"])
        expected_keys = {"step", "exp_avg", "exp_avg_sq"} | ({"max_exp_avg_sq"} if group.get("amsgrad") else set())
        _require(set(values) == expected_keys, "checkpoint AdamW moment fields mismatch")
        placement = placements[parameter_id]
        _require(type(placement) is dict and set(placement) == expected_keys, "checkpoint AdamW placement is malformed")
        name, parameter = parameter_by_id[parameter_id]
        parameter_device = "cuda:0" if device_ids == [0] else "cpu"
        _require(
            placement["step"] in {"cpu", parameter_device}
            and all(placement[key] == parameter_device for key in expected_keys - {"step"}),
            "checkpoint AdamW placement device mismatch",
        )
        step = values["step"]
        _validate_cpu_tensor(step, f"AdamW step/{name}")
        _require(
            step.shape == torch.Size([])
            and step.dtype == torch.float32
            and float(step.item()).is_integer()
            and int(step.item()) == progress[name],
            "checkpoint AdamW step does not match optimizer progress",
        )
        for key in expected_keys - {"step"}:
            value = values[key]
            _validate_cpu_tensor(value, f"AdamW {key}/{name}", shape=parameter.shape, dtype=parameter.dtype)
            if key in {"exp_avg_sq", "max_exp_avg_sq"}:
                _require(bool((value >= 0).all()), f"checkpoint AdamW {key} is negative")


def _validate_preflight_scheduler(scheduler: Any) -> None:
    _require(type(scheduler) is dict and scheduler, "checkpoint scheduler state is malformed")
    for name, value in scheduler.items():
        _require(type(name) is str and name, "checkpoint scheduler field name is malformed")
        if _is_callable_description(value):
            callable_description = value["callable"]
            _require(
                len(callable_description) == 2 and all(type(item) is str and item for item in callable_description),
                "checkpoint scheduler callable is malformed",
            )
        else:
            try:
                common.cpu_tree(value)
            except Exception as error:
                raise CheckpointValidationError("checkpoint scheduler has unsupported values") from error


def _requested_schedule(config: dict[str, Any]) -> tuple[int, int]:
    seed = config.get("seed", 42)
    max_steps = config.get("max_steps", 20)
    _require(type(seed) is int and 0 <= seed < 2**63, "requested Z-Image seed is invalid")
    _require(type(max_steps) is int and max_steps > 0, "requested Z-Image max_steps is invalid")
    return seed, max_steps


def preflight_checkpoint(payload: Any, *, requested_config: dict[str, Any]) -> None:
    """Reject malformed serialized checkpoints before model or CUDA setup."""
    expected_fields = {"metadata", "state", "scheduler", "lr_scheduler", "rng", "adapter_sha256", "integrity_sha256"}
    _require(type(payload) is dict and set(payload) == expected_fields, "not a full Z-Image training checkpoint")
    unsigned = {key: value for key, value in payload.items() if key != "integrity_sha256"}
    _require(payload["integrity_sha256"] == common.tree_sha256(unsigned), "checkpoint integrity mismatch")
    metadata = payload["metadata"]
    _require(type(metadata) is dict and type(metadata.get("contract")) is dict, "checkpoint metadata is malformed")
    contract = metadata["contract"]
    validate_contract(contract)
    _require(metadata == boundary_metadata(contract, metadata.get("global_step")), "checkpoint step or data cursor mismatch")
    _require(type(requested_config) is dict, "requested Z-Image configuration is malformed")
    if requested_config.get("lr_scheduler") is not None:
        raise CheckpointValidationError("Z-Image training does not support a learning-rate scheduler")
    expected_group = _adamw_group_template(requested_config)
    _validate_preflight_model_state(payload["state"], metadata["global_step"], expected_group, contract["device_ids"])
    _validate_preflight_scheduler(payload["scheduler"])
    _require(
        contract["identity"]["scheduler"] == common.tree_sha256(payload["scheduler"]),
        "checkpoint scheduler does not match contract identity",
    )
    _require(payload["lr_scheduler"] is None, "Z-Image training does not support a learning-rate scheduler")
    _require_sha256(payload["adapter_sha256"], "checkpoint adapter SHA is malformed")
    _require(payload["adapter_sha256"] == common.tree_sha256(payload["state"]["trainable"]), "adapter SHA mismatch")
    try:
        common.validate_rng(payload["rng"], contract["device_ids"], native=False)
    except common.CheckpointValidationError as error:
        raise CheckpointValidationError(str(error)) from error
    seed, max_steps = _requested_schedule(requested_config)
    _require(contract["seed"] == seed, "checkpoint seed does not match requested configuration")
    _require(contract["max_steps"] == max_steps, "checkpoint max_steps does not match requested configuration")
    _require(metadata["global_step"] < max_steps, "checkpoint already completed the configured schedule")
