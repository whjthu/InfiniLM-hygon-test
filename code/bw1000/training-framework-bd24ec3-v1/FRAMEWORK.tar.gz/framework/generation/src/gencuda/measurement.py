"""CLI-owned qualification for backend post-warmup measurement windows."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Mapping, MutableMapping


MEASUREMENT_VERSION = "cli-measurement-v1"
MEASUREMENT_SCOPE = "current_invocation_post_warmup_through_validated_manifest"
MEASUREMENT_UNITS = {"optimizer_steps", "policy_updates", "reconstructions"}


@dataclass(frozen=True)
class MeasurementWindow:
    start_monotonic: float
    work_units: float
    unit: str


def _finite_number(value: Any, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"measurement_window.{label} must be a finite number")
    converted = float(value)
    if not math.isfinite(converted):
        raise ValueError(f"measurement_window.{label} must be a finite number")
    return converted


def consume_backend_window(
    result: MutableMapping[str, Any], *, recovery_enabled: bool, t0: float, t1: float
) -> MeasurementWindow | None:
    """Remove a backend-only window after the backend returns, before manifest merging."""
    value = result.pop("measurement_window", None)
    if recovery_enabled:
        if value is not None:
            raise ValueError("measurement_window is forbidden when recovery validation is enabled")
        return None
    if value is None:
        return None
    if not isinstance(value, Mapping) or set(value) != {"start_monotonic", "work_units", "unit"}:
        raise ValueError("measurement_window fields mismatch")
    start = _finite_number(value["start_monotonic"], "start_monotonic")
    units = _finite_number(value["work_units"], "work_units")
    unit = value["unit"]
    if not isinstance(unit, str) or unit not in MEASUREMENT_UNITS:
        raise ValueError("measurement_window.unit is unsupported")
    if units <= 0.0:
        raise ValueError("measurement_window.work_units must be positive")
    if not all(math.isfinite(value) for value in (t0, t1)) or t0 > start or start > t1:
        raise ValueError("measurement_window.start_monotonic is outside backend execution")
    return MeasurementWindow(start, units, unit)


def stamp_completed_measurement(
    manifest: MutableMapping[str, Any],
    window: MeasurementWindow | None,
    *,
    recovery_enabled: bool,
    t0: float,
    t1: float,
    t3: float,
) -> None:
    """Persist qualification after the timed validated-manifest write has completed."""
    if not all(math.isfinite(value) for value in (t0, t1, t3)) or not t0 <= t1 < t3:
        raise ValueError("measurement clock ordering is invalid")
    metrics = manifest.setdefault("metrics", {})
    if not isinstance(metrics, MutableMapping):
        raise ValueError("manifest metrics must be mutable")
    metrics.update(
        {
            "measurement_version": MEASUREMENT_VERSION,
            "measurement_scope": MEASUREMENT_SCOPE,
            "outer_end_to_end_seconds": t3 - t0,
            # This stamp is intentionally outside measurement_duration_seconds.
            "measurement_final_metadata_stamp_excluded": True,
        }
    )
    if recovery_enabled:
        metrics.update(
            {
                "measurement_qualification": "UNAVAILABLE",
                "measurement_unavailable_reason": "recovery_validation_enabled",
                "measurement_duration_seconds": None,
                "measurement_work_units": None,
                "measurement_unit": None,
                "measurement_rate_per_second": None,
            }
        )
        return
    if window is None:
        metrics.update(
            {
                "measurement_qualification": "UNAVAILABLE",
                "measurement_unavailable_reason": "backend_did_not_emit_measurement_window",
                "measurement_duration_seconds": None,
                "measurement_work_units": None,
                "measurement_unit": None,
                "measurement_rate_per_second": None,
            }
        )
        return
    duration = t3 - window.start_monotonic
    if not math.isfinite(duration) or duration <= 0.0:
        raise ValueError("measurement duration is invalid")
    metrics.update(
        {
            "measurement_qualification": "QUALIFIED",
            "measurement_duration_seconds": duration,
            "measurement_work_units": window.work_units,
            "measurement_unit": window.unit,
            "measurement_rate_per_second": window.work_units / duration,
        }
    )


def stamp_failed_measurement(manifest: MutableMapping[str, Any]) -> None:
    metrics = manifest.setdefault("metrics", {})
    if not isinstance(metrics, MutableMapping):
        return
    metrics.update(
        {
            "measurement_version": MEASUREMENT_VERSION,
            "measurement_scope": MEASUREMENT_SCOPE,
            "measurement_qualification": "FAILED",
            "measurement_final_metadata_stamp_excluded": True,
            "measurement_duration_seconds": None,
            "measurement_work_units": None,
            "measurement_unit": None,
            "measurement_rate_per_second": None,
        }
    )
