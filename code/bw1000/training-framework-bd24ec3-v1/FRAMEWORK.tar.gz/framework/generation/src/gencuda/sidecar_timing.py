"""Wall-time and host-memory observations without device synchronization."""

from __future__ import annotations

import json
import math
import os
import sys
from pathlib import Path
from time import perf_counter
from typing import Any, Callable


def read_host_memory() -> dict[str, Any]:
    result: dict[str, Any] = {
        "rss_bytes": None, "process_peak_rss_bytes": None, "errors": [],
    }
    if not sys.platform.startswith("linux"):
        result["errors"].append("Linux host-memory accounting is unavailable")
        return result
    try:
        fields = Path("/proc/self/statm").read_text(encoding="ascii").split()
        result["rss_bytes"] = int(fields[1]) * os.sysconf("SC_PAGE_SIZE")
    except (OSError, ValueError, IndexError) as exc:
        result["errors"].append(f"instant RSS: {type(exc).__name__}: {exc}")
    try:
        import resource

        result["process_peak_rss_bytes"] = int(
            resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
        )
    except (ImportError, OSError, ValueError) as exc:
        result["errors"].append(f"process peak RSS: {type(exc).__name__}: {exc}")
    return result


class SidecarTiming:
    """Record consecutive, nonoverlapping segments of an existing sidecar."""

    def __init__(self, *, clock: Callable[[], float] = perf_counter,
                 memory_reader: Callable[[], dict[str, Any]] = read_host_memory):
        self._clock = clock
        self._memory_reader = memory_reader
        self._started = clock()
        self._memory_before = self._memory()
        self._previous = clock()
        self._records: list[dict[str, Any]] = []
        self._finished = False

    def _memory(self) -> dict[str, Any]:
        try:
            value = self._memory_reader()
            for key in ("rss_bytes", "process_peak_rss_bytes"):
                number = value.get(key)
                if number is not None and (type(number) is not int or number < 0):
                    raise ValueError(f"invalid {key}")
            return value
        except Exception as exc:
            return {"rss_bytes": None, "process_peak_rss_bytes": None,
                    "errors": [f"memory reader: {type(exc).__name__}: {exc}"]}

    def mark(self, name: str, execution: str) -> None:
        if self._finished or any(row["name"] == name for row in self._records):
            raise ValueError("phase already completed")
        if execution not in {"cpu", "cuda", "transfer", "mixed"}:
            raise ValueError("unknown execution scope")
        ended = self._clock()
        elapsed = ended - self._previous
        if not math.isfinite(elapsed) or elapsed < 0:
            raise ValueError("non-monotonic phase clock")
        self._records.append({"name": name, "execution": execution,
                              "seconds": elapsed, "memory_after": self._memory()})
        self._previous = self._clock()

    def finish(self, *, status: str, error: str | None = None) -> dict[str, Any]:
        if self._finished or status not in {"completed", "failed"}:
            raise ValueError("invalid timing completion")
        ended = self._clock()
        elapsed = ended - self._started
        covered = sum(row["seconds"] for row in self._records)
        if not math.isfinite(elapsed) or elapsed < covered:
            raise ValueError("invalid outer timing window")
        self._finished = True
        memory_after = self._memory()
        samples = [self._memory_before, memory_after]
        samples.extend(row["memory_after"] for row in self._records)
        rss = [item["rss_bytes"] for item in samples if item.get("rss_bytes") is not None]
        return {
            "schema_version": 1, "status": status, "error": error,
            "wall_seconds": elapsed, "covered_seconds": covered,
            "unattributed_seconds": elapsed - covered,
            "phases": list(self._records), "memory_before": self._memory_before,
            "memory_after": memory_after,
            "sampled_max_rss_bytes": max(rss) if rss else None,
            "memory_scope": "process-wide; sampled RSS is not a true phase peak",
            "timing_scope": "host wall time; only existing device synchronizations",
        }


def record_sidecar_failure(trace: SidecarTiming, output: Path, error: BaseException) -> None:
    """Best-effort diagnostic output; never replace the model's original error."""
    try:
        report = trace.finish(status="failed", error=f"{type(error).__name__}: {error}")
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("x", encoding="utf-8") as handle:
            json.dump(report, handle, indent=2, sort_keys=True, allow_nan=False)
            handle.write("\n")
    except Exception:
        pass
