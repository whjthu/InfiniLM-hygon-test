from __future__ import annotations

import json
import statistics
import sys
from pathlib import Path
from time import perf_counter, time
from typing import Any

from ..manifest import sha256_path
from ..runtime import autocast_bf16, require_cuda, synchronize


def _benchmark_image_paths(config: dict[str, Any], count: int) -> list[Path]:
    manifest = config.get("sample_manifest")
    if not manifest:
        return [Path(path) for path in config.get("image_paths", [])]
    records = [
        json.loads(line)
        for line in Path(manifest).read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if len(records) < count:
        raise RuntimeError(f"VGGT benchmark needs {count} images, found {len(records)}")
    return [Path(record["image"]) for record in records[:count]]


def run_vggt_inference(
    weights: Path, config: dict[str, Any], output_dir: Path, source_root: Path | None = None
) -> dict[str, Any]:
    if not weights.is_dir():
        raise RuntimeError(f"weights are missing: {weights}")
    if source_root is None:
        raise RuntimeError("VGGT source root must be supplied by the command dispatcher")
    if not source_root.is_dir():
        raise RuntimeError(f"VGGT source is missing: {source_root}")
    sys.path.insert(0, str(source_root))
    from vggt.models.vggt import VGGT
    from vggt.utils.load_fn import load_and_preprocess_images

    warmup_samples = int(config.get("warmup_samples", 0))
    measurement_samples = int(config.get("measurement_samples", 1))
    if warmup_samples < 0 or measurement_samples < 1:
        raise ValueError("warmup_samples must be non-negative and measurement_samples must be positive")
    image_paths = _benchmark_image_paths(config, warmup_samples + measurement_samples)
    if not image_paths or not all(path.is_file() for path in image_paths):
        raise RuntimeError("vggt image_paths must contain existing image files")
    torch = require_cuda()
    raw_state = torch.load(weights / "model.pt", map_location="cpu", weights_only=True)
    state = raw_state.get("model", raw_state) if isinstance(raw_state, dict) else raw_state
    model = VGGT()
    model.load_state_dict(state, strict=True)
    model.to("cuda").eval()
    output_dir.mkdir(parents=True, exist_ok=True)
    if warmup_samples == 0 and measurement_samples == 1:
        batches = [image_paths]
    else:
        batches = [[path] for path in image_paths]
    measured_seconds: list[float] = []
    step_records: list[dict[str, Any]] = []
    torch.cuda.reset_peak_memory_stats()
    predictions = None
    finite = True
    for index, batch_paths in enumerate(batches):
        images = load_and_preprocess_images([str(path) for path in batch_paths]).to("cuda")
        synchronize()
        started_unix = time()
        started = perf_counter()
        with torch.no_grad(), autocast_bf16():
            predictions = model(images)
        synchronize()
        elapsed = perf_counter() - started
        step_records.append(
            {
                "ended_unix": time(),
                "image": str(batch_paths[0]) if len(batch_paths) == 1 else [str(path) for path in batch_paths],
                "index": index,
                "started_unix": started_unix,
                "step_seconds": elapsed,
                "warmup": index < warmup_samples,
            }
        )
        if index >= warmup_samples:
            measured_seconds.append(elapsed)
            finite = finite and all(
                bool(torch.isfinite(value).all().item())
                for value in predictions.values()
                if hasattr(value, "detach") and value.is_floating_point()
            )
    if predictions is None:
        raise RuntimeError("VGGT produced no predictions")
    summary = {
        name: list(value.shape) if hasattr(value, "shape") else {"type": type(value).__name__}
        for name, value in predictions.items()
    }
    (output_dir / "predictions.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    output_path = output_dir / "predictions.pt"
    torch.save(
        {name: value.detach().cpu() for name, value in predictions.items() if hasattr(value, "detach")},
        output_path,
    )
    step_path = output_dir / "steps.ndjson"
    step_path.write_text(
        "".join(json.dumps(record, sort_keys=True) + "\n" for record in step_records),
        encoding="utf-8",
    )
    benchmark = {
        "forward_seconds": measured_seconds,
        "measurement_samples": measurement_samples,
        "seconds_max": max(measured_seconds),
        "seconds_median": statistics.median(measured_seconds),
        "seconds_min": min(measured_seconds),
        "warmup_samples": warmup_samples,
    }
    benchmark_path = output_dir / "benchmark.json"
    benchmark_path.write_text(json.dumps(benchmark, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    artifacts = [
        {"path": str(output_path), "sha256": sha256_path(output_path)},
        {"path": str(output_dir / "predictions.json"), "sha256": sha256_path(output_dir / "predictions.json")},
        {"path": str(benchmark_path), "sha256": sha256_path(benchmark_path)},
        {"path": str(step_path), "sha256": sha256_path(step_path)},
    ]
    return {
        "artifact": output_path,
        "artifacts": artifacts,
        "checks": {
            "finite_tensors": finite,
            "main_forward_device": "cuda",
        },
        "observations": {"unique_images": len(set(image_paths)) == len(image_paths)},
        "logs": [
            {"path": str(step_path), "sha256": sha256_path(step_path)},
            {"path": str(benchmark_path), "sha256": sha256_path(benchmark_path)},
        ],
        "metrics": {
            "measurement_samples": measurement_samples,
            "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
            "samples_per_second": measurement_samples / sum(measured_seconds),
            "seconds_max": max(measured_seconds),
            "seconds_median": statistics.median(measured_seconds),
            "seconds_min": min(measured_seconds),
            "warmup_samples": warmup_samples,
            "warmup_steps": warmup_samples,
        },
        "stage_timings": {"forward_seconds": measured_seconds},
    }
