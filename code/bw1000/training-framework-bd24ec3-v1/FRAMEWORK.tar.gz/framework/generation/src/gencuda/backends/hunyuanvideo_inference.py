from __future__ import annotations

import hashlib
import json
import os
try:
    import resource
except ModuleNotFoundError:  # Windows can inspect the CLI but cannot run an CUDA backend.
    resource = None
import statistics
import sys
from pathlib import Path
from time import perf_counter, time
from typing import Any

import numpy as np

from ..manifest import sha256_path
from ..runtime import memory_stats, require_cuda, synchronize


def video_tensor_to_uint8(video: Any) -> np.ndarray:
    array = video.detach().cpu().float().numpy()
    if array.ndim == 5:
        if array.shape[0] != 1:
            raise RuntimeError(f"expected one generated video, got shape {array.shape}")
        array = array[0]
    if array.ndim != 4 or array.shape[0] != 3:
        raise RuntimeError(f"expected C,F,H,W video tensor, got shape {array.shape}")
    if not np.isfinite(array).all():
        raise RuntimeError("HunyuanVideo returned non-finite pixels")
    return np.rint(np.clip(array, 0.0, 1.0) * 255.0).astype(np.uint8).transpose(1, 2, 3, 0)


def _array_sha(value: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()


def _repeat_determinism(values: list[str], benchmark_mode: bool) -> bool | None:
    if benchmark_mode or len(values) < 2:
        return None
    return len(set(values)) == 1


def _checks_pass(checks: dict[str, bool | None]) -> bool:
    return all(value is None or bool(value) for value in checks.values())


def _init_nccl(torch: Any, output_dir: Path) -> tuple[bool, Path]:
    if torch.distributed.is_initialized():
        return False, output_dir / "existing-process-group"
    rendezvous = output_dir / "nccl-rendezvous"
    rendezvous.parent.mkdir(parents=True, exist_ok=True)
    rendezvous.unlink(missing_ok=True)
    torch.distributed.init_process_group(
        backend="nccl",
        init_method=f"file://{rendezvous}",
        rank=0,
        world_size=1,
    )
    return True, rendezvous


def run_hunyuanvideo_inference(
    weights: Path,
    config: dict[str, Any],
    output_dir: Path,
    source_root: Path,
) -> dict[str, Any]:
    if not weights.is_dir():
        raise RuntimeError(f"HunyuanVideo weights are missing: {weights}")
    if not source_root.is_dir():
        raise RuntimeError(f"HunyuanVideo source is missing: {source_root}")
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    torch = require_cuda()
    output_dir.mkdir(parents=True, exist_ok=True)
    created_group, rendezvous = _init_nccl(torch, output_dir)
    sys.path.insert(0, str(source_root))

    try:
        from hyvideo.commons.parallel_states import initialize_parallel_state
        from hyvideo.pipelines.hunyuan_video_pipeline import HunyuanVideo_1_5_Pipeline

        initialize_parallel_state(sp=1)
        torch.cuda.reset_peak_memory_stats()
        load_started = perf_counter()
        pipe = HunyuanVideo_1_5_Pipeline.create_pipeline(
            pretrained_model_name_or_path=str(weights),
            transformer_version=str(config.get("transformer_version", "480p_t2v_distilled")),
            create_sr_pipeline=False,
            transformer_dtype=torch.bfloat16,
            device=torch.device("cuda"),
            transformer_init_device=torch.device("cuda"),
        )
        pipe.apply_infer_optimization(
            infer_state=None,
            enable_offloading=False,
            enable_group_offloading=False,
            overlap_group_offloading=False,
        )
        pipe.transformer.set_attn_mode("torch")
        pipe.transformer.eval()
        load_seconds = perf_counter() - load_started

        forward_input_devices: list[str] = []
        forward_output_devices: list[str] = []

        def capture_input(_module: Any, inputs: tuple[Any, ...]) -> None:
            tensors = [item for item in inputs if hasattr(item, "device")]
            forward_input_devices.append(str(tensors[0].device) if tensors else "missing")

        def capture_output(_module: Any, _inputs: tuple[Any, ...], output: Any) -> None:
            value = output[0] if isinstance(output, (tuple, list)) else output
            forward_output_devices.append(str(getattr(value, "device", "missing")))

        pre_handle = pipe.transformer.register_forward_pre_hook(capture_input)
        post_handle = pipe.transformer.register_forward_hook(capture_output)
        warmup_steps = int(config.get("warmup_iterations", 0))
        measure_steps = int(config.get("measure_iterations", 0))
        benchmark_mode = measure_steps > 0
        pipe.validate_finite = not benchmark_mode
        repeat_count = warmup_steps + measure_steps if benchmark_mode else int(config.get("repeats", 2))
        prompt = str(config["prompt"])
        seed = int(config.get("seed", 42))
        generation_runs: list[dict[str, Any]] = []
        artifacts: list[dict[str, Any]] = []
        frame_shas: list[str] = []

        import imageio.v2 as imageio

        for index in range(repeat_count):
            synchronize()
            started_unix = time()
            started = perf_counter()
            result = pipe(
                prompt=prompt,
                aspect_ratio=str(config.get("aspect_ratio", "16:9")),
                video_length=int(config.get("frames", 9)),
                prompt_rewrite=False,
                num_inference_steps=int(config.get("num_inference_steps", 4)),
                enable_sr=False,
                seed=seed,
                output_type="pt",
                return_dict=True,
                enable_vae_tile_parallelism=bool(config.get("vae_tile_parallelism", False)),
            )
            synchronize()
            generation_seconds = perf_counter() - started
            ended_unix = time()
            frames = video_tensor_to_uint8(result.videos)
            frame_sha = _array_sha(frames)
            frame_shas.append(frame_sha)
            output_path = output_dir / f"video-{index + 1}.mp4"
            encode_started = perf_counter()
            imageio.mimwrite(
                output_path,
                frames,
                fps=int(config.get("fps", 8)),
                codec="libx264",
                quality=8,
                macro_block_size=None,
            )
            encode_seconds = perf_counter() - encode_started
            if output_path.stat().st_size <= 0 or b"ftyp" not in output_path.read_bytes()[:64]:
                raise RuntimeError(f"invalid MP4 artifact: {output_path}")
            artifact = {"path": str(output_path), "sha256": sha256_path(output_path)}
            artifacts.append(artifact)
            generation_runs.append(
                {
                    "index": index,
                    "generation_seconds": generation_seconds,
                    "cpu_mp4_encode_seconds": encode_seconds,
                    "started_unix": started_unix,
                    "ended_unix": ended_unix,
                    "shape_fhwc": list(frames.shape),
                    "frame_sha256": frame_sha,
                    "artifact": artifact,
                }
            )
        pre_handle.remove()
        post_handle.remove()

        deterministic = _repeat_determinism(frame_shas, benchmark_mode)
        measured = generation_runs[warmup_steps:] if benchmark_mode else generation_runs
        generation_seconds = [run["generation_seconds"] for run in measured]
        summary = {
            "prompt": prompt,
            "seed": seed,
            "transformer_version": str(config.get("transformer_version", "480p_t2v_distilled")),
            "attention_mode": pipe.transformer.attn_mode,
            "forward_input_devices": forward_input_devices,
            "forward_output_devices": forward_output_devices,
            "deterministic": deterministic,
            "runs": generation_runs,
        }
        summary_path = output_dir / "summary.json"
        summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
        artifacts.append({"path": str(summary_path), "sha256": sha256_path(summary_path)})
        step_log = output_dir / "steps.ndjson"
        step_log.write_text(
            "".join(json.dumps(run, sort_keys=True) + "\n" for run in generation_runs),
            encoding="utf-8",
        )
        checks = {
            "finite_tensors": True,
            "main_forward_device": bool(forward_input_devices)
            and all("cuda" in device for device in forward_input_devices + forward_output_devices),
            "valid_artifact": all(Path(item["path"]).stat().st_size > 0 for item in artifacts),
            "attention_cuda_sdpa_fallback": pipe.transformer.attn_mode == "torch",
            "deterministic_repeat": deterministic,
        }
        if benchmark_mode:
            checks["benchmark_measurement_count"] = len(measured) == measure_steps
        if not _checks_pass(checks):
            raise RuntimeError(f"HunyuanVideo inference checks failed: {checks}")
        metrics = {
            "model_load_seconds": load_seconds,
            "warmup_steps": warmup_steps,
            "measure_steps": len(measured),
            "generation_seconds": generation_seconds,
            "sample_seconds_median": statistics.median(generation_seconds),
            "sample_seconds_min": min(generation_seconds),
            "sample_seconds_max": max(generation_seconds),
            "samples_per_second": 1.0 / statistics.median(generation_seconds),
            "frames_per_second": int(config.get("frames", 9)) / statistics.median(generation_seconds),
            "peak_cpu_rss_bytes": int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024),
            "cuda_memory": memory_stats(),
            "cuda_utilization": None,
        }
        return {
            "artifact": Path(artifacts[0]["path"]),
            "artifacts": artifacts,
            "metrics": metrics,
            "stage_timings": {
                "model_load_seconds": load_seconds,
                "generation_seconds": generation_seconds,
                "cpu_mp4_encode_seconds": [run["cpu_mp4_encode_seconds"] for run in measured],
            },
            "checks": checks,
            "logs": [
                {"path": str(step_log), "sha256": sha256_path(step_log)},
                {"path": str(summary_path), "sha256": sha256_path(summary_path)},
            ],
        }
    finally:
        if created_group and torch.distributed.is_initialized():
            torch.distributed.destroy_process_group()
        rendezvous.unlink(missing_ok=True)
