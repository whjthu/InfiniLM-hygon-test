"""Single-card LoRA training for the shape-flow-1.3B component only."""
from __future__ import annotations

from contextlib import contextmanager
import importlib
import json
import math
import os
from pathlib import Path
import random
import sys
from time import perf_counter
from typing import Any

from .. import hy_resume_checkpoint as common
from .. import trellis_training_resume_checkpoint as checkpoint
from ..runtime import MEMORY_LIMIT_BYTES, memory_stats, require_cuda, synchronize
from ..source_identity import source_identity
from ..trellis_training_contract import (
    TARGETS, adapter_shapes, file_sha, inspect_weights, json_sha, load_cache,
    require, resolve_config, verify_source,
)


def trainable_parameters(model: Any) -> dict[str, Any]:
    import torch
    values = {n: p for n, p in model.named_parameters() if p.requires_grad}
    expected = adapter_shapes()
    require(set(values) == set(expected), "actual trainable target set differs")
    for name, shape in expected.items():
        require(tuple(values[name].shape) == shape and values[name].dtype == torch.float32, f"trainable schema differs: {name}")
    return {name: values[name] for name in expected}


def inject_lora(model: Any) -> list[str]:
    import torch
    nn, functional = torch.nn, torch.nn.functional
    modules = dict(model.named_modules())
    for name, shape in TARGETS.items():
        layer = modules.get(name)
        require(isinstance(layer, nn.Linear) and tuple(layer.weight.shape) == shape, f"LoRA target schema differs: {name}")
    require(len({id(modules[n]) for n in TARGETS}) == len(TARGETS), "aliased LoRA targets")

    class LoRALinear(nn.Module):
        def __init__(self, original: Any) -> None:
            super().__init__()
            self.original = original
            self.lora_A = nn.Parameter(torch.empty(2, original.in_features, device=original.weight.device, dtype=torch.float32))
            self.lora_B = nn.Parameter(torch.zeros(original.out_features, 2, device=original.weight.device, dtype=torch.float32))
            nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))

        def forward(self, value: Any) -> Any:
            base = self.original(value)
            delta = functional.linear(functional.linear(value, self.lora_A.to(value.dtype)), self.lora_B.to(value.dtype))
            return base + 2.0 * delta

    model.requires_grad_(False)
    for name in TARGETS:
        parent, child = name.rsplit(".", 1)
        modules[parent]._modules[child] = LoRALinear(modules[name])
    require(sum(p.numel() for p in trainable_parameters(model).values()) == 96256, "LoRA element count differs")
    return list(TARGETS)


def validate_weight_layout(model: Any, header: dict[str, Any]) -> None:
    import torch
    state = model.state_dict()
    require(len(state) == 640 and set(state) == set(header), "base checkpoint key coverage differs")
    for name, tensor in state.items():
        entry = header[name]
        require(entry["shape"] == list(tensor.shape) and entry["dtype"] == "BF16", f"base weight schema differs: {name}")
    require(sum(t.dtype == torch.bfloat16 for t in state.values()) == 420
            and sum(t.dtype == torch.float32 for t in state.values()) == 220, "native mixed precision layout differs")


def load_base_weights(model: Any, identity: dict[str, Any]) -> None:
    import torch
    from safetensors import safe_open
    validate_weight_layout(model, identity["header"])
    dtypes = {n: t.dtype for n, t in model.state_dict().items()}
    with safe_open(identity["path"], framework="pt", device="cpu") as reader:
        require(set(reader.keys()) == set(identity["header"]), "base checkpoint keys changed")
        state = {}
        for name in reader.keys():
            tensor = reader.get_tensor(name)
            require(tensor.dtype == torch.bfloat16 and bool(torch.isfinite(tensor).all()), f"invalid base weight: {name}")
            state[name] = tensor
        model.load_state_dict(state, strict=True)
    require({n: t.dtype for n, t in model.state_dict().items()} == dtypes, "base load changed native dtypes")
    require(file_sha(Path(identity["path"])) == identity["sha256"], "weights changed during load")


def preclip_gradients(parameters: dict[str, Any]) -> dict[str, Any]:
    import torch
    require(set(parameters) == set(adapter_shapes()), "preclip target set differs")
    gradients = {}
    for name, parameter in parameters.items():
        grad = parameter.grad
        require(grad is not None and grad.shape == parameter.shape and grad.dtype == parameter.dtype
                and bool(torch.isfinite(grad).all()), f"missing or non-finite preclip gradient: {name}")
        gradients[name] = grad.detach().cpu().clone()
    energy = sum(float(g.double().square().sum()) for g in gradients.values())
    # Zero A gradients are expected at initialization when B is zero.
    require(math.isfinite(energy) and energy > 0, "all gradients are zero or invalid")
    return {"sha256": common.tree_sha256(gradients), "tensors": len(gradients), "norm": math.sqrt(energy),
            "zero_tensors": [n for n, g in gradients.items() if not bool(g.count_nonzero())]}


def step_coordinate(step: int, warmup: int) -> dict[str, Any]:
    return {"global_step": step, "warmup": step <= warmup,
            "measurement_step": None if step <= warmup else step - warmup,
            "sample_cursor": 0}


def checked_memory() -> dict[str, int]:
    values = memory_stats()
    require(all(type(values[key]) is int and 0 <= values[key] <= MEMORY_LIMIT_BYTES
                for key in ("peak_allocated_bytes", "peak_reserved_bytes")), "CUDA allocator peak exceeds 75e9 bytes")
    return values


def require_adapter_update(before: str, after: str) -> None:
    require(before != after, "optimizer produced no actual FP32 adapter change")


@contextmanager
def observe_sdpa(torch: Any):
    functional = torch.nn.functional
    original = functional.scaled_dot_product_attention
    calls = {"forward_and_recompute_calls": 0}

    def observed(q: Any, k: Any, v: Any, *args: Any, **kwargs: Any) -> Any:
        require(all(x.device.type == "cuda" and x.dtype == torch.bfloat16 for x in (q, k, v)), "SDPA must execute CUDA BF16")
        calls["forward_and_recompute_calls"] += 1
        return original(q, k, v, *args, **kwargs)

    functional.scaled_dot_product_attention = observed
    try:
        yield calls
    finally:
        functional.scaled_dot_product_attention = original


def validate_module_origin(module: Any, root: Path, name: str) -> None:
    directory = root.resolve() / "trellis2"
    file = getattr(module, "__file__", None)
    if file is not None:
        require(Path(file).resolve().is_relative_to(directory), f"foreign TRELLIS module: {name}")
        return
    # Upstream modules includes namespace packages without an __init__.py.
    paths = tuple(getattr(module, "__path__", ()))
    require(bool(paths) and all(Path(path).resolve().is_relative_to(directory)
                               for path in paths), f"foreign TRELLIS namespace: {name}")


def _import_model(config: dict[str, Any]) -> tuple[Any, Any]:
    require(not any(n == "trellis2" or n.startswith("trellis2.") for n in sys.modules), "TRELLIS already imported; use a fresh process")
    for key, value in (("ATTN_BACKEND", "sdpa"), ("SPARSE_ATTN_BACKEND", "sdpa"), ("SPARSE_CONV_BACKEND", "none")):
        os.environ[key] = value
    root = Path(config["source_root"]).resolve()
    sys.path.insert(0, str(root))
    module = importlib.import_module("trellis2.models.structured_latent_flow")
    sp = importlib.import_module("trellis2.modules.sparse")
    sparse_config = importlib.import_module("trellis2.modules.sparse.config")
    require(sparse_config.ATTN == "sdpa", "actual sparse attention backend is not SDPA")
    for name, imported in list(sys.modules.items()):
        if name == "trellis2" or name.startswith("trellis2."):
            validate_module_origin(imported, root, name)
    return module.SLatFlowModel, sp


def realize_flow_inputs(clean: Any, fraction: Any, noise: Any) -> tuple[Any, Any]:
    sigma_min = 1e-5
    coefficient = (sigma_min + (1.0 - sigma_min) * fraction).to(clean.dtype)
    noised = (1.0 - fraction.to(clean.dtype)) * clean + coefficient * noise
    target = (1.0 - sigma_min) * noise - clean
    return noised, target


def flow_prediction_and_loss(
    torch: Any, model: Any, sparse: Any, coords: Any, noised: Any, fraction: Any, condition: Any, target: Any,
) -> tuple[Any, Any]:
    sample = sparse.SparseTensor(feats=noised, coords=coords)
    with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
        prediction = model(sample, fraction * 1000.0, condition)
        require(torch.equal(prediction.coords, coords), "prediction coordinates or order changed")
        require(prediction.feats.shape == noised.shape and prediction.feats.device == noised.device
                and prediction.feats.dtype == torch.bfloat16, "prediction shape/device/precision differs")
        loss = (prediction.feats.float() - target.float()).square().mean()
    return prediction, loss


def run_trellis2_training(weights: Path, config: dict[str, Any], output_dir: Path, source_root: Path) -> dict[str, Any]:
    import numpy as np
    config = resolve_config(config)
    require(source_root.resolve() == Path(config["source_root"]).resolve(), "CLI and configured source paths differ")
    payload = None
    resume_identity = None
    if config.get("resume_from_checkpoint"):
        payload, resume_identity = checkpoint.load_checkpoint_with_identity(Path(config["resume_from_checkpoint"]), requested_config=config)
    start_step = payload["metadata"]["global_step"] if payload else 0
    stop = config.get("stop_after_global_step", config["max_steps"])
    require(start_step < stop, "resume must perform at least one requested remaining update")
    source = verify_source(config)
    model_config, normalization, weight_identity = inspect_weights(weights)
    arrays, cache_identity = load_cache(config, normalization)
    torch = require_cuda()
    require(torch.cuda.device_count() == 1, "shape-flow training requires one visible CUDA")
    torch.cuda.set_device(0)
    random.seed(config["seed"])
    np.random.seed(config["seed"] % 2**32)
    torch.manual_seed(config["seed"])
    torch.cuda.manual_seed_all(config["seed"])
    load_start = perf_counter()
    model_class, sp = _import_model(config)
    require(model_config["name"] == "SLatFlowModel", "component model class differs")
    model = model_class(**model_config["args"])
    load_base_weights(model, weight_identity)
    lora_targets = inject_lora(model)
    for block in model.blocks:
        require(hasattr(block, "use_checkpoint"), "missing native checkpoint control")
        block.use_checkpoint = config["gradient_checkpointing"]
    model.to("cuda:0")
    model.train()
    parameters = trainable_parameters(model)
    optimizer = checkpoint.make_optimizer(list(parameters.values()), config)
    progress = common.initial_optimizer_progress(model, optimizer)
    require(verify_source(config) == source, "source changed during import")
    identities = {"source": source, "weights": {k: v for k, v in weight_identity.items() if k != "header"},
                  "cache": cache_identity, "package": source_identity(),
                  "runtime": {"torch": str(torch.__version__), "torch_cuda": str(torch.version.cuda),
                              "python": sys.version, "device": str(torch.cuda.get_device_name(0)),
                              "sparse_attention": "sdpa", "compute_dtype": "bfloat16"}}
    contract = checkpoint.build_contract(config, identities, [0])
    coords = torch.from_numpy(arrays["coords"]).to("cuda:0")
    clean = torch.from_numpy(arrays["shape_latent"]).to("cuda:0", dtype=torch.bfloat16)
    condition = torch.from_numpy(arrays["condition"]).to("cuda:0", dtype=torch.bfloat16)
    require(bool(torch.isfinite(clean).all()) and bool(torch.isfinite(condition).all()), "BF16 cache conversion overflow")
    if payload:
        progress = checkpoint.restore_checkpoint(payload, contract, model, optimizer)
    adapter_before = common.tree_sha256(common.cpu_tree(parameters))
    previous_adapter = adapter_before
    synchronize()
    load_seconds = perf_counter() - load_start
    checked_memory()
    output_dir.mkdir(parents=True, exist_ok=True)
    log_path = output_dir / "steps.ndjson"
    require(not log_path.exists(), "refusing to overwrite training log")
    artifacts, records = [], []
    measured_start = None
    with log_path.open("x", encoding="utf-8") as log, observe_sdpa(torch) as sdpa:
        for step in range(start_step + 1, stop + 1):
            optimizer.zero_grad(set_to_none=True)
            if step > config["warmup_steps"] and measured_start is None:
                synchronize()
                measured_start = perf_counter()
            started = perf_counter()
            noise = torch.randn_like(clean)
            fraction = torch.rand((1,), device="cuda:0", dtype=torch.float32)
            noised, target = realize_flow_inputs(clean, fraction, noise)
            calls_before = sdpa["forward_and_recompute_calls"]
            prediction, loss = flow_prediction_and_loss(torch, model, sp, coords, noised, fraction, condition, target)
            require(bool(torch.isfinite(loss)), "non-finite loss before backward")
            loss.backward()
            grads = preclip_gradients(parameters)
            norm = torch.nn.utils.clip_grad_norm_(list(parameters.values()), config["max_grad_norm"])
            require(bool(torch.isfinite(norm)), "non-finite clipping norm before optimizer")
            require(sdpa["forward_and_recompute_calls"] > calls_before, "no actual CUDA BF16 SDPA calls")
            optimizer.step()
            progress = common.advance_optimizer_progress(progress, model, optimizer)
            optimizer.zero_grad(set_to_none=True)
            synchronize()
            state = common.capture_model_state(model, optimizer, progress)
            common.validate_model_state(state, model, optimizer, step)
            adapter_sha = common.tree_sha256(state["trainable"])
            require_adapter_update(previous_adapter, adapter_sha)
            previous_adapter = adapter_sha
            checked_memory()
            record = {**step_coordinate(step, config["warmup_steps"]), "loss": float(loss.detach().cpu()),
                      "learning_rate": optimizer.param_groups[0]["lr"], "preclip": grads,
                      "noise_sha256": common.tree_sha256(noise), "timestep": float(fraction.item()),
                      "adapter_sha256": adapter_sha,
                      "optimizer_sha256": common.tree_sha256(state["optimizer"]),
                      "sdpa_calls": sdpa["forward_and_recompute_calls"] - calls_before,
                      "step_seconds": perf_counter() - started}
            log.write(json.dumps(record, sort_keys=True, allow_nan=False) + "\n")
            log.flush()
            records.append(record)
            if step in config["checkpoint_steps"] or step == stop:
                path = output_dir / f"checkpoint-{step}.pt"
                checkpoint.save_checkpoint(path, checkpoint.make_payload(contract, step, model, optimizer, progress))
                artifacts.append(path)
    require(verify_source(config) == source, "source changed during training")
    from safetensors.torch import save_file
    adapter_path = output_dir / "adapter-final.safetensors"
    require(not adapter_path.exists(), "refusing to overwrite adapter")
    save_file(common.cpu_tree(parameters), str(adapter_path))
    artifacts.extend((adapter_path, log_path))
    memory = checked_memory()
    measured = [r for r in records if not r["warmup"]]
    result = {"artifacts": [{"path": str(p), "sha256": file_sha(p)} for p in artifacts],
              "logs": [{"path": str(log_path), "sha256": file_sha(log_path)}],
              "checks": {"finite_tensors": True, "main_forward_device": True,
                         "nonzero_finite_gradients": True, "checkpoint_resume": None},
              "metrics": {"component": contract["component"], "full_4b_training": False,
                          "training_identity": contract, "steps": len(measured), "global_optimizer_step": stop,
                          "invocation_updates": stop - start_step, "resume_step": start_step,
                          "resume_checkpoint": resume_identity,
                          "resume_boundary_verified": payload is not None, "warmup_steps": config["warmup_steps"],
                          "lora_targets": lora_targets, "trainable_tensors": len(parameters), "trainable_elements": 96256,
                          "adapter_sha_before": adapter_before, "adapter_sha_after": records[-1]["adapter_sha256"],
                          "loss_last": records[-1]["loss"], "cuda_memory": memory,
                          "peak_reserved_bytes": memory["peak_reserved_bytes"],
                          "peak_allocated_bytes": memory["peak_allocated_bytes"]},
              "stage_timings": {"model_load_seconds": load_seconds,
                                "training_seconds": sum(r["step_seconds"] for r in measured),
                                "warmup_seconds": sum(r["step_seconds"] for r in records if r["warmup"])}}
    if measured_start is not None:
        result["measurement_window"] = {"start_monotonic": measured_start, "work_units": len(measured), "unit": "optimizer_steps"}
    return result
