from __future__ import annotations

import importlib
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


def parse_cards(value: str) -> tuple[int, ...]:
    cards = tuple(int(part.strip()) for part in value.split(",") if part.strip())
    if not cards or len(set(cards)) != len(cards) or any(card < 0 for card in cards):
        raise ValueError(f"invalid card selection: {value!r}")
    return tuple(sorted(cards))


def _load_fcntl():
    try:
        return importlib.import_module("fcntl")
    except ModuleNotFoundError as exc:
        raise RuntimeError("CUDA card locking requires POSIX fcntl on the execution host") from exc


def _host_namespace(host: str) -> str:
    if not host or host in {".", ".."} or any(char not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._-" for char in host):
        raise ValueError(f"invalid lock host: {host!r}")
    return host


def lease_location(lock_root: Path | str | None, host: str | None) -> tuple[Path, str]:
    if lock_root is None:
        raise ValueError("--lock-root must name a shared absolute host path")
    root = Path(lock_root)
    if not root.is_absolute():
        raise ValueError("--lock-root must be an absolute shared host path")
    if not isinstance(host, str) or not host:
        raise ValueError("--lock-host must identify the physical host")
    return root.resolve(), _host_namespace(host)


@contextmanager
def acquire(
    cards: tuple[int, ...],
    lock_root: Path,
    host: str,
) -> Iterator[Path]:
    """Acquire every requested card in a stable order without waiting indefinitely."""

    normalized = tuple(sorted(set(cards)))
    if not normalized or any(card < 0 for card in normalized):
        raise ValueError(f"invalid card selection: {cards!r}")
    fcntl = _load_fcntl()
    root, physical_host = lease_location(lock_root, host)
    host_root = root / physical_host
    host_root.mkdir(parents=True, exist_ok=True)
    handles = []
    try:
        for card in normalized:
            lock_path = host_root / f"card-{card}.lock"
            handle = lock_path.open("a+", encoding="utf-8")
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                handle.close()
                raise RuntimeError(f"CUDA card {card} is already leased on host {host_root.name}") from exc
            handle.seek(0)
            handle.truncate()
            handle.write(f"cards={','.join(str(value) for value in normalized)}\n")
            handle.flush()
            handles.append(handle)
        yield host_root
    finally:
        for handle in reversed(handles):
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            finally:
                handle.close()
