from __future__ import annotations

import hashlib
import importlib.metadata
import inspect
import json
import math
import platform
import statistics
import time
from pathlib import Path
from typing import Any

from ..manifest import sha256_path
from ..runtime import autocast_bf16, memory_stats, require_cuda, synchronize
from .. import zimage_resume_checkpoint as z_resume
from .sdxl_ddpo import ppo_clipped_loss
from .zimage_training import (
    _adapter_sha,
    _image_regression,
    _save_lora,
    _training_module_class,
    TURBO_REGRESSION_CONTRACT,
    local_model_paths,
    render_turbo_regression_image,
    turbo_regression_check,
    turbo_regression_metrics,
    turbo_regression_options,
)


def _execution_metadata(final_global_step: int, records: list[dict[str, Any]]) -> dict[str, int]:
    if type(final_global_step) is not int or final_global_step < 0:
        raise ValueError("final_global_step must be a non-negative integer")
    return {
        "global_optimizer_step": final_global_step,
        "executed_optimizer_steps": len(records),
    }


def _identity_file_map(paths: dict[str, Path]) -> dict[str, str]:
    result = {}
    for name, path in paths.items():
        if not path.is_file():
            raise RuntimeError(f"Z-Image resume identity file is missing: {name}={path}")
        result[name] = sha256_path(path)
    return result


def _resume_effective_config(
    config: dict[str, Any],
    regression_options: dict[str, int | str] | None = None,
) -> dict[str, Any]:
    operational_keys = {"output_root", "run_name", "resume_from_checkpoint"}
    effective_config = {
        key: value for key, value in config.items() if key not in operational_keys
    }
    if regression_options is None:
        regression_options = turbo_regression_options(config)
    effective_config["validate_turbo_regression"] = regression_options is not None
    # This keeps a pre-opt-in checkpoint from resuming under a changed workload.
    effective_config["turbo_regression_contract"] = TURBO_REGRESSION_CONTRACT
    return effective_config


def _build_resume_contract(
    *,
    torch: Any,
    weights: Path,
    config: dict[str, Any],
    source_root: Path,
    scheduler: Any,
    group_size: int,
    max_steps: int,
    regression_options: dict[str, int | str] | None,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    effective_config = _resume_effective_config(config, regression_options)
    scheduler_identity = z_resume.scheduler_spec(scheduler)
    backend_path = Path(__file__).resolve()
    source_files = _identity_file_map(
        {
            "backend": backend_path,
            "checkpoint": Path(inspect.getsourcefile(z_resume) or ""),
            "checkpoint_common": Path(inspect.getsourcefile(z_resume.common) or ""),
            "training_helpers": Path(inspect.getsourcefile(_adapter_sha) or ""),
            "ppo_loss": Path(inspect.getsourcefile(ppo_clipped_loss) or ""),
            "runtime": Path(inspect.getsourcefile(require_cuda) or ""),
            "scheduler": source_root / "diffsynth" / "diffusion" / "flow_match.py",
            "pipeline": source_root / "diffsynth" / "pipelines" / "z_image.py",
            "noise_source": source_root / "diffsynth" / "diffusion" / "base_pipeline.py",
        }
    )
    preset_lora = Path(str(config["preset_lora_path"]))
    model_files = _identity_file_map({"preset_lora": preset_lora})
    model_files["declared_model_sha256"] = str(config["model_sha"])
    declared_preset = str(config.get("preset_lora_sha", ""))
    if model_files["preset_lora"] != declared_preset:
        raise RuntimeError("Z-Image preset LoRA SHA mismatch")
    if len(model_files["declared_model_sha256"]) != 64:
        raise RuntimeError("Z-Image declared model SHA is missing or invalid")
    try:
        torch_cuda_version = importlib.metadata.version("torch")
    except importlib.metadata.PackageNotFoundError:
        torch_cuda_version = "installed-without-package-metadata"
    evidence = {
        "config": effective_config,
        "source": source_files,
        "data": {"prompt_sha256": hashlib.sha256(str(config["prompt"]).encode()).hexdigest()},
        "model": model_files,
        "reward": {"target_rgb": [float(value) for value in config["reward_target_rgb"]]},
        "scheduler": scheduler_identity,
        "runtime": {
            "python": platform.python_version(),
            "torch": str(torch.__version__),
            "torch_cuda": torch_cuda_version,
            "container": str(config.get("container", "")),
            "platform": platform.platform(),
        },
    }
    identity = {key: z_resume.common.json_sha256(value) for key, value in evidence.items()}
    contract = z_resume.build_contract(
        identity=identity,
        seed=int(config.get("seed", 42)),
        max_steps=max_steps,
        group_size=group_size,
        sample_order=["prompt:" + evidence["data"]["prompt_sha256"]],
        device_ids=[0],
    )
    return contract, evidence, scheduler_identity


def image_prompt_scores(
    images: list[Any],
    target_rgb: tuple[float, float, float],
) -> list[float]:
    """Score prompt color alignment plus contrast, saturation, and sharpness."""
    import numpy as np

    target = np.asarray(target_rgb, dtype=np.float32)
    rewards = []
    for image in images:
        pixels = np.asarray(image.convert("RGB"), dtype=np.float32) / 255.0
        channel_mean = pixels.mean(axis=(0, 1))
        color_score = -float(np.square(channel_mean - target).mean())
        contrast = float(pixels.std())
        saturation = float((pixels.max(axis=2) - pixels.min(axis=2)).mean())
        horizontal = float(np.abs(pixels[:, 1:] - pixels[:, :-1]).mean())
        vertical = float(np.abs(pixels[1:] - pixels[:-1]).mean())
        sharpness = 0.5 * (horizontal + vertical)
        rewards.append(color_score + 0.05 * contrast + 0.05 * saturation + 0.02 * sharpness)
    return rewards


def image_prompt_reward(
    images: list[Any],
    target_rgb: tuple[float, float, float],
) -> Any:
    torch = require_cuda()
    return torch.tensor(image_prompt_scores(images, target_rgb), device="cuda", dtype=torch.float32)


def _build_model(weights: Path, config: dict[str, Any], source_root: Path) -> Any:
    training_class = _training_module_class(source_root)
    adapter_path = Path(config["preset_lora_path"])
    if not adapter_path.is_file():
        raise RuntimeError(f"Z-Image differential adapter is missing: {adapter_path}")
    model = training_class(
        model_paths=local_model_paths(weights),
        tokenizer_path=str(weights / "tokenizer"),
        lora_base_model="dit",
        lora_target_modules=str(config["lora_target_modules"]),
        lora_rank=int(config.get("lora_rank", 4)),
        preset_lora_path=str(adapter_path),
        preset_lora_model="dit",
        use_gradient_checkpointing=bool(config.get("gradient_checkpointing", True)),
        device="cuda",
        task="sft",
    )
    if next(model.pipe.dit.parameters()).device.type != "cuda":
        raise RuntimeError("Z-Image DiT main forward is not on CUDA")
    return model


def _encode_prompt(pipe: Any, prompt: str) -> Any:
    prompt_unit = next(
        unit for unit in pipe.units if unit.__class__.__name__ == "ZImageUnit_PromptEmbedder"
    )
    with require_cuda().no_grad(), autocast_bf16():
        return prompt_unit.process(pipe, prompt, None)["prompt_embeds"]


def _predict_velocity(
    pipe: Any,
    latents: Any,
    timestep: Any,
    prompt_embeds: Any,
    gradient_checkpointing: bool,
) -> Any:
    timestep_cuda = timestep.reshape(1).to(device="cuda", dtype=pipe.torch_dtype)
    with autocast_bf16():
        return pipe.model_fn(
            dit=pipe.dit,
            controlnet=pipe.controlnet,
            latents=latents,
            timestep=timestep_cuda,
            prompt_embeds=prompt_embeds,
            use_gradient_checkpointing=gradient_checkpointing,
            use_gradient_checkpointing_offload=False,
        )


def _decode(pipe: Any, latents: Any) -> Any:
    torch = require_cuda()
    with torch.no_grad(), autocast_bf16():
        decoded = pipe.vae_decoder(latents.to(dtype=pipe.torch_dtype))
    return pipe.vae_output_to_image(decoded)


def _sample_one(
    pipe: Any,
    scheduler: Any,
    prompt_embeds: Any,
    size: int,
    steps: int,
    seed: int,
) -> dict[str, Any]:
    torch = require_cuda()
    scheduler.set_seed(seed)
    scheduler.set_timesteps(steps)
    latents = pipe.generate_noise(
        (1, 16, size // 8, size // 8),
        seed=seed,
        rand_device="cpu",
        rand_torch_dtype=torch.float32,
    ).float()
    generator = torch.Generator(device="cpu").manual_seed(seed + 1000003)
    states = []
    next_states = []
    noises = []
    log_probs = []
    with torch.no_grad():
        for timestep_index, timestep in enumerate(scheduler.timesteps):
            states.append(latents)
            velocity = _predict_velocity(pipe, latents, timestep, prompt_embeds, False)
            result = scheduler.step(
                velocity,
                timestep,
                latents,
                generator=generator,
                return_log_prob=True,
                return_dict=True,
            )
            latents = result["prev_sample"]
            sigma = scheduler.sigmas[timestep_index]
            sigma_next = (
                scheduler.sigmas[timestep_index + 1]
                if timestep_index + 1 < len(scheduler.sigmas)
                else torch.tensor(0.0)
            )
            scale = result["std_dev_t"] * torch.sqrt(sigma - sigma_next)
            noise = (latents - result["prev_sample_mean"]) / scale.to("cuda").clamp_min(1e-12)
            next_states.append(latents)
            noises.append(noise)
            log_probs.append(result["log_prob"].reshape(()))
    return {
        "latents": torch.stack([item.squeeze(0) for item in states]),
        "next_latents": torch.stack([item.squeeze(0) for item in next_states]),
        "noise": torch.stack([item.squeeze(0) for item in noises]),
        "log_probs": torch.stack(log_probs),
        "timesteps": scheduler.timesteps.detach().clone(),
        "generator_state": generator.get_state().detach().cpu().clone(),
        "image": _decode(pipe, latents),
    }


def _sample_group(
    pipe: Any,
    scheduler: Any,
    prompt_embeds: Any,
    size: int,
    steps: int,
    seed: int,
    group_size: int,
) -> dict[str, Any]:
    torch = require_cuda()
    samples = [
        _sample_one(pipe, scheduler, prompt_embeds, size, steps, seed + index)
        for index in range(group_size)
    ]
    return {
        "latents": torch.stack([sample["latents"] for sample in samples]),
        "next_latents": torch.stack([sample["next_latents"] for sample in samples]),
        "noise": torch.stack([sample["noise"] for sample in samples]),
        "log_probs": torch.stack([sample["log_probs"] for sample in samples]),
        "timesteps": samples[0]["timesteps"],
        "generator_states": [sample["generator_state"] for sample in samples],
        "images": [sample["image"] for sample in samples],
    }


def _train_transition(
    model: Any,
    optimizer: Any,
    scheduler: Any,
    prompt_embeds: Any,
    rollout: dict[str, Any],
    rewards: Any,
    timestep_index: int,
    clip_range: float,
    max_grad_norm: float,
) -> dict[str, float | bool]:
    torch = require_cuda()
    advantages = (rewards - rewards.mean()) / (rewards.std(unbiased=False) + 1e-6)
    optimizer.zero_grad(set_to_none=True)
    losses = []
    ratios = []
    kls = []
    differences = []
    timestep = rollout["timesteps"][timestep_index]
    group_size = int(rewards.shape[0])
    for index in range(group_size):
        latent = rollout["latents"][index, timestep_index].unsqueeze(0)
        next_latent = rollout["next_latents"][index, timestep_index].unsqueeze(0)
        old_log_prob = rollout["log_probs"][index, timestep_index].detach().float().reshape(1)
        velocity = _predict_velocity(
            model.pipe,
            latent,
            timestep,
            prompt_embeds,
            bool(model.use_gradient_checkpointing),
        )
        result = scheduler.step(
            velocity,
            timestep,
            latent,
            prev_sample=next_latent,
            return_log_prob=True,
            return_dict=True,
        )
        new_log_prob = result["log_prob"].float().reshape(1)
        difference = (new_log_prob.detach() - old_log_prob).abs()
        loss, ratio, approx_kl = ppo_clipped_loss(
            new_log_prob,
            old_log_prob,
            advantages[index].reshape(1),
            clip_range,
        )
        (loss / group_size).backward()
        losses.append(loss.detach())
        ratios.append(ratio.detach())
        kls.append(approx_kl.detach())
        differences.append(difference)
    parameters = list(model.trainable_modules())
    grad_norm = torch.nn.utils.clip_grad_norm_(parameters, max_grad_norm)
    finite_gradients = bool(torch.isfinite(grad_norm).item()) and float(grad_norm) > 0.0
    if not finite_gradients:
        raise RuntimeError(f"non-finite or zero Z-Image GRPO gradient: {float(grad_norm)}")
    optimizer.step()
    synchronize()
    difference = torch.cat(differences)
    return {
        "loss": float(torch.stack(losses).mean().cpu()),
        "ratio": float(torch.stack(ratios).mean().cpu()),
        "approx_kl": float(torch.stack(kls).mean().cpu()),
        "grad_norm": float(grad_norm.detach().cpu()),
        "log_prob_mae": float(difference.mean().cpu()),
        "log_prob_p99": float(torch.quantile(difference, 0.99).cpu()),
        "finite_gradients": finite_gradients,
    }


def _write_trajectory(
    directory: Path,
    rollout: dict[str, Any],
    rewards: Any,
    prompt: str,
    seed: int,
    adapter_sha: str,
    global_step: int,
) -> list[dict[str, str | None]]:
    torch = require_cuda()
    directory.mkdir(parents=True, exist_ok=True)
    tensor_path = directory / "trajectory.pt"
    torch.save(
        {
            key: rollout[key].detach().cpu()
            for key in ("latents", "next_latents", "noise", "log_probs", "timesteps")
        },
        tensor_path,
    )
    tensor_sha = sha256_path(tensor_path)
    records = [{"path": str(tensor_path), "sha256": tensor_sha}]
    for index, reward in enumerate(rewards.detach().cpu().tolist()):
        payload = {
            "adapter_sha": adapter_sha,
            "global_step": global_step,
            "latent": {"path": str(tensor_path), "sample": index, "sha256": tensor_sha},
            "log_prob": rollout["log_probs"][index].detach().cpu().tolist(),
            "noise": {"path": str(tensor_path), "sample": index, "sha256": tensor_sha},
            "prompt": prompt,
            "reward": float(reward),
            "seed": seed + index,
            "timestep": rollout["timesteps"].detach().cpu().tolist(),
        }
        record_path = directory / f"sample-{index}.json"
        record_path.write_text(json.dumps(payload, sort_keys=True) + "\n", encoding="utf-8")
        records.append({"path": str(record_path), "sha256": sha256_path(record_path)})
    return records


def run_zimage_flow_grpo(
    weights: Path,
    config: dict[str, Any],
    output_dir: Path,
    source_root: Path,
) -> dict[str, Any]:
    torch = require_cuda()
    from diffsynth.diffusion.flow_match import FlowMatchSDEScheduler

    output_dir.mkdir(parents=True, exist_ok=True)
    raw_log = output_dir / "steps.jsonl"
    resume_value = config.get("resume_from_checkpoint")
    resume_path = Path(str(resume_value)) if resume_value else None
    if raw_log.exists() and resume_path is None:
        raw_log.unlink()
    total_started = time.perf_counter()
    torch.manual_seed(int(config.get("seed", 42)))
    torch.cuda.reset_peak_memory_stats()
    load_started = time.perf_counter()
    model = _build_model(weights, config, source_root)
    model.pipe.dit.train()
    load_seconds = time.perf_counter() - load_started
    prompt = str(config["prompt"])
    prompt_embeds = _encode_prompt(model.pipe, prompt)
    sample_steps = int(config.get("sample_steps", 8))
    if sample_steps != 8:
        raise ValueError("Z-Image-Turbo GRPO acceptance requires exactly eight DiT forwards")
    group_size = int(config.get("rollouts_per_prompt", 4))
    if group_size < 4:
        raise ValueError("Z-Image GRPO requires at least four rollouts per prompt")
    scheduler = FlowMatchSDEScheduler(
        "Z-Image",
        noise_level=float(config.get("noise_level", 0.7)),
        noise_window=list(range(sample_steps)),
        sde_step_num=sample_steps,
        sde_type=str(config.get("sde_type", "Flow-SDE")),
    )
    parameters = list(model.trainable_modules())
    optimizer = torch.optim.AdamW(
        parameters,
        lr=float(config.get("learning_rate", 1e-4)),
        weight_decay=float(config.get("weight_decay", 0.01)),
    )
    optimizer_progress = z_resume.common.initial_optimizer_progress(model, optimizer)
    target_rgb = tuple(float(value) for value in config.get("reward_target_rgb", [0.65, 0.2, 0.15]))
    max_steps = int(config.get("max_steps", 20))
    warmup_steps = int(config.get("warmup_steps", 0))
    if warmup_steps < 0 or warmup_steps >= max_steps:
        raise ValueError("warmup_steps must leave at least one measured Z-Image GRPO update")
    checkpoint_steps = {int(value) for value in config.get("checkpoint_steps", [10, 20])}
    if not checkpoint_steps or any(value <= 0 or value > max_steps for value in checkpoint_steps):
        raise ValueError("checkpoint_steps must be within Z-Image max_steps")
    base_seed = int(config.get("seed", 42))
    size = int(config.get("size", 256))
    regression_options = turbo_regression_options(
        config, default_prompt=prompt, default_size=size
    )
    adapter_before = _adapter_sha(model)
    expected_adapter = adapter_before
    resume_contract, resume_identity_evidence, scheduler_identity = _build_resume_contract(
        torch=torch,
        weights=weights,
        config=config,
        source_root=source_root,
        scheduler=scheduler,
        group_size=group_size,
        max_steps=max_steps,
        regression_options=regression_options,
    )
    completed_global_step = 0
    resume_validation_seconds = 0.0
    resume_checkpoint_sha = None
    resume_rng_validation = None
    resume_boundary_validated = False
    if resume_path is not None:
        resume_started = time.perf_counter()
        if not resume_path.is_file():
            raise RuntimeError(f"Z-Image resume checkpoint is missing: {resume_path}")
        resume_payload = z_resume.load_checkpoint(resume_path)
        preflight = z_resume.validate_checkpoint(
            resume_payload,
            resume_contract,
            model,
            optimizer,
            scheduler_identity,
            native_rng=True,
        )
        completed_global_step = int(preflight["metadata"]["global_step"])
        optimizer_progress, restored = z_resume.restore_checkpoint(
            resume_payload,
            resume_contract,
            model,
            optimizer,
            scheduler,
            scheduler_identity,
        )
        z_resume.assert_restored_boundary(
            resume_payload,
            model,
            optimizer,
            scheduler,
            optimizer_progress,
            [0],
        )
        resume_boundary_validated = True
        resume_rng_validation = restored["rng_validation"]
        resume_checkpoint_sha = sha256_path(resume_path)
        resume_validation_seconds = time.perf_counter() - resume_started
        adapter_before = _adapter_sha(model)
        expected_adapter = adapter_before
    metrics = []
    trajectory_records: list[dict[str, str | None]] = []
    current_adapter = True
    pre_image = output_dir / "turbo-before.png"
    post_image = output_dir / "turbo-after.png"
    if regression_options is not None:
        render_turbo_regression_image(regression_options, model, pre_image)
    model.pipe.dit.train()

    written_checkpoint_paths: set[Path] = set()
    last_rollout: dict[str, Any] | None = None
    final_global_step = completed_global_step
    training_started = time.perf_counter()
    measurement_started: float | None = None
    for global_step in range(completed_global_step + 1, max_steps + 1):
        if global_step > warmup_steps and measurement_started is None:
            synchronize()
            measurement_started = time.perf_counter()
        final_global_step = global_step
        if getattr(model, "_zimage_resume_poisoned", False):
            raise RuntimeError("Z-Image checkpoint restore poisoned this worker")
        step_started = time.perf_counter()
        started_unix = time.time()
        adapter_sha = _adapter_sha(model)
        current_adapter = current_adapter and adapter_sha == expected_adapter
        rollout_started = time.perf_counter()
        rollout = _sample_group(
            model.pipe,
            scheduler,
            prompt_embeds,
            size,
            sample_steps,
            base_seed + global_step * group_size,
            group_size,
        )
        last_rollout = rollout
        synchronize()
        rollout_seconds = time.perf_counter() - rollout_started
        reward_started = time.perf_counter()
        rewards = image_prompt_reward(rollout["images"], target_rgb)
        reward_seconds = time.perf_counter() - reward_started
        reward_variance = float(rewards.var(unbiased=False).cpu())
        if not math.isfinite(reward_variance) or reward_variance <= 0.0:
            raise RuntimeError("Z-Image GRPO reward variance is zero or non-finite")
        timestep_index = (global_step - 1) % sample_steps
        update_started = time.perf_counter()
        update = _train_transition(
            model,
            optimizer,
            scheduler,
            prompt_embeds,
            rollout,
            rewards,
            timestep_index,
            float(config.get("clip_range", 0.2)),
            float(config.get("max_grad_norm", 1.0)),
        )
        optimizer_progress = z_resume.common.advance_optimizer_progress(
            optimizer_progress, model, optimizer
        )
        update_seconds = time.perf_counter() - update_started
        adapter_after = _adapter_sha(model)
        expected_adapter = adapter_after
        records = _write_trajectory(
            output_dir / "trajectories" / f"step-{global_step:04d}",
            rollout,
            rewards,
            prompt,
            base_seed + global_step * group_size,
            adapter_sha,
            global_step,
        )
        trajectory_records.extend(records)
        metric = {
            "adapter_sha": adapter_sha,
            "adapter_sha_after": adapter_after,
            "ended_unix": time.time(),
            "global_step": global_step,
            "reward_mean": float(rewards.mean().cpu()),
            "reward_seconds": reward_seconds,
            "reward_variance": reward_variance,
            "rollout_seconds": rollout_seconds,
            "started_unix": started_unix,
            "step_seconds": time.perf_counter() - step_started,
            "timestep_index": timestep_index,
            "update_seconds": update_seconds,
            **update,
        }
        metrics.append(metric)
        with raw_log.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(metric, sort_keys=True) + "\n")
            handle.flush()
        if global_step in checkpoint_steps:
            checkpoint_path = output_dir / f"checkpoint-{global_step}" / "state.pt"
            payload = z_resume.make_payload(
                contract=resume_contract,
                global_step=global_step,
                model=model,
                optimizer=optimizer,
                optimizer_progress=optimizer_progress,
                scheduler=scheduler,
                expected_scheduler=scheduler_identity,
                rollout=rollout,
            )
            z_resume.save_atomic(checkpoint_path, payload)
            written_checkpoint_paths.add(checkpoint_path)

    checkpoint = output_dir / f"checkpoint-{max_steps}" / "state.pt"
    if checkpoint not in written_checkpoint_paths:
        if completed_global_step == max_steps and resume_path is not None:
            checkpoint = resume_path
        else:
            if last_rollout is None:
                raise RuntimeError("Z-Image final checkpoint has no completed rollout")
            payload = z_resume.make_payload(
                contract=resume_contract,
                global_step=max_steps,
                model=model,
                optimizer=optimizer,
                optimizer_progress=optimizer_progress,
                scheduler=scheduler,
                expected_scheduler=scheduler_identity,
                rollout=last_rollout,
            )
            z_resume.save_atomic(checkpoint, payload)
            written_checkpoint_paths.add(checkpoint)
    adapter_after = _adapter_sha(model)
    final_adapter = output_dir / "adapter-final.safetensors"
    _save_lora(final_adapter, model)
    if regression_options is not None:
        render_turbo_regression_image(regression_options, model, post_image)
        regression = _image_regression(pre_image, post_image)
    else:
        regression = None
    synchronize()
    training_seconds = time.perf_counter() - training_started
    measured = [item for item in metrics if int(item["global_step"]) > warmup_steps]
    if not measured:
        raise ValueError("warmup_steps must leave at least one measured Z-Image GRPO update")
    step_seconds = [float(item["step_seconds"]) for item in measured]
    rewards_var = [float(item["reward_variance"]) for item in metrics]
    grad_norms = [float(item["grad_norm"]) for item in metrics]
    log_prob_mae = [float(item["log_prob_mae"]) for item in metrics]
    log_prob_p99 = [float(item["log_prob_p99"]) for item in metrics]
    ratios = [float(item["ratio"]) for item in metrics]
    finite_metrics = all(
        math.isfinite(float(value))
        for metric in metrics
        for key, value in metric.items()
        if key not in {"adapter_sha", "adapter_sha_after"}
    )
    artifacts = list(dict.fromkeys([
        *sorted(written_checkpoint_paths),
        checkpoint,
        final_adapter,
        *([pre_image, post_image] if regression is not None else []),
    ]))
    result = {
        "artifacts": [
            {"path": str(path), "sha256": sha256_path(path)}
            for path in artifacts
            if path.is_file()
        ],
        "logs": [
            {"path": str(raw_log), "sha256": sha256_path(raw_log)},
            *trajectory_records,
        ],
        "metrics": {
            "adapter_sha_after": adapter_after,
            "adapter_sha_before": adapter_before,
            "approx_kl_max": max(float(item["approx_kl"]) for item in metrics),
            "grad_norm_min": min(grad_norms),
            "log_prob_mae_max": max(log_prob_mae),
            "log_prob_p99_max": max(log_prob_p99),
            "measurement_steps": len(measured),
            "executed_steps": len(metrics),
            "completed_global_step_before_resume": completed_global_step,
            "cuda_memory": memory_stats(),
            "ratio_max": max(ratios),
            "ratio_min": min(ratios),
            "reward_variance_min": min(rewards_var),
            "samples_per_second": len(measured) * group_size / sum(step_seconds),
            "step_seconds_max": max(step_seconds),
            "step_seconds_median": statistics.median(step_seconds),
            "step_seconds_min": min(step_seconds),
            "steps": max_steps,
            **_execution_metadata(final_global_step, metrics),
            "checkpoint_schema": z_resume.SCHEMA,
            "checkpoint_identity": resume_contract["identity"],
            "checkpoint_identity_evidence": resume_identity_evidence,
            "checkpoint_final_sha256": sha256_path(checkpoint),
            "resume_source_sha256": resume_checkpoint_sha,
            **turbo_regression_metrics(regression),
            "warmup_steps": warmup_steps,
        },
        "stage_timings": {
            "load": load_seconds,
            "reward": sum(float(item["reward_seconds"]) for item in metrics),
            "rollout": sum(float(item["rollout_seconds"]) for item in metrics),
            "total": time.perf_counter() - total_started,
            "training_including_checkpoints": training_seconds,
            "resume_validation": resume_validation_seconds,
            "update": sum(float(item["update_seconds"]) for item in metrics),
        },
        "checks": {
            "completed_step_checkpoint": bool(written_checkpoint_paths)
            or resume_boundary_validated,
            "resume_boundary": resume_path is None or resume_boundary_validated,
            "current_adapter": current_adapter and adapter_before != adapter_after,
            "finite_tensors": finite_metrics,
            "log_prob_alignment": max(log_prob_mae) <= 0.02 and max(log_prob_p99) <= 0.10,
            "main_forward_device": "cuda",
            "nonzero_finite_gradients": all(value > 0.0 and math.isfinite(value) for value in grad_norms),
            "reward_variance_nonzero": all(value > 0.0 and math.isfinite(value) for value in rewards_var),
            "turbo_8step_regression": turbo_regression_check(regression),
        },
    }
    # The CLI closes this window after artifact validation and the manifest write.
    if config.get("validate_recovery", False) is False:
        result["measurement_window"] = {
            "start_monotonic": measurement_started,
            "work_units": len(measured),
            "unit": "policy_updates",
        }
    return result
