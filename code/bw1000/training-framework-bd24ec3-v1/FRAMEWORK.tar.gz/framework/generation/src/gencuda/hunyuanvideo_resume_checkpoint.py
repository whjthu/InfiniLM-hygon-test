"""Strict full-step checkpoints for native single-rank HunyuanVideo training."""
from __future__ import annotations

import inspect
import math
from collections import defaultdict
from pathlib import Path
from typing import Any

from . import hy_resume_checkpoint as common


SCHEMA = "hunyuanvideo-native-full-optimizer-step-v1"
BOUNDARY = "after-complete-optimizer-step"
IDENTITY_FIELDS = {"config", "source", "model", "data", "runtime", "dependencies"}
CACHE_CONSUMPTION = "train_step(latents,text_emb,text_mask,byt5_text_states,byt5_text_mask)/v1"
_MUON_GROUP_FIELDS = {
    "params", "lr", "wd", "momentum", "nesterov", "ns_steps", "adamw_betas", "adamw_eps"
}

CheckpointValidationError = common.CheckpointValidationError
ResumeApplyFatal = common.ResumeApplyFatal
file_sha256 = common.file_sha256
json_sha256 = common.json_sha256
tree_sha256 = common.tree_sha256
save_atomic = common.save_atomic
load_checkpoint = common.load_checkpoint


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise CheckpointValidationError(message)


def _dtensor_type() -> Any | None:
    try:
        from torch.distributed.tensor import DTensor
    except (ImportError, ModuleNotFoundError):
        return None
    return DTensor


def _is_dtensor(value: Any) -> bool:
    value_type = _dtensor_type()
    return value_type is not None and isinstance(value, value_type)


def _cpu_tree(value: Any) -> Any:
    import torch

    if _is_dtensor(value):
        raise CheckpointValidationError("DTensor checkpoint state is unsupported for world size one")
    if isinstance(value, torch.Tensor):
        _require(value.layout == torch.strided, "unsupported optimizer tensor layout")
        return value.detach().cpu().clone()
    if isinstance(value, dict):
        return {key: _cpu_tree(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_cpu_tree(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_cpu_tree(item) for item in value)
    _require(value is None or type(value) in (bool, int, float, str, bytes), "unsupported checkpoint value")
    return value


def build_contract(
    *,
    identity: dict[str, str],
    seed: int,
    warmup_steps: int,
    max_steps: int,
    cache_sha256: str,
    device_ids: list[int],
    world_size: int = 1,
    rank: int = 0,
) -> dict[str, Any]:
    contract = {
        "backend": "hunyuanvideo-native-training",
        "identity": dict(identity),
        "seed": seed,
        "warmup_steps": warmup_steps,
        "max_steps": max_steps,
        "total_global_steps": warmup_steps + max_steps,
        "data_order": [cache_sha256],
        "cache_consumption": CACHE_CONSUMPTION,
        "device_ids": list(device_ids),
        "world_size": world_size,
        "rank": rank,
        "seed_formula": "restored-rng-before-noise-and-timestep/v1",
        "checkpoint_step_basis": "global-optimizer-step",
    }
    validate_contract(contract)
    return contract


def validate_contract(contract: dict[str, Any]) -> None:
    expected = {
        "backend", "identity", "seed", "warmup_steps", "max_steps", "total_global_steps",
        "data_order", "cache_consumption", "device_ids", "world_size", "rank", "seed_formula",
        "checkpoint_step_basis",
    }
    _require(type(contract) is dict and set(contract) == expected, "checkpoint contract fields mismatch")
    _require(contract["backend"] == "hunyuanvideo-native-training", "checkpoint backend mismatch")
    _require(contract["checkpoint_step_basis"] == "global-optimizer-step", "legacy measured-step checkpoint schema is rejected")
    _require(contract["seed_formula"] == "restored-rng-before-noise-and-timestep/v1", "checkpoint seed formula mismatch")
    _require(contract["cache_consumption"] == CACHE_CONSUMPTION, "cache consumption mismatch")
    _require(contract["world_size"] == 1 and contract["rank"] == 0, "only native world size one is supported")
    _require(contract["device_ids"] in ([], [0]), "invalid native single-card device IDs")
    for key, minimum in (("seed", 0), ("warmup_steps", 0), ("max_steps", 1), ("total_global_steps", 1)):
        _require(type(contract[key]) is int and contract[key] >= minimum, f"invalid {key}")
    _require(contract["total_global_steps"] == contract["warmup_steps"] + contract["max_steps"], "global schedule mismatch")
    identity = contract["identity"]
    _require(type(identity) is dict and set(identity) == IDENTITY_FIELDS, "checkpoint identity fields mismatch")
    _require(all(type(value) is str and len(value) == 64 and all(ch in "0123456789abcdef" for ch in value) for value in identity.values()), "invalid checkpoint identity")
    _require(type(contract["data_order"]) is list and len(contract["data_order"]) == 1, "invalid fixed cache order")
    _require(type(contract["data_order"][0]) is str and len(contract["data_order"][0]) == 64, "invalid cache SHA")


def boundary_metadata(contract: dict[str, Any], global_step: int) -> dict[str, Any]:
    validate_contract(contract)
    _require(type(global_step) is int and 1 <= global_step <= contract["total_global_steps"], "checkpoint is not at a completed optimizer step")
    return {
        "schema": SCHEMA,
        "boundary": BOUNDARY,
        "contract": contract,
        "global_optimizer_step": global_step,
        "completed_warmup_steps": min(global_step, contract["warmup_steps"]),
        "completed_measured_steps": max(0, global_step - contract["warmup_steps"]),
        "next_global_optimizer_step": global_step + 1,
        "next_measured_step": max(0, global_step + 1 - contract["warmup_steps"]),
        "next_cache_cursor": 0,
    }


def next_coordinate(metadata: dict[str, Any]) -> dict[str, int] | None:
    contract = metadata["contract"]
    if metadata["global_optimizer_step"] == contract["total_global_steps"]:
        return None
    return {
        "global_optimizer_step": metadata["next_global_optimizer_step"],
        "measured_step": metadata["next_measured_step"],
        "cache_cursor": metadata["next_cache_cursor"],
    }


def _optimizer_implementation(optimizer: Any) -> dict[str, str]:
    source = inspect.getsourcefile(type(optimizer))
    _require(source is not None and Path(source).is_file(), "cannot identify Muon implementation")
    _require(type(optimizer).__name__ == "Muon", "native HunyuanVideo requires the Muon optimizer")
    return {
        "module": type(optimizer).__module__,
        "qualname": type(optimizer).__qualname__,
        "source_sha256": file_sha256(Path(source)),
    }


def _parameter_names(model: Any, optimizer: Any) -> list[list[str]]:
    names = {id(parameter): name for name, parameter in model.named_parameters()}
    groups: list[list[str]] = []
    for group in optimizer.param_groups:
        parameters = group.get("params")
        _require(type(parameters) is list and all(id(parameter) in names for parameter in parameters), "optimizer has an unnamed parameter")
        groups.append([names[id(parameter)] for parameter in parameters])
    flattened = [name for group in groups for name in group]
    _require(len(flattened) == len(set(flattened)), "optimizer parameter order has duplicates")
    return groups


def _validate_live_muon(model: Any, optimizer: Any) -> None:
    _require(
        not any(_is_dtensor(value) for value in list(model.parameters()) + list(model.buffers())),
        "DTensor model state is unsupported",
    )
    _require(_optimizer_implementation(optimizer)["qualname"] == "Muon", "optimizer must be Muon")
    _require(bool(optimizer.param_groups), "Muon has no parameter groups")
    for group in optimizer.param_groups:
        _require(set(group) == _MUON_GROUP_FIELDS, "unknown or missing Muon hyperparameters")
        _require(type(group["params"]) is list and group["params"], "invalid Muon parameter group")
        for key in ("lr", "wd", "momentum", "adamw_eps"):
            _require(type(group[key]) in (int, float) and math.isfinite(float(group[key])), f"invalid Muon {key}")
        _require(
            type(group["nesterov"]) is bool and type(group["ns_steps"]) is int and group["ns_steps"] >= 1,
            "invalid Muon group fields",
        )
        _require(
            type(group["adamw_betas"]) is tuple
            and len(group["adamw_betas"]) == 2
            and all(type(value) in (int, float) and math.isfinite(float(value)) for value in group["adamw_betas"]),
            "invalid Muon AdamW betas",
        )


def capture_model_state(model: Any, optimizer: Any) -> dict[str, Any]:
    _validate_live_muon(model, optimizer)
    raw_optimizer = optimizer.state_dict()
    names = _parameter_names(model, optimizer)
    placements: dict[int, dict[str, str]] = {}
    for saved_group, live_group in zip(raw_optimizer["param_groups"], optimizer.param_groups):
        for saved_id, parameter in zip(saved_group["params"], live_group["params"]):
            values = optimizer.state.get(parameter, {})
            tensor_placements = {
                key: str(value.device)
                for key, value in values.items()
                if hasattr(value, "device")
            }
            if tensor_placements:
                placements[int(saved_id)] = tensor_placements
    return {
        "trainable": _cpu_tree({name: parameter for name, parameter in model.named_parameters() if parameter.requires_grad}),
        "buffers": _cpu_tree(dict(model.named_buffers())),
        "modes": {name: module.training for name, module in model.named_modules()},
        "optimizer": _cpu_tree(raw_optimizer),
        "optimizer_parameter_names": names,
        "optimizer_placements": placements,
        "optimizer_implementation": _optimizer_implementation(optimizer),
    }


def _validate_tensor(value: Any, parameter: Any, label: str, *, expected_shape: Any | None = None) -> None:
    import torch

    _require(isinstance(value, torch.Tensor) and not _is_dtensor(value), f"invalid {label} DTensor")
    _require(value.device.type == "cpu" and not value.requires_grad and value.layout == torch.strided, f"invalid {label} placement or layout")
    _require(value.dtype == parameter.dtype and value.shape == (expected_shape if expected_shape is not None else parameter.shape), f"invalid {label} shape or dtype")
    if value.is_floating_point() or value.is_complex():
        _require(bool(torch.isfinite(value).all()), f"non-finite {label}")


def _validate_model_tensors(saved: dict[str, Any], live: dict[str, Any], label: str) -> None:
    _require(type(saved) is dict and set(saved) == set(live), f"{label} keys mismatch")
    for name, value in saved.items():
        _validate_tensor(value, live[name], f"{label}/{name}")


def _validate_optimizer_state(state: dict[str, Any], model: Any, optimizer: Any, global_step: int) -> None:
    _validate_live_muon(model, optimizer)
    _require(type(state) is dict and set(state) == {"state", "param_groups"}, "Muon optimizer fields mismatch")
    live = optimizer.state_dict()
    _require(len(state["param_groups"]) == len(live["param_groups"]), "Muon group count mismatch")
    names = _parameter_names(model, optimizer)
    parameters_by_id: dict[int, Any] = {}
    ids: list[int] = []
    for saved_group, live_group, names_group, configured_group in zip(state["param_groups"], live["param_groups"], names, optimizer.param_groups):
        _require(type(saved_group) is dict and set(saved_group) == _MUON_GROUP_FIELDS, "Muon group fields mismatch")
        _require(set(live_group) == _MUON_GROUP_FIELDS and set(configured_group) == _MUON_GROUP_FIELDS, "configured Muon group fields mismatch")
        _require(tree_sha256({key: value for key, value in saved_group.items() if key != "params"}) == tree_sha256({key: value for key, value in live_group.items() if key != "params"}), "Muon hyperparameters differ from configured optimizer")
        saved_ids = saved_group["params"]
        _require(type(saved_ids) is list and all(type(value) is int and value >= 0 for value in saved_ids), "invalid Muon parameter IDs")
        _require(len(saved_ids) == len(names_group) == len(configured_group["params"]), "Muon parameter count mismatch")
        ids.extend(saved_ids)
        parameters_by_id.update(zip(saved_ids, configured_group["params"]))
    _require(len(ids) == len(set(ids)), "duplicate Muon parameter ID")
    _require(type(state["state"]) is dict and set(state["state"]) == set(ids), "missing Muon parameter state")
    for saved_id, values in state["state"].items():
        _require(type(saved_id) is int and type(values) is dict, "invalid Muon state entry")
        parameter = parameters_by_id[saved_id]
        _require(type(values.get("use_muon")) is bool, "Muon branch flag is missing")
        _require(
            values["use_muon"] is optimizer.state[parameter].get("use_muon"),
            "saved Muon branch differs from the configured parameter branch",
        )
        if values["use_muon"]:
            _require(set(values) == {"use_muon", "momentum_buffer"}, "missing or unknown Muon state field")
            expected_shape = parameter.shape if parameter.ndim <= 2 else (parameter.shape[0], math.prod(parameter.shape[1:]))
            _validate_tensor(values["momentum_buffer"], parameter, "Muon momentum buffer", expected_shape=expected_shape)
        else:
            _require(set(values) in ({"use_muon"}, {"use_muon", "step", "moment1", "moment2"}), "unknown Muon AdamW state field")
            if "step" in values:
                _require(type(values["step"]) is int and 1 <= values["step"] <= global_step, "invalid Muon AdamW Python step")
                _validate_tensor(values["moment1"], parameter, "Muon AdamW moment1")
                _validate_tensor(values["moment2"], parameter, "Muon AdamW moment2")
                import torch
                _require(bool((values["moment2"] >= 0).all()), "negative Muon AdamW second moment")


def validate_model_state(state: dict[str, Any], model: Any, optimizer: Any, global_step: int) -> None:
    expected = {"trainable", "buffers", "modes", "optimizer", "optimizer_parameter_names", "optimizer_placements", "optimizer_implementation"}
    _require(type(state) is dict and set(state) == expected, "HunyuanVideo model state fields mismatch")
    _validate_model_tensors(state["trainable"], {name: parameter for name, parameter in model.named_parameters() if parameter.requires_grad}, "trainable")
    _validate_model_tensors(state["buffers"], dict(model.named_buffers()), "buffers")
    _require(type(state["modes"]) is dict and set(state["modes"]) == {name for name, _ in model.named_modules()}, "module topology mismatch")
    _require(all(type(value) is bool for value in state["modes"].values()), "invalid module mode")
    _require(state["optimizer_implementation"] == _optimizer_implementation(optimizer), "Muon implementation mismatch")
    _require(state["optimizer_parameter_names"] == _parameter_names(model, optimizer), "Muon parameter order mismatch")
    _validate_optimizer_state(state["optimizer"], model, optimizer, global_step)
    placements = state["optimizer_placements"]
    _require(type(placements) is dict, "invalid Muon placement map")
    tensors_by_id: dict[int, set[str]] = {}
    for saved_id, values in state["optimizer"]["state"].items():
        tensor_keys = {key for key, value in values.items() if hasattr(value, "device")}
        if tensor_keys:
            tensors_by_id[saved_id] = tensor_keys
    _require(set(placements) == set(tensors_by_id), "Muon placement entries mismatch")
    parameters = [parameter for group in optimizer.param_groups for parameter in group["params"]]
    ids = [item for group in state["optimizer"]["param_groups"] for item in group["params"]]
    for saved_id, keys in tensors_by_id.items():
        placement = placements[saved_id]
        _require(type(placement) is dict and set(placement) == keys, "Muon tensor placement fields mismatch")
        parameter = parameters[ids.index(saved_id)]
        _require(all(value == str(parameter.device) for value in placement.values()), "Muon tensor placement mismatch")


def make_payload(*, contract: dict[str, Any], global_step: int, model: Any, optimizer: Any) -> dict[str, Any]:
    payload = {
        "metadata": boundary_metadata(contract, global_step),
        "state": capture_model_state(model, optimizer),
        "rng": common.capture_rng(contract["device_ids"]),
    }
    payload["adapter_sha256"] = tree_sha256(payload["state"]["trainable"])
    payload["integrity_sha256"] = tree_sha256(payload)
    validate_checkpoint(payload, contract, model, optimizer, native_rng=False)
    return payload


def validate_checkpoint(payload: dict[str, Any], contract: dict[str, Any], model: Any, optimizer: Any, *, native_rng: bool) -> dict[str, Any]:
    expected = {"metadata", "state", "rng", "adapter_sha256", "integrity_sha256"}
    _require(type(payload) is dict and set(payload) == expected, "not a full native HunyuanVideo checkpoint")
    unsigned = {key: value for key, value in payload.items() if key != "integrity_sha256"}
    _require(payload["integrity_sha256"] == tree_sha256(unsigned), "checkpoint integrity mismatch")
    metadata = payload["metadata"]
    _require(type(metadata) is dict and metadata.get("contract") == contract, "checkpoint identity or schedule mismatch")
    expected_metadata = boundary_metadata(contract, metadata.get("global_optimizer_step"))
    _require(metadata == expected_metadata, "checkpoint data progress mismatch")
    validate_model_state(payload["state"], model, optimizer, metadata["global_optimizer_step"])
    _require(payload["adapter_sha256"] == tree_sha256(payload["state"]["trainable"]), "checkpoint adapter SHA mismatch")
    rng_validation = common.validate_rng(payload["rng"], contract["device_ids"], native=native_rng)
    return {"metadata": metadata, "next": next_coordinate(metadata), "rng_validation": rng_validation}


def _copy_model_state(state: dict[str, Any], model: Any, optimizer: Any) -> None:
    import torch

    parameters = dict(model.named_parameters())
    buffers = dict(model.named_buffers())
    with torch.no_grad():
        for label, targets in (("trainable", parameters), ("buffers", buffers)):
            for name, value in state[label].items():
                targets[name].copy_(value.to(device=targets[name].device, dtype=targets[name].dtype))
    for name, module in model.named_modules():
        module.training = state["modes"][name]
    restored = defaultdict(dict)
    for saved_group, live_group in zip(state["optimizer"]["param_groups"], optimizer.param_groups):
        for saved_id, parameter in zip(saved_group["params"], live_group["params"]):
            values = state["optimizer"]["state"][saved_id]
            placements = state["optimizer_placements"].get(saved_id, {})
            restored[parameter] = {
                key: value.to(device=placements[key]).clone() if hasattr(value, "device") else value
                for key, value in values.items()
            }
    optimizer.state = restored


def restore_checkpoint(payload: dict[str, Any], contract: dict[str, Any], model: Any, optimizer: Any) -> dict[str, Any]:
    checked = validate_checkpoint(payload, contract, model, optimizer, native_rng=bool(contract["device_ids"]))
    try:
        _copy_model_state(payload["state"], model, optimizer)
        # RNG is deliberately applied after every model and optimizer mutation.
        common._restore_rng(payload["rng"], contract["device_ids"])
    except Exception as error:
        setattr(model, "_hunyuanvideo_resume_poisoned", True)
        raise ResumeApplyFatal("checkpoint application failed; terminate this worker") from error
    return checked


def assert_restored_boundary(payload: dict[str, Any], contract: dict[str, Any], model: Any, optimizer: Any) -> None:
    observed = {
        "state": capture_model_state(model, optimizer),
        "rng": common.capture_rng(contract["device_ids"]),
    }
    expected = {key: payload[key] for key in ("state", "rng")}
    _require(tree_sha256(observed) == tree_sha256(expected), "restored boundary differs from checkpoint")
