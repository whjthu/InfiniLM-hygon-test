from __future__ import annotations

import hashlib
import inspect
import json
import math
import random
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np

from .. import hy_resume_checkpoint as resume_checkpoint
from .. import runtime as runtime_helpers
from .. import sdxl_rollout_graph as rollout_graph_helpers
from ..manifest import sha256_path
from ..recovery_validation import (
    RecoveryValidation,
    run_recovery_validation,
    validate_recovery_enabled,
)
from ..runtime import autocast_bf16, memory_stats, require_cuda, synchronize
from ..sdxl_rollout_graph import SDXLRolloutGraph


SDXL_CHECKPOINT_SCHEMA = "sdxl-ddpo-full-policy-step-v1"
_SDXL_IDENTITY_FIELDS = {
    "config",
    "source",
    "model",
    "data",
    "reward",
    "runtime",
    "dependencies",
}


def ppo_clipped_loss(
    new_log_prob: Any,
    old_log_prob: Any,
    advantage: Any,
    clip_range: float,
) -> tuple[Any, Any, Any]:
    ratio = (new_log_prob - old_log_prob).exp()
    unclipped = -advantage * ratio
    clipped = -advantage * ratio.clamp(1.0 - clip_range, 1.0 + clip_range)
    loss = unclipped.maximum(clipped).mean()
    approx_kl = 0.5 * ((new_log_prob - old_log_prob) ** 2).mean()
    return loss, ratio.mean(), approx_kl


def image_color_reward(images: Any, target_rgb: tuple[float, float, float]) -> Any:
    """Score decoded images against a target color while preserving rollout variance."""
    target = images.new_tensor(target_rgb).view(1, 3)
    channel_mean = images.float().mean(dim=(2, 3))
    color_error = ((channel_mean - target) ** 2).mean(dim=1)
    contrast = images.float().std(dim=(1, 2, 3))
    return -color_error + 0.05 * contrast


def _sha256_trainable(module: Any) -> str:
    digest = hashlib.sha256()
    for name, parameter in sorted(module.named_parameters()):
        if not parameter.requires_grad:
            continue
        tensor = parameter.detach().contiguous().view(-1).float().cpu()
        digest.update(name.encode("utf-8"))
        digest.update(tensor.numpy().tobytes())
    return digest.hexdigest()


def _seed_initialization(torch: Any, seed: int) -> None:
    """Seed host and CUDA RNGs before stochastic model or adapter construction."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def _cpu_tree(value: Any) -> Any:
    if hasattr(value, "detach"):
        return value.detach().cpu()
    if isinstance(value, dict):
        return {key: _cpu_tree(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_cpu_tree(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_cpu_tree(item) for item in value)
    return value


def _weights_sha256(weights: Path) -> str:
    """Hash the local model tree so a checkpoint cannot cross model contents."""
    digest = hashlib.sha256()
    for path in sorted(weights.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(weights).as_posix().encode("utf-8")
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(path.stat().st_size.to_bytes(8, "big"))
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
    return digest.hexdigest()


def _source_sha256(value: Any, label: str) -> str:
    try:
        source = inspect.getsourcefile(value)
    except (OSError, TypeError):
        source = None
    if source is None or not Path(source).is_file():
        raise RuntimeError(f"cannot identify SDXL resume dependency source: {label}")
    return resume_checkpoint.file_sha256(Path(source))


def _dependency_evidence(
    pipe: Any,
    scheduler_type: Any,
    lora_config_type: Any,
    torch: Any,
    rollout_graph_enabled: bool = False,
) -> dict[str, Any]:
    attention_sources = {
        f"{type(processor).__module__}.{type(processor).__qualname__}": _source_sha256(
            type(processor), "diffusers attention processor"
        )
        for processor in pipe.unet.attn_processors.values()
    }
    lora_layer_sources = {
        f"{type(module).__module__}.{type(module).__qualname__}": _source_sha256(
            type(module), "PEFT LoRA layer"
        )
        for _, module in pipe.unet.named_modules()
        if type(module).__module__.startswith("peft.") and hasattr(module, "lora_A")
    }
    if not lora_layer_sources:
        raise RuntimeError("SDXL LoRA injection exposed no PEFT LoRA layer sources")
    helpers = {
        "backend": resume_checkpoint.file_sha256(Path(__file__)),
        "resume_checkpoint": _source_sha256(resume_checkpoint, "resume helper"),
        "runtime_module": _source_sha256(runtime_helpers, "runtime helper module"),
        "require_cuda": _source_sha256(require_cuda, "require_cuda helper"),
    }
    if rollout_graph_enabled:
        helpers.update(
            rollout_graph_module=_source_sha256(
                rollout_graph_helpers, "SDXL rollout graph module"
            ),
            rollout_graph_class=_source_sha256(
                SDXLRolloutGraph, "SDXL rollout graph class"
            ),
        )
    torch_cuda = {
        "torch_version": str(torch.__version__),
        "torch_python": _source_sha256(torch, "torch Python module"),
        "cuda_version": getattr(getattr(torch, "version", None), "cuda", None),
        "cuda_python": _source_sha256(torch.cuda, "torch CUDA module"),
    }
    if rollout_graph_enabled:
        torch_cuda.update(
            graph_context_source=_source_sha256(
                getattr(torch.cuda, "graph", None), "torch.cuda.graph"
            ),
            graph_class_source=_source_sha256(
                getattr(torch.cuda, "CUDAGraph", None), "torch.cuda.CUDAGraph"
            ),
        )
    return {
        "helpers": helpers,
        "diffusers": {
            "pipeline": _source_sha256(type(pipe), "pipeline"),
            "scheduler": _source_sha256(scheduler_type, "scheduler"),
            "unet": _source_sha256(type(pipe.unet), "unet"),
            "unet_add_adapter": _source_sha256(pipe.unet.add_adapter, "UNet adapter helper"),
            "attention_processors": attention_sources,
        },
        "peft": {
            "lora_config": _source_sha256(lora_config_type, "PEFT LoRA config"),
            "lora_layers": lora_layer_sources,
        },
        "torch_cuda": torch_cuda,
    }


def _checkpoint_identity(
    weights: Path, resolved: dict[str, Any], dependencies: dict[str, Any]
) -> dict[str, str]:
    relevant_config = {
        key: resolved[key]
        for key in sorted(resolved)
        if key not in {"resume_from_checkpoint", "validate_recovery", "resume_atol"}
        # False preserves the pre-option eager config identity; true is explicit.
        and not (key == "rollout_graph" and resolved[key] is False)
    }
    return {
        "config": resume_checkpoint.json_sha256(relevant_config),
        "source": dependencies["helpers"]["backend"],
        "model": _weights_sha256(weights),
        "data": resume_checkpoint.json_sha256({"prompt": resolved["prompt"]}),
        "reward": resume_checkpoint.json_sha256(
            {"target_rgb": resolved["target_rgb"], "formula": "image-color-v1"}
        ),
        "runtime": resume_checkpoint.json_sha256(
            {"dtype": "bfloat16", "device": "cuda", "torch": dependencies["torch_cuda"]}
        ),
        "dependencies": resume_checkpoint.json_sha256(dependencies),
    }


def _build_checkpoint_contract(
    identity: dict[str, str],
    resolved: dict[str, Any],
    device_ids: list[int],
) -> dict[str, Any]:
    contract = {
        "backend": "sdxl-ddpo",
        "identity": identity,
        "seed": resolved["seed"],
        "warmup_steps": resolved["warmup_steps"],
        "max_steps": resolved["max_steps"],
        "total_global_steps": resolved["total_global_steps"],
        "rollouts_per_prompt": resolved["batch_size"],
        "sample_steps": resolved["sample_steps"],
        "data_order": [identity["data"]],
        "device_ids": device_ids,
        "seed_formula": "base+global-step/v1",
        "checkpoint_step_basis": "global-optimizer-step",
    }
    _validate_checkpoint_contract(contract)
    return contract


def _validate_checkpoint_contract(contract: dict[str, Any]) -> None:
    expected = {
        "backend", "identity", "seed", "warmup_steps", "max_steps", "total_global_steps",
        "rollouts_per_prompt", "sample_steps", "data_order", "device_ids", "seed_formula",
        "checkpoint_step_basis",
    }
    if type(contract) is not dict or set(contract) != expected:
        raise resume_checkpoint.CheckpointValidationError("SDXL checkpoint contract fields mismatch")
    if (
        contract["backend"] != "sdxl-ddpo"
        or contract["seed_formula"] != "base+global-step/v1"
        or contract["checkpoint_step_basis"] != "global-optimizer-step"
    ):
        raise resume_checkpoint.CheckpointValidationError("SDXL checkpoint backend or seed formula mismatch")
    if (
        type(contract["identity"]) is not dict
        or set(contract["identity"]) != _SDXL_IDENTITY_FIELDS
    ):
        raise resume_checkpoint.CheckpointValidationError("SDXL checkpoint identity fields mismatch")
    if not all(
        type(value) is str
        and len(value) == 64
        and all(char in "0123456789abcdef" for char in value)
        for value in contract["identity"].values()
    ):
        raise resume_checkpoint.CheckpointValidationError("invalid SDXL checkpoint identity")
    for key, minimum in (
        ("seed", 0),
        ("warmup_steps", 0),
        ("max_steps", 1),
        ("total_global_steps", 1),
        ("rollouts_per_prompt", 4),
        ("sample_steps", 2),
    ):
        if type(contract[key]) is not int or contract[key] < minimum:
            raise resume_checkpoint.CheckpointValidationError(f"invalid SDXL checkpoint {key}")
    if contract["total_global_steps"] != contract["warmup_steps"] + contract["max_steps"]:
        raise resume_checkpoint.CheckpointValidationError("SDXL total global step count mismatch")
    if type(contract["data_order"]) is not list or len(contract["data_order"]) != 1:
        raise resume_checkpoint.CheckpointValidationError("invalid SDXL data order")
    if type(contract["device_ids"]) is not list or contract["device_ids"] not in ([], [0]):
        raise resume_checkpoint.CheckpointValidationError("invalid SDXL device IDs")


def _checkpoint_metadata(contract: dict[str, Any], global_step: int) -> dict[str, Any]:
    _validate_checkpoint_contract(contract)
    if type(global_step) is not int or not 1 <= global_step <= contract["total_global_steps"]:
        raise resume_checkpoint.CheckpointValidationError("checkpoint is not at a completed SDXL update")
    return {
        "schema": SDXL_CHECKPOINT_SCHEMA,
        "boundary": "after-complete-policy-update",
        "contract": contract,
        "global_step": global_step,
        "completed_policy_updates": global_step,
        "completed_warmup_updates": min(global_step, contract["warmup_steps"]),
        "completed_measured_updates": max(0, global_step - contract["warmup_steps"]),
        "next_global_step": global_step + 1,
        "next_measured_step": max(0, global_step + 1 - contract["warmup_steps"]),
        "next_data_cursor": global_step % len(contract["data_order"]),
        "next_rollout_seed": contract["seed"] + global_step + 1,
    }


def _next_step_record(metadata: dict[str, Any]) -> dict[str, int]:
    return {
        "global_step": metadata["next_global_step"],
        "measured_step": metadata["next_measured_step"],
        "data_cursor": metadata["next_data_cursor"],
        "rollout_seed": metadata["next_rollout_seed"],
    }


def _make_checkpoint_payload(
    contract: dict[str, Any],
    global_step: int,
    unet: Any,
    optimizer: Any,
    optimizer_progress: dict[str, int],
) -> dict[str, Any]:
    payload = {
        "metadata": _checkpoint_metadata(contract, global_step),
        "state": resume_checkpoint.capture_model_state(unet, optimizer, optimizer_progress),
        "rng": resume_checkpoint.capture_rng(contract["device_ids"]),
    }
    payload["adapter_sha256"] = resume_checkpoint.tree_sha256(payload["state"]["trainable"])
    payload["integrity_sha256"] = resume_checkpoint.tree_sha256(payload)
    _validate_checkpoint_payload(payload, contract, unet, optimizer, native_rng=False)
    return payload


def _validate_checkpoint_payload(
    payload: dict[str, Any],
    contract: dict[str, Any],
    unet: Any,
    optimizer: Any,
    *,
    native_rng: bool,
) -> dict[str, Any]:
    expected_fields = {"metadata", "state", "rng", "adapter_sha256", "integrity_sha256"}
    if type(payload) is not dict or set(payload) != expected_fields:
        raise resume_checkpoint.CheckpointValidationError("not a full SDXL DDPO checkpoint")
    unsigned = {key: value for key, value in payload.items() if key != "integrity_sha256"}
    if payload["integrity_sha256"] != resume_checkpoint.tree_sha256(unsigned):
        raise resume_checkpoint.CheckpointValidationError("SDXL checkpoint integrity mismatch")
    metadata = payload["metadata"]
    if type(metadata) is not dict or metadata.get("contract") != contract:
        raise resume_checkpoint.CheckpointValidationError("SDXL checkpoint identity or schedule mismatch")
    expected_metadata = _checkpoint_metadata(contract, metadata.get("global_step"))
    if metadata != expected_metadata:
        raise resume_checkpoint.CheckpointValidationError("SDXL checkpoint data progress mismatch")
    resume_checkpoint.validate_model_state(payload["state"], unet, optimizer, metadata["global_step"])
    if payload["adapter_sha256"] != resume_checkpoint.tree_sha256(payload["state"]["trainable"]):
        raise resume_checkpoint.CheckpointValidationError("SDXL checkpoint adapter SHA mismatch")
    rng_validation = resume_checkpoint.validate_rng(
        payload["rng"], contract["device_ids"], native=native_rng
    )
    return {"metadata": metadata, "rng_validation": rng_validation}


def _restore_checkpoint(
    payload: dict[str, Any], contract: dict[str, Any], unet: Any, optimizer: Any
) -> tuple[dict[str, int], dict[str, Any]]:
    checked = _validate_checkpoint_payload(payload, contract, unet, optimizer, native_rng=True)
    try:
        resume_checkpoint._copy_model_state(payload["state"], unet, optimizer)
        resume_checkpoint._restore_rng(payload["rng"], contract["device_ids"])
    except Exception as error:
        setattr(unet, "_sdxl_resume_poisoned", True)
        raise resume_checkpoint.ResumeApplyFatal("SDXL checkpoint application failed; terminate this worker") from error
    return dict(payload["state"]["optimizer_progress"]), checked


def _assert_restored_boundary(
    payload: dict[str, Any],
    contract: dict[str, Any],
    unet: Any,
    optimizer: Any,
    optimizer_progress: dict[str, int],
) -> None:
    observed = {
        "state": resume_checkpoint.capture_model_state(unet, optimizer, optimizer_progress),
        "rng": resume_checkpoint.capture_rng(contract["device_ids"]),
    }
    expected = {key: payload[key] for key in ("state", "rng")}
    if resume_checkpoint.tree_sha256(observed) != resume_checkpoint.tree_sha256(expected):
        raise resume_checkpoint.CheckpointValidationError("restored SDXL boundary differs from checkpoint")


def _checkpoint_path(value: Any) -> Path | None:
    if value is None:
        return None
    if type(value) is not str or not value:
        raise ValueError("resume_from_checkpoint must be a non-empty path")
    path = Path(value).expanduser().resolve()
    return path / "state.pt" if path.is_dir() else path


def _ddim_step_with_log_prob(
    scheduler: Any,
    model_output: Any,
    timestep: Any,
    sample: Any,
    eta: float,
    previous_sample: Any | None = None,
    variance_noise: Any | None = None,
) -> tuple[Any, Any, Any, bool]:
    torch = require_cuda()
    timestep_value = int(timestep.item()) if hasattr(timestep, "item") else int(timestep)
    stride = scheduler.config.num_train_timesteps // scheduler.num_inference_steps
    previous_timestep = timestep_value - stride
    alpha_t = scheduler.alphas_cumprod[timestep_value].to(sample.device, torch.float32)
    alpha_previous = (
        scheduler.alphas_cumprod[previous_timestep]
        if previous_timestep >= 0
        else scheduler.final_alpha_cumprod
    ).to(sample.device, torch.float32)
    beta_t = 1.0 - alpha_t
    sample_float = sample.float()
    output_float = model_output.float()
    prediction_type = scheduler.config.prediction_type
    if prediction_type == "epsilon":
        original = (sample_float - beta_t.sqrt() * output_float) / alpha_t.sqrt()
        epsilon = output_float
    elif prediction_type == "v_prediction":
        original = alpha_t.sqrt() * sample_float - beta_t.sqrt() * output_float
        epsilon = alpha_t.sqrt() * output_float + beta_t.sqrt() * sample_float
    elif prediction_type == "sample":
        original = output_float
        epsilon = (sample_float - alpha_t.sqrt() * original) / beta_t.sqrt()
    else:
        raise ValueError(f"unsupported DDIM prediction type: {prediction_type}")
    if scheduler.config.thresholding:
        original = scheduler._threshold_sample(original)
    elif scheduler.config.clip_sample:
        original = original.clamp(
            -scheduler.config.clip_sample_range,
            scheduler.config.clip_sample_range,
        )
    variance = ((1.0 - alpha_previous) / (1.0 - alpha_t)) * (
        1.0 - alpha_t / alpha_previous
    )
    std = eta * variance.clamp_min(0.0).sqrt()
    direction = (1.0 - alpha_previous - std**2).clamp_min(0.0).sqrt() * epsilon
    mean = alpha_previous.sqrt() * original + direction
    stochastic = bool(float(std.cpu()) > 0.0)
    if previous_sample is None:
        if variance_noise is None:
            variance_noise = torch.randn_like(model_output)
        previous_sample = mean + std * variance_noise.float()
    elif variance_noise is None and stochastic:
        variance_noise = (previous_sample.float() - mean) / std
    if stochastic:
        log_prob = -((previous_sample.detach().float() - mean) ** 2) / (2.0 * std**2)
        log_prob = log_prob - std.log() - 0.5 * math.log(2.0 * math.pi)
        log_prob = log_prob.mean(dim=tuple(range(1, log_prob.ndim)))
    else:
        log_prob = torch.zeros(sample.shape[0], device=sample.device, dtype=torch.float32)
        if variance_noise is None:
            variance_noise = torch.zeros_like(model_output)
    return previous_sample.to(sample.dtype), log_prob, variance_noise, stochastic


def _decode_images(pipe: Any, latents: Any) -> Any:
    torch = require_cuda()
    scaled = latents / pipe.vae.config.scaling_factor
    with torch.no_grad(), autocast_bf16():
        decoded = pipe.vae.decode(scaled, return_dict=False)[0]
    return pipe.image_processor.postprocess(decoded, output_type="pt")


def _prepare_conditioning(pipe: Any, prompt: str, batch_size: int, height: int, width: int) -> dict[str, Any]:
    torch = require_cuda()
    with torch.no_grad(), autocast_bf16():
        prompt_embeds, negative_embeds, pooled, negative_pooled = pipe.encode_prompt(
            prompt=[prompt] * batch_size,
            device=torch.device("cuda"),
            num_images_per_prompt=1,
            do_classifier_free_guidance=True,
        )
    projection_dim = int(pipe.text_encoder_2.config.projection_dim)
    time_ids = pipe._get_add_time_ids(
        (height, width),
        (0, 0),
        (height, width),
        dtype=prompt_embeds.dtype,
        text_encoder_projection_dim=projection_dim,
    ).to("cuda").repeat(batch_size, 1)
    return {
        "prompt_embeds": torch.cat([negative_embeds, prompt_embeds]),
        "text_embeds": torch.cat([negative_pooled, pooled]),
        "time_ids": torch.cat([time_ids, time_ids]),
    }


def _prepare_unet_inputs(
    pipe: Any, latents: Any, timestep: Any, conditioning: dict[str, Any]
) -> list[Any]:
    torch = require_cuda()
    latent_input = torch.cat([latents, latents])
    latent_input = pipe.scheduler.scale_model_input(latent_input, timestep)
    timestep_batch = timestep.expand(latent_input.shape[0]) if timestep.ndim == 0 else timestep
    return [
        latent_input,
        timestep_batch,
        conditioning["prompt_embeds"],
        conditioning["text_embeds"],
        conditioning["time_ids"],
    ]


def _predict_noise(
    pipe: Any,
    latents: Any,
    timestep: Any,
    conditioning: dict[str, Any],
    guidance: float,
    *,
    raw_predictor: Any = None,
) -> Any:
    values = _prepare_unet_inputs(pipe, latents, timestep, conditioning)
    if raw_predictor is None:
        with autocast_bf16():
            prediction = pipe.unet(
                values[0],
                values[1],
                encoder_hidden_states=values[2],
                added_cond_kwargs={"text_embeds": values[3], "time_ids": values[4]},
                return_dict=False,
            )[0]
    else:
        prediction = raw_predictor(pipe.unet, values)
    unconditional, conditional = prediction.chunk(2)
    return unconditional + guidance * (conditional - unconditional)


def _sample_rollouts(
    pipe: Any,
    conditioning: dict[str, Any],
    batch_size: int,
    height: int,
    width: int,
    steps: int,
    guidance: float,
    eta: float,
    seed: int,
    profile_stages: bool = False,
    *,
    predict_noise: Any = None,
) -> dict[str, Any]:
    torch = require_cuda()
    torch.manual_seed(seed)
    pipe.scheduler.set_timesteps(steps, device="cuda")
    shape = (
        batch_size,
        pipe.unet.config.in_channels,
        height // pipe.vae_scale_factor,
        width // pipe.vae_scale_factor,
    )
    latents = torch.randn(shape, device="cuda", dtype=torch.bfloat16)
    latents = latents * pipe.scheduler.init_noise_sigma
    states = []
    next_states = []
    noises = []
    log_probs = []
    stochastic_mask = []
    if profile_stages:
        synchronize()
    rollout_started = time.perf_counter()
    with torch.no_grad():
        for timestep in pipe.scheduler.timesteps:
            states.append(latents)
            if predict_noise is None:
                predicted_noise = _predict_noise(
                    pipe, latents, timestep, conditioning, guidance
                )
            else:
                predicted_noise = predict_noise(
                    pipe, latents, timestep, conditioning, guidance
                )
            latents, log_prob, variance_noise, stochastic = _ddim_step_with_log_prob(
                pipe.scheduler,
                predicted_noise,
                timestep,
                latents,
                eta,
            )
            next_states.append(latents)
            noises.append(variance_noise)
            log_probs.append(log_prob)
            stochastic_mask.append(stochastic)
    if profile_stages:
        synchronize()
    unet_rollout_seconds = time.perf_counter() - rollout_started
    if profile_stages:
        synchronize()
    decode_started = time.perf_counter()
    images = _decode_images(pipe, latents)
    if profile_stages:
        synchronize()
    vae_decode_seconds = time.perf_counter() - decode_started
    return {
        "latents": torch.stack(states, dim=1),
        "next_latents": torch.stack(next_states, dim=1),
        "noise": torch.stack(noises, dim=1),
        "log_probs": torch.stack(log_probs, dim=1),
        "timesteps": pipe.scheduler.timesteps.detach().clone(),
        "stochastic_mask": stochastic_mask,
        "images": images,
        "unet_rollout_seconds": unet_rollout_seconds,
        "vae_decode_seconds": vae_decode_seconds,
    }


def _train_transition(
    pipe: Any,
    optimizer: Any,
    conditioning: dict[str, Any],
    rollout: dict[str, Any],
    rewards: Any,
    timestep_index: int,
    guidance: float,
    eta: float,
    clip_range: float,
    max_grad_norm: float,
) -> dict[str, float | bool]:
    torch = require_cuda()
    advantages = (rewards - rewards.mean()) / (rewards.std(unbiased=False) + 1e-6)
    latents = rollout["latents"][:, timestep_index]
    next_latents = rollout["next_latents"][:, timestep_index]
    timestep = rollout["timesteps"][timestep_index]
    old_log_prob = rollout["log_probs"][:, timestep_index].detach().float()
    started = time.perf_counter()
    optimizer.zero_grad(set_to_none=True)
    zero_grad_seconds = time.perf_counter() - started
    forward_started = time.perf_counter()
    predicted_noise = _predict_noise(pipe, latents, timestep, conditioning, guidance)
    _, new_log_prob, _, stochastic = _ddim_step_with_log_prob(
        pipe.scheduler,
        predicted_noise,
        timestep,
        latents,
        eta,
        previous_sample=next_latents,
    )
    if not stochastic:
        raise RuntimeError("DDPO selected a deterministic scheduler transition")
    unet_forward_seconds = time.perf_counter() - forward_started
    difference = (new_log_prob.detach() - old_log_prob).abs()
    loss, ratio, approx_kl = ppo_clipped_loss(
        new_log_prob,
        old_log_prob,
        advantages,
        clip_range,
    )
    backward_started = time.perf_counter()
    loss.backward()
    backward_seconds = time.perf_counter() - backward_started
    trainable = [parameter for parameter in pipe.unet.parameters() if parameter.requires_grad]
    optimizer_started = time.perf_counter()
    grad_norm = torch.nn.utils.clip_grad_norm_(trainable, max_grad_norm)
    finite_gradients = bool(torch.isfinite(grad_norm).item()) and float(grad_norm) > 0.0
    if not finite_gradients:
        raise RuntimeError(f"non-finite or zero SDXL DDPO gradient norm: {float(grad_norm)}")
    optimizer.step()
    synchronize()
    optimizer_seconds = time.perf_counter() - optimizer_started
    return {
        "loss": float(loss.detach().cpu()),
        "ratio": float(ratio.detach().cpu()),
        "approx_kl": float(approx_kl.detach().cpu()),
        "grad_norm": float(grad_norm.detach().cpu()),
        "log_prob_mae": float(difference.mean().cpu()),
        "log_prob_p99": float(torch.quantile(difference, 0.99).cpu()),
        "finite_gradients": finite_gradients,
        "zero_grad_seconds": zero_grad_seconds,
        "unet_forward_seconds": unet_forward_seconds,
        "backward_seconds": backward_seconds,
        "optimizer_seconds": optimizer_seconds,
    }


def _write_rollout_evidence(
    directory: Path,
    rollout: dict[str, Any],
    prompt: str,
    seed: int,
    adapter_sha: str,
    global_step: int,
    rewards: Any,
) -> list[dict[str, Any]]:
    torch = require_cuda()
    directory.mkdir(parents=True, exist_ok=True)
    tensor_path = directory / "tensors.pt"
    torch.save(
        {
            key: _cpu_tree(rollout[key])
            for key in ("latents", "next_latents", "noise", "log_probs", "timesteps")
        },
        tensor_path,
    )
    tensor_sha = sha256_path(tensor_path)
    records = []
    for index, reward in enumerate(rewards.detach().cpu().tolist()):
        record = {
            "latent": {"path": str(tensor_path), "sha256": tensor_sha, "sample": index},
            "timestep": rollout["timesteps"].detach().cpu().tolist(),
            "noise": {"path": str(tensor_path), "sha256": tensor_sha, "sample": index},
            "log_prob": rollout["log_probs"][index].detach().cpu().tolist(),
            "reward": float(reward),
            "prompt": prompt,
            "seed": seed,
            "adapter_sha": adapter_sha,
            "global_step": global_step,
        }
        path = directory / f"sample-{index}.json"
        path.write_text(json.dumps(record, sort_keys=True) + "\n", encoding="utf-8")
        records.append({"path": str(path), "sha256": sha256_path(path)})
    return records


def run_sdxl_ddpo(weights: Path, config: dict[str, Any], output_dir: Path) -> dict[str, Any]:
    base_seed = int(config.get("seed", 42))
    rollout_graph_enabled = config.get("rollout_graph", False)
    if type(rollout_graph_enabled) is not bool:
        raise ValueError("rollout_graph must be a boolean")
    if not weights.is_dir():
        raise RuntimeError(f"weights are missing: {weights}")
    try:
        from diffusers import DDIMScheduler, StableDiffusionXLPipeline
        from peft import LoraConfig
    except ImportError as exc:
        raise RuntimeError("SDXL DDPO requires the locked diffusers and PEFT sources") from exc

    torch = require_cuda()
    _seed_initialization(torch, base_seed)
    total_started = time.perf_counter()
    load_started = time.perf_counter()
    pipe = StableDiffusionXLPipeline.from_pretrained(
        str(weights),
        torch_dtype=torch.bfloat16,
        local_files_only=True,
    )
    pipe.scheduler = DDIMScheduler.from_config(pipe.scheduler.config)
    pipe.unet.requires_grad_(False)
    pipe.unet.add_adapter(
        LoraConfig(
            r=int(config.get("lora_rank", 4)),
            lora_alpha=int(config.get("lora_alpha", 4)),
            init_lora_weights="gaussian",
            target_modules=["to_k", "to_q", "to_v", "to_out.0"],
        )
    )
    pipe.to("cuda")
    if next(pipe.unet.parameters()).device.type != "cuda":
        raise RuntimeError("SDXL UNet main forward is not on CUDA")
    load_seconds = time.perf_counter() - load_started

    batch_size = int(config.get("rollouts_per_prompt", 4))
    if batch_size < 4:
        raise ValueError("SDXL DDPO requires at least four rollouts per prompt")
    height = int(config.get("height", 256))
    width = int(config.get("width", 256))
    sample_steps = int(config.get("sample_steps", 4))
    if sample_steps < 2:
        raise ValueError("SDXL DDPO needs at least two scheduler steps")
    max_steps = int(config.get("max_steps", 20))
    if max_steps < 1:
        raise ValueError("max_steps must be positive")
    warmup_steps = int(config.get("warmup_steps", 0))
    if warmup_steps < 0:
        raise ValueError("warmup_steps must be non-negative")
    total_global_steps = warmup_steps + max_steps
    checkpoint_step_basis = config.get("checkpoint_step_basis", "global-optimizer-step")
    if checkpoint_step_basis != "global-optimizer-step":
        raise ValueError("checkpoint_step_basis must be global-optimizer-step")
    configured_checkpoint_steps = config.get("checkpoint_steps")
    try:
        checkpoint_steps = (
            {int(value) for value in configured_checkpoint_steps}
            if configured_checkpoint_steps is not None
            else {value for value in (10, 20) if value <= total_global_steps}
        )
    except TypeError as error:
        raise ValueError("checkpoint_steps must be a sequence of integers") from error
    if any(value <= 0 or value > total_global_steps for value in checkpoint_steps):
        raise ValueError("checkpoint_steps must be within total global optimizer steps")
    checkpoint_steps.add(total_global_steps)
    prompt = str(config["prompt"])
    guidance = float(config.get("guidance_scale", 5.0))
    eta = float(config.get("eta", 1.0))
    clip_range = float(config.get("clip_range", 0.2))
    target_rgb = tuple(float(item) for item in config.get("reward_target_rgb", [0.65, 0.25, 0.20]))
    if len(target_rgb) != 3:
        raise ValueError("reward_target_rgb must contain three values")
    conditioning = _prepare_conditioning(pipe, prompt, batch_size, height, width)
    pipe.text_encoder.to("cpu")
    pipe.text_encoder_2.to("cpu")
    torch.cuda.empty_cache()
    trainable = [parameter for parameter in pipe.unet.parameters() if parameter.requires_grad]
    if not trainable:
        raise RuntimeError("SDXL DDPO LoRA injection produced no trainable parameters")
    optimizer = torch.optim.AdamW(
        trainable,
        lr=float(config.get("learning_rate", 1e-4)),
        fused=bool(config.get("fused_optimizer", False)),
    )
    resolved = {
        "seed": base_seed,
        "batch_size": batch_size,
        "height": height,
        "width": width,
        "sample_steps": sample_steps,
        "max_steps": max_steps,
        "warmup_steps": warmup_steps,
        "total_global_steps": total_global_steps,
        "prompt": prompt,
        "guidance": guidance,
        "eta": eta,
        "clip_range": clip_range,
        "target_rgb": target_rgb,
        "learning_rate": float(config.get("learning_rate", 1e-4)),
        "fused_optimizer": bool(config.get("fused_optimizer", False)),
        "lora_rank": int(config.get("lora_rank", 4)),
        "lora_alpha": int(config.get("lora_alpha", 4)),
        "max_grad_norm": float(config.get("max_grad_norm", 1.0)),
        "rollout_graph": rollout_graph_enabled,
        "checkpoint_steps": sorted(checkpoint_steps),
        "checkpoint_step_basis": checkpoint_step_basis,
    }
    dependency_evidence = _dependency_evidence(
        pipe, DDIMScheduler, LoraConfig, torch, rollout_graph_enabled
    )
    identity = _checkpoint_identity(weights, resolved, dependency_evidence)
    checkpoint_contract = _build_checkpoint_contract(identity, resolved, [0])
    resume_path = _checkpoint_path(config.get("resume_from_checkpoint"))
    resume_payload: dict[str, Any] | None = None
    completed_global_step = 0
    optimizer_progress = resume_checkpoint.initial_optimizer_progress(pipe.unet, optimizer)
    resume_checkpoint_sha = None
    resume_validation_seconds = 0.0
    if resume_path is not None:
        if not resume_path.is_file():
            raise RuntimeError(f"SDXL resume checkpoint is missing: {resume_path}")
        resume_started = time.perf_counter()
        resume_payload = resume_checkpoint.load_checkpoint(resume_path)
        # Preflight validates identity and every state component before any restore.
        checked = _validate_checkpoint_payload(
            resume_payload, checkpoint_contract, pipe.unet, optimizer, native_rng=True
        )
        optimizer_progress, checked = _restore_checkpoint(
            resume_payload, checkpoint_contract, pipe.unet, optimizer
        )
        _assert_restored_boundary(
            resume_payload, checkpoint_contract, pipe.unet, optimizer, optimizer_progress
        )
        completed_global_step = int(checked["metadata"]["global_step"])
        resume_checkpoint_sha = sha256_path(resume_path)
        resume_validation_seconds = time.perf_counter() - resume_started
    output_dir.mkdir(parents=True, exist_ok=True)
    raw_log = output_dir / "steps.jsonl"
    if raw_log.exists():
        raw_log.unlink()
    adapter_before = _sha256_trainable(pipe.unet)
    step_metrics: list[dict[str, Any]] = []
    trajectory_records: list[dict[str, Any]] = []
    rollout_seconds = 0.0
    reward_seconds = 0.0
    update_seconds = 0.0
    evidence_seconds = 0.0
    checkpoint_seconds = 0.0
    logging_seconds = 0.0
    rollout_unet_seconds = 0.0
    vae_decode_seconds = 0.0
    finite_tensors = True
    current_adapter = True
    written_checkpoint_paths: set[Path] = set()
    measurement_window_started: float | None = None
    measurement_window_seconds = 0.0
    rollout_graph: SDXLRolloutGraph | None = None
    rollout_graph_setup_seconds = 0.0
    rollout_options: dict[str, Any] = {}
    if rollout_graph_enabled:
        rollout_graph = SDXLRolloutGraph(torch)
        pipe.scheduler.set_timesteps(sample_steps, device="cuda")
        setup_shape = (
            batch_size,
            pipe.unet.config.in_channels,
            height // pipe.vae_scale_factor,
            width // pipe.vae_scale_factor,
        )
        with torch.no_grad():
            setup_latents = torch.zeros(setup_shape, device="cuda", dtype=torch.bfloat16)
            setup_values = _prepare_unet_inputs(
                pipe, setup_latents, pipe.scheduler.timesteps[0], conditioning
            )
        rollout_graph.setup(pipe.unet, setup_values, adapter_before)
        rollout_graph_setup_seconds = rollout_graph.setup_seconds

        def rollout_predictor(
            pipe: Any,
            latents: Any,
            timestep: Any,
            conditioning: dict[str, Any],
            guidance: float,
        ) -> Any:
            return _predict_noise(
                pipe,
                latents,
                timestep,
                conditioning,
                guidance,
                raw_predictor=rollout_graph,
            )

        rollout_options["predict_noise"] = rollout_predictor

    for global_step in range(completed_global_step + 1, total_global_steps + 1):
        if global_step > warmup_steps and measurement_window_started is None:
            synchronize()
            measurement_window_started = time.perf_counter()
        step_started = time.perf_counter()
        adapter_sha = _sha256_trainable(pipe.unet)
        if rollout_graph is not None:
            rollout_graph.begin_rollout(pipe.unet, adapter_sha)
        rollout_started = time.perf_counter()
        rollout = _sample_rollouts(
            pipe,
            conditioning,
            batch_size,
            height,
            width,
            sample_steps,
            guidance,
            eta,
            base_seed + global_step,
            bool(config.get("profile_stages", False)),
            **rollout_options,
        )
        synchronize()
        rollout_elapsed = time.perf_counter() - rollout_started
        reward_started = time.perf_counter()
        rewards = image_color_reward(rollout["images"], target_rgb)
        reward_elapsed = time.perf_counter() - reward_started
        if not torch.isfinite(rewards).all():
            raise RuntimeError("SDXL DDPO reward contains non-finite values")
        stochastic_indices = [
            index for index, stochastic in enumerate(rollout["stochastic_mask"]) if stochastic
        ]
        timestep_index = stochastic_indices[(global_step - 1) % len(stochastic_indices)]
        update_started = time.perf_counter()
        update = _train_transition(
            pipe,
            optimizer,
            conditioning,
            rollout,
            rewards,
            timestep_index,
            guidance,
            eta,
            clip_range,
            float(config.get("max_grad_norm", 1.0)),
        )
        update_elapsed = time.perf_counter() - update_started
        optimizer_progress = resume_checkpoint.advance_optimizer_progress(
            optimizer_progress, pipe.unet, optimizer
        )
        rollout_seconds += rollout_elapsed
        rollout_unet_seconds += float(rollout["unet_rollout_seconds"])
        vae_decode_seconds += float(rollout["vae_decode_seconds"])
        reward_seconds += reward_elapsed
        update_seconds += update_elapsed
        evidence_started = time.perf_counter()
        record_dir = output_dir / "trajectories" / f"step-{global_step:04d}"
        records = _write_rollout_evidence(
            record_dir,
            rollout,
            prompt,
            base_seed + global_step,
            adapter_sha,
            global_step,
            rewards,
        )
        trajectory_records.extend(records)
        current_adapter = current_adapter and all(
            json.loads(Path(record["path"]).read_text(encoding="utf-8"))["adapter_sha"]
            == adapter_sha
            for record in records
        )
        evidence_elapsed = time.perf_counter() - evidence_started
        evidence_seconds += evidence_elapsed
        checkpoint_elapsed = 0.0
        if global_step in checkpoint_steps:
            checkpoint_started = time.perf_counter()
            checkpoint_path = output_dir / f"checkpoint-{global_step}" / "state.pt"
            payload = _make_checkpoint_payload(
                checkpoint_contract, global_step, pipe.unet, optimizer, optimizer_progress
            )
            resume_checkpoint.save_atomic(checkpoint_path, payload)
            written_checkpoint_paths.add(checkpoint_path)
            checkpoint_elapsed = time.perf_counter() - checkpoint_started
            checkpoint_seconds += checkpoint_elapsed
        metric = {
            "global_step": global_step,
            "adapter_sha": adapter_sha,
            "adapter_sha_after": _sha256_trainable(pipe.unet),
            "reward_mean": float(rewards.mean().cpu()),
            "reward_variance": float(rewards.var(unbiased=False).cpu()),
            "rollout_seconds": rollout_elapsed,
            "rollout_unet_seconds": float(rollout["unet_rollout_seconds"]),
            "vae_decode_seconds": float(rollout["vae_decode_seconds"]),
            "reward_seconds": reward_elapsed,
            "update_seconds": update_elapsed,
            "evidence_seconds": evidence_elapsed,
            "checkpoint_seconds": checkpoint_elapsed,
            "compute_step_seconds": time.perf_counter() - step_started,
            # Keep the established per-step field for raw-log compatibility.
            "step_seconds": time.perf_counter() - step_started,
            **update,
        }
        finite_tensors = finite_tensors and all(
            math.isfinite(float(value))
            for key, value in metric.items()
            if key not in {"global_step", "adapter_sha", "adapter_sha_after", "finite_gradients"}
        )
        logging_started = time.perf_counter()
        with raw_log.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(metric, sort_keys=True) + "\n")
        logging_elapsed = time.perf_counter() - logging_started
        logging_seconds += logging_elapsed
        metric["logging_seconds"] = logging_elapsed
        metric["full_step_seconds"] = time.perf_counter() - step_started
        metric["step_seconds"] = metric["full_step_seconds"]
        step_metrics.append(metric)
    checkpoint = output_dir / f"checkpoint-{total_global_steps}" / "state.pt"
    if (
        checkpoint not in written_checkpoint_paths
        and completed_global_step == total_global_steps
        and resume_path is not None
    ):
        checkpoint = resume_path
    if not checkpoint.is_file():
        raise RuntimeError(f"final checkpoint is missing: {checkpoint}")
    adapter_after = _sha256_trainable(pipe.unet)
    final_metadata = _checkpoint_metadata(checkpoint_contract, total_global_steps)
    final_state_sha256 = resume_checkpoint.tree_sha256(
        {
            "state": resume_checkpoint.capture_model_state(
                pipe.unet, optimizer, optimizer_progress
            ),
            "rng": resume_checkpoint.capture_rng(checkpoint_contract["device_ids"]),
        }
    )
    final_adapter = output_dir / "adapter-final.pt"
    torch.save(
        {
            name: parameter.detach().cpu()
            for name, parameter in pipe.unet.named_parameters()
            if parameter.requires_grad
        },
        final_adapter,
    )
    trajectory_index = output_dir / "trajectory-index.json"
    trajectory_index.write_text(
        json.dumps({"records": trajectory_records}, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    checkpoint_final_sha256 = sha256_path(checkpoint)
    final_adapter_sha256 = sha256_path(final_adapter)
    trajectory_index_sha256 = sha256_path(trajectory_index)
    raw_log_sha256 = sha256_path(raw_log)
    artifact_paths = list(
        dict.fromkeys(
            [*sorted(written_checkpoint_paths), checkpoint, final_adapter, trajectory_index]
        )
    )
    artifact_records = [
        {"path": str(path), "sha256": sha256_path(path)}
        for path in artifact_paths
        if path.is_file()
    ]
    log_records = [{"path": str(raw_log), "sha256": raw_log_sha256}]
    if measurement_window_started is not None:
        synchronize()
        measurement_window_seconds = time.perf_counter() - measurement_window_started

    recovery_enabled = validate_recovery_enabled(config)
    if recovery_enabled:
        if rollout_graph is not None:
            rollout_graph.begin_rollout(pipe.unet, adapter_after)
        validation_rollout = _sample_rollouts(
            pipe,
            conditioning,
            batch_size,
            height,
            width,
            sample_steps,
            guidance,
            eta,
            base_seed + total_global_steps + 1,
            **rollout_options,
        )
        validation_rewards = image_color_reward(validation_rollout["images"], target_rgb)
        validation_index = next(
            index
            for index, stochastic in enumerate(validation_rollout["stochastic_mask"])
            if stochastic
        )

        def recovery_update() -> dict[str, Any]:
            nonlocal optimizer_progress
            _train_transition(
                pipe,
                optimizer,
                conditioning,
                validation_rollout,
                validation_rewards,
                validation_index,
                guidance,
                eta,
                clip_range,
                float(config.get("max_grad_norm", 1.0)),
            )
            optimizer_progress = resume_checkpoint.advance_optimizer_progress(
                optimizer_progress, pipe.unet, optimizer
            )
            return {
                name: parameter.detach().float().cpu()
                for name, parameter in pipe.unet.named_parameters()
                if parameter.requires_grad
            }

        def compare_recovery(
            continuous: dict[str, Any],
            resumed: dict[str, Any],
            _continuous_fingerprint: str | None,
            _resumed_fingerprint: str | None,
        ) -> tuple[bool, dict[str, Any]]:
            resume_max_abs = max(
                float((resumed[name] - value).abs().max())
                for name, value in continuous.items()
            )
            return (
                resume_max_abs <= float(config.get("resume_atol", 1e-6)),
                {"resume_max_abs": resume_max_abs},
            )

        def restore_recovery_checkpoint() -> int:
            nonlocal optimizer_progress
            payload = resume_checkpoint.load_checkpoint(checkpoint)
            optimizer_progress, checked = _restore_checkpoint(
                payload, checkpoint_contract, pipe.unet, optimizer
            )
            _assert_restored_boundary(
                payload, checkpoint_contract, pipe.unet, optimizer, optimizer_progress
            )
            return int(checked["metadata"]["global_step"])

        recovery = run_recovery_validation(
            enabled=True,
            expected_step=total_global_steps,
            metric_names=("resume_max_abs",),
            update=recovery_update,
            restore=restore_recovery_checkpoint,
            fingerprint=None,
            compare=compare_recovery,
        )
    else:
        recovery = RecoveryValidation.not_run(("resume_max_abs",))
    reward_variances = [float(item["reward_variance"]) for item in step_metrics]
    log_prob_mae = [float(item["log_prob_mae"]) for item in step_metrics]
    log_prob_p99 = [float(item["log_prob_p99"]) for item in step_metrics]
    ratios = [float(item["ratio"]) for item in step_metrics]
    gradients = [float(item["grad_norm"]) for item in step_metrics]
    measured_metrics = [item for item in step_metrics if int(item["global_step"]) > warmup_steps]
    if not measured_metrics:
        raise ValueError("resume checkpoint already completes the SDXL DDPO workload")
    measured_step_seconds = [float(item["full_step_seconds"]) for item in measured_metrics]
    measured_compute_step_seconds = [float(item["compute_step_seconds"]) for item in measured_metrics]
    measured_rollout_seconds = [float(item["rollout_seconds"]) for item in measured_metrics]
    measured_rollout_unet_seconds = [float(item["rollout_unet_seconds"]) for item in measured_metrics]
    measured_vae_decode_seconds = [float(item["vae_decode_seconds"]) for item in measured_metrics]
    measured_reward_seconds = [float(item["reward_seconds"]) for item in measured_metrics]
    measured_update_seconds = [float(item["update_seconds"]) for item in measured_metrics]
    result = {
        "artifacts": artifact_records,
        "logs": log_records,
        "metrics": {
            "steps": max_steps,
            "total_global_steps": total_global_steps,
            "checkpoint_step_basis": checkpoint_step_basis,
            "warmup_steps": warmup_steps,
            "measurement_steps": len(measured_metrics),
            "executed_steps": len(step_metrics),
            "completed_global_step_before_resume": completed_global_step,
            "rollouts_per_prompt": batch_size,
            "rollout_graph": rollout_graph_enabled,
            "rollout_graph_setup_seconds": rollout_graph_setup_seconds,
            "rollout_graph_replays": rollout_graph.replays if rollout_graph is not None else 0,
            "reward_variance_min": min(reward_variances),
            "reward_variance_mean": sum(reward_variances) / len(reward_variances),
            "ratio_mean": sum(ratios) / len(ratios),
            "grad_norm_min": min(gradients),
            "log_prob_mae_max": max(log_prob_mae),
            "log_prob_p99_max": max(log_prob_p99),
            "resume_max_abs": recovery.metrics["resume_max_abs"],
            "adapter_sha_before": adapter_before,
            "adapter_sha_after": adapter_after,
            "step_seconds_median": statistics.median(measured_step_seconds),
            "step_seconds_min": min(measured_step_seconds),
            "step_seconds_max": max(measured_step_seconds),
            "compute_step_seconds_median": statistics.median(measured_compute_step_seconds),
            "rollout_seconds_median": statistics.median(measured_rollout_seconds),
            "rollout_unet_seconds_median": statistics.median(measured_rollout_unet_seconds),
            "vae_decode_seconds_median": statistics.median(measured_vae_decode_seconds),
            "reward_seconds_median": statistics.median(measured_reward_seconds),
            "update_seconds_median": statistics.median(measured_update_seconds),
            "samples_per_second": (
                batch_size * len(measured_metrics) / sum(measured_step_seconds)
            ),
            "measurement_window_seconds": measurement_window_seconds,
            "measurement_window_samples_per_second": (
                batch_size * len(measured_metrics) / measurement_window_seconds
            ),
            "checkpoint_schema": SDXL_CHECKPOINT_SCHEMA,
            "checkpoint_identity": identity,
            "checkpoint_dependency_evidence": dependency_evidence,
            "checkpoint_final_sha256": checkpoint_final_sha256,
            "final_adapter_sha256": final_adapter_sha256,
            "trajectory_index_sha256": trajectory_index_sha256,
            "resume_source_sha256": resume_checkpoint_sha,
            "final_state_sha256": final_state_sha256,
            "next_step_record": _next_step_record(final_metadata),
            "resume_next_step_record": (
                _next_step_record(resume_payload["metadata"])
                if resume_payload is not None
                else None
            ),
            "cuda_memory": memory_stats(),
        },
        "stage_timings": {
            "load": load_seconds,
            "rollout": rollout_seconds,
            "rollout_unet": rollout_unet_seconds,
            "vae_decode": vae_decode_seconds,
            "reward": reward_seconds,
            "update": update_seconds,
            "rollout_evidence": evidence_seconds,
            "checkpoint": checkpoint_seconds,
            "logging": logging_seconds,
            "resume_validation": resume_validation_seconds,
            "rollout_graph_setup": rollout_graph_setup_seconds,
            "measurement_window": measurement_window_seconds,
            "total": time.perf_counter() - total_started,
        },
        "checks": {
            "finite_tensors": finite_tensors,
            "nonzero_finite_gradients": all(bool(item["finite_gradients"]) for item in step_metrics),
            "checkpoint_resume": recovery.passed,
            "current_adapter": current_adapter and adapter_before != adapter_after,
            "main_forward_device": "cuda",
            "reward_variance_nonzero": min(reward_variances) > 0.0,
            "log_prob_alignment": max(log_prob_mae) <= 0.02 and max(log_prob_p99) <= 0.10,
        },
        "rollout_graph": (
            rollout_graph.report() if rollout_graph is not None else {"enabled": False}
        ),
    }
    if not recovery_enabled:
        result["measurement_window"] = {
            "start_monotonic": measurement_window_started,
            "work_units": len(measured_metrics),
            "unit": "policy_updates",
        }
    return result
