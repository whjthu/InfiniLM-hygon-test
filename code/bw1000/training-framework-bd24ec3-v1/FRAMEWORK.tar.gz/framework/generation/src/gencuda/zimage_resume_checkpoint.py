"""Completed policy-step checkpoints for the Z-Image GRPO backend."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from . import hy_resume_checkpoint as common


SCHEMA = "zimage-full-policy-step-v1"
IDENTITY_FIELDS = {"config", "source", "data", "model", "reward", "scheduler", "runtime"}
SCHEDULER_STATIC_FIELDS = {
    "set_timesteps_fn",
    "num_train_timesteps",
    "noise_window",
    "noise_level",
    "sde_step_num",
    "sde_type",
    "seed",
}


class CheckpointValidationError(ValueError):
    pass


class ResumeApplyFatal(RuntimeError):
    pass


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise CheckpointValidationError(message)


def build_contract(
    *,
    identity: dict[str, str],
    seed: int,
    max_steps: int,
    group_size: int,
    sample_order: list[str],
    device_ids: list[int],
) -> dict[str, Any]:
    contract = {
        "backend": "zimage-flow-grpo",
        "identity": identity,
        "seed": seed,
        "max_steps": max_steps,
        "group_size": group_size,
        "sample_order": sample_order,
        "device_ids": device_ids,
    }
    validate_contract(contract)
    return contract


def validate_contract(contract: dict[str, Any]) -> None:
    _require(
        type(contract) is dict
        and set(contract)
        == {"backend", "identity", "seed", "max_steps", "group_size", "sample_order", "device_ids"},
        "Z-Image checkpoint contract fields mismatch",
    )
    _require(contract["backend"] == "zimage-flow-grpo", "checkpoint backend mismatch")
    _require(type(contract["seed"]) is int and 0 <= contract["seed"] < 2**63, "invalid seed")
    _require(type(contract["max_steps"]) is int and contract["max_steps"] > 0, "invalid max_steps")
    _require(type(contract["group_size"]) is int and contract["group_size"] >= 4, "invalid group size")
    _require(
        type(contract["sample_order"]) is list
        and contract["sample_order"]
        and all(type(item) is str and item for item in contract["sample_order"])
        and len(set(contract["sample_order"])) == len(contract["sample_order"]),
        "invalid sample order",
    )
    _require(type(contract["device_ids"]) is list and contract["device_ids"] in ([], [0]), "invalid device IDs")
    _require(type(contract["identity"]) is dict and set(contract["identity"]) == IDENTITY_FIELDS, "identity fields mismatch")
    for value in contract["identity"].values():
        _require(type(value) is str and len(value) == 64 and all(item in "0123456789abcdef" for item in value), "invalid identity SHA")


def boundary_metadata(contract: dict[str, Any], global_step: int) -> dict[str, Any]:
    validate_contract(contract)
    _require(type(global_step) is int and 1 <= global_step <= contract["max_steps"], "checkpoint is not at a completed Z-Image policy step")
    return {
        "schema": SCHEMA,
        "boundary": "after-complete-policy-update",
        "contract": contract,
        "global_step": global_step,
        "completed_policy_updates": global_step,
        "measured_step": global_step,
        "next_global_step": global_step + 1,
        "next_sample_cursor": global_step % len(contract["sample_order"]),
        "seed_formula": "base+global*group+sample/v1",
        "private_generator_formula": "seed+1000003/v1",
    }


def next_coordinate(metadata: dict[str, Any]) -> dict[str, Any] | None:
    contract = metadata["contract"]
    if metadata["global_step"] == contract["max_steps"]:
        return None
    global_step = metadata["next_global_step"]
    cursor = metadata["next_sample_cursor"]
    return {
        "global_step": global_step,
        "sample_cursor": cursor,
        "sample_id": contract["sample_order"][cursor],
        "rollout_seeds": [
            contract["seed"] + global_step * contract["group_size"] + index
            for index in range(contract["group_size"])
        ],
    }


def _scheduler_value(value: Any) -> Any:
    if callable(value):
        return [value.__module__, value.__qualname__]
    return common.cpu_tree(value)


def scheduler_spec(scheduler: Any) -> dict[str, Any]:
    values = {key: _scheduler_value(value) for key, value in vars(scheduler).items()}
    _require(set(values) == SCHEDULER_STATIC_FIELDS, "unexpected Z-Image scheduler constructor state")
    _require(values["set_timesteps_fn"] == ["diffsynth.diffusion.flow_match", "FlowMatchScheduler.set_timesteps_z_image"], "scheduler set_timesteps implementation mismatch")
    _require(values["sde_step_num"] == 8 and values["noise_window"] == list(range(8)), "Z-Image must retain the eight-step scheduler")
    return values


def capture_scheduler(scheduler: Any) -> dict[str, Any]:
    values = {key: _scheduler_value(value) for key, value in vars(scheduler).items()}
    _require(set(values) == SCHEDULER_STATIC_FIELDS | {"sigmas", "timesteps", "training"}, "incomplete Z-Image scheduler boundary")
    return values


def _validate_scheduler(saved: dict[str, Any], expected: dict[str, Any], expected_seed: int) -> None:
    import torch

    _require(type(saved) is dict and set(saved) == SCHEDULER_STATIC_FIELDS | {"sigmas", "timesteps", "training"}, "scheduler fields mismatch")
    static_fields = SCHEDULER_STATIC_FIELDS - {"seed"}
    _require({key: saved[key] for key in static_fields} == {key: expected[key] for key in static_fields}, "scheduler constructor identity mismatch")
    _require(type(saved["seed"]) is int and saved["seed"] == expected_seed, "scheduler seed differs from completed policy step")
    _require(saved["training"] is False, "scheduler must be in sampling mode")
    for key in ("sigmas", "timesteps"):
        value = saved[key]
        _require(isinstance(value, torch.Tensor) and value.device.type == "cpu" and value.dtype == torch.float32 and value.shape == (8,) and not value.requires_grad and bool(torch.isfinite(value).all()), f"invalid scheduler {key}")
    _require(bool((saved["sigmas"][:-1] > saved["sigmas"][1:]).all()), "scheduler sigmas are not decreasing")
    _require(torch.equal(saved["timesteps"], saved["sigmas"] * saved["num_train_timesteps"]), "scheduler timestep relationship mismatch")


def capture_generators(rollout: dict[str, Any], contract: dict[str, Any], global_step: int) -> dict[str, Any]:
    return {
        "rollout_seeds": [contract["seed"] + global_step * contract["group_size"] + index for index in range(contract["group_size"])],
        "states": common.cpu_tree(rollout["generator_states"]),
    }


def _validate_generators(saved: dict[str, Any], contract: dict[str, Any], global_step: int) -> None:
    import torch

    expected = [contract["seed"] + global_step * contract["group_size"] + index for index in range(contract["group_size"])]
    _require(type(saved) is dict and set(saved) == {"rollout_seeds", "states"}, "generator state fields mismatch")
    _require(saved["rollout_seeds"] == expected, "per-sample generator seed mismatch")
    _require(type(saved["states"]) is list and len(saved["states"]) == len(expected), "per-sample generator state count mismatch")
    for state in saved["states"]:
        _require(isinstance(state, torch.Tensor) and state.device.type == "cpu" and state.dtype == torch.uint8 and state.ndim == 1 and state.numel() > 0, "invalid per-sample generator state")


def make_payload(
    *,
    contract: dict[str, Any],
    global_step: int,
    model: Any,
    optimizer: Any,
    optimizer_progress: dict[str, int],
    scheduler: Any,
    expected_scheduler: dict[str, Any],
    rollout: dict[str, Any],
) -> dict[str, Any]:
    payload = {
        "metadata": boundary_metadata(contract, global_step),
        "state": common.capture_model_state(model, optimizer, optimizer_progress),
        "scheduler": capture_scheduler(scheduler),
        "generators": capture_generators(rollout, contract, global_step),
        "rng": common.capture_rng(contract["device_ids"]),
    }
    payload["adapter_sha256"] = common.tree_sha256(payload["state"]["trainable"])
    payload["integrity_sha256"] = common.tree_sha256(payload)
    validate_checkpoint(payload, contract, model, optimizer, expected_scheduler, native_rng=False)
    return payload


def validate_checkpoint(
    payload: dict[str, Any],
    contract: dict[str, Any],
    model: Any,
    optimizer: Any,
    expected_scheduler: dict[str, Any],
    *,
    native_rng: bool,
) -> dict[str, Any]:
    expected_fields = {"metadata", "state", "scheduler", "generators", "rng", "adapter_sha256", "integrity_sha256"}
    _require(type(payload) is dict and set(payload) == expected_fields, "not a full Z-Image checkpoint")
    unsigned = {key: value for key, value in payload.items() if key != "integrity_sha256"}
    _require(payload["integrity_sha256"] == common.tree_sha256(unsigned), "checkpoint integrity mismatch")
    metadata = payload["metadata"]
    _require(type(metadata) is dict and metadata.get("contract") == contract, "checkpoint identity or schedule mismatch")
    _require(metadata == boundary_metadata(contract, metadata.get("global_step")), "checkpoint global step or cursor mismatch")
    common.validate_model_state(payload["state"], model, optimizer, metadata["global_step"])
    _validate_scheduler(payload["scheduler"], expected_scheduler, contract["seed"] + metadata["global_step"] * contract["group_size"] + contract["group_size"] - 1)
    _validate_generators(payload["generators"], contract, metadata["global_step"])
    _require(payload["adapter_sha256"] == common.tree_sha256(payload["state"]["trainable"]), "adapter SHA mismatch")
    rng_validation = common.validate_rng(payload["rng"], contract["device_ids"], native=native_rng)
    return {"metadata": metadata, "next": next_coordinate(metadata), "rng_validation": rng_validation}


def restore_checkpoint(payload: dict[str, Any], contract: dict[str, Any], model: Any, optimizer: Any, scheduler: Any, expected_scheduler: dict[str, Any]) -> tuple[dict[str, int], dict[str, Any]]:
    checked = validate_checkpoint(payload, contract, model, optimizer, expected_scheduler, native_rng=True)
    try:
        common._copy_model_state(payload["state"], model, optimizer)
        for key in set(vars(scheduler)) - {"set_timesteps_fn"}:
            delattr(scheduler, key)
        for key, value in payload["scheduler"].items():
            if key != "set_timesteps_fn":
                setattr(scheduler, key, common.cpu_tree(value))
        common._restore_rng(payload["rng"], contract["device_ids"])
    except Exception as error:
        setattr(model, "_zimage_resume_poisoned", True)
        raise ResumeApplyFatal("checkpoint application failed; terminate this worker") from error
    return dict(payload["state"]["optimizer_progress"]), checked


def assert_restored_boundary(payload: dict[str, Any], model: Any, optimizer: Any, scheduler: Any, optimizer_progress: dict[str, int], device_ids: list[int]) -> None:
    observed = {
        "state": common.capture_model_state(model, optimizer, optimizer_progress),
        "scheduler": capture_scheduler(scheduler),
        "generators": payload["generators"],
        "rng": common.capture_rng(device_ids),
    }
    expected = {key: payload[key] for key in ("state", "scheduler", "generators", "rng")}
    _require(common.tree_sha256(observed) == common.tree_sha256(expected), "restored boundary differs from checkpoint")


def save_atomic(path: Path | str, payload: dict[str, Any]) -> None:
    common.save_atomic(path, payload)


def load_checkpoint(path: Path | str) -> dict[str, Any]:
    return common.load_checkpoint(path)
