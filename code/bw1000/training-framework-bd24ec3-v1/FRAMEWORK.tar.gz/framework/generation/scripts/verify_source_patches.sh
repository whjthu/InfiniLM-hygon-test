#!/usr/bin/env bash

# Validate the shipped patch set without modifying the supplied source cache.
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "usage: $0 SOURCE_ROOT" >&2
  exit 2
fi

source_root=$(realpath -e -- "$1") || {
  echo "SOURCE_ROOT does not exist: $1" >&2
  exit 2
}
[[ -d "${source_root}" ]] || {
  echo "SOURCE_ROOT is not a directory: $1" >&2
  exit 2
}

repo_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
apply_script="${repo_root}/scripts/apply_source_patches.sh"
lock_file="${repo_root}/sources.lock.json"

readonly -a mapped_sources=(
  diffusers-v039
  diffsynth-studio-grpo
  stable-fast-3d
  hunyuanvideo-1.5
  hy-motion
  trellis2
)
readonly -a patch_files=(
  diffusers-sdxl-training-evidence.patch
  diffsynth-mlu.patch
  stable-fast-3d-mlu.patch
  hunyuanvideo-1.5-mlu.patch
  hy-motion-mlu.patch
  hy-motion-cpu-sidecar.patch
  trellis2-mlu.patch
)

command -v git >/dev/null || { echo "git is required" >&2; exit 2; }
command -v python3 >/dev/null || { echo "python3 is required" >&2; exit 2; }
command -v mktemp >/dev/null || { echo "mktemp is required" >&2; exit 2; }
[[ -f "${apply_script}" && -f "${lock_file}" ]] || {
  echo "patch verifier is missing its packaged inputs" >&2
  exit 2
}

canonical_origin() {
  local value=${1%/}
  value=${value%.git}
  if [[ "${value}" =~ ^git@([^:]+):(.+)$ ]]; then
    value="https://${BASH_REMATCH[1]}/${BASH_REMATCH[2]}"
  fi
  printf '%s\n' "${value}"
}

source_metadata() {
  python3 - "${lock_file}" "$1" <<'PY'
import json
import re
import sys

lock_path, name = sys.argv[1:]
entry = json.load(open(lock_path, encoding="utf-8"))["sources"].get(name)
if not isinstance(entry, dict):
    raise SystemExit(f"source is absent from lock: {name}")
revision = entry.get("revision")
origin = entry.get("origin")
if not isinstance(revision, str) or re.fullmatch(r"[0-9a-f]{40}", revision) is None:
    raise SystemExit(f"source has invalid locked revision: {name}")
if not isinstance(origin, str) or not origin:
    raise SystemExit(f"source has invalid locked origin: {name}")
print(f"{revision}\t{origin}")
PY
}

for patch_file in "${patch_files[@]}"; do
  patch_path="${repo_root}/patches/${patch_file}"
  [[ -f "${patch_path}" ]] || { echo "missing patch: ${patch_file}" >&2; exit 2; }
  git apply --numstat --summary "${patch_path}" >/dev/null
done

temporary_root=$(mktemp -d "${TMPDIR:-/tmp}/genmlu-source-patches.XXXXXX")
cleanup() {
  rm -rf -- "${temporary_root}"
}
trap cleanup EXIT

for source_name in "${mapped_sources[@]}"; do
  source_dir=$(realpath -e -- "${source_root}/${source_name}") || {
    echo "locked source is missing: ${source_root}/${source_name}" >&2
    exit 2
  }
  [[ -d "${source_dir}" ]] || {
    echo "locked source is not a directory: ${source_dir}" >&2
    exit 2
  }
  [[ "$(git -C "${source_dir}" rev-parse --is-inside-work-tree 2>/dev/null)" == true ]] || {
    echo "locked source is not a Git worktree: ${source_dir}" >&2
    exit 2
  }

  metadata=$(source_metadata "${source_name}")
  IFS=$'\t' read -r expected_revision expected_origin <<< "${metadata}"
  actual_revision=$(git -C "${source_dir}" rev-parse HEAD)
  [[ "${actual_revision}" == "${expected_revision}" ]] || {
    echo "source revision mismatch for ${source_name}: expected ${expected_revision}, got ${actual_revision}" >&2
    exit 1
  }
  # Read the configured remote, not its transport-expanded form. Global
  # url.*.insteadOf rules may rewrite `remote get-url` without changing source
  # provenance.
  actual_origin=$(git -C "${source_dir}" config --get remote.origin.url 2>/dev/null || true)
  [[ -n "${actual_origin}" ]] || {
    echo "source origin is missing for ${source_name}" >&2
    exit 1
  }
  [[ "$(canonical_origin "${actual_origin}")" == "$(canonical_origin "${expected_origin}")" ]] || {
    echo "source origin mismatch for ${source_name}: expected ${expected_origin}, got ${actual_origin}" >&2
    exit 1
  }

  clone_dir="${temporary_root}/${source_name}"
  git clone --no-hardlinks --no-checkout --quiet "${source_dir}" "${clone_dir}"
  git -C "${clone_dir}" checkout --detach --quiet "${expected_revision}"
  clone_revision=$(git -C "${clone_dir}" rev-parse HEAD)
  [[ "${clone_revision}" == "${expected_revision}" ]] || {
    echo "isolated clone revision mismatch for ${source_name}" >&2
    exit 1
  }
  [[ -z "$(git -C "${clone_dir}" status --porcelain=v1 --untracked-files=all)" ]] || {
    echo "isolated clone is not clean at locked revision for ${source_name}" >&2
    exit 1
  }
  "${apply_script}" "${temporary_root}" "${source_name}"
  "${apply_script}" "${temporary_root}" "${source_name}"
done

echo "Verified ${#patch_files[@]} patch streams against isolated locked source clones."
