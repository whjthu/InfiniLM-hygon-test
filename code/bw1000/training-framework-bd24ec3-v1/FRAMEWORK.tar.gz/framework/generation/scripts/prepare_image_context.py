"""Stage only committed deployment files and a matching, prebuilt wheel."""

from __future__ import annotations

import argparse
from pathlib import Path
import shutil
import subprocess

from verify_release_wheel import is_package_source, package_digest, verify_wheel


ROOT = Path(__file__).resolve().parents[2]


def prepare_context(wheel: Path, output: Path, root: Path = ROOT) -> str:
    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", "-C", str(root), *args])

    if git("status", "--porcelain").strip():
        raise ValueError("image context requires a clean source checkout")
    commit = git("rev-parse", "HEAD").decode().strip()
    tree = git("rev-parse", "HEAD^{tree}").decode().strip()
    names = git("ls-tree", "-r", "--name-only", "-z", commit).decode().split("\0")
    identity = verify_wheel(wheel, commit)
    if identity["tree"] != tree:
        raise ValueError("wheel tree differs from the source checkout")
    committed_package = []
    for name in names:
        if not name.startswith("generation/src/genmlu/"):
            continue
        relative = name.removeprefix("generation/src/")
        if is_package_source(relative):
            committed_package.append(
                (relative.removeprefix("genmlu/"), git("show", f"{commit}:{name}"))
            )
    if identity["package_sha256"] != package_digest(committed_package):
        raise ValueError("wheel package sources differ from committed HEAD")
    output = output.expanduser().resolve()
    if output == root.resolve() or root.resolve() in output.parents:
        raise ValueError("image context must be outside the source checkout")
    selected = [name for name in names if name in {
        "generation/README.md", "generation/sources.lock.json",
        "generation/docker/Dockerfile.torch212",
    } or name.startswith(("generation/configs/", "generation/patches/", "generation/scripts/"))]
    output.mkdir(parents=True, exist_ok=False)
    for name in selected:
        relative = name.removeprefix("generation/")
        if relative == "docker/Dockerfile.torch212":
            relative = "Dockerfile"
        target = output / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(git("show", f"{commit}:{name}"))
    (output / "wheels").mkdir()
    shutil.copyfile(wheel, output / "wheels" / wheel.name)
    return commit


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--wheel", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    print(prepare_context(args.wheel, args.output_dir))


if __name__ == "__main__":
    main()
