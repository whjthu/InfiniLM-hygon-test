#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "usage: $0 SOURCE_ROOT [SOURCE_NAME ...]" >&2
  exit 2
fi

source_root="$1"
shift
repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

apply_once() {
  local source_dir="$1"
  local patch_file="$2"
  if [[ ! -e "$source_dir/.git" ]]; then
    echo "source checkout is missing or not a git checkout: $source_dir" >&2
    exit 1
  fi
  if git -C "$source_dir" apply --reverse --check --unidiff-zero "$patch_file" >/dev/null 2>&1; then
    return
  fi
  git -C "$source_dir" apply --check --unidiff-zero "$patch_file"
  git -C "$source_dir" apply --unidiff-zero "$patch_file"
}

if [[ $# -eq 0 ]]; then
  set -- diffusers-v039 diffsynth-studio-grpo stable-fast-3d hunyuanvideo-1.5 hy-motion trellis2
fi

for source in "$@"; do
  case "$source" in
    diffusers-v039) patches=(diffusers-sdxl-training-evidence.patch) ;;
    diffsynth-studio-grpo) patches=(diffsynth-mlu.patch) ;;
    stable-fast-3d) patches=(stable-fast-3d-mlu.patch) ;;
    hunyuanvideo-1.5) patches=(hunyuanvideo-1.5-mlu.patch) ;;
    hy-motion) patches=(hy-motion-mlu.patch hy-motion-cpu-sidecar.patch) ;;
    trellis2) patches=(trellis2-mlu.patch) ;;
    *) echo "unsupported patch source: $source" >&2; exit 2 ;;
  esac
  expected=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["sources"][sys.argv[2]]["revision"])' \
    "$repo_root/sources.lock.json" "$source")
  actual=$(git -C "$source_root/$source" rev-parse HEAD)
  if [[ "$actual" != "$expected" ]]; then
    echo "source revision mismatch for $source: expected $expected, got $actual" >&2
    exit 1
  fi
  for patch in "${patches[@]}"; do
    apply_once "$source_root/$source" "$repo_root/patches/$patch"
  done
done
