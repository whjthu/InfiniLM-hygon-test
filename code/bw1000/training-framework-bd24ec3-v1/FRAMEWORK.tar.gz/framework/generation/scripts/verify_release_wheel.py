"""Validate a release wheel before installing it into a runtime image."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile


PACKAGE_PREFIX = "genmlu/"
BUILD_IDENTITY = "genmlu/_build_identity.json"
PACKAGE_SUFFIXES = {".py", ".yaml"}
DIST_INFO_FILES = {"METADATA", "WHEEL", "RECORD", "entry_points.txt", "top_level.txt"}
REQUIRED_DIST_INFO_FILES = {"METADATA", "WHEEL", "RECORD"}


def package_digest(entries: list[tuple[str, bytes]]) -> str:
    digest = hashlib.sha256()
    for relative, data in sorted(entries):
        encoded = relative.encode("utf-8")
        normalized = data.replace(b"\r\n", b"\n")
        digest.update(len(encoded).to_bytes(8, "big"))
        digest.update(encoded)
        digest.update(len(normalized).to_bytes(8, "big"))
        digest.update(normalized)
    return digest.hexdigest()


def is_package_source(name: str) -> bool:
    return (
        name.startswith(PACKAGE_PREFIX)
        and not any(part == ".env" or part.startswith(".env.") for part in name.split("/"))
        and Path(name).suffix in PACKAGE_SUFFIXES
    )


def verify_wheel(path: Path, expected_commit: str) -> dict:
    if not re.fullmatch(r"[0-9a-f]{40}", expected_commit):
        raise ValueError("expected commit must be a full Git commit ID")
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("wheel contains duplicate entries")
        package_entries: list[tuple[str, bytes]] = []
        dist_info_directories: dict[str, set[str]] = {}
        identity_count = 0
        for name in sorted(names):
            parts = name.split("/")
            if not name or name.endswith("/") or ".." in parts or "\\" in name:
                raise ValueError(f"unexpected wheel entry: {name}")
            if archive.getinfo(name).file_size > 2_000_000:
                raise ValueError(f"oversized wheel entry: {name}")
            if name == BUILD_IDENTITY:
                identity_count += 1
                continue
            if is_package_source(name):
                package_entries.append((name.removeprefix(PACKAGE_PREFIX), archive.read(name)))
                continue
            match = re.fullmatch(
                r"(genmlu-[A-Za-z0-9][A-Za-z0-9_.+-]*\.dist-info)/([A-Za-z0-9_.-]+)",
                name,
            )
            if match is None or match.group(2) not in DIST_INFO_FILES:
                raise ValueError(f"unexpected wheel entry: {name}")
            dist_info_directories.setdefault(match.group(1), set()).add(match.group(2))
        if identity_count != 1:
            raise ValueError("wheel must contain exactly one build identity")
        if len(dist_info_directories) != 1:
            raise ValueError("wheel must contain exactly one dist-info directory")
        metadata_files = next(iter(dist_info_directories.values()))
        if not REQUIRED_DIST_INFO_FILES.issubset(metadata_files):
            raise ValueError("wheel is missing required dist-info metadata")
        identity = json.loads(archive.read(BUILD_IDENTITY))
        if not isinstance(identity, dict) or identity.get("commit") != expected_commit:
            raise ValueError("wheel commit differs from the requested release")
        if identity.get("dirty") is not False or not re.fullmatch(
            r"[0-9a-f]{40}", str(identity.get("tree", ""))
        ):
            raise ValueError("wheel must originate from a clean, identified source tree")
        if identity.get("package_sha256") != package_digest(package_entries):
            raise ValueError("wheel package contents differ from the build identity")
    return identity


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("wheel_directory", type=Path)
    parser.add_argument("--expected-commit", required=True)
    args = parser.parse_args()
    wheels = list(args.wheel_directory.glob("*.whl"))
    if len(wheels) != 1:
        raise ValueError("runtime context must contain exactly one wheel")
    identity = verify_wheel(wheels[0], args.expected_commit)
    print(json.dumps(identity, sort_keys=True))


if __name__ == "__main__":
    main()
