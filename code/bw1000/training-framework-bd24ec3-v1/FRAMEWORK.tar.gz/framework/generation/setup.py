"""Include the source identity in built distributions without changing source files."""

import importlib.util
import json
from pathlib import Path

from setuptools import setup
from setuptools.command.build_py import build_py


class BuildWithIdentity(build_py):
    def run(self):
        super().run()
        package = Path(__file__).resolve().parent / "src" / "genmlu"
        spec = importlib.util.spec_from_file_location("source_identity", package / "source_identity.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        identity = module.source_identity(package)
        target = Path(self.build_lib) / "genmlu" / "_build_identity.json"
        target.write_text(json.dumps(identity, sort_keys=True) + "\n", encoding="utf-8")


setup(cmdclass={"build_py": BuildWithIdentity})
