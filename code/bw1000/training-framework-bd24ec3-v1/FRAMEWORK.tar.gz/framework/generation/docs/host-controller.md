# Host Job Controller

`genmlu.benchctl` runs on the Linux host, outside the training container. It
requires Python 3.10 or later, POSIX process groups and `fcntl`, `cnmon`, and
the Docker CLI when managing containers. Its Python imports use the standard
library only. No host-side model framework installation is required.

Use a clean checkout of a fixed release and a dedicated host environment.
Set `PYTHONPATH` to that checkout's `generation/src`; do not combine it with
another `genmlu` installation or a historical development directory. Record
the release commit and the SHA256 of `benchctl.py`, `lease.py`, and
`__init__.py` in the deployment inventory before starting a controlled run.
Source and checkpoint mounts should be read-only; outputs must be separate.

```bash
export PYTHONPATH=/mnt/afs/releases/mlu-runtime/generation/src
python3 -B -m genmlu.benchctl preflight --cards 0 --sample-interval 300
python3 -B -m genmlu.benchctl --output-root /mnt/afs/outputs \
  --project generative-mlu run --host-label mlu-10000 --cards 0 \
  --sample-interval 300 --watch-interval 60 --timeout-seconds 3600 \
  --run-id example --container-name genmlu-example -- \
  docker run --rm --name genmlu-example \
  --label genmlu.run_id=example <runtime-image> <model-command>
```

Replace the image and model command with the approved deployment command,
including its devices, mounts and resource limits. The controller does not
choose model settings or grant additional Docker permissions.

Direct Docker commands receive a unique `genmlu.lease_id` label from the
controller. For nested launchers, declare every container name and copy
`GENMLU_RUN_ID` and `GENMLU_LEASE_ID` from the child environment into the
corresponding container labels. A missing or changed lease label fails
ownership checks, including single-container jobs.
The direct launcher supports an explicit set of foreground Docker run
options. Unknown options, opaque label files and caller-supplied lease
labels are rejected before execution. Options after the image are passed
to the container command unchanged.

The auxiliary `mlu-10001` host requires all eight cards and two idle samples
300 seconds apart. The maximum job duration is eight hours and resource
checks are at most 60 seconds apart. Foreign processes and incomplete
`cnmon` data prevent admission or cause this job to yield.

Overlapping leases are blocked across projects on the same host. Existing
run directories are not overwritten. Cleanup acts on the child process
group and verified owned container IDs, not arbitrary process names. A
changed container identity or failed cleanup leaves a blocking lease for
manual investigation; the controller does not delete unknown leases.
Stopping a container establishes that it is not running, not that its object
has been deleted. Workflows requiring absence must use `--rm` and verify it
separately before accepting their output.

`resume` uses the same lifecycle checks and additionally requires
`--checkpoint` to be an existing, absolute, non-symlink path present in the
child command. The model backend, not this controller, restores the state.

Outputs are `lease.json` and `command.log` under
`<output-root>/<project>/<host-label>/<run-id>`. A completed command and
released resources do not establish numerical correctness, model quality,
recovery correctness or benchmark acceptance. Validate those separately.

The host module deliberately has no queue, result summarizer or report
generator. Model weights, caches, outputs and environments belong on AFS,
not in the checkout or home directory.
