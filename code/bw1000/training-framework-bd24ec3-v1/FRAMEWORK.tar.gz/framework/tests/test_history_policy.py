import io
import sys
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
import check_history


class HistoryPolicyTests(unittest.TestCase):
    def check_inventory(self, entries, content=b"value = 1\n"):
        def fake_git(*args):
            if args[0] == "rev-list":
                return "a" * 40 + "\n"
            if args[0] == "show":
                return "whjthu\0haojie0429@gmail.com\0whjthu\0haojie0429@gmail.com\0fix: validate paths\n"
            self.assertEqual(args[:2], ("ls-tree", "-rz"))
            return entries

        with patch.object(check_history, "git", fake_git), patch.object(check_history, "read_blob", return_value=content), patch.object(sys, "argv", ["check_history"]), redirect_stdout(io.StringIO()):
            return check_history.main()

    def test_unicode_weights_are_rejected(self):
        self.assertEqual(self.check_inventory("100644 blob hash\tassets/\u6a21\u578b.pt\0"), 1)

    def test_newline_filename_is_not_split(self):
        self.assertEqual(self.check_inventory('100644 blob hash\tassets/test"\n.pt\0'), 1)

    def test_unicode_report_path_is_rejected(self):
        self.assertEqual(self.check_inventory("100644 blob hash\treports/\u8bc4\u6d4b.md\0"), 1)

    def test_symlink_is_rejected(self):
        self.assertEqual(self.check_inventory("120000 blob hash\tsrc/model.py\0"), 1)

    def test_normal_source_is_allowed(self):
        self.assertEqual(self.check_inventory("100644 blob hash\tgeneration/src/genmlu/model.py\0"), 0)

    def test_old_blob_content_is_checked(self):
        self.assertEqual(self.check_inventory("100644 blob hash\tsrc/model.py\0", b"binary\0weights"), 1)

    def test_old_blob_size_is_checked(self):
        self.assertEqual(self.check_inventory("100644 blob hash\tsrc/model.py\0", b"x" * 2_000_001), 1)


if __name__ == "__main__":
    unittest.main()
