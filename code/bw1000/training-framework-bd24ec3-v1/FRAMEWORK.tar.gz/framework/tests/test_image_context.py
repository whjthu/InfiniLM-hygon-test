import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "generation/scripts"))
from prepare_image_context import prepare_context
from verify_release_wheel import verify_wheel


class ImageContextTests(unittest.TestCase):
    def test_image_restores_shell_entrypoint_permissions(self):
        dockerfile = (ROOT / "generation/docker/Dockerfile.torch212").read_text()
        self.assertIn("chmod +x scripts/*.sh", dockerfile)
        self.assertLess(dockerfile.index("chmod +x"), dockerfile.index("python scripts/verify_release_wheel.py"))

    def make_wheel(self, directory, *, dirty=False, commit="1" * 40, content=b"VALUE = 1\n"):
        name = b"__init__.py"
        digest = hashlib.sha256()
        for value in (name, content):
            digest.update(len(value).to_bytes(8, "big"))
            digest.update(value)
        identity = dict(commit=commit, tree="2" * 40, dirty=dirty, package_sha256=digest.hexdigest())
        path = Path(directory) / "genmlu-0.1.0-py3-none-any.whl"
        with zipfile.ZipFile(path, "w") as archive:
            archive.writestr("genmlu/__init__.py", content)
            archive.writestr("genmlu/_build_identity.json", json.dumps(identity))
            for metadata in ("METADATA", "WHEEL", "RECORD"):
                archive.writestr(f"genmlu-0.1.0.dist-info/{metadata}", "")
        return path

    def test_clean_wheel_identity_is_required(self):
        with tempfile.TemporaryDirectory() as directory:
            wheel = self.make_wheel(directory)
            self.assertEqual(verify_wheel(wheel, "1" * 40)["tree"], "2" * 40)
            with self.assertRaisesRegex(ValueError, "commit differs"):
                verify_wheel(wheel, "3" * 40)
            self.make_wheel(directory, dirty=True)
            with self.assertRaisesRegex(ValueError, "clean"):
                verify_wheel(wheel, "1" * 40)

    def test_modified_code_and_extra_installed_paths_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            wheel = self.make_wheel(directory)
            with zipfile.ZipFile(wheel, "a") as archive:
                archive.writestr("genmlu/extra.py", "VALUE = 2\n")
            with self.assertRaisesRegex(ValueError, "contents differ"):
                verify_wheel(wheel, "1" * 40)
            self.make_wheel(directory)
            with zipfile.ZipFile(wheel, "a") as archive:
                archive.writestr("startup.pth", "unwanted\n")
            with self.assertRaisesRegex(ValueError, "unexpected wheel entry"):
                verify_wheel(wheel, "1" * 40)

    def test_unhashed_package_payload_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            for name in ("genmlu/native.so", "genmlu/.env", "genmlu/.env.py", "genmlu/results.csv"):
                wheel = self.make_wheel(directory)
                with zipfile.ZipFile(wheel, "a") as archive:
                    archive.writestr(name, "unverified\n")
                with self.subTest(name=name):
                    with self.assertRaisesRegex(ValueError, "unexpected wheel entry"):
                        verify_wheel(wheel, "1" * 40)

    def test_multiple_dist_info_directories_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            wheel = self.make_wheel(directory)
            with zipfile.ZipFile(wheel, "a") as archive:
                archive.writestr("genmlu-0.1.1.dist-info/METADATA", "")
            with self.assertRaisesRegex(ValueError, "exactly one dist-info"):
                verify_wheel(wheel, "1" * 40)

    def test_staging_uses_only_committed_deployment_files(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "source"
            root.mkdir()
            wheel = self.make_wheel(directory)
            files = {
                "generation/README.md": b"usage\n",
                "generation/docker/Dockerfile.torch212": b"FROM scratch\n",
                "generation/scripts/verify_release_wheel.py": b"pass\n",
                "generation/src/genmlu/__init__.py": b"VALUE = 1\n",
                "generation/.env": b"DUMMY=not-for-image\n",
                "generation/outputs/results.json": b"{}\n",
            }

            def fake_git(command):
                args = command[3:]
                if args[0] == "status":
                    return b""
                if args[0] == "rev-parse":
                    return (("1" if args[1] == "HEAD" else "2") * 40).encode()
                if args[0] == "ls-tree":
                    return "\0".join(files).encode()
                return files[args[1].split(":", 1)[1]]

            output = Path(directory) / "context"
            with patch.object(subprocess, "check_output", side_effect=fake_git):
                self.assertEqual(prepare_context(wheel, output, root), "1" * 40)
            self.assertTrue((output / "Dockerfile").is_file())
            self.assertTrue((output / "scripts/verify_release_wheel.py").is_file())
            self.assertFalse((output / ".env").exists())
            self.assertFalse((output / "outputs").exists())

    def test_staging_rejects_wheel_with_self_asserted_source_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "source"
            root.mkdir()
            wheel = self.make_wheel(directory, content=b"VALUE = from-wheel\n")
            files = {"generation/src/genmlu/__init__.py": b"VALUE = from-head\n"}

            def fake_git(command):
                args = command[3:]
                if args[0] == "status":
                    return b""
                if args[0] == "rev-parse":
                    return (("1" if args[1] == "HEAD" else "2") * 40).encode()
                if args[0] == "ls-tree":
                    return "\0".join(files).encode()
                return files[args[1].split(":", 1)[1]]

            output = Path(directory) / "context"
            with patch.object(subprocess, "check_output", side_effect=fake_git):
                with self.assertRaisesRegex(ValueError, "sources differ from committed HEAD"):
                    prepare_context(wheel, output, root)
            self.assertFalse(output.exists())

    def test_dirty_checkout_rejected_before_output_creation(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "context"
            with patch.object(subprocess, "check_output", return_value=b" M README.md\n"):
                with self.assertRaisesRegex(ValueError, "clean source"):
                    prepare_context(Path(directory) / "missing.whl", output)
            self.assertFalse(output.exists())


if __name__ == "__main__":
    unittest.main()
