"""Prepare and verify a controlled, base-only TextVQA run on the main host."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import re
from pathlib import Path
import subprocess
import os
import socket
import signal

import textvqa_contract as c
from textvqa_runner import validate_deployment, controller_bootstrap


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    return c.sha256_file(Path(path))


def completed_lease(plan, lease):
    require(type(lease.get("schema_version")) is int and lease["schema_version"] == 2, "lease schema differs")
    require(isinstance(plan["cards"], list) and len(plan["cards"]) == 1
            and type(plan["cards"][0]) is int and 0 <= plan["cards"][0] < 8
            and isinstance(lease.get("cards"), list) and len(lease["cards"]) == 1
            and type(lease["cards"][0]) is int, "invalid card identity")
    for name in ("run_id", "host", "host_label", "project", "cards", "container_name"):
        require(lease.get(name) == plan[name], "lease differs: " + name)
    require(lease.get("state") == "completed" and type(lease.get("returncode")) is int
            and lease["returncode"] == 0, "lease did not complete successfully")
    require(lease.get("command") == lease.get("requested_command") == plan["child_command"],
            "actual lease command differs")
    require(type(lease.get("pid")) is int and lease["pid"] > 1
            and isinstance(lease.get("lease_id"), str) and re.fullmatch(r"[0-9a-f]{32}", lease["lease_id"])
            and lease.get("container_lease_label_required") is True, "invalid lease identity")
    start = datetime.fromisoformat(lease["started_at_utc"])
    end = datetime.fromisoformat(lease["finished_at_utc"])
    created = datetime.fromisoformat(plan["created_at_utc"])
    require(all(value.tzinfo is not None for value in (start, end, created))
            and created <= start <= end, "launch plan must precede the actual run")
    require(lease.get("container_names") == [plan["container_name"]], "unexpected owned containers")
    require(type(lease.get("timeout_seconds")) is int and lease["timeout_seconds"] == 3600
            and type(lease.get("watch_interval_seconds")) is int and lease["watch_interval_seconds"] == 15,
            "controller resource policy differs")
    preflight = lease.get("preflight")
    require(isinstance(preflight, dict) and set(preflight) == {"first", "second"}, "missing idle observations")
    times = []
    for sample in (preflight["first"], preflight["second"]):
        require(sample.get("host") == plan["host"] and sample.get("cards") == plan["cards"]
                and all(type(card) is int for card in sample["cards"])
                and sample.get("foreign_accelerator_processes") == [], "idle observation identity differs")
        states = sample.get("card_states")
        require(isinstance(states, list) and len(states) == 1, "idle card observations missing")
        state = states[0]
        require(type(state.get("index")) is int and state["index"] == plan["cards"][0]
                and type(state.get("used_mib")) in (int, float) and 0 <= state["used_mib"] <= 64
                and type(state.get("utilization_percent")) in (int, float)
                and state["utilization_percent"] == 0, "card not idle")
        checked = datetime.fromisoformat(sample["checked_at_utc"])
        require(checked.tzinfo is not None, "naive idle observation")
        times.append(checked)
    require(created <= times[0] <= times[1] <= end
            and (times[1] - times[0]).total_seconds() >= 300, "idle observations must be 300 seconds apart")
    containers = lease.get("containers")
    require(isinstance(containers, list) and len(containers) == 1
            and containers[0].get("name") == plan["container_name"]
            and containers[0].get("state") == "exited"
            and re.fullmatch(r"[0-9a-f]{64}", containers[0].get("container_id", ""))
            and type(containers[0].get("last_pid")) is int and containers[0]["last_pid"] > 1,
            "missing registered owned container")


def confirm_absent(name, run_id, run=subprocess.run):
    result = run(["docker", "inspect", name], capture_output=True, text=True, timeout=30)
    require(type(result.returncode) is int and result.returncode == 1 and result.stdout.strip() in ("", "[]")
            and re.fullmatch(r"(?:error:|error response from daemon:) no such (?:object|container): " + re.escape(name), result.stderr.strip(), re.I),
            "owned container still exists or Docker status is unknown")
    remaining = run(["docker", "ps", "-a", "--filter", "label=genmlu.run_id=" + run_id,
                     "--format", "{{.ID}}"], capture_output=True, text=True, timeout=30)
    require(type(remaining.returncode) is int and remaining.returncode == 0
            and not remaining.stdout.strip(), "owned run label remains")


def bind_launcher(plan, args):
    require(args.command == "docker", "launcher mode differs")
    fields = {"model": "model", "identity": "identity", "identity_sha256": "identity_sha256",
              "questions": "questions", "manifest": "manifest", "manifest_sha256": "manifest_sha256",
              "images_root": "images_root", "api_evidence": "api_evidence", "runtime_image": "image",
              "lease_root": "run_root", "container_name": "container_name", "uid": "uid", "gid": "gid",
              "host_label": "host_label", "runner_source": "runner_source", "runner_sha256": "runner_sha256",
              "runner_deployment": "runner_deployment", "runner_deployment_sha256": "runner_deployment_sha256"}
    for argument, key in fields.items():
        require(getattr(args, argument) == plan[key], "launcher-plan differs: " + argument)
    require(args.physical_card == plan["cards"][0]
            and args.out == str(Path(plan["run_root"]) / "generation")
            and args.adapter is None and args.training_manifest is None
            and args.training_manifest_sha256 is None, "launcher output/card/base mode differs")


def recheck_inputs(c, plan, identity, api, input_pins):
    require(c.read_json(plan["identity"], plan["identity_sha256"]) == identity
            and c.read_json(plan["api_evidence"], identity["api_evidence_sha256"]) == api
            and c.tree_sha256(Path(plan["model"])) == identity["model_tree_sha256"],
            "model/identity/API changed while verifying")
    require(c.validate_inputs(plan["questions"], plan["manifest"], plan["manifest_sha256"],
                              plan["images_root"])[1] == input_pins, "inputs changed while verifying")


def finalize(args):
    plan_path = Path(args.plan).absolute()
    require(sha(plan_path) == args.plan_sha256, "launch plan SHA differs")
    # The caller holds this pin from before launch; a new post-run descriptor is not accepted.
    plan = c.read_json(plan_path, args.plan_sha256)
    require(plan["schema"] == "textvqa-owned-host-plan-v2"
            and plan["runroot_absent_at_creation"] is True, "invalid pre-launch plan")
    source = Path(plan["source_root"])
    require(sha(Path(__file__)) == plan["finalizer_sha256"], "host verifier changed")
    validate_deployment(plan["runner_deployment"], plan["runner_deployment_sha256"], plan["runner_source"])
    require(c.ROOT == source and c.tree_sha256(source) == plan["source_tree_sha256"], "source changed")
    runner = Path(plan["runner_source"])
    require(sha(runner) == plan["runner_sha256"], "runner changed")
    require(sha(source / "runtime/textvqa_docker.py") == plan["launcher_sha256"], "launcher changed")
    root = Path(plan["run_root"])
    require(root.name == plan["run_id"] and root.parent.name == plan["host_label"]
            and root.parent.parent.name == plan["project"] and plan["project"] == "generative-mlu",
            "run namespace differs")
    watched = [plan_path, root / "lease.json", root / "generation/generation.json",
               root / "generation/predictions.jsonl", root / "generation/execution.json"]
    before = {str(c.regular(p)): sha(p) for p in watched}
    lease = c.read_json(root / "lease.json")
    completed_lease(plan, lease)
    identity = c.validate_identity(c.read_json(plan["identity"], plan["identity_sha256"]))
    require(identity["adapter_tree_sha256"] is None, "this host plan supports base-only runs")
    require(identity["source_tree_sha256"] == plan["source_tree_sha256"]
            and identity["runtime_image"] == plan["image"]
            and c.tree_sha256(Path(plan["model"])) == identity["model_tree_sha256"], "model/image identity differs")
    rows, inputs = c.validate_inputs(plan["questions"], plan["manifest"],
                                    plan["manifest_sha256"], plan["images_root"])
    api = c.validate_api(c.read_json(plan["api_evidence"], identity["api_evidence_sha256"]))
    require(identity["input_manifest_sha256"] == plan["manifest_sha256"]
            and api["runtime_image"] == plan["image"], "input/API runtime binding differs")
    generation = c.read_json(root / "generation/generation.json")
    predictions = root / "generation/predictions.jsonl"
    records = [c.loads(line) for line in predictions.read_text().splitlines()]
    c.validate_run(generation, identity, inputs, records, rows)
    require(generation["identity_sha256"] == plan["identity_sha256"]
            and generation["predictions_sha256"] == sha(predictions) and generation["api"] == api,
            "diagnostic pins differ")
    receipt = c.read_json(root / "generation/execution.json", generation["execution_sha256"])
    require(receipt == generation["execution"] and receipt["lease_id"] == lease["lease_id"]
            and receipt["command_sha256"] == c.digest(plan["child_command"])
            and receipt["runner_sha256"] == plan["runner_sha256"]
            and receipt["uid"] == plan["uid"] and receipt["card"] == plan["cards"][0]
            and all(receipt[key] == plan[key] for key in ("run_id", "host", "host_label")),
            "actual admission receipt differs")
    from textvqa_generate import parser
    from textvqa_docker import command
    launch_args = parser().parse_args(plan["launcher_arguments"])
    bind_launcher(plan, launch_args)
    require(plan["child_command"] == ["python3", "-B", str(source / "runtime/textvqa_generate.py"),
                                       *plan["launcher_arguments"]], "launcher command differs")
    require(command(launch_args, "0" * 32) == plan["docker_command_template"], "approved Docker command differs")
    require(lease["container_lease_label_required"] is True, "missing controller nonce enforcement")
    actual_image = subprocess.run(["docker", "image", "inspect", "--format", "{{.Id}}", plan["image"]],
                                  capture_output=True, text=True, timeout=30)
    require(actual_image.returncode == 0 and actual_image.stdout.strip() == plan["image"], "image unavailable")
    confirm_absent(plan["container_name"], plan["run_id"])
    active = root.parent / ".leases" / ("cards-" + str(plan["cards"][0]) + ".json")
    require(not active.exists(), "active lease was not released")
    recheck_inputs(c, plan, identity, api, inputs)
    require(all(sha(p) == value for p, value in before.items()), "evidence changed while verifying")
    validate_deployment(plan["runner_deployment"], plan["runner_deployment_sha256"], plan["runner_source"])
    require(sha(runner) == plan["runner_sha256"] and c.tree_sha256(source) == plan["source_tree_sha256"],
            "execution code changed while verifying")
    result = {"schema": "textvqa-owned-host-result-v2", "status": "verified-owned-execution",
              "owned_execution_accepted": True, "run_id": plan["run_id"],
              "source_tree_sha256": plan["source_tree_sha256"], "image": plan["image"],
              "evidence": before, "finalizer_sha256": sha(Path(__file__)),
              "runner_deployment_sha256": plan["runner_deployment_sha256"],
              "container_id": lease["containers"][0]["container_id"], "lease_id": lease["lease_id"],
              "identity_sha256": plan["identity_sha256"], "api_sha256": identity["api_evidence_sha256"],
              "model_tree_sha256": identity["model_tree_sha256"], "input_pins": inputs,
              "question_count": 64, "quality_accepted": False, "performance_accepted": False,
              "recovery_accepted": False, "trust_scope": "trusted same-UID host workflow, not adversarial attestation"}
    require(Path(args.output).absolute() == plan_path.parent / "result.json", "finalizer output differs")
    c.write_json(args.output, result)
    return result


def prepare(args):
    from textvqa_generate import parser
    from textvqa_docker import command
    arguments = c.read_json(args.launcher_arguments, args.launcher_arguments_sha256)
    require(isinstance(arguments, list) and all(isinstance(word, str) for word in arguments), "launcher argv")
    launch = parser().parse_args(arguments)
    require(launch.command == "docker" and launch.host_label == "mlu-10000"
            and socket.gethostname().split(".")[0] == "node1"
            and launch.uid == os.getuid(), "requires main host and matching user")
    require(launch.adapter is None and launch.training_manifest is None
            and launch.training_manifest_sha256 is None, "owned evaluator currently supports base mode only")
    deployment = validate_deployment(launch.runner_deployment, launch.runner_deployment_sha256,
                                     launch.runner_source)
    require(launch.runner_sha256 == deployment["files"]["benchctl.py"], "runner SHA differs")
    identity = c.validate_identity(c.read_json(launch.identity, launch.identity_sha256))
    require(c.tree_sha256(c.ROOT) == identity["source_tree_sha256"]
            and c.tree_sha256(Path(launch.model)) == identity["model_tree_sha256"], "source/model identity differs")
    c.validate_inputs(launch.questions, launch.manifest, launch.manifest_sha256, launch.images_root)
    root = Path(launch.lease_root).absolute()
    require(not root.exists() and root.parent.name == launch.host_label
            and root.parent.parent.name == "generative-mlu"
            and Path(launch.out).absolute() == root / "generation", "fresh run namespace required")
    target = Path(args.out).absolute()
    require(target.name == "plan.json" and not target.resolve().is_relative_to(root)
            and not target.resolve().is_relative_to(c.ROOT.parent), "plan must be external to run/source")
    plan = {"schema": "textvqa-owned-host-plan-v2", "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "runroot_absent_at_creation": True, "source_root": str(c.ROOT),
            "source_tree_sha256": identity["source_tree_sha256"], "runner_source": launch.runner_source,
            "runner_sha256": launch.runner_sha256, "runner_deployment": launch.runner_deployment,
            "runner_deployment_sha256": launch.runner_deployment_sha256,
            "launcher_sha256": sha(c.ROOT / "runtime/textvqa_docker.py"),
            "run_root": str(root), "run_id": root.name, "host": "node1", "host_label": launch.host_label,
            "project": "generative-mlu", "cards": [launch.physical_card],
            "container_name": launch.container_name, "uid": launch.uid, "gid": launch.gid,
            "model": launch.model, "identity": launch.identity, "identity_sha256": launch.identity_sha256,
            "questions": launch.questions, "manifest": launch.manifest, "manifest_sha256": launch.manifest_sha256,
            "images_root": launch.images_root, "api_evidence": launch.api_evidence, "image": launch.runtime_image,
            "child_command": ["python3", "-B", str(c.ROOT / "runtime/textvqa_generate.py"), *arguments],
            "launcher_arguments": arguments, "docker_command_template": command(launch, "0" * 32),
            "finalizer_sha256": sha(Path(__file__))}
    c.regular(args.launcher_arguments)
    require(not any(p.is_symlink() for p in (target, *target.parents)), "aliased plan output")
    c.write_json(target, plan)
    return {"plan": str(target), "plan_sha256": sha(target), "child_command": plan["child_command"]}


def wait_controller(command, cwd, environment):
    child, interrupted = None, []
    forwarded = False
    original = {number: signal.getsignal(number) for number in (signal.SIGINT, signal.SIGTERM)}

    def deliver(number):
        nonlocal forwarded
        if child is not None and not forwarded:
            forwarded = True
            try:
                child.send_signal(number)
            except ProcessLookupError:
                pass

    def forward(number, frame):
        if interrupted:
            return
        interrupted.append(number)
        deliver(number)

    for number in original:
        signal.signal(number, forward)
    try:
        child = subprocess.Popen(command, cwd=cwd, env=environment, start_new_session=True)
        if interrupted:
            deliver(interrupted[0])
        try:
            code = child.wait()
        except BaseException:
            if child.poll() is None:
                try:
                    child.send_signal(signal.SIGTERM)
                except ProcessLookupError:
                    pass
                child.wait()
            raise
        require(not interrupted, "host interrupted; controller cleanup completed; do not finalize")
        return code
    finally:
        for number, handler in original.items():
            signal.signal(number, handler)


def run_plan(args):
    from textvqa_generate import parser
    plan = c.read_json(args.plan, args.plan_sha256)
    require(plan["schema"] == "textvqa-owned-host-plan-v2"
            and plan["runroot_absent_at_creation"] is True
            and sha(Path(__file__)) == plan["finalizer_sha256"]
            and c.ROOT == Path(plan["source_root"])
            and c.tree_sha256(c.ROOT) == plan["source_tree_sha256"], "pre-launch source/plan differs")
    deployment = validate_deployment(plan["runner_deployment"], plan["runner_deployment_sha256"],
                                     plan["runner_source"])
    launch = parser().parse_args(plan["launcher_arguments"])
    bind_launcher(plan, launch)
    require(plan["child_command"] == ["python3", "-B", str(c.ROOT / "runtime/textvqa_generate.py"),
                                       *plan["launcher_arguments"]], "planned child differs")
    root = Path(plan["run_root"])
    require(not root.exists() and plan["host_label"] == "mlu-10000"
            and plan["host"] == socket.gethostname().split(".")[0]
            and plan["uid"] == os.getuid(), "run must be fresh on the original host/user")
    command = ["python3", "-I", "-S", "-B", "-c", controller_bootstrap(deployment["import_root"]),
               "--output-root", str(root.parents[2]),
               "--project", plan["project"], "run", "--host-label", plan["host_label"],
               "--cards", str(plan["cards"][0]), "--sample-interval", "300", "--watch-interval", "15",
               "--timeout-seconds", "3600", "--run-id", plan["run_id"],
               "--container-name", plan["container_name"], "--", *plan["child_command"]]
    # The controller owns timeout and child cleanup; do not kill it from an outer timer.
    code = wait_controller(command, deployment["import_root"],
                           {**os.environ, "PYTHONPATH": deployment["import_root"],
                            "PYTHONDONTWRITEBYTECODE": "1"})
    require(code == 0, "owned controller did not complete; inspect its external lease/log")
    return {"run_id": plan["run_id"], "controller_returncode": 0, "verification_required": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    start = commands.add_parser("prepare")
    start.add_argument("--launcher-arguments", required=True)
    start.add_argument("--launcher-arguments-sha256", required=True)
    start.add_argument("--out", required=True)
    end = commands.add_parser("finalize")
    end.add_argument("--plan", required=True)
    end.add_argument("--plan-sha256", required=True)
    end.add_argument("--output", required=True)
    run = commands.add_parser("run")
    run.add_argument("--plan", required=True)
    run.add_argument("--plan-sha256", required=True)
    args = parser.parse_args()
    operation = {"prepare": prepare, "run": run_plan, "finalize": finalize}[args.command]
    print(json.dumps(operation(args), sort_keys=True))


if __name__ == "__main__":
    main()
