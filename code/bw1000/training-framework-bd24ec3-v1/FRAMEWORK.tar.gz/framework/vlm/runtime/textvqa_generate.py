#!/usr/bin/env python3
"""Native Swift 4.4.2 TextVQA generation; no annotations or scoring imports."""

from __future__ import annotations

import argparse
from dataclasses import fields
import importlib
import importlib.metadata as metadata
import inspect
import os
from pathlib import Path
import sys

from textvqa_contract import (
    FALSE_CLAIMS, GENERATION, ROOT, digest, external_output, hexsha, image_path, loads,
    prompt, read_json, regular, require, sha256_file, tree_sha256, validate_allocator,
    validate_identity, validate_inputs, validate_predictions, validate_execution, write_json,
    validate_api, registry_policy, training_provenance, ENGINE_PARAMETERS, REGISTRY,
)


def installed_versions():
    from verify_environment import EXPECTED_DISTRIBUTIONS, EXPECTED_TORCH
    expected = {**EXPECTED_DISTRIBUTIONS, "torch": EXPECTED_TORCH}
    actual = {name: metadata.version(name) for name in expected}
    require(actual == expected, "pinned package versions differ")
    return actual


def engine_parameters(engine):
    parameters = sorted(inspect.signature(engine).parameters)
    require(ENGINE_PARAMETERS <= set(parameters), "Swift engine API changed")
    return parameters


def api_inventory(runtime_image):
    # This path imports the installed stack but never creates a model or selects a card.
    from verify_environment import main as verify_environment
    import re
    require(isinstance(runtime_image, str) and re.fullmatch(r"sha256:[0-9a-f]{64}", runtime_image),
            "CPU API evidence requires full runtime image ID")
    versions = installed_versions()
    verify_environment()
    from swift import TransformersEngine, InferRequest, RequestConfig
    from swift.utils import import_external_file
    constructor = engine_parameters(TransformersEngine)
    require({"infer_requests", "request_config", "use_tqdm"}
            <= set(inspect.signature(TransformersEngine.infer).parameters), "Swift infer API changed")
    require({"messages", "images"} <= {f.name for f in fields(InferRequest)}, "Swift request API changed")
    require(set(GENERATION) <= {f.name for f in fields(RequestConfig)}, "Swift config API changed")
    request = InferRequest(messages=[{"role": "user", "content": "<image>\nCPU API check"}], images=["image.jpg"])
    config = RequestConfig(**GENERATION)
    require(request.images == ["image.jpg"] and config.max_tokens == 32 and config.temperature == 0,
            "Swift request construction failed")
    origins = {}
    for name in ("swift", "transformers", "peft", "torch", "torch_mlu"):
        module = importlib.import_module(name)
        path = regular(module.__file__)
        origins[name] = {"path": str(path), "sha256": sha256_file(path)}
        if name != "torch_mlu":
            distribution = "ms-swift" if name == "swift" else name
            require(path.resolve() == Path(metadata.distribution(distribution).locate_file(
                name + "/__init__.py")).resolve(), "import shadows installed distribution: " + name)
    sources = {}
    for name, obj in (("engine", TransformersEngine), ("infer", TransformersEngine.infer),
                      ("request", InferRequest), ("config", RequestConfig), ("plugin_import", import_external_file)):
        path = regular(inspect.getsourcefile(obj))
        sources[name] = {"path": str(path), "sha256": sha256_file(path)}
    # Bind implementation, including native model/template loaders, not just exported names.
    packages = {}
    for name in ("swift", "transformers", "peft"):
        root = Path(importlib.import_module(name).__file__).parent
        packages[name] = digest({p.relative_to(root).as_posix(): sha256_file(regular(p))
                                 for p in sorted(root.rglob("*.py"))})
    from swift.model.register import MODEL_MAPPING
    from swift.model.model_meta import get_matched_model_meta
    # Native resolution applies model-group template overrides before type defaults.
    templates = {}
    for alias, (folder, model_type) in REGISTRY.items():
        meta = get_matched_model_meta(folder)
        if meta is None or meta.model_type != model_type:
            meta = MODEL_MAPPING[model_type]
        templates[alias] = meta.template
    return validate_api({"schema": "vlm-textvqa-api-v2", "status": "verified-cpu-import", "runtime_image": runtime_image,
                         "versions": versions,
                         "engine_parameters": constructor, "registry_templates": templates,
                         "origins": origins, "sources": sources, "package_sources": packages})


def directory(path):
    root = Path(path).absolute()
    require(root.is_dir() and not any(p.is_symlink() for p in (root, *root.parents)), "aliased/missing directory")
    return root


def freeze(args):
    validate_inputs(args.questions, args.manifest, args.manifest_sha256, args.images_root)
    api = validate_api(read_json(args.api_evidence, args.api_sha256))
    require(api.get("runtime_image") == args.runtime_image, "CPU API runtime image differs")
    registry_policy(args, args.template, api)
    model_sha = tree_sha256(directory(args.model))
    adapter = directory(args.adapter) if args.adapter else None
    adapter_sha = tree_sha256(adapter) if adapter else None
    provenance = None
    if adapter:
        require(args.training_manifest and args.training_manifest_sha256, "adapter requires actual training provenance file/SHA")
        provenance = training_provenance(args.training_manifest, args.training_manifest_sha256,
                                        model_alias=args.model_alias, model_type=args.model_type, template=args.template,
                                        model_sha=model_sha, adapter_sha=adapter_sha,
                                        runtime_image=args.runtime_image, adapter=adapter)
    else:
        require(args.training_manifest is None and args.training_manifest_sha256 is None, "base mode has no training provenance")
    identity = validate_identity({
        "schema": "vlm-textvqa-identity-v2", "model_alias": args.model_alias, "model_type": args.model_type,
        "template": args.template, "model_tree_sha256": model_sha,
        "adapter_tree_sha256": adapter_sha,
        "training_manifest_sha256": provenance["training_dataset_sha256"] if provenance else None,
        "training_provenance_sha256": args.training_manifest_sha256,
        "source_tree_sha256": tree_sha256(ROOT), "runtime_image": args.runtime_image,
        "api_evidence_sha256": args.api_sha256, "input_manifest_sha256": args.manifest_sha256,
        "generation": GENERATION, "processor_env": loads(args.processor_env),
        "attn_impl": args.attn_impl, "model_kwargs": loads(args.model_kwargs)})
    output = external_output(args.out, (args.model, args.images_root, *([args.adapter] if adapter else [])))
    write_json(output / "identity.json", identity)


def bound_training(args, identity):
    if identity["adapter_tree_sha256"] is None:
        require(args.adapter is None and args.training_manifest is None
                and args.training_manifest_sha256 is None, "base mode provenance differs")
        return None
    require(args.adapter and args.training_manifest
            and args.training_manifest_sha256 == identity["training_provenance_sha256"],
            "adapter requires frozen training provenance file/SHA")
    value = training_provenance(args.training_manifest, args.training_manifest_sha256,
                                model_alias=identity["model_alias"], model_type=identity["model_type"],
                                template=identity["template"], model_sha=identity["model_tree_sha256"],
                                adapter_sha=identity["adapter_tree_sha256"], runtime_image=identity["runtime_image"],
                                adapter=directory(args.adapter))
    require(value["training_dataset_sha256"] == identity["training_manifest_sha256"], "training dataset binding differs")
    return value


def validate_isolated_environment(execution, environment, uid):
    validate_execution(execution)
    require(environment.get("MLU_VISIBLE_DEVICES") == "0"
            and environment.get("CNRT_VISIBLE_DEVICES") == "0",
            "isolated container requires logical visible card 0")
    require(execution["uid"] == uid, "admitted UID differs")


def allocator(torch, requested, total):
    actual = float(torch.mlu.get_per_process_memory_fraction(0))
    result = {"requested_fraction": requested, "actual_fraction": actual, "total_memory": total,
              "peak_reserved": int(torch.mlu.max_memory_reserved(0))}
    import math
    if not math.isfinite(actual):
        result["actual_fraction"] = str(actual)
    return result


class ForwardWitness:
    """Observe actual native generation forwards; handles PEFT's generate delegation."""

    def __init__(self, model, torch):
        self.torch, self.handles = torch, []
        self.reset()
        try:
            for module in model.modules():
                if callable(getattr(module, "generate", None)):
                    self.handles.append(module.register_forward_pre_hook(self.before, with_kwargs=True))
                    self.handles.append(module.register_forward_hook(self.after))
            require(self.handles, "no native generation forward hook targets")
        except BaseException:
            self.close()
            raise

    def reset(self):
        self.calls, self.input_devices, self.output_devices, self.finite = 0, set(), set(), True

    def tensors(self, value):
        if isinstance(value, self.torch.Tensor):
            yield value
        elif isinstance(value, dict):
            for item in value.values():
                yield from self.tensors(item)
        elif isinstance(value, (list, tuple)):
            for item in value:
                yield from self.tensors(item)

    def before(self, module, args, kwargs):
        self.input_devices.update(str(t.device) for t in self.tensors((args, kwargs)))

    def after(self, module, args, output):
        tensors = list(self.tensors(output))
        self.calls += 1
        self.output_devices.update(str(t.device) for t in tensors)
        self.finite = self.finite and all(bool(self.torch.isfinite(t).all().item())
                                        for t in tensors if t.is_floating_point())

    def record(self):
        return {"calls": self.calls, "input_devices": sorted(self.input_devices),
                "output_devices": sorted(self.output_devices), "finite": self.finite}

    def close(self):
        for handle in reversed(self.handles):
            handle.remove()
        self.handles.clear()


def native_model_kwargs(identity):
    kwargs = dict(identity["model_kwargs"])
    if "trust_remote_code" in kwargs:
        from swift.model.register import MODEL_MAPPING
        loader = MODEL_MAPPING[identity["model_type"]].loader
        require(kwargs["trust_remote_code"] is True
                and getattr(loader, "default_trust_remote_code", None) is True,
                "native loader trust policy differs")
        # Swift supplies this explicit keyword itself; passing it twice is invalid.
        del kwargs["trust_remote_code"]
    return kwargs


def generate(args):
    identity = validate_identity(read_json(args.identity, args.identity_sha256))
    registry_policy(args, identity["template"], read_json(args.api_evidence, identity["api_evidence_sha256"]))
    provenance = bound_training(args, identity)
    # Docker's authenticated lease child creates only this admission receipt.
    output = Path(args.out).absolute()
    execution_file = regular(args.execution_evidence)
    require(execution_file.parent == output and execution_file.name == "execution.json"
            and {p.name for p in output.iterdir()} == {"execution.json"}, "fresh admitted output required")
    require(not output.resolve().is_relative_to(ROOT.parent), "output must be external")
    for raw in (args.model, args.questions, args.manifest, args.images_root, args.identity,
                args.api_evidence, *([args.adapter, args.training_manifest] if args.adapter else [])):
        path = Path(raw).resolve()
        require(not output.resolve().is_relative_to(path) and not path.is_relative_to(output.resolve()),
                "output overlaps read-only input")
    execution = read_json(execution_file, args.execution_sha256)
    validate_execution(execution)
    witness = None
    try:
        rows, input_pins = validate_inputs(args.questions, args.manifest, args.manifest_sha256, args.images_root)
        require(input_pins["manifest_sha256"] == identity["input_manifest_sha256"], "input identity differs")
        require(args.model_alias == identity["model_alias"] and args.model_type == identity["model_type"],
                "registry identity differs")
        require(args.attn_impl == identity["attn_impl"] and loads(args.model_kwargs) == identity["model_kwargs"],
                "registry loader policy differs")
        require(args.runtime_image == identity["runtime_image"], "runtime image identity differs")
        api = api_inventory(args.runtime_image)
        require(api == read_json(args.api_evidence, identity["api_evidence_sha256"]), "installed CPU API identity differs")
        model_root = directory(args.model)
        adapter_root = directory(args.adapter) if args.adapter else None
        require((adapter_root is None) == (identity["adapter_tree_sha256"] is None), "adapter/base mode mismatch")
        require(tree_sha256(ROOT) == identity["source_tree_sha256"], "source identity differs")
        require(tree_sha256(model_root) == identity["model_tree_sha256"], "model identity differs")
        if adapter_root:
            saved_args = read_json(adapter_root / "args.json")
            require(isinstance(saved_args, dict) and saved_args.get("model_type") == args.model_type
                    and saved_args.get("template") in (None, identity["template"]), "saved adapter metadata differs")
            require(tree_sha256(adapter_root) == identity["adapter_tree_sha256"], "adapter identity differs")
        for key in ("MAX_PIXELS",):
            require(key not in os.environ or os.environ[key] == identity["processor_env"].get(key),
                    "unbound processor environment")
        os.environ.update(identity["processor_env"])
        validate_isolated_environment(execution, os.environ, os.getuid())
        import torch
        import torch_mlu  # noqa: F401
        from swift import TransformersEngine, InferRequest, RequestConfig
        from swift.utils import import_external_file
        for name in ("set_device", "get_device_properties", "set_per_process_memory_fraction",
                     "get_per_process_memory_fraction", "max_memory_reserved", "device_count"):
            require(callable(getattr(torch.mlu, name, None)), "missing MLU API: " + name)
        require(torch.mlu.device_count() == 1, "visible device topology differs")
        torch.mlu.set_device(0)
        total = int(torch.mlu.get_device_properties(0).total_memory)
        require(total > 0, "invalid device capacity")
        fraction = min(1.0, (75_000_000_000 - 1_048_576) / total)
        torch.mlu.set_per_process_memory_fraction(fraction, 0)
        before = allocator(torch, fraction, total)
        write_json(output / "allocator-before.json", before)
        validate_allocator(before)
        if args.external_plugins:
            plugin = regular(args.external_plugins)
            require(plugin == ROOT / "plugins" / "llava_onevision.py", "unsupported external plugin")
            import_external_file(str(plugin))
        require(bool(args.external_plugins) == (args.model_type == "llava_onevision1_5"),
                "registry plugin policy differs")
        engine = TransformersEngine(str(model_root), adapters=[str(adapter_root)] if adapter_root else [],
                                    model_type=args.model_type, torch_dtype=torch.bfloat16,
                                    device_map={"": "mlu:0"}, max_batch_size=1, template_type=identity["template"],
                                    attn_impl=args.attn_impl, model_kwargs=native_model_kwargs(identity))
        require(engine.template_type == identity["template"], "native template identity differs")
        engine.template.truncation_strategy = "raise"
        parameter_devices = sorted({str(p.device) for p in engine.model.parameters()})
        require(parameter_devices == ["mlu:0"], "CPU or other-device model parameter fallback")
        adapter_active = False
        if adapter_root:
            active = getattr(engine.model, "active_adapters", None)
            if callable(active):
                active = active()
            adapter_active = bool(active) and any("lora_" in name for name, _ in engine.model.named_parameters())
            require(adapter_active, "native adapter is not active")
        witness = ForwardWitness(engine.model, torch)
        records = []
        with (output / "predictions.jsonl").open("x", encoding="utf-8", newline="\n") as handle:
            import json
            for row in rows:
                witness.reset()
                config = RequestConfig(**GENERATION)
                response = engine.infer([InferRequest(
                    messages=[{"role": "user", "content": prompt(row)}],
                    images=[str(image_path(args.images_root, row["image_path"]))])], config, use_tqdm=False)
                require(isinstance(response, list) and len(response) == 1
                        and len(response[0].choices) == 1, "native response cardinality differs")
                choice, usage = response[0].choices[0], response[0].usage
                require(config.max_tokens == 32, "native engine changed token budget")
                if engine.max_model_len is not None:
                    require(usage.prompt_tokens + 32 <= engine.max_model_len, "insufficient native context budget")
                record = {"question_id": row["question_id"], "image_id": row["image_id"],
                          "answer": choice.message.content,
                          "request_sha256": digest({"prompt": prompt(row), "image_sha256": row["image_sha256"]}),
                          "completion_tokens": usage.completion_tokens, "prompt_tokens": usage.prompt_tokens,
                          "finish_reason": choice.finish_reason, "forward": witness.record()}
                # Validate each record before writing; full cardinality is checked at completion.
                from textvqa_contract import text, positive_int
                text(record["answer"])
                require(positive_int(record["completion_tokens"]) <= 32, "invalid completion")
                require(record["forward"]["calls"] > 0 and record["forward"]["finite"]
                        and record["forward"]["input_devices"] == record["forward"]["output_devices"] == ["mlu:0"],
                        "missing actual MLU input/output or nonfinite forward")
                handle.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
                handle.flush()
                records.append(record)
        validate_predictions(rows, records)
        after = allocator(torch, fraction, total)
        write_json(output / "allocator-after.json", after)
        validate_allocator(after, peak=True)
        require(before["total_memory"] == after["total_memory"]
                and before["actual_fraction"] == after["actual_fraction"], "allocator changed")
        require(api == api_inventory(args.runtime_image), "runtime implementation changed")
        require(tree_sha256(ROOT) == identity["source_tree_sha256"]
                and tree_sha256(model_root) == identity["model_tree_sha256"], "source/model changed")
        if adapter_root:
            require(tree_sha256(adapter_root) == identity["adapter_tree_sha256"], "adapter changed")
        require(bound_training(args, identity) == provenance, "training provenance changed")
        require(validate_inputs(args.questions, args.manifest, args.manifest_sha256, args.images_root)[1] == input_pins,
                "inputs changed")
        require(read_json(args.identity, args.identity_sha256) == identity, "identity changed")
        require(read_json(execution_file, args.execution_sha256) == execution, "admission receipt changed")
        write_json(output / "generation.json", {
            "schema": "vlm-textvqa-generation-v2", "status": "diagnostic_completed", "identity": identity,
            "owned_execution_accepted": False,
            "identity_sha256": args.identity_sha256, "inputs": input_pins, "api": api,
            "predictions_sha256": sha256_file(output / "predictions.jsonl"),
            "question_ids": [r["question_id"] for r in rows], "question_count": len(rows),
            "parameter_devices": parameter_devices, "adapter_active": adapter_active,
            "execution": execution, "execution_sha256": args.execution_sha256,
            "allocator_before": before, "allocator_after": after, "claims": FALSE_CLAIMS})
    except BaseException as exc:
        write_json(output / "failed.json", {"status": "failed", "error": str(exc), "claims": FALSE_CLAIMS})
        raise
    finally:
        if witness is not None:
            witness.close()


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    commands = result.add_subparsers(dest="command", required=True)
    api = commands.add_parser("api-preflight", help="CPU import/API construction only; no model or MLU calls")
    api.add_argument("--out", required=True)
    api.add_argument("--runtime-image", required=True)
    for name in ("freeze", "generate", "docker"):
        command = commands.add_parser(name)
        for flag in ("model", "model-alias", "model-type", "questions", "manifest", "manifest-sha256",
                     "images-root", "api-evidence", "runtime-image", "out"):
            command.add_argument("--" + flag, required=True)
        command.add_argument("--adapter")
        command.add_argument("--attn_impl", choices=("eager", "sdpa"))
        command.add_argument("--model_kwargs", default="{}")
        command.add_argument("--external_plugins")
        command.add_argument("--training-manifest")
        command.add_argument("--training-manifest-sha256")
        if name == "freeze":
            command.add_argument("--template", required=True)
            command.add_argument("--api-sha256", required=True)
            command.add_argument("--processor-env", default="{}")
        else:
            command.add_argument("--identity", required=True)
            command.add_argument("--identity-sha256", required=True)
        if name == "generate":
            command.add_argument("--execution-evidence", required=True)
            command.add_argument("--execution-sha256", required=True)
        if name == "docker":
            command.add_argument("--container-name", required=True)
            command.add_argument("--physical-card", type=int, required=True)
            command.add_argument("--uid", type=int, default=1001)
            command.add_argument("--gid", type=int, default=1002)
            command.add_argument("--lease-root", required=True)
            command.add_argument("--host-label", choices=("mlu-10000", "mlu-10001"), required=True)
            command.add_argument("--runner-source", required=True)
            command.add_argument("--runner-sha256", required=True)
            command.add_argument("--runner-deployment", required=True)
            command.add_argument("--runner-deployment-sha256", required=True)
    return result


def main():
    args = parser().parse_args()
    if args.command == "api-preflight":
        output = Path(args.out).absolute()
        require(not output.resolve().is_relative_to(ROOT.parent), "API evidence must be external")
        write_json(output, api_inventory(args.runtime_image))
    elif args.command == "freeze":
        freeze(args)
    elif args.command == "docker":
        from textvqa_docker import launch
        launch(args)
    else:
        generate(args)


if __name__ == "__main__":
    main()
