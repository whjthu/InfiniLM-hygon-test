#!/usr/bin/env python3
"""Offline official MMF TextVQA scoring, with strict generation and held-out bindings."""

from __future__ import annotations

import argparse
from pathlib import Path

from textvqa_contract import (
    ANNOTATIONS_SHA, SUBSET_SHA, FALSE_CLAIMS, ROOT, digest, external_output, hexsha, image_path,
    keys, loads, read_json, regular, require, sha256_file, text, validate_identity,
    validate_inputs, validate_run, write_json, validate_api, training_provenance,
)

MMF_COMMIT = "72f898ec35af86567423c7a019dd1dc5175d1a5a"
MMF_SHA = "e10a99e15c4658f8d0d83a05cc536c835922e701171fce0016718bec021b8c0a"
LICENSE_SHA = "dbb40c7bb9a3de99f13fe5643fbdaa0ae90a1591c232f1b316e0528a835776c9"
EMPTY_THINK_PREFIX = "<think>\n\n</think>\n\n"


def extracted_answers(records, model_alias, policy):
    require(policy in ("raw", "empty-think-prefix-v1"), "unsupported answer policy")
    answers = [record["answer"] for record in records]
    if policy == "raw":
        return answers
    require(model_alias == "minicpmv4_6", "empty prefix policy is MiniCPM-specific")
    # Swift's non-thinking template adds this empty envelope, not generated reasoning.
    result = []
    for answer in answers:
        require(answer.startswith(EMPTY_THINK_PREFIX), "missing exact empty thinking prefix")
        value = answer[len(EMPTY_THINK_PREFIX):]
        text(value)
        require("<think>" not in value and "</think>" not in value, "nested or malformed thinking response")
        result.append(value)
    return result


def official_evaluator():
    require(sha256_file(regular(ROOT / "runtime/mmf_m4c_evaluators.py")) == MMF_SHA
            and sha256_file(regular(ROOT / "runtime/MMF-LICENSE.txt")) == LICENSE_SHA, "official scorer bytes differ")
    from mmf_m4c_evaluators import TextVQAAccuracyEvaluator
    return TextVQAAccuracyEvaluator()


def jsonl(path):
    values = []
    with regular(path).open(encoding="utf-8") as handle:
        for line in handle:
            require(bool(line.strip()), "blank JSONL row")
            values.append(loads(line))
    require(values, "empty JSONL")
    return values


def ground_truth(annotations_file, subset_file, rows):
    annotations = read_json(annotations_file, ANNOTATIONS_SHA)
    require(isinstance(annotations, dict) and annotations.get("dataset_type") == "val"
            and annotations.get("dataset_version") == "0.5.1", "official annotations split/version")
    data = annotations.get("data")
    require(isinstance(data, list) and len(data) == 5000, "official annotation count")
    by_id = {}
    for row in data:
        require(isinstance(row, dict) and type(row.get("question_id")) is int
                and row["question_id"] not in by_id, "duplicate/invalid official question ID")
        by_id[row["question_id"]] = row
    subset = read_json(subset_file, SUBSET_SHA)
    require(isinstance(subset, dict) and isinstance(subset.get("data"), list)
            and len(subset["data"]) == len(rows), "subset schema/count")
    answers = []
    for question, selected in zip(rows, subset["data"]):
        # The GT-free sibling can rebase image paths, but not IDs, bytes or dimensions.
        field_names = {"width": "image_width", "height": "image_height"}
        require(isinstance(selected, dict) and all(
            selected.get(field_names.get(k, k)) == v for k, v in question.items() if k != "image_path"),
                "subset/question metadata differs")
        require(selected.get("set_name") == "val" and "width" not in selected and "height" not in selected
                and type(selected.get("image_width")) is int and type(selected.get("image_height")) is int,
                "fixed subset dimensions/split schema differs")
        text(selected.get("image_path"))
        official = by_id.get(question["question_id"])
        require(official is not None and official.get("question") == question["question"]
                and official.get("image_id") == question["image_id"]
                and official.get("image_width") == question["width"]
                and official.get("image_height") == question["height"], "question not in official validation split")
        gt = official.get("answers")
        require(isinstance(gt, list) and len(gt) == 10 and all(isinstance(a, str) for a in gt),
                "requires ten actual annotator answers")
        require(selected.get("answers") == gt, "subset answers differ from official annotations")
        answers.append(gt)
    return answers


def held_out(training_file, expected_sha, training_images_root, rows):
    before = hexsha(expected_sha)
    require(sha256_file(regular(training_file)) == before, "training input SHA differs")
    eval_shas = {r["image_sha256"] for r in rows}
    eval_ids = {r["question_id"] for r in rows}
    image_shas = set()
    count = 0
    for row in jsonl(training_file):
        require(isinstance(row, dict) and isinstance(row.get("images"), list) and row["images"],
                "SFT row lacks explicit image list")
        if "question_id" in row:
            require(type(row["question_id"]) is int and row["question_id"] not in eval_ids,
                    "training/evaluation question overlap")
        for raw in row["images"]:
            text(raw)
            path = Path(raw)
            if path.is_absolute():
                root = Path(training_images_root).resolve()
                require(path.resolve().is_relative_to(root), "SFT image outside supplied root")
                relative = path.relative_to(root).as_posix()
            else:
                relative = raw
            path = image_path(training_images_root, relative)
            value = sha256_file(path)
            require(value not in eval_shas, "training/evaluation image byte overlap")
            image_shas.add(value)
            count += 1
    require(count > 0 and sha256_file(regular(training_file)) == before, "training input changed/empty")
    return {"training_manifest_sha256": before, "image_references": count,
            "distinct_image_sha256": sorted(image_shas), "held_out_from_supplied_sft_inputs": True,
            "pretraining_overlap": "not assessed"}


def score(args):
    rows, inputs = validate_inputs(args.questions, args.manifest, args.manifest_sha256, args.images_root)
    identity = validate_identity(read_json(args.identity, args.identity_sha256))
    require(identity["input_manifest_sha256"] == args.manifest_sha256, "identity input binding")
    api = validate_api(read_json(args.api_evidence, identity["api_evidence_sha256"]))
    require(api.get("runtime_image") == identity["runtime_image"], "CPU API runtime image differs")
    require(identity["template"] == api["registry_templates"][identity["model_alias"]], "native template binding differs")
    provenance = None
    if identity["adapter_tree_sha256"] is not None:
        require(args.training_manifest and args.training_manifest_sha256 == identity["training_provenance_sha256"],
                "scoring requires frozen accepted training provenance")
        provenance = training_provenance(args.training_manifest, args.training_manifest_sha256,
                                        model_alias=identity["model_alias"], model_type=identity["model_type"],
                                        template=identity["template"], model_sha=identity["model_tree_sha256"],
                                        adapter_sha=identity["adapter_tree_sha256"], runtime_image=identity["runtime_image"])
        require(provenance["training_dataset_sha256"] == identity["training_manifest_sha256"], "training dataset provenance differs")
    else:
        require(args.training_manifest is None and args.training_manifest_sha256 is None, "base scoring provenance differs")
    run_file = regular(Path(args.run_root) / "generation.json")
    run = read_json(run_file, args.run_sha256)
    predictions = regular(Path(args.run_root) / "predictions.jsonl")
    require(sha256_file(predictions) == run.get("predictions_sha256"), "prediction file SHA differs")
    records = jsonl(predictions)
    validate_run(run, identity, inputs, records, rows)
    execution_file = regular(Path(args.run_root) / "execution.json")
    require(read_json(execution_file, run["execution_sha256"]) == run["execution"], "execution receipt differs")
    require(run["identity_sha256"] == args.identity_sha256 and run["api"] == api, "run/API identity differs")
    answers = ground_truth(args.annotations, args.subset, rows)
    training_sha = identity["training_manifest_sha256"] or args.training_data_sha256
    require(training_sha == args.training_data_sha256, "adapter training input identity differs")
    separation = held_out(args.training_data, training_sha, args.training_images_root, rows)
    evaluator = official_evaluator()
    policy = getattr(args, "answer_policy", "raw")
    predicted = extracted_answers(records, identity["model_alias"], policy)
    accuracy = evaluator.eval_pred_list([{"pred_answer": answer, "gt_answers": gt}
                                        for answer, gt in zip(predicted, answers)])
    require(type(accuracy) in (float, int) and 0 <= accuracy <= 1, "invalid official accuracy")
    require(read_json(run_file, args.run_sha256) == run
            and sha256_file(predictions) == run["predictions_sha256"], "generation artifacts changed")
    require(read_json(execution_file, run["execution_sha256"]) == run["execution"], "execution receipt changed")
    require(validate_inputs(args.questions, args.manifest, args.manifest_sha256, args.images_root)[1] == inputs,
            "evaluation inputs changed")
    require(read_json(args.identity, args.identity_sha256) == identity
            and read_json(args.api_evidence, identity["api_evidence_sha256"]) == api, "identity/API changed")
    require(ground_truth(args.annotations, args.subset, rows) == answers, "ground truth changed")
    require(held_out(args.training_data, training_sha, args.training_images_root, rows) == separation,
            "training images changed")
    if provenance is not None:
        require(read_json(args.training_manifest, args.training_manifest_sha256) == provenance, "training provenance changed")
    output = external_output(args.out, (args.run_root, args.images_root, args.training_images_root,
                                       args.training_data, args.annotations, args.subset))
    extracted = output / "answers.jsonl"
    import json
    with extracted.open("x", encoding="utf-8", newline="\n") as handle:
        for record, answer in zip(records, predicted):
            handle.write(json.dumps({"question_id": record["question_id"], "raw_answer": record["answer"],
                                     "answer": answer, "changed": answer != record["answer"]},
                                    ensure_ascii=False, allow_nan=False) + "\n")
    write_json(output / "score.json", {
        "schema": "vlm-textvqa-score-v2", "status": "diagnostic_completed", "dataset": "TextVQA",
        "owned_execution_accepted": False,
        "version": "0.5.1", "split": "val", "scope": "validation-subset", "question_count": 64,
        "accuracy": accuracy, "accuracy_percent": 100 * accuracy,
        "answer_extraction": {"policy": policy, "source_sha256": sha256_file(Path(__file__)),
                              "raw_predictions_sha256": run["predictions_sha256"],
                              "extracted_answers_sha256": digest(predicted),
                              "extracted_file_sha256": sha256_file(extracted),
                              "changed_answers": sum(answer != record["answer"]
                                                     for answer, record in zip(predicted, records))},
        "question_ids": [r["question_id"] for r in rows], "identity": identity,
        "identity_sha256": args.identity_sha256, "inputs": inputs, "run_sha256": args.run_sha256,
        "predictions_sha256": run["predictions_sha256"], "training_separation": separation,
        "scorer": {"upstream_commit": MMF_COMMIT, "source_sha256": MMF_SHA, "license_sha256": LICENSE_SHA,
                   "entry_source_sha256": sha256_file(Path(__file__)), "source_tree_sha256": digest({
                       name: sha256_file(ROOT / "runtime" / name)
                       for name in ("textvqa_score.py", "textvqa_contract.py", "mmf_m4c_evaluators.py")})},
        "claims": FALSE_CLAIMS})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("questions", "manifest", "manifest-sha256", "images-root", "identity", "identity-sha256",
                 "api-evidence", "run-root", "run-sha256", "annotations", "subset", "training-data",
                 "training-data-sha256", "training-images-root", "out"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--training-manifest")
    parser.add_argument("--training-manifest-sha256")
    parser.add_argument("--answer-policy", choices=("raw", "empty-think-prefix-v1"), default="raw")
    score(parser.parse_args())


if __name__ == "__main__":
    main()
