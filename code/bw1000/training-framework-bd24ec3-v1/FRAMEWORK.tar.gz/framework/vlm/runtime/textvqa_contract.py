"""Strict TextVQA subset input, identity and prediction contracts (CPU only)."""

from __future__ import annotations

import hashlib
import json
import math
import re
from pathlib import Path, PurePosixPath

from verify_minicpm_identity import sha256_file, tree_sha256

ROOT = Path(__file__).resolve().parents[1]
ANNOTATIONS_SHA = "4ceb5aadc1a41719d0a3e4dfdf06838bcfee1db569a9a65ee67d31c99893081d"
SUBSET_SHA = "18584e8a62d4e717fbcb1731a02fad65da205602a02079dc932208b561cba325"
GENERATION = {"max_tokens": 32, "temperature": 0, "num_beams": 1, "n": 1, "stream": False}
FALSE_CLAIMS = {"full_benchmark": False, "quality_accepted": False,
                "performance_accepted": False, "fresh_recovery_verified": False}
ROW_KEYS = {"question_id", "question", "image_id", "image_path", "image_sha256",
            "image_bytes", "width", "height"}
REGISTRY = {
    "qwen3-vl": ("Qwen3-VL-8B-Instruct", "qwen3_vl"),
    "gemma3": ("gemma-3-4b-it", "gemma3_vision"),
    "internvl3_5": ("InternVL3_5-8B-HF", "internvl"),
    "llava-onevision1_5": ("LLaVA-OneVision-1.5-8B-Instruct", "llava_onevision1_5"),
    "minicpmv4_6": ("MiniCPM-V-4.6", "minicpmv4_6"),
}
ENGINE_PARAMETERS = {"model", "adapters", "torch_dtype", "model_type", "device_map",
                     "model_kwargs", "attn_impl", "template_type", "max_batch_size"}


def validate_api(api):
    from verify_environment import EXPECTED_DISTRIBUTIONS, EXPECTED_TORCH
    require(api.get("schema") == "vlm-textvqa-api-v2"
            and api.get("status") == "verified-cpu-import", "requires r2 actual CPU API evidence")
    require(api.get("versions") == {**EXPECTED_DISTRIBUTIONS, "torch": EXPECTED_TORCH},
            "pinned package versions differ")
    parameters = api.get("engine_parameters")
    require(isinstance(parameters, list) and all(isinstance(p, str) for p in parameters)
            and len(parameters) == len(set(parameters)) and ENGINE_PARAMETERS <= set(parameters),
            "Swift engine parameter contract differs")
    templates = api.get("registry_templates")
    keys(templates, REGISTRY, "native registry templates")
    for template in templates.values():
        text(template)
    return api


def registry_policy(args, template, api):
    import os
    require(args.model_alias in REGISTRY, "unsupported registry alias")
    folder, model_type = REGISTRY[args.model_alias]
    expected = Path(os.environ.get("MODELS_DIR", "/mnt/models")).absolute() / folder
    require(Path(args.model).absolute() == expected and args.model_type == model_type,
            "registry model path/type differs")
    llava = args.model_alias == "llava-onevision1_5"
    require(args.attn_impl == ("eager" if llava else None)
            and digest(loads(args.model_kwargs)) == digest({"trust_remote_code": True} if llava else {}),
            "registry loader policy differs")
    expected_plugin = ROOT / "plugins/llava_onevision.py" if llava else None
    plugin = getattr(args, "external_plugins", None)
    require((Path(plugin).absolute() if plugin else None) == expected_plugin, "registry plugin differs")
    require(template == validate_api(api)["registry_templates"][args.model_alias],
            "registry native template differs")


def training_provenance(path, expected_sha, *, model_alias, model_type, template,
                        model_sha, adapter_sha, runtime_image, adapter=None):
    value = read_json(path, hexsha(expected_sha))
    keys(value, {"schema", "status", "model_alias", "model_type", "template", "model_tree_sha256",
                 "adapter_tree_sha256", "checkpoint_args_sha256", "adapter_config_sha256",
                 "base_model_name_or_path", "training_dataset", "training_dataset_sha256",
                 "training_source_tree_sha256", "runtime_image", "accepted_run"}, "training provenance")
    require(value["schema"] == "vlm-textvqa-training-provenance-v1"
            and value["status"] == "accepted-qualified-training", "training provenance not accepted")
    expected = {"model_alias": model_alias, "model_type": model_type, "template": template,
                "model_tree_sha256": model_sha, "adapter_tree_sha256": adapter_sha,
                "runtime_image": runtime_image}
    require(all(value[k] == v for k, v in expected.items()), "training provenance identity differs")
    for field in ("model_tree_sha256", "adapter_tree_sha256", "checkpoint_args_sha256",
                  "adapter_config_sha256", "training_dataset_sha256", "training_source_tree_sha256"):
        hexsha(value[field])
    base = text(value["base_model_name_or_path"])
    require(Path(base).name == REGISTRY[model_alias][0], "training base model mapping differs")
    dataset = value["training_dataset"]
    require(isinstance(dataset, list) and dataset and all(isinstance(p, str) and p.strip() for p in dataset),
            "training dataset references missing")
    run = value["accepted_run"]
    keys(run, {"run_id", "host_label", "global_step", "report_sha256", "identity_sha256", "source_commit"},
         "accepted training run")
    text(run["run_id"])
    require(run["host_label"] in ("mlu-10000", "mlu-10001"), "training host label")
    positive_int(run["global_step"])
    for field in ("report_sha256", "identity_sha256"):
        hexsha(run[field])
    require(isinstance(run["source_commit"], str) and re.fullmatch(r"[0-9a-f]{40}", run["source_commit"]),
            "training source commit")
    if adapter is not None:
        root = Path(adapter)
        saved = read_json(root / "args.json", value["checkpoint_args_sha256"])
        config = read_json(root / "adapter_config.json", value["adapter_config_sha256"])
        regular(root / "adapter_model.safetensors")
        require(isinstance(saved, dict) and saved.get("model") == base
                and saved.get("model_type") == model_type and saved.get("template") in (None, template)
                and saved.get("dataset") == dataset, "saved checkpoint args provenance differs")
        require(isinstance(config, dict) and config.get("base_model_name_or_path") == base
                and config.get("peft_type") == "LORA", "adapter base model/PEFT metadata differs")
        positive_int(config.get("r"))
        alpha = config.get("lora_alpha")
        require(type(alpha) in (int, float) and math.isfinite(alpha) and alpha > 0, "invalid LoRA alpha")
        targets = config.get("target_modules")
        require((isinstance(targets, str) and bool(targets.strip())) or
                (isinstance(targets, list) and targets and all(isinstance(t, str) and t.strip() for t in targets)),
                "missing LoRA target modules")
        require(tree_sha256(root) == adapter_sha, "adapter provenance tree differs")
    return value


def require(condition, message):
    if not condition:
        raise ValueError(message)


def keys(value, expected, label):
    require(isinstance(value, dict) and set(value) == set(expected), label + ": unexpected fields")


def hexsha(value):
    require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value), "invalid SHA256")
    return value


def positive_int(value):
    require(type(value) is int and value > 0, "expected positive integer")
    return value


def text(value):
    require(isinstance(value, str) and bool(value.strip()), "expected nonempty text")
    return value


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON key: " + key)
        result[key] = value
    return result


def loads(value):
    return json.loads(value, object_pairs_hook=_pairs,
                      parse_constant=lambda value: require(False, "nonfinite JSON: " + value))


def regular(path):
    path = Path(path).absolute()
    require(not any(p.is_symlink() for p in (path, *path.parents)), "symlink path")
    require(path.is_file(), "missing regular file: " + str(path))
    return path


def read_json(path, expected_sha=None):
    path = regular(path)
    before = sha256_file(path)
    if expected_sha is not None:
        require(before == hexsha(expected_sha), "file SHA differs: " + str(path))
    value = loads(path.read_text(encoding="utf-8"))
    require(before == sha256_file(path), "file changed while reading")
    return value


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def write_json(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


def external_output(path, inputs=(), allow_empty=False):
    path = Path(path).absolute()
    require(not any(p.is_symlink() for p in (path, *path.parents)), "aliased output")
    path = path.resolve()
    for source in (ROOT.parent, *[Path(p).resolve() for p in inputs]):
        require(not path.is_relative_to(source) and not source.is_relative_to(path), "output overlaps input/source")
    if path.exists():
        require(allow_empty and path.is_dir() and not any(path.iterdir()), "output must be fresh")
    else:
        path.mkdir(parents=False)
    return path


def image_path(root, relative):
    require(isinstance(relative, str) and relative and "\\" not in relative and ":" not in relative,
            "invalid image path")
    parts = PurePosixPath(relative)
    require(not parts.is_absolute() and all(p not in (".", "..") for p in relative.split("/"))
            and parts.as_posix() == relative, "image path escape")
    root = Path(root).absolute()
    require(root.is_dir() and not any(p.is_symlink() for p in (root, *root.parents)), "aliased image root")
    path = regular(root / relative)
    require(path.resolve().is_relative_to(root.resolve()), "image outside root")
    return path


def validate_inputs(questions_file, manifest_file, manifest_sha, images_root):
    questions = read_json(questions_file)
    keys(questions, {"schema", "dataset", "version", "split", "scope", "data"}, "questions")
    require({k: questions[k] for k in ("schema", "dataset", "version", "split", "scope")} == {
        "schema": "vlm-textvqa-questions-v1", "dataset": "TextVQA", "version": "0.5.1",
        "split": "val", "scope": "validation-subset"}, "wrong dataset/split/scope")
    rows = questions["data"]
    require(isinstance(rows, list) and len(rows) == 64, "requires 64 questions")
    manifest = read_json(manifest_file, manifest_sha)
    keys(manifest, {"schema", "questions_sha256", "question_ids", "question_count",
                    "source_annotations_sha256", "source_subset_sha256"}, "manifest")
    require(manifest["schema"] == "vlm-textvqa-input-manifest-v1", "manifest schema")
    require(manifest["source_annotations_sha256"] == ANNOTATIONS_SHA
            and manifest["source_subset_sha256"] == SUBSET_SHA, "source dataset pins")
    ids, images, paths = [], [], []
    from PIL import Image
    for row in rows:
        keys(row, ROW_KEYS, "question row")
        require(type(row["question_id"]) is int and row["question_id"] >= 0, "invalid question ID")
        ids.append(row["question_id"])
        images.append(text(row["image_id"]))
        text(row["question"])
        path = image_path(images_root, row["image_path"])
        paths.append(row["image_path"])
        require(path.stat().st_size == positive_int(row["image_bytes"]), "image size differs")
        require(sha256_file(path) == hexsha(row["image_sha256"]), "image SHA differs")
        with Image.open(path) as image:
            image.load()
            require(image.size == (positive_int(row["width"]), positive_int(row["height"])), "image dimensions differ")
    require(len(set(ids)) == len(set(images)) == len(set(paths)) == 64, "duplicate question/image")
    require(type(manifest["question_count"]) is int and manifest["question_count"] == 64
            and manifest["question_ids"] == ids
            and all(type(i) is int for i in manifest["question_ids"]), "ordered question IDs/count differ")
    require(manifest["questions_sha256"] == sha256_file(regular(questions_file)), "questions SHA differs")
    files = set()
    for path in Path(images_root).rglob("*"):
        require(not path.is_symlink(), "symlink image tree")
        if path.is_file():
            files.add(path.relative_to(images_root).as_posix())
    require(files == set(paths), "image root must contain only the 64 listed images")
    return rows, {"questions_sha256": manifest["questions_sha256"], "manifest_sha256": manifest_sha,
                  "source_annotations_sha256": ANNOTATIONS_SHA, "source_subset_sha256": SUBSET_SHA}


def validate_identity(identity):
    keys(identity, {"schema", "model_alias", "model_type", "template", "model_tree_sha256",
                    "adapter_tree_sha256", "training_manifest_sha256", "training_provenance_sha256", "source_tree_sha256",
                    "runtime_image", "api_evidence_sha256", "input_manifest_sha256",
                    "generation", "processor_env", "attn_impl", "model_kwargs"}, "identity")
    require(identity["schema"] == "vlm-textvqa-identity-v2", "identity schema")
    for key in ("model_alias", "model_type", "template"):
        text(identity[key])
    require(identity["model_alias"] in ("qwen3-vl", "gemma3", "internvl3_5",
                                       "llava-onevision1_5", "minicpmv4_6"), "unsupported registry alias")
    for key in ("model_tree_sha256", "source_tree_sha256", "api_evidence_sha256", "input_manifest_sha256"):
        hexsha(identity[key])
    for key in ("adapter_tree_sha256", "training_manifest_sha256", "training_provenance_sha256"):
        if identity[key] is not None:
            hexsha(identity[key])
    require((identity["adapter_tree_sha256"] is None) == (identity["training_manifest_sha256"] is None),
            "adapter requires its training input manifest SHA")
    require((identity["adapter_tree_sha256"] is None) == (identity["training_provenance_sha256"] is None),
            "adapter requires accepted training provenance")
    require(identity["model_type"] == REGISTRY[identity["model_alias"]][1], "registry model type differs")
    require(re.fullmatch(r"sha256:[0-9a-f]{64}", identity["runtime_image"] or ""), "image must be full ID")
    require(digest(identity["generation"]) == digest(GENERATION), "generation policy differs")
    require(isinstance(identity["processor_env"], dict)
            and set(identity["processor_env"]) <= {"MAX_PIXELS"}
            and all(isinstance(v, str) and v.isdecimal() and int(v) > 0
                    for v in identity["processor_env"].values()), "processor env policy")
    require(identity["attn_impl"] in (None, "eager", "sdpa"), "attention implementation")
    require(digest(identity["model_kwargs"]) in (digest({}), digest({"trust_remote_code": True})),
            "model kwargs policy")
    llava = identity["model_alias"] == "llava-onevision1_5"
    require(identity["attn_impl"] == ("eager" if llava else None)
            and digest(identity["model_kwargs"]) == digest({"trust_remote_code": True} if llava else {}),
            "registry identity loader policy differs")
    return identity


def prompt(row):
    return "<image>\n" + row["question"] + "\nAnswer the question using a short phrase."


def validate_allocator(value, peak=False):
    keys(value, {"requested_fraction", "actual_fraction", "total_memory", "peak_reserved"}, "allocator")
    total = positive_int(value["total_memory"])
    for field in ("requested_fraction", "actual_fraction"):
        number = value[field]
        require(type(number) in (float, int) and math.isfinite(number) and 0 < number <= 1, "allocator fraction")
    require(value["actual_fraction"] * total <= 75_000_000_000, "allocator exceeds budget")
    require(type(value["peak_reserved"]) is int and 0 <= value["peak_reserved"] <= 75_000_000_000,
            "allocator peak exceeds budget")
    if peak:
        require(value["peak_reserved"] > 0, "missing actual allocator peak")


def validate_predictions(rows, records):
    require(len(records) == len(rows) == 64, "incomplete predictions")
    for row, record in zip(rows, records):
        keys(record, {"question_id", "image_id", "answer", "request_sha256", "completion_tokens",
                      "prompt_tokens", "finish_reason", "forward"}, "prediction")
        require(type(record["question_id"]) is int and record["question_id"] == row["question_id"]
                and record["image_id"] == row["image_id"], "prediction order/identity differs")
        text(record["answer"])
        require(record["request_sha256"] == digest({"prompt": prompt(row), "image_sha256": row["image_sha256"]}),
                "request binding differs")
        require(positive_int(record["completion_tokens"]) <= GENERATION["max_tokens"], "completion tokens")
        positive_int(record["prompt_tokens"])
        require(record["finish_reason"] in ("stop", "length"), "incomplete response")
        forward = record["forward"]
        keys(forward, {"calls", "input_devices", "output_devices", "finite"}, "forward")
        positive_int(forward["calls"])
        require(forward["input_devices"] == forward["output_devices"] == ["mlu:0"]
                and forward["finite"] is True, "missing actual MLU forward witness")


def validate_execution(execution):
    keys(execution, {"run_id", "host", "host_label", "card", "uid", "lease_id", "lease_sha256",
                     "runner_sha256", "command_sha256"}, "execution")
    require(execution["host_label"] in ("mlu-10000", "mlu-10001")
            and execution["host"] == {"mlu-10000": "node1", "mlu-10001": "node2"}[execution["host_label"]],
            "execution host binding")
    text(execution["run_id"])
    text(execution["lease_id"])
    require(type(execution["card"]) is int and 0 <= execution["card"] < 8, "execution card")
    positive_int(execution["uid"])
    for field in ("lease_sha256", "runner_sha256", "command_sha256"):
        hexsha(execution[field])


def validate_run(run, identity, input_pins, records, rows):
    keys(run, {"schema", "status", "identity", "identity_sha256", "inputs", "api", "predictions_sha256",
               "question_ids", "question_count", "parameter_devices", "adapter_active",
               "allocator_before", "allocator_after", "claims", "execution", "execution_sha256",
               "owned_execution_accepted"}, "generation run")
    require(run["schema"] == "vlm-textvqa-generation-v2"
            and run["status"] == "diagnostic_completed", "run not completed")
    require(run["owned_execution_accepted"] is False, "generation cannot attest its own lease")
    require(digest(run["identity"]) == digest(identity) and digest(run["inputs"]) == digest(input_pins),
            "run identity/input mismatch")
    hexsha(run["identity_sha256"])
    hexsha(run["predictions_sha256"])
    require(run["question_ids"] == [r["question_id"] for r in rows]
            and all(type(qid) is int for qid in run["question_ids"])
            and type(run["question_count"]) is int and run["question_count"] == 64, "run ordered IDs/count")
    require(run["parameter_devices"] == ["mlu:0"] and run["adapter_active"] is
            (identity["adapter_tree_sha256"] is not None), "parameter/adapter evidence")
    validate_execution(run["execution"])
    hexsha(run["execution_sha256"])
    require(digest(run["claims"]) == digest(FALSE_CLAIMS), "unsupported acceptance claim")
    validate_allocator(run["allocator_before"])
    validate_allocator(run["allocator_after"], peak=True)
    validate_predictions(rows, records)
