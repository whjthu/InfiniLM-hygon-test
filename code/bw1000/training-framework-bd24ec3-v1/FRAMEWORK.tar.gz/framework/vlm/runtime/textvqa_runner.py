"""Verify the host controller against the reviewed release policy."""

from pathlib import Path
import json

from textvqa_contract import keys, read_json, regular, require, sha256_file, write_json


RELEASE_COMMIT = "fa7fa97c093fa136447b3555ca3d3af757b03dde"
RELEASE_FILES = {
    "__init__.py": "7e0bbab1296e6b90dd041a36b42d0b32364caaa70b74801df0e568d4b3f716dd",
    "lease.py": "9d238e2e0c05a27a0c8c83d5d706ff56fa1e2716f48a1b429007d048d411b8dc",
    "benchctl.py": "d0112069a978a4841bfb4a35bf55ca821d62354b53859c76bbf2bb9febb908ae",
}


def verified_files(runner_source):
    runner = regular(runner_source)
    require(runner.name == "benchctl.py" and runner.parent.name == "genmlu",
            "controller package layout differs")
    actual = {name: sha256_file(regular(runner.parent / name)) for name in RELEASE_FILES}
    require(actual == RELEASE_FILES, "controller is not the reviewed release")
    return runner, actual


def validate_deployment(path, expected_sha, runner_source):
    value = read_json(path, expected_sha)
    keys(value, {"schema", "release_commit", "runner_source", "import_root", "files"}, "controller deployment")
    runner, actual = verified_files(runner_source)
    require(value["schema"] == "textvqa-controller-deployment-v1"
            and value["release_commit"] == RELEASE_COMMIT
            and value["runner_source"] == str(runner)
            and value["import_root"] == str(runner.parents[1])
            and value["files"] == actual, "controller deployment differs")
    return value


def freeze_deployment(runner_source, output):
    runner, actual = verified_files(runner_source)
    target = Path(output).absolute()
    require(not any(p.is_symlink() for p in (target, *target.parents))
            and not target.resolve().is_relative_to(runner.parents[1]), "deployment output overlaps controller")
    write_json(target, {"schema": "textvqa-controller-deployment-v1", "release_commit": RELEASE_COMMIT,
                        "runner_source": str(runner), "import_root": str(runner.parents[1]), "files": actual})


def controller_bootstrap(import_root):
    root = Path(import_root).absolute()
    return "\n".join((
        "import sys, pathlib, hashlib, importlib",
        "root = pathlib.Path(" + json.dumps(str(root)) + ")",
        "expected = " + repr(RELEASE_FILES),
        "def checked(condition, message):",
        "    if not condition: raise SystemExit(message)",
        "checked(root.is_absolute() and {p.name for p in root.iterdir()} == {'genmlu'}, 'controller import root differs')",
        "for name, expected_sha in expected.items():",
        "    path = root / 'genmlu' / name",
        "    checked(not any(p.is_symlink() for p in (path, *path.parents)), 'aliased controller source')",
        "    checked(hashlib.sha256(path.read_bytes()).hexdigest() == expected_sha, 'controller source differs')",
        "sys.path.insert(0, str(root))",
        "for name, filename in (('genmlu', '__init__.py'), ('genmlu.lease', 'lease.py'), ('genmlu.benchctl', 'benchctl.py')):",
        "    module = importlib.import_module(name)",
        "    path = pathlib.Path(module.__file__)",
        "    checked(path == root / 'genmlu' / filename, 'controller module origin differs')",
        "    checked(hashlib.sha256(path.read_bytes()).hexdigest() == expected[filename], 'loaded controller source differs')",
        "sys.argv = ['genmlu.benchctl', *sys.argv[1:]]",
        "raise SystemExit(module.main())",
    ))


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runner-source", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    freeze_deployment(args.runner_source, args.out)
