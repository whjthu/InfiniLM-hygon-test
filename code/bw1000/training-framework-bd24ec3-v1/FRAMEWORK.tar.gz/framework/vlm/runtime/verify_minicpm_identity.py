#!/usr/bin/env python3
"""Freeze or verify MiniCPM wrapper and model-weight identity for comparisons."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MODEL_DIRECTORY = "MiniCPM-V-4.6"
REQUIRED_SOURCE_FILES = (
    "runtime/common.sh",
    "runtime/minicpm_sft_preset.sh",
    "runtime/model_registry.sh",
    "runtime/verify_minicpm_identity.py",
    "scripts/train_sft.sh",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def tree_sha256(root: Path) -> str:
    """Hash regular files by relative path and content digest, rejecting aliases."""
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix()):
        if path.is_symlink():
            raise ValueError(f"model tree must not contain symlinks: {path}")
        if not path.is_file():
            continue
        relative = path.relative_to(root).as_posix().encode("utf-8")
        digest.update(relative)
        digest.update(b"\0")
        digest.update(sha256_file(path).encode("ascii"))
        digest.update(b"\n")
    return digest.hexdigest()


def load_object(path: Path, label: str) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot read {label}: {path}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"{label} must be a JSON object")
    return value


def wrapper_file_hashes(root: Path) -> dict[str, str]:
    hashes = {}
    for relative in REQUIRED_SOURCE_FILES:
        path = root / relative
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"required MiniCPM wrapper file is missing or aliased: {relative}")
        hashes[relative] = sha256_file(path)
    return hashes


def build_manifest(model_path: Path) -> dict:
    if model_path.name != MODEL_DIRECTORY:
        raise ValueError("MiniCPM model directory does not match the strict comparison contract")
    model_config = model_path / "config.json"
    if not model_config.is_file() or model_config.is_symlink():
        raise ValueError("MiniCPM model must contain a regular config.json")
    return {
        "schema_version": 1,
        "scope": "minicpm_wrapper_and_model_weights_only",
        "wrapper_files": wrapper_file_hashes(ROOT),
        "model": {
            "directory": MODEL_DIRECTORY,
            "config_sha256": sha256_file(model_config),
            "tree_sha256": tree_sha256(model_path),
        },
    }


def write_manifest(model_path: Path, manifest_path: Path) -> None:
    model_root = model_path.resolve(strict=True)
    manifest_path = manifest_path.resolve(strict=False)
    try:
        manifest_path.relative_to(model_root)
    except ValueError:
        pass
    else:
        raise ValueError("manifest path must be outside the MiniCPM model tree")
    if not manifest_path.parent.is_dir():
        raise ValueError(f"manifest parent directory does not exist: {manifest_path.parent}")
    payload = build_manifest(model_root)
    with manifest_path.open("x", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")


def verify(model_path: Path, manifest_path: Path) -> None:
    manifest = load_object(manifest_path, "MiniCPM wrapper-and-weights manifest")
    if manifest.get("schema_version") != 1:
        raise ValueError("MiniCPM wrapper-and-weights manifest must use schema_version 1")
    if manifest.get("scope") != "minicpm_wrapper_and_model_weights_only":
        raise ValueError("MiniCPM manifest scope is not wrapper and model weights only")

    expected_wrappers = manifest.get("wrapper_files")
    if not isinstance(expected_wrappers, dict) or set(expected_wrappers) != set(REQUIRED_SOURCE_FILES):
        raise ValueError("MiniCPM manifest must pin exactly the required wrapper files")
    if expected_wrappers != wrapper_file_hashes(ROOT):
        raise ValueError("MiniCPM wrapper identity differs from the manifest")

    expected = build_manifest(model_path)["model"]
    model = manifest.get("model")
    if not isinstance(model, dict) or model.get("directory") != MODEL_DIRECTORY:
        raise ValueError("MiniCPM manifest has an unexpected model directory")
    if model.get("config_sha256") != expected["config_sha256"]:
        raise ValueError("MiniCPM config.json digest differs from the manifest")
    if model.get("tree_sha256") != expected["tree_sha256"]:
        raise ValueError("MiniCPM model-tree digest differs from the manifest")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-path", type=Path, required=True)
    operation = parser.add_mutually_exclusive_group(required=True)
    operation.add_argument("--manifest", type=Path, help="existing manifest to verify")
    operation.add_argument("--write-manifest", type=Path, help="new manifest path to create exclusively")
    args = parser.parse_args()
    try:
        model_path = args.model_path.resolve(strict=True)
        if args.write_manifest:
            write_manifest(model_path, args.write_manifest)
        else:
            verify(model_path, args.manifest.resolve(strict=True))
    except (OSError, ValueError) as exc:
        print(f"MiniCPM identity verification failed: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
