#!/usr/bin/env bash

MODELS_DIR=${MODELS_DIR:-/mnt/models}
MODEL_EXTRA_ARGS=()

load_model() {
  local key=${1:?model key is required}
  MODEL_EXTRA_ARGS=()

  case "${key}" in
    qwen|qwen3|qwen3-vl)
      MODEL_ALIAS=qwen3-vl
      MODEL_PATH="${MODELS_DIR}/Qwen3-VL-8B-Instruct"
      MODEL_TYPE=qwen3_vl
      ;;
    gemma|gemma3|gemma3-vl)
      MODEL_ALIAS=gemma3
      MODEL_PATH="${MODELS_DIR}/gemma-3-4b-it"
      MODEL_TYPE=gemma3_vision
      ;;
    internvl|internvl3|internvl3_5)
      MODEL_ALIAS=internvl3_5
      MODEL_PATH="${MODELS_DIR}/InternVL3_5-8B-HF"
      MODEL_TYPE=internvl
      ;;
    llava|llava-onevision)
      MODEL_ALIAS=llava-onevision1_5
      MODEL_PATH="${MODELS_DIR}/LLaVA-OneVision-1.5-8B-Instruct"
      MODEL_TYPE=llava_onevision1_5
      local root
      root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
      MODEL_EXTRA_ARGS=(
        --attn_impl eager
        --model_kwargs '{"trust_remote_code": true}'
        --external_plugins "${root}/plugins/llava_onevision.py"
      )
      ;;
    minicpm|minicpmv|minicpmv4_6)
      MODEL_ALIAS=minicpmv4_6
      MODEL_PATH="${MODELS_DIR}/MiniCPM-V-4.6"
      MODEL_TYPE=minicpmv4_6
      ;;
    *)
      echo "Unknown model key: ${key}. Valid keys: qwen, gemma, internvl, llava, minicpm" >&2
      return 2
      ;;
  esac

  [[ -d "${MODEL_PATH}" ]] || { echo "Model path does not exist: ${MODEL_PATH}" >&2; return 2; }
}
