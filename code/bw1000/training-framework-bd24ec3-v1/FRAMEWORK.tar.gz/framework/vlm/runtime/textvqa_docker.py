"""Narrow GT-free Docker command for TextVQA, independent of the SFT data mount."""

from __future__ import annotations

from pathlib import Path
import os
import re
import socket
import subprocess
import sys

from textvqa_contract import ROOT, digest, external_output, read_json, regular, require, sha256_file, tree_sha256, validate_identity, validate_inputs, write_json, registry_policy


def own_lease(args, proc_root=Path("/proc")):
    from textvqa_runner import validate_deployment, controller_bootstrap
    deployment = validate_deployment(args.runner_deployment, args.runner_deployment_sha256, args.runner_source)
    require(args.host_label == "mlu-10000", "this evaluation launcher currently supports the main host only")
    root = Path(args.lease_root)
    lease_file = regular(root / "lease.json")
    active_file = regular(root.parent / ".leases" / ("cards-" + str(args.physical_card) + ".json"))
    lease, active = read_json(lease_file), read_json(active_file)
    require(all(type(value.get("schema_version")) is int and value["schema_version"] == 2
                for value in (lease, active)), "lease schema differs")
    fields = ("lease_id", "pid", "host", "host_label", "run_id", "cards", "project",
              "requested_command", "command")
    require(all(active.get(k) == lease.get(k) for k in fields)
            and all(v.get("state") in ("starting", "running") and v.get("returncode") is None
                    for v in (lease, active)), "active own lease required")
    require(isinstance(lease.get("lease_id"), str) and re.fullmatch(r"[0-9a-f]{32}", lease["lease_id"])
            and os.environ.get("GENMLU_LEASE_ID") == lease["lease_id"]
            and os.environ.get("GENMLU_RUN_ID") == root.name
            and lease.get("container_lease_label_required") is True
            and lease["run_id"] == root.name
            and args.container_name in (root.name, "genmlu-" + root.name)
            and lease["host"] == socket.gethostname().split(".")[0]
            and lease["host_label"] == args.host_label
            and lease["cards"] == [args.physical_card] and type(lease["cards"][0]) is int
            and lease["project"] == "generative-mlu", "lease host/run/card mismatch")
    require(root.parent.name == args.host_label and root.parent.parent.name == "generative-mlu",
            "lease output namespace mismatch")
    require(args.host_label in ("mlu-10000", "mlu-10001") and lease["host"] ==
            {"mlu-10000": "node1", "mlu-10001": "node2"}[args.host_label], "physical host binding")
    require(os.getuid() == args.uid and all(p.stat().st_uid == args.uid for p in (root, lease_file, active_file)),
            "lease UID mismatch")
    pid = lease["pid"]
    require(type(pid) is int and pid > 1 and pid == os.getppid(), "lease must own direct parent")
    parent = proc_root / str(pid)
    require(parent.stat().st_uid == args.uid, "parent owner mismatch")
    status = dict(line.split(":", 1) for line in (parent / "status").read_text().splitlines() if ":" in line)
    require(status["Uid"].split() == [str(args.uid)] * 4
            and not status["State"].strip().startswith("Z"), "parent UID/state mismatch")
    require(sha256_file(regular(args.runner_source)) == args.runner_sha256
            and Path(args.runner_source).name == "benchctl.py", "runner source SHA mismatch")
    argv = (parent / "cmdline").read_bytes().rstrip(b"\0").decode().split("\0")
    require(argv[1:5] == ["-I", "-S", "-B", "-c"]
            and argv[5] == controller_bootstrap(deployment["import_root"])
            and os.readlink(parent / "cwd") == deployment["import_root"], "parent controller origin differs")
    module_args = argv[6:]
    require(Path(argv[0]).name == "python3"
            and module_args.count("run") == 1 and "--" in module_args, "parent runner command")
    options = module_args[:module_args.index("--")]
    for flag, value in (("--run-id", root.name), ("--host-label", args.host_label),
                        ("--cards", str(args.physical_card)), ("--project", "generative-mlu"),
                        ("--output-root", str(root.parents[2])), ("--container-name", args.container_name),
                        ("--sample-interval", "300"), ("--watch-interval", "15"),
                        ("--timeout-seconds", "3600")):
        require(options.count(flag) == 1 and options[options.index(flag) + 1] == value,
                "parent runner option differs: " + flag)
    environment = (parent / "environ").read_bytes().split(b"\0")
    require(("PYTHONPATH=" + str(Path(args.runner_source).parents[1])).encode() in environment,
            "parent runner import path mismatch")
    child = lease["command"]
    require(isinstance(child, list) and child == lease["requested_command"] and len(child) > 2,
            "lease child command mismatch")
    require(module_args[module_args.index("--") + 1:] == child, "parent actual child differs from lease")
    if Path(child[0]).name == "python3":
        actual = child[2:] if child[1:2] == ["-B"] else child[1:]
        require(actual == sys.argv, "Python child argv differs")
    else:
        require(child[:2] == ["bash", str(ROOT / "scripts/eval_textvqa.sh")] and child[3] == "docker",
                "unsupported lease child")
        prefix = ["docker", "--model", args.model, "--model-alias", args.model_alias, "--model-type", args.model_type]
        if args.external_plugins:
            prefix += ["--attn_impl", args.attn_impl, "--model_kwargs", args.model_kwargs,
                       "--external_plugins", args.external_plugins]
        require(prefix + child[4:] == sys.argv[1:], "registry-transformed child argv differs")
    os.kill(pid, 0)
    require(os.getpgid(0) == os.getpid()
            and (lease["state"] != "running" or lease.get("child_pgid") == os.getpid()), "owned child group")
    require(Path(args.out).absolute() == root.absolute() / "generation", "output must be own lease/generation")
    return {"run_id": root.name, "host": lease["host"], "host_label": args.host_label,
            "card": args.physical_card, "uid": args.uid, "lease_id": lease["lease_id"],
            "lease_sha256": sha256_file(lease_file), "runner_sha256": args.runner_sha256,
            "command_sha256": digest(child)}


def command(args, lease_id):
    require(isinstance(lease_id, str) and re.fullmatch(r"[0-9a-f]{32}", lease_id), "invalid controller nonce")
    identity = validate_identity(read_json(args.identity, args.identity_sha256))
    registry_policy(args, identity["template"], read_json(args.api_evidence, identity["api_evidence_sha256"]))
    from textvqa_generate import bound_training
    bound_training(args, identity)
    require(args.runtime_image == identity["runtime_image"], "Docker image identity mismatch")
    require(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,100}", args.container_name or ""), "container name")
    require(type(args.physical_card) is int and 0 <= args.physical_card < 8, "physical card")
    require(type(args.uid) is int and args.uid > 0 and type(args.gid) is int and args.gid > 0, "UID/GID")
    readonly = [ROOT, Path(args.model), regular(args.questions), regular(args.manifest),
                Path(args.images_root), regular(args.identity), regular(args.api_evidence)]
    if args.adapter:
        readonly.append(Path(args.adapter))
        readonly.append(regular(args.training_manifest))
    for path in readonly:
        require(path.is_absolute() and path.exists() and "," not in str(path)
                and not any(p.is_symlink() for p in (path, *path.parents)), "invalid read-only mount")
    output = Path(args.out).absolute()
    for path in readonly:
        require(not output.resolve().is_relative_to(path.resolve())
                and not path.resolve().is_relative_to(output.resolve()), "output overlaps mount")
    argv = ["docker", "run", "--rm", "--pull", "never", "--runtime", "runc",
            "--name", args.container_name, "--label", "genmlu.run_id=" + Path(args.lease_root).name,
            "--label", "genmlu.lease_id=" + lease_id,
            "--network", "none", "--ipc", "private", "--shm-size", "2g", "--memory", "80g",
            "--memory-swap", "80g", "--cpus", "4", "--pids-limit", "512",
            "--user", str(args.uid) + ":" + str(args.gid), "--read-only", "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges", "--tmpfs", "/tmp:rw,exec,nosuid,nodev,size=2g",
            "--entrypoint", "python3", "--workdir", str(ROOT)]
    # The isolated physical card is enumerated as logical device 0 in the container.
    for key, value in {"MLU_VISIBLE_DEVICES": "0",
                       "CNRT_VISIBLE_DEVICES": "0",
                       "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
                       "HF_HOME": "/tmp/hf", "HOME": "/tmp", "PYTHONDONTWRITEBYTECODE": "1",
                       "USER": "whj", "LOGNAME": "whj", "TORCH_DEVICE_BACKEND_AUTOLOAD": "0",
                       "TRITON_CACHE_DIR": "/tmp/triton", "OMP_NUM_THREADS": "1",
                       "MKL_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1",
                       "TOKENIZERS_PARALLELISM": "false", "CUDA_VISIBLE_DEVICES": "",
                       "MODELS_DIR": str(Path(args.model).parent)}.items():
        argv += ["--env", key + "=" + value]
    for path in readonly:
        argv += ["--mount", "type=bind,source=" + str(path) + ",target=" + str(path) + ",readonly"]
    argv += ["--mount", "type=bind,source=" + str(output) + ",target=" + str(output)]
    devices = ["/dev/cambricon_dev" + str(args.physical_card), "/dev/cambricon_ctl",
               "/dev/cambricon_ipcm" + str(args.physical_card), "/dev/cambricon_gdr"]
    for path in devices:
        argv += ["--device", path]
    argv += [args.runtime_image, "-B", str(ROOT / "runtime/textvqa_generate.py"), "generate"]
    for flag in ("model", "model_alias", "model_type", "questions", "manifest", "manifest_sha256", "images_root",
                 "api_evidence", "runtime_image", "out", "identity", "identity_sha256", "adapter",
                 "attn_impl", "model_kwargs", "external_plugins", "training_manifest", "training_manifest_sha256"):
        value = getattr(args, flag, None)
        if value is not None:
            option = "--" + (flag if flag in ("attn_impl", "model_kwargs", "external_plugins")
                            else flag.replace("_", "-"))
            argv += [option, str(value)]
    return argv


def launch(args):
    validate_inputs(args.questions, args.manifest, args.manifest_sha256, args.images_root)
    receipt = own_lease(args)
    identity = validate_identity(read_json(args.identity, args.identity_sha256))
    require(tree_sha256(ROOT) == identity["source_tree_sha256"]
            and tree_sha256(Path(args.model)) == identity["model_tree_sha256"], "host source/model identity differs")
    require((args.adapter is None) == (identity["adapter_tree_sha256"] is None), "host adapter mode differs")
    if args.adapter:
        require(tree_sha256(Path(args.adapter)) == identity["adapter_tree_sha256"], "host adapter identity differs")
    argv = command(args, receipt["lease_id"])
    actual = subprocess.run(["docker", "image", "inspect", "--format", "{{.Id}}", args.runtime_image],
                            check=True, text=True, capture_output=True, timeout=30).stdout.strip()
    require(actual == args.runtime_image, "actual Docker image ID differs")
    for index, item in enumerate(argv):
        if item == "--device":
            require(Path(argv[index + 1]).exists(), "missing device node")
    external_output(args.out, (ROOT, args.model, args.images_root, args.questions, args.manifest,
                               args.identity, args.api_evidence, *([args.adapter] if args.adapter else [])))
    write_json(Path(args.out) / "execution.json", receipt)
    argv += ["--execution-evidence", str(Path(args.out) / "execution.json"),
             "--execution-sha256", sha256_file(Path(args.out) / "execution.json")]
    subprocess.run(argv, check=True)
