The unmodified `mmf_m4c_evaluators.py` comes from Facebook Research MMF:
https://github.com/facebookresearch/mmf/blob/72f898ec35af86567423c7a019dd1dc5175d1a5a/mmf/utils/m4c_evaluators.py

Upstream commit: `72f898ec35af86567423c7a019dd1dc5175d1a5a`.
Source SHA256: `e10a99e15c4658f8d0d83a05cc536c835922e701171fce0016718bec021b8c0a`.
License SHA256: `dbb40c7bb9a3de99f13fe5643fbdaa0ae90a1591c232f1b316e0528a835776c9`.
Copyright (c) Facebook, Inc. and its affiliates. All rights reserved.
The complete upstream BSD license is retained in `MMF-LICENSE.txt`.

TextVQA data is obtained separately, not distributed in this repository.
Dataset attribution: TextVQA, https://textvqa.org/dataset/ (CC BY 4.0).
Retain the downloaded dataset's notices and image-source/rights metadata.
This entry point evaluates a frozen validation subset, not the full benchmark.
