#!/usr/bin/env bash

set -euo pipefail

runtime_dir() {
  cd "$(dirname "${BASH_SOURCE[0]}")" && pwd
}

repo_root() {
  cd "$(runtime_dir)/.." && pwd
}

monorepo_root() {
  cd "$(repo_root)/.." && pwd
}

resolve_resume_output_path() {
  local path=${1:?path is required}
  local parent component
  local -a missing_components=()
  path=$(realpath -m -- "${path}") || {
    echo "Cannot resolve path: ${1}" >&2
    return 2
  }
  while [[ ! -e "${path}" ]]; do
    [[ ! -L "${path}" ]] || {
      echo "Cannot resolve broken symlink path: ${1}" >&2
      return 2
    }
    component=$(basename "${path}")
    parent=$(dirname "${path}")
    [[ "${parent}" != "${path}" ]] || {
      echo "Cannot resolve path: ${1}" >&2
      return 2
    }
    missing_components=("${component}" "${missing_components[@]}")
    path=${parent}
  done
  path=$(realpath -e -- "${path}") || {
    echo "Cannot resolve path: ${1}" >&2
    return 2
  }
  for component in "${missing_components[@]}"; do
    path="${path}/${component}"
  done
  printf '%s\n' "${path}"
}

require_external_output_dir() {
  local output_dir=${1:?output directory is required}
  local root first_entry
  root=$(monorepo_root)
  local normalized_output normalized_root
  normalized_output=$(realpath -m "${output_dir}")
  normalized_root=$(realpath -m "${root}")
  if [[ "${normalized_output}" == "${normalized_root}" || "${normalized_output}" == "${normalized_root}/"* ]]; then
    echo "OUTPUT_DIR must be outside the source tree: ${output_dir}" >&2
    return 2
  fi
  if [[ -e "${normalized_output}" ]]; then
    [[ -d "${normalized_output}" ]] || { echo "OUTPUT_DIR exists but is not a directory: ${output_dir}" >&2; return 2; }
    if ! first_entry=$(find "${normalized_output}" -mindepth 1 -maxdepth 1 -print -quit); then
      echo "Cannot inspect OUTPUT_DIR for overwrite safety: ${output_dir}" >&2
      return 2
    fi
    if [[ -n "${first_entry}" ]]; then
      echo "OUTPUT_DIR already exists and is not empty: ${output_dir}" >&2
      return 2
    fi
  fi
}

paths_overlap() {
  local first=${1:?first path is required}
  local second=${2:?second path is required}
  [[ "${first}" == "${second}" || "${first}" == "${second}/"* || "${second}" == "${first}/"* ]]
}

resolve_resume_checkpoint() {
  local checkpoint=${1:?resume checkpoint is required}
  local expected_processes=${2:?expected process count is required}
  local normalized_checkpoint
  local rank
  local -a rng_state_files=()
  [[ "${expected_processes}" =~ ^[1-9][0-9]*$ ]] || {
    echo "Expected process count must be a positive integer: ${expected_processes}" >&2
    return 2
  }
  [[ "${checkpoint}" == /* ]] || {
    echo "RESUME_FROM_CHECKPOINT must be an absolute path: ${checkpoint}" >&2
    return 2
  }
  normalized_checkpoint=$(realpath -e -- "${checkpoint}") || {
    echo "RESUME_FROM_CHECKPOINT does not exist: ${checkpoint}" >&2
    return 2
  }
  [[ -d "${normalized_checkpoint}" ]] || {
    echo "RESUME_FROM_CHECKPOINT must be a directory: ${checkpoint}" >&2
    return 2
  }
  [[ "$(basename "${normalized_checkpoint}")" =~ ^checkpoint-[1-9][0-9]*$ ]] || {
    echo "RESUME_FROM_CHECKPOINT must name an exact checkpoint-N directory: ${checkpoint}" >&2
    return 2
  }
  [[ -f "${normalized_checkpoint}/trainer_state.json" ]] || {
    echo "RESUME_FROM_CHECKPOINT lacks trainer_state.json: ${checkpoint}" >&2
    return 2
  }
  [[ -f "${normalized_checkpoint}/adapter_model.safetensors" ]] || {
    echo "RESUME_FROM_CHECKPOINT lacks adapter_model.safetensors: ${checkpoint}" >&2
    return 2
  }
  [[ -f "${normalized_checkpoint}/optimizer.pt" ]] || {
    echo "RESUME_FROM_CHECKPOINT lacks optimizer.pt; weights-only checkpoints cannot be resumed: ${checkpoint}" >&2
    return 2
  }
  [[ -f "${normalized_checkpoint}/scheduler.pt" ]] || {
    echo "RESUME_FROM_CHECKPOINT lacks scheduler.pt; weights-only checkpoints cannot be resumed: ${checkpoint}" >&2
    return 2
  }
  if ((expected_processes == 1)); then
    [[ -f "${normalized_checkpoint}/rng_state.pth" ]] || {
      echo "RESUME_FROM_CHECKPOINT lacks rng_state.pth for a single process: ${checkpoint}" >&2
      return 2
    }
    compgen -G "${normalized_checkpoint}/rng_state_*.pth" >/dev/null && {
      echo "RESUME_FROM_CHECKPOINT mixes single-process and rank-indexed RNG state: ${checkpoint}" >&2
      return 2
    }
  else
    [[ ! -f "${normalized_checkpoint}/rng_state.pth" ]] || {
      echo "RESUME_FROM_CHECKPOINT requires rank-indexed RNG state for ${expected_processes} processes: ${checkpoint}" >&2
      return 2
    }
    for ((rank = 0; rank < expected_processes; rank++)); do
      [[ -f "${normalized_checkpoint}/rng_state_${rank}.pth" ]] || {
        echo "RESUME_FROM_CHECKPOINT lacks rng_state_${rank}.pth for ${expected_processes} processes: ${checkpoint}" >&2
        return 2
      }
    done
    mapfile -t rng_state_files < <(compgen -G "${normalized_checkpoint}/rng_state_*.pth" || true)
    ((${#rng_state_files[@]} == expected_processes)) || {
      echo "RESUME_FROM_CHECKPOINT RNG state count does not match ${expected_processes} processes: ${checkpoint}" >&2
      return 2
    }
  fi
  printf '%s\n' "${normalized_checkpoint}"
}

require_separate_resume_output_dir() {
  local output_dir=${1:?output directory is required}
  local checkpoint_dir=${2:?resume checkpoint is required}
  local normalized_output
  normalized_output=$(resolve_resume_output_path "${output_dir}")
  if paths_overlap "${normalized_output}" "${checkpoint_dir}"; then
    echo "OUTPUT_DIR must be a separate new run directory, not the resume checkpoint or its parent: ${output_dir}" >&2
    return 2
  fi
}

prepare_external_run_dir() {
  local output_dir=${1:?output directory is required}
  shift
  local normalized_output normalized_input
  [[ "${output_dir}" == /* ]] || { echo "OUTPUT_DIR must be an absolute path: ${output_dir}" >&2; return 2; }
  require_external_output_dir "${output_dir}" || return
  normalized_output=$(realpath -m "${output_dir}")
  for normalized_input in "$@"; do
    normalized_input=$(realpath -m "${normalized_input}")
    if paths_overlap "${normalized_output}" "${normalized_input}"; then
      echo "OUTPUT_DIR overlaps a read-only input path: ${output_dir}" >&2
      return 2
    fi
  done
  [[ ! -e "${normalized_output}" ]] || { echo "OUTPUT_DIR must be a new dedicated run directory: ${output_dir}" >&2; return 2; }
  mkdir -- "${normalized_output}" || { echo "Cannot create dedicated OUTPUT_DIR: ${output_dir}" >&2; return 2; }
  [[ "$(realpath -e "${normalized_output}")" == "${normalized_output}" ]] || {
    echo "OUTPUT_DIR changed while being created: ${output_dir}" >&2
    return 2
  }
  printf '%s\n' "${normalized_output}"
}

validate_sft_tuning_args() {
  [[ ! -v RAY_SWIFT_ARGS && ! -v SWIFT_ARGS && ! -v SWIFT_SFT_ARGS ]] || {
    echo "Environment-provided Swift argv is not allowed for this entry point" >&2
    return 2
  }

  local argument option value
  while (($#)); do
    argument=$1
    case "${argument}" in
      --learning_rate|--warmup_ratio|--weight_decay|--lr_scheduler_type|--num_train_epochs|--max_steps|--per_device_train_batch_size|--gradient_accumulation_steps|--gradient_checkpointing|--freeze_vit|--max_length|--max_pixels|--logging_steps|--save_steps|--save_total_limit|--dataloader_num_workers|--report_to|--torch_dtype|--tuner_type|--target_modules|--lora_rank|--lora_alpha|--lora_dropout|--val_dataset|--seed|--eval_strategy|--save_strategy|--run_name)
        (($# >= 2)) || { echo "Missing value for allowed SFT option: ${argument}" >&2; return 2; }
        value=$2
        [[ "${value}" != --* ]] || { echo "Missing value for allowed SFT option: ${argument}" >&2; return 2; }
        shift 2
        ;;
      --learning_rate=*|--warmup_ratio=*|--weight_decay=*|--lr_scheduler_type=*|--num_train_epochs=*|--max_steps=*|--per_device_train_batch_size=*|--gradient_accumulation_steps=*|--gradient_checkpointing=*|--freeze_vit=*|--max_length=*|--max_pixels=*|--logging_steps=*|--save_steps=*|--save_total_limit=*|--dataloader_num_workers=*|--report_to=*|--torch_dtype=*|--tuner_type=*|--target_modules=*|--lora_rank=*|--lora_alpha=*|--lora_dropout=*|--val_dataset=*|--seed=*|--eval_strategy=*|--save_strategy=*|--run_name=*)
        option=${argument%%=*}
        value=${argument#*=}
        [[ -n "${value}" ]] || { echo "Missing value for allowed SFT option: ${option}" >&2; return 2; }
        shift
        ;;
      *)
        echo "Unsupported extra SFT option: ${argument}" >&2
        return 2
        ;;
    esac
  done
}

validate_visible_devices() {
  local devices=${1:?device list is required}
  local compact=${devices//[[:space:]]/}
  [[ -n "${compact}" ]] || { echo "MLU_VISIBLE_DEVICES must not be empty" >&2; return 2; }
  if [[ "${compact}" =~ (^,|,$|,,) ]]; then
    echo "MLU_VISIBLE_DEVICES must not contain empty device items" >&2
    return 2
  fi
  local old_ifs=${IFS}
  local -a values
  IFS=',' read -r -a values <<< "${compact}"
  IFS=${old_ifs}
  local value
  declare -A seen=()
  for value in "${values[@]}"; do
    [[ "${value}" =~ ^[0-9]+$ ]] || { echo "MLU_VISIBLE_DEVICES contains an invalid device: ${value:-<empty>}" >&2; return 2; }
    [[ -z "${seen[${value}]:-}" ]] || { echo "MLU_VISIBLE_DEVICES contains a duplicate device: ${value}" >&2; return 2; }
    seen[${value}]=1
  done
}

count_visible_devices() {
  local devices=${1:?device list is required}
  validate_visible_devices "${devices}" || return
  local compact=${devices//[[:space:]]/}
  local old_ifs=${IFS}
  local -a values
  IFS=',' read -r -a values <<< "${compact}"
  IFS=${old_ifs}
  printf '%s\n' "${#values[@]}"
}
