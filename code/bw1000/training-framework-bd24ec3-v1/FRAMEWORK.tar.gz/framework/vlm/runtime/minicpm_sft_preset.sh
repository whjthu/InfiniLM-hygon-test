#!/usr/bin/env bash

MINICPM_SFT_PRESET_NAME=qualified-gc-25

minicpm_sft_preset_enabled() {
  [[ -v MINICPM_SFT_PRESET ]]
}

validate_minicpm_sft_preset_environment() {
  [[ "${MINICPM_SFT_PRESET}" == "${MINICPM_SFT_PRESET_NAME}" ]] || {
    echo "Unknown MINICPM_SFT_PRESET: ${MINICPM_SFT_PRESET}. Expected ${MINICPM_SFT_PRESET_NAME}." >&2
    return 2
  }
  [[ -z "${RESUME_FROM_CHECKPOINT:-}" ]] || {
    echo "RESUME_FROM_CHECKPOINT is not supported by ${MINICPM_SFT_PRESET_NAME}." >&2
    return 2
  }

  local gc=${MINICPM_PRESET_GRADIENT_CHECKPOINTING-false}
  [[ "${gc}" == true || "${gc}" == false ]] || {
    echo "MINICPM_PRESET_GRADIENT_CHECKPOINTING must be exactly true or false." >&2
    return 2
  }

  [[ ! -v NNODES || "${NNODES}" == 1 ]] || {
    echo "${MINICPM_SFT_PRESET_NAME} requires NNODES=1 when NNODES is set." >&2
    return 2
  }
  [[ ! -v NODE_RANK || "${NODE_RANK}" == 0 ]] || {
    echo "${MINICPM_SFT_PRESET_NAME} requires NODE_RANK=0 when NODE_RANK is set." >&2
    return 2
  }

  local name
  for name in WORLD_SIZE RANK LOCAL_RANK LOCAL_WORLD_SIZE; do
    [[ ! -v "${name}" ]] || {
      echo "${name} must be unset before launching ${MINICPM_SFT_PRESET_NAME}." >&2
      return 2
    }
  done

  for name in VAL_DATASET NUM_TRAIN_EPOCHS WARMUP_RATIO GRADIENT_CHECKPOINTING \
    AVERAGE_TOKENS_ACROSS_DEVICES RAY_SWIFT_ARGS SWIFT_ARGS SWIFT_SFT_ARGS; do
    [[ ! -v "${name}" ]] || {
      echo "${name} cannot override the ${MINICPM_SFT_PRESET_NAME} workload." >&2
      return 2
    }
  done

  local -A fixed=(
    [MAX_STEPS]=25 [SAVE_STEPS]=10 [SAVE_TOTAL_LIMIT]=3 [LOGGING_STEPS]=1 [REPORT_TO]=none
    [MAX_LENGTH]=4096 [MAX_PIXELS]=262144 [PER_DEVICE_TRAIN_BATCH_SIZE]=1
    [GRADIENT_ACCUMULATION_STEPS]=4 [LEARNING_RATE]=0.0001 [WARMUP_STEPS]=5
    [MAX_GRAD_NORM]=1.0 [FREEZE_VIT]=true [FREEZE_ALIGNER]=true [FREEZE_LLM]=false
    [VIT_GRADIENT_CHECKPOINTING]=false [DATALOADER_NUM_WORKERS]=4 [TUNER_TYPE]=lora
    [TARGET_MODULES]=all-linear [LORA_RANK]=16 [LORA_ALPHA]=32 [LORA_DROPOUT]=0.05
    [TORCH_DTYPE]=bfloat16 [SPLIT_DATASET_RATIO]=0.0 [DATA_SEED]=42
    [LR_SCHEDULER_TYPE]=cosine [OPTIM]=adamw_torch [ADAM_BETA1]=0.9 [ADAM_BETA2]=0.95
    [ADAM_EPSILON]=1e-08 [WEIGHT_DECAY]=0.1 [SEED]=42 [DATASET_SHUFFLE]=true
    [DATALOADER_DROP_LAST]=false [PACKING]=false [PADDING_FREE]=false [PADDING_SIDE]=right
    [TEMPLATE]=minicpmv4_6 [ADD_VERSION]=false [SAVE_STRATEGY]=steps
  )
  for name in "${!fixed[@]}"; do
    [[ ! -v "${name}" || "${!name}" == "${fixed[${name}]}" ]] || {
      echo "${name} differs from the ${MINICPM_SFT_PRESET_NAME} workload." >&2
      return 2
    }
  done
}

validate_minicpm_sft_preset() {
  local model_alias=${1:?model alias is required}
  local visible_device_count=${2:?visible device count is required}
  local process_count=${3:?process count is required}
  shift 3

  validate_minicpm_sft_preset_environment
  [[ "${model_alias}" == minicpmv4_6 ]] || {
    echo "${MINICPM_SFT_PRESET_NAME} is available only for MiniCPM-V 4.6." >&2
    return 2
  }
  (($# == 0)) || {
    echo "${MINICPM_SFT_PRESET_NAME} does not accept extra Swift arguments." >&2
    return 2
  }
  [[ "${visible_device_count}" == 8 && "${process_count}" == 8 ]] || {
    echo "${MINICPM_SFT_PRESET_NAME} requires exactly eight visible devices and eight processes." >&2
    return 2
  }
}

build_minicpm_sft_preset_command() {
  local gc=${MINICPM_PRESET_GRADIENT_CHECKPOINTING-false}
  export NNODES=1
  export NODE_RANK=0
  cmd=(
    swift sft
    --model "${MODEL_PATH}"
    --model_type minicpmv4_6
    --template minicpmv4_6
    --dataset "${DATASET}"
    --output_dir "${OUTPUT_DIR}"
    --add_version false
    --no_check_model
    --torch_dtype bfloat16
    --max_length 4096
    --max_pixels 262144
    --tuner_type lora
    --target_modules all-linear
    --lora_rank 16
    --lora_alpha 32
    --lora_dropout 0.05
    --per_device_train_batch_size 1
    --gradient_accumulation_steps 4
    --learning_rate 0.0001
    --max_grad_norm 1.0
    --warmup_steps 5
    --lr_scheduler_type cosine
    --optim adamw_torch
    --adam_beta1 0.9
    --adam_beta2 0.95
    --adam_epsilon 1e-08
    --weight_decay 0.1
    --gradient_checkpointing "${gc}"
    --freeze_vit true
    --freeze_aligner true
    --freeze_llm false
    --vit_gradient_checkpointing false
    --dataloader_num_workers 4
    --split_dataset_ratio 0.0
    --dataset_shuffle true
    --dataloader_drop_last false
    --packing false
    --padding_free false
    --padding_side right
    --seed 42
    --data_seed 42
    --max_steps 25
    --save_strategy steps
    --save_steps 10
    --save_total_limit 3
    --logging_steps 1
    --report_to none
  )
}
