"""Verify the exact Python package and Torch MLU runtime contract."""

from __future__ import annotations

import importlib.metadata as metadata
from dataclasses import fields


EXPECTED_DISTRIBUTIONS = {
    "ms-swift": "4.4.2",
    "transformers": "5.12.1",
    "peft": "0.19.1",
    "accelerate": "1.14.0",
    "tokenizers": "0.22.2",
    "qwen-vl-utils": "0.0.14",
    "safetensors": "0.8.0",
    "av": "17.1.0",
    "timm": "1.0.28",
}
EXPECTED_TORCH = "2.6.0+cpu"


def main() -> None:
    actual = {name: metadata.version(name) for name in EXPECTED_DISTRIBUTIONS}
    if actual != EXPECTED_DISTRIBUTIONS:
        raise RuntimeError(f"package versions differ: expected={EXPECTED_DISTRIBUTIONS}, actual={actual}")

    import swift
    import torch
    import torch_mlu  # noqa: F401
    from swift import SftArguments
    from transformers import HfArgumentParser

    if swift.__version__ != EXPECTED_DISTRIBUTIONS["ms-swift"]:
        raise RuntimeError(f"swift import version differs: {swift.__version__}")
    if torch.__version__ != EXPECTED_TORCH:
        raise RuntimeError(f"torch version differs: {torch.__version__}")

    sft_fields = {field.name for field in fields(SftArguments)}
    sft_parser = HfArgumentParser(SftArguments)
    if (
        "resume_from_checkpoint" not in sft_fields
        or "--resume_from_checkpoint" not in sft_parser._option_string_actions
    ):
        raise RuntimeError("pinned ms-swift SFT parser lacks --resume_from_checkpoint")
    print({"swift": swift.__version__, "torch": torch.__version__, **actual})


if __name__ == "__main__":
    main()
