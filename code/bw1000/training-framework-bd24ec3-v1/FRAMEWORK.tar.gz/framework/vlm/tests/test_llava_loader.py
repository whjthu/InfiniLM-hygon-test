"""CPU-only regression tests for the bounded LLaVA Swift loader plugin."""

from __future__ import annotations

import importlib
import importlib.util
import sys
import types
from pathlib import Path
from types import SimpleNamespace

import pytest


PLUGIN_PATH = Path(__file__).parents[1] / "plugins" / "llava_onevision.py"


class BaseLoader:
    calls: list[dict] = []

    def get_model(self, model_dir, config, processor, model_kwargs):
        type(self).calls.append(dict(model_kwargs))
        return object()


def load_plugin(monkeypatch):
    registry = {
        "llava_onevision1_5": SimpleNamespace(loader=BaseLoader, marker="llava"),
        "unrelated": SimpleNamespace(loader=object, marker="unrelated"),
    }
    swift = types.ModuleType("swift")
    model = types.ModuleType("swift.model")
    register = types.ModuleType("swift.model.register")
    register.MODEL_MAPPING = registry
    monkeypatch.setitem(sys.modules, "swift", swift)
    monkeypatch.setitem(sys.modules, "swift.model", model)
    monkeypatch.setitem(sys.modules, "swift.model.register", register)
    monkeypatch.setenv("VLM_PLUGIN_DISABLE_AUTO_INSTALL", "1")

    spec = importlib.util.spec_from_file_location("llava_onevision_test_plugin", PLUGIN_PATH)
    plugin = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(plugin)
    return plugin, registry


def eager_config(root="eager", text="eager", vision="eager"):
    def component(value):
        return SimpleNamespace(_attn_implementation=value, _attn_implementation_internal=value)

    return SimpleNamespace(
        _attn_implementation=root,
        _attn_implementation_internal=root,
        text_config=component(text),
        vision_config=component(vision),
    )


def target_source(other_module=None, use_torch=False, interrupt=False):
    other = ""
    if other_module is not None:
        other = f"""
from transformers.dynamic_module_utils import get_class_from_dynamic_module
import threading
_other_result = []
def _load_other():
    _other_result.append(get_class_from_dynamic_module("other.Other", "unused", local_files_only=True).marker)
_other_thread = threading.Thread(target=_load_other)
_other_thread.start()
_other_thread.join()
if _other_result != ["native"]:
    raise RuntimeError("other dynamic import was changed")
"""
    header = """\
from transformers.modeling_flash_attention_utils import is_flash_attn_available
retained_flash_predicate = is_flash_attn_available
flash_available_during_import = retained_flash_predicate()
if flash_available_during_import:
    from transformers.modeling_flash_attention_utils import flash_attn_varlen_func
"""
    if interrupt:
        return header + other + "raise KeyboardInterrupt('test interrupt')\n"
    if use_torch:
        return "import torch\n" + header + other + """
class LLaVAOneVision1_5_Attention(torch.nn.Module):
    def forward(self, value):
        return value


class RiceAttention(torch.nn.Module):
    def forward(self, value):
        return value


class DecoderLayer(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.self_attn = LLaVAOneVision1_5_Attention()


class RiceBlock(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.attn = RiceAttention()


class TextComponent(torch.nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.weight = torch.nn.Parameter(torch.tensor(2.0))
        self.layers = torch.nn.ModuleList([DecoderLayer()])

    def forward(self, value):
        return value * self.weight


class VisionComponent(torch.nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.weight = torch.nn.Parameter(torch.tensor(2.0))
        self.blocks = torch.nn.ModuleList([RiceBlock()])

    def forward(self, value):
        return value * self.weight


class TinyModel(torch.nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.model = torch.nn.Module()
        self.model.language_model = TextComponent(config.text_config)
        self.model.visual = VisionComponent(config.vision_config)

    def forward(self, value):
        return self.model.language_model(value) + self.model.visual(value)


LLaVAOneVision1_5_ForConditionalGeneration = TinyModel
"""
    return header + other + """
class LLaVAOneVision1_5_Attention:
    pass


class RiceAttention:
    pass


class DecoderLayer:
    def __init__(self):
        self.self_attn = LLaVAOneVision1_5_Attention()


class RiceBlock:
    def __init__(self):
        self.attn = RiceAttention()


class TextComponent:
    def __init__(self, config):
        self.config = config
        self.layers = [DecoderLayer()]


class VisionComponent:
    def __init__(self, config):
        self.config = config
        self.blocks = [RiceBlock()]


class TinyModel:
    def __init__(self, config):
        self.config = config
        self.model = type("Container", (), {})()
        self.model.language_model = TextComponent(config.text_config)
        self.model.visual = VisionComponent(config.vision_config)

    def get_submodule(self, path):
        if path == "model.language_model":
            return self.model.language_model
        if path == "model.visual":
            return self.model.visual
        raise AttributeError(path)


LLaVAOneVision1_5_ForConditionalGeneration = TinyModel
"""


def install_dynamic_runtime(monkeypatch, tmp_path, source, runtime="5.12.1"):
    for name in (
        "transformers_modules.llava_target.modeling_llavaonevision1_5",
        "transformers_modules.llava_target.other",
        "transformers_modules.llava_target",
        "transformers_modules",
    ):
        monkeypatch.delitem(sys.modules, name, raising=False)
    cache = tmp_path / "hf_modules"
    package = cache / "transformers_modules" / "llava_target"
    package.mkdir(parents=True)
    for directory in (cache / "transformers_modules", package):
        (directory / "__init__.py").write_text("", encoding="utf-8")
    target = package / "modeling_llavaonevision1_5.py"
    target.write_text(source, encoding="utf-8")
    other = package / "other.py"
    other.write_text(
        "from transformers.modeling_flash_attention_utils import is_flash_attn_available\n"
        "if not is_flash_attn_available():\n"
        "    raise RuntimeError('other predicate changed')\n"
        "class Other:\n"
        "    marker = 'native'\n",
        encoding="utf-8",
    )
    monkeypatch.syspath_prepend(str(cache))
    module_name = "transformers_modules.llava_target.modeling_llavaonevision1_5"
    other_name = "transformers_modules.llava_target.other"

    transformers = types.ModuleType("transformers")
    transformers.__version__ = runtime
    dynamic = types.ModuleType("transformers.dynamic_module_utils")
    dynamic.HF_MODULES_CACHE = str(cache)
    flash = types.ModuleType("transformers.modeling_flash_attention_utils")
    native_predicate = lambda: True
    flash.is_flash_attn_available = native_predicate
    calls = []

    def get_cached_module_file(model_dir, module_file, *args, **kwargs):
        del model_dir, args, kwargs
        assert module_file == "modeling_llavaonevision1_5.py"
        return "transformers_modules/llava_target/modeling_llavaonevision1_5.py"

    def get_class_from_dynamic_module(class_reference, model_dir, *args, **kwargs):
        del model_dir, args, kwargs
        name, class_name = class_reference.rsplit(".", 1)
        if name == "other":
            name = other_name
        else:
            name = module_name
        calls.append((name, flash.is_flash_attn_available()))
        return getattr(importlib.import_module(name), class_name)

    dynamic.get_cached_module_file = get_cached_module_file
    dynamic.get_class_from_dynamic_module = get_class_from_dynamic_module
    transformers.dynamic_module_utils = dynamic
    transformers.modeling_flash_attention_utils = flash
    monkeypatch.setitem(sys.modules, "transformers", transformers)
    monkeypatch.setitem(sys.modules, "transformers.dynamic_module_utils", dynamic)
    monkeypatch.setitem(sys.modules, "transformers.modeling_flash_attention_utils", flash)
    return SimpleNamespace(
        cache=cache,
        calls=calls,
        dynamic=dynamic,
        flash=flash,
        module_name=module_name,
        native_predicate=native_predicate,
        other_name=other_name,
        target_path=target,
    )


def dynamic_loader(plugin, runtime, monkeypatch):
    monkeypatch.setattr(plugin, "_prepare_load_config", lambda config: None)
    monkeypatch.setattr(plugin, "_initialize_loaded_rope", lambda model: None)

    def native_get_model(self, model_dir, config, processor, model_kwargs):
        del self, model_dir, processor, model_kwargs
        model_cls = runtime.dynamic.get_class_from_dynamic_module("modeling_llavaonevision1_5.TinyModel", "unused")
        return model_cls(config)

    monkeypatch.setattr(BaseLoader, "get_model", native_get_model)
    return plugin.register_swift_load_mapping()()


def verify_target_hash(monkeypatch, plugin):
    monkeypatch.setattr(plugin, "_sha256_file", lambda path: plugin._TARGET_SOURCE_SHA256)


EAGER_LOAD_KWARGS = {"attn_implementation": "eager"}


def test_registration_isolated_and_idempotent(monkeypatch):
    plugin, registry = load_plugin(monkeypatch)
    original_unrelated = registry["unrelated"]

    first = plugin.register_swift_load_mapping()
    replacement = registry["llava_onevision1_5"]
    second = plugin.register_swift_load_mapping()

    assert first is second
    assert replacement.loader is first
    assert replacement.marker == "llava"
    assert registry["unrelated"] is original_unrelated
    assert registry["unrelated"].loader is object


def test_loader_passes_only_the_approved_key_mapping(monkeypatch):
    plugin, registry = load_plugin(monkeypatch)
    loader = plugin.register_swift_load_mapping()()
    BaseLoader.calls = []
    monkeypatch.setattr(plugin, "_prepare_load_config", lambda config: None)
    monkeypatch.setattr(plugin, "_initialize_loaded_rope", lambda model: None)

    supplied = {"trust_remote_code": True}
    loader.get_model("unused", object(), object(), supplied)

    assert supplied == {"trust_remote_code": True}
    assert BaseLoader.calls == [{"trust_remote_code": True, "key_mapping": plugin.LOAD_KEY_MAPPING}]
    assert registry["llava_onevision1_5"].loader is type(loader)


def test_loader_rejects_conflicting_key_mapping_before_loading(monkeypatch):
    plugin, _ = load_plugin(monkeypatch)
    loader = plugin.register_swift_load_mapping()()
    BaseLoader.calls = []

    with pytest.raises(plugin.LlavaCompatibilityError, match="conflicting"):
        loader.get_model("unused", object(), object(), {"key_mapping": {"^visual": "wrong"}})

    assert BaseLoader.calls == []


def test_rope_rejects_unsupported_layout_with_real_cpu_torch(monkeypatch):
    torch = pytest.importorskip("torch")
    plugin, _ = load_plugin(monkeypatch)

    class UnsupportedModel(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.weight = torch.nn.Parameter(torch.zeros(1))
            self.config = SimpleNamespace(
                text_config=SimpleNamespace(hidden_size=1024, num_attention_heads=32, rope_theta=1_000_000.0),
                vision_config=SimpleNamespace(hidden_size=1024, num_heads=16),
            )

    with pytest.raises(plugin.LlavaCompatibilityError, match="text hidden size"):
        plugin._initialize_loaded_rope(UnsupportedModel())


def test_dynamic_guard_handles_missing_export_cold_then_hot(monkeypatch, tmp_path):
    plugin, _ = load_plugin(monkeypatch)
    runtime = install_dynamic_runtime(monkeypatch, tmp_path, target_source())
    verify_target_hash(monkeypatch, plugin)
    loader = dynamic_loader(plugin, runtime, monkeypatch)
    original_loader = runtime.dynamic.get_class_from_dynamic_module

    cold = loader.get_model("unused", eager_config(), object(), EAGER_LOAD_KWARGS)
    target_module = sys.modules[runtime.module_name]
    hot = loader.get_model("unused", eager_config(), object(), EAGER_LOAD_KWARGS)

    assert type(cold).__module__ == runtime.module_name
    assert type(hot).__module__ == runtime.module_name
    assert runtime.calls == [(runtime.module_name, True)] * 4
    assert target_module.flash_available_during_import is False
    assert target_module.is_flash_attn_available is runtime.native_predicate
    assert runtime.flash.is_flash_attn_available is runtime.native_predicate
    assert runtime.dynamic.get_class_from_dynamic_module is original_loader
    exec(
        compile("retained_after_exit = retained_flash_predicate()", str(runtime.target_path), "exec"),
        target_module.__dict__,
    )
    assert target_module.retained_after_exit is True


def test_dynamic_guard_uses_eager_loader_request_before_config_is_applied(monkeypatch, tmp_path):
    plugin, _ = load_plugin(monkeypatch)
    runtime = install_dynamic_runtime(monkeypatch, tmp_path, target_source())
    verify_target_hash(monkeypatch, plugin)

    target = plugin._preimport_verified_eager_class("unused", eager_config(None, None, None), EAGER_LOAD_KWARGS)

    assert target == runtime.module_name
    assert sys.modules[runtime.module_name].flash_available_during_import is False
    assert runtime.calls == [(runtime.module_name, True)]


def test_dynamic_guard_uses_actual_swift_eager_config_without_attn_kw(monkeypatch, tmp_path):
    plugin, _ = load_plugin(monkeypatch)
    runtime = install_dynamic_runtime(monkeypatch, tmp_path, target_source())
    verify_target_hash(monkeypatch, plugin)

    target = plugin._preimport_verified_eager_class(
        "unused", eager_config(), {"device_map": "cpu", "dtype": "torch.bfloat16"}
    )

    assert target == runtime.module_name
    assert sys.modules[runtime.module_name].flash_available_during_import is False


@pytest.mark.parametrize(
    ("config", "model_kwargs"),
    [
        (eager_config(None, None, None), {}),
        (eager_config("eager", "sdpa", "eager"), {}),
        (eager_config("eager", None, "eager"), {}),
        (eager_config(), {"attn_implementation": "sdpa"}),
        (eager_config(), {"attn_implementation": None}),
    ],
)
def test_dynamic_guard_rejects_missing_or_non_eager_dispatch(monkeypatch, tmp_path, config, model_kwargs):
    plugin, _ = load_plugin(monkeypatch)
    runtime = install_dynamic_runtime(monkeypatch, tmp_path, target_source())
    verify_target_hash(monkeypatch, plugin)

    assert plugin._preimport_verified_eager_class("unused", config, model_kwargs) is None
    assert runtime.calls == []


def test_dynamic_guard_rejects_fallback_public_attention_conflict(monkeypatch, tmp_path):
    plugin, _ = load_plugin(monkeypatch)
    runtime = install_dynamic_runtime(monkeypatch, tmp_path, target_source())
    verify_target_hash(monkeypatch, plugin)
    config = eager_config()
    config.vision_config.attn_implementation = "sdpa"

    assert plugin._preimport_verified_eager_class("unused", config, {}) is None
    assert runtime.calls == []


@pytest.mark.parametrize(
    ("component_name", "field", "value"),
    [
        (component_name, field, value)
        for component_name in ("root", "text", "vision")
        for field, value in (
            ("_attn_implementation", None),
            ("_attn_implementation", "sdpa"),
            ("_attn_implementation_internal", None),
            ("_attn_implementation_internal", "sdpa"),
            ("attn_implementation", "sdpa"),
        )
    ],
)
def test_dynamic_guard_requires_each_fallback_dispatch_field(
    monkeypatch, tmp_path, component_name, field, value
):
    plugin, _ = load_plugin(monkeypatch)
    runtime = install_dynamic_runtime(monkeypatch, tmp_path, target_source())
    verify_target_hash(monkeypatch, plugin)
    config = eager_config()
    component = config if component_name == "root" else getattr(config, f"{component_name}_config")
    setattr(component, field, value)

    assert plugin._preimport_verified_eager_class("unused", config, {}) is None
    assert runtime.calls == []


def test_dynamic_guard_reloads_after_native_failure_and_rechecks_source_hash(monkeypatch, tmp_path):
    plugin, _ = load_plugin(monkeypatch)
    runtime = install_dynamic_runtime(monkeypatch, tmp_path, target_source())
    hash_calls = []
    monkeypatch.setattr(
        plugin,
        "_sha256_file",
        lambda path: hash_calls.append(path) or plugin._TARGET_SOURCE_SHA256,
    )
    native_loader = runtime.dynamic.get_class_from_dynamic_module
    attempts = 0

    def fail_once(class_reference, model_dir, *args, **kwargs):
        nonlocal attempts
        attempts += 1
        if attempts == 1:
            sys.modules[runtime.module_name] = types.ModuleType(runtime.module_name)
            raise RuntimeError("native dynamic import failed")
        sys.modules.pop(runtime.module_name, None)
        return native_loader(class_reference, model_dir, *args, **kwargs)

    monkeypatch.setattr(runtime.dynamic, "get_class_from_dynamic_module", fail_once)

    with pytest.raises(RuntimeError, match="native dynamic import failed"):
        plugin._preimport_verified_eager_class("unused", eager_config(), EAGER_LOAD_KWARGS)

    assert runtime.flash.is_flash_attn_available is runtime.native_predicate
    assert plugin._preimport_verified_eager_class("unused", eager_config(), EAGER_LOAD_KWARGS) == runtime.module_name
    assert attempts == 2
    assert hash_calls == [runtime.target_path, runtime.target_path]


def test_loaded_eager_rejects_conflicting_dispatch_fields(monkeypatch, tmp_path):
    plugin, _ = load_plugin(monkeypatch)
    runtime = install_dynamic_runtime(monkeypatch, tmp_path, target_source())
    verify_target_hash(monkeypatch, plugin)
    loader = dynamic_loader(plugin, runtime, monkeypatch)
    config = eager_config()

    def native_get_model(self, model_dir, config, processor, model_kwargs):
        del self, model_dir, processor, model_kwargs
        model_cls = runtime.dynamic.get_class_from_dynamic_module("modeling_llavaonevision1_5.TinyModel", "unused")
        config.text_config.attn_implementation = "sdpa"
        return model_cls(config)

    monkeypatch.setattr(BaseLoader, "get_model", native_get_model)

    with pytest.raises(plugin.LlavaCompatibilityError, match="not explicitly eager"):
        loader.get_model("unused", config, object(), EAGER_LOAD_KWARGS)


def test_loaded_eager_rejects_conflicting_root_dispatch_fields(monkeypatch, tmp_path):
    plugin, _ = load_plugin(monkeypatch)
    runtime = install_dynamic_runtime(monkeypatch, tmp_path, target_source())
    verify_target_hash(monkeypatch, plugin)
    loader = dynamic_loader(plugin, runtime, monkeypatch)
    config = eager_config()

    def native_get_model(self, model_dir, config, processor, model_kwargs):
        del self, model_dir, processor, model_kwargs
        model_cls = runtime.dynamic.get_class_from_dynamic_module("modeling_llavaonevision1_5.TinyModel", "unused")
        config.attn_implementation = "sdpa"
        return model_cls(config)

    monkeypatch.setattr(BaseLoader, "get_model", native_get_model)

    with pytest.raises(plugin.LlavaCompatibilityError, match="loaded root is not explicitly eager"):
        loader.get_model("unused", config, object(), EAGER_LOAD_KWARGS)


def test_loaded_eager_rejects_non_native_attention_instance(monkeypatch, tmp_path):
    plugin, _ = load_plugin(monkeypatch)
    runtime = install_dynamic_runtime(monkeypatch, tmp_path, target_source())
    verify_target_hash(monkeypatch, plugin)
    loader = dynamic_loader(plugin, runtime, monkeypatch)

    def native_get_model(self, model_dir, config, processor, model_kwargs):
        del self, model_dir, processor, model_kwargs
        model_cls = runtime.dynamic.get_class_from_dynamic_module("modeling_llavaonevision1_5.TinyModel", "unused")
        model = model_cls(config)
        model.model.language_model.layers[0].self_attn = object()
        return model

    monkeypatch.setattr(BaseLoader, "get_model", native_get_model)

    with pytest.raises(plugin.LlavaCompatibilityError, match="attention is outside"):
        loader.get_model("unused", eager_config(), object(), EAGER_LOAD_KWARGS)


@pytest.mark.parametrize(
    ("runtime_version", "root", "text", "vision", "verify_hash"),
    [
        ("5.12.0", "eager", "eager", "eager", True),
        ("5.12.1", "sdpa", "eager", "eager", True),
        ("5.12.1", "eager", "sdpa", "eager", True),
        ("5.12.1", "eager", "eager", "sdpa", True),
        ("5.12.1", "auto", "eager", "eager", True),
        ("5.12.1", "eager", "eager", "eager", False),
    ],
)
def test_dynamic_guard_rejects_unverified_runtime_source_or_attention(monkeypatch, tmp_path, runtime_version, root, text, vision, verify_hash):
    plugin, _ = load_plugin(monkeypatch)
    runtime = install_dynamic_runtime(monkeypatch, tmp_path, target_source(), runtime=runtime_version)
    if verify_hash:
        verify_target_hash(monkeypatch, plugin)
    loader = dynamic_loader(plugin, runtime, monkeypatch)
    original_loader = runtime.dynamic.get_class_from_dynamic_module

    with pytest.raises(ImportError, match="flash_attn_varlen_func"):
        loader.get_model("unused", eager_config(root, text, vision), object(), EAGER_LOAD_KWARGS)

    assert runtime.calls == [(runtime.module_name, True)]
    assert runtime.flash.is_flash_attn_available is runtime.native_predicate
    assert runtime.dynamic.get_class_from_dynamic_module is original_loader


def test_existing_native_flash_export_delegates_without_guard(monkeypatch, tmp_path):
    plugin, _ = load_plugin(monkeypatch)
    runtime = install_dynamic_runtime(monkeypatch, tmp_path, target_source())
    runtime.flash.flash_attn_varlen_func = object()
    verify_target_hash(monkeypatch, plugin)
    loader = dynamic_loader(plugin, runtime, monkeypatch)

    model = loader.get_model("unused", eager_config(), object(), EAGER_LOAD_KWARGS)

    assert type(model).__module__ == runtime.module_name
    assert runtime.calls == [(runtime.module_name, True)]
    assert runtime.flash.is_flash_attn_available is runtime.native_predicate


def test_dynamic_guard_leaves_other_thread_and_module_native(monkeypatch, tmp_path):
    plugin, _ = load_plugin(monkeypatch)
    runtime = install_dynamic_runtime(monkeypatch, tmp_path, target_source(other_module="transformers_modules.llava_target.other"))
    verify_target_hash(monkeypatch, plugin)
    loader = dynamic_loader(plugin, runtime, monkeypatch)

    loader.get_model("unused", eager_config(), object(), EAGER_LOAD_KWARGS)

    assert (runtime.module_name, True) in runtime.calls
    assert (runtime.other_name, True) in runtime.calls
    assert runtime.flash.is_flash_attn_available is runtime.native_predicate


def test_dynamic_guard_restores_native_functions_after_keyboard_interrupt(monkeypatch, tmp_path):
    plugin, _ = load_plugin(monkeypatch)
    runtime = install_dynamic_runtime(monkeypatch, tmp_path, target_source(interrupt=True))
    verify_target_hash(monkeypatch, plugin)
    loader = dynamic_loader(plugin, runtime, monkeypatch)
    original_loader = runtime.dynamic.get_class_from_dynamic_module

    with pytest.raises(KeyboardInterrupt, match="test interrupt"):
        loader.get_model("unused", eager_config(), object(), EAGER_LOAD_KWARGS)

    assert runtime.flash.is_flash_attn_available is runtime.native_predicate
    assert runtime.dynamic.get_class_from_dynamic_module is original_loader


def test_dynamic_guard_tiny_cpu_eager_output_and_gradients(monkeypatch, tmp_path):
    torch = pytest.importorskip("torch")
    plugin, _ = load_plugin(monkeypatch)
    runtime = install_dynamic_runtime(monkeypatch, tmp_path, target_source(use_torch=True))
    verify_target_hash(monkeypatch, plugin)
    loader = dynamic_loader(plugin, runtime, monkeypatch)

    model = loader.get_model("unused", eager_config(), object(), EAGER_LOAD_KWARGS)
    output = model(torch.tensor(3.0))
    output.square().backward()

    assert output.item() == pytest.approx(12.0)
    assert torch.isfinite(output)
    assert all(parameter.grad is not None and torch.isfinite(parameter.grad).all() for parameter in model.parameters())
