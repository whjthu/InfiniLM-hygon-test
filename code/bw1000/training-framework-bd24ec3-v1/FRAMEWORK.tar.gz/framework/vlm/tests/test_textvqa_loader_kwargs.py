"""Native model kwargs preserve the frozen policy without duplicate keywords."""

from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parents[1] / "runtime"))
from textvqa_generate import native_model_kwargs


class LoaderKwargsTest(unittest.TestCase):
    def call(self, kwargs, default):
        register = ModuleType("swift.model.register")
        register.MODEL_MAPPING = {"llava_onevision1_5": SimpleNamespace(
            loader=SimpleNamespace(default_trust_remote_code=default))}
        identity = {"model_type": "llava_onevision1_5", "model_kwargs": kwargs}
        with patch.dict(sys.modules, {"swift.model.register": register}):
            return native_model_kwargs(identity)

    def test_native_explicit_keyword_is_not_duplicated(self):
        supplied = {"trust_remote_code": True, "local_files_only": True}
        forwarded = self.call(supplied, True)

        def native_load(*, trust_remote_code, **kwargs):
            return trust_remote_code, kwargs

        self.assertEqual(native_load(trust_remote_code=True, **forwarded),
                         (True, {"local_files_only": True}))
        self.assertEqual(supplied, {"trust_remote_code": True, "local_files_only": True})

    def test_empty_policy_remains_empty_and_separate(self):
        supplied = {}
        forwarded = self.call(supplied, False)
        self.assertEqual(forwarded, {})
        self.assertIsNot(forwarded, supplied)

    def test_conflicting_or_untyped_policy_is_rejected(self):
        for requested, default in ((False, True), (1, True), (True, False),
                                   (True, None), (True, 1)):
            with self.subTest(requested=requested, default=default):
                with self.assertRaisesRegex(ValueError, "native loader trust policy differs"):
                    self.call({"trust_remote_code": requested}, default)


if __name__ == "__main__":
    unittest.main()
