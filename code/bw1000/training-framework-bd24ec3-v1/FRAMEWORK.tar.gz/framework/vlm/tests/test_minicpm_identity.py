"""CPU regression tests for strict MiniCPM comparison identity."""

from __future__ import annotations

import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


VLM_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(VLM_ROOT / "runtime"))
import verify_minicpm_identity as identity  # noqa: E402


class MiniCPMIdentityTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.model = self.root / "MiniCPM-V-4.6"
        self.model.mkdir()
        (self.model / "config.json").write_text('{"architectures":["MiniCPMV"]}\n', encoding="utf-8")
        (self.model / "model-00001.safetensors").write_bytes(b"test-weight")
        self.manifest = self.root / "identity.json"
        identity.write_manifest(self.model, self.manifest)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def test_verified_model_and_current_source_pins_pass(self) -> None:
        identity.verify(self.model, self.manifest)

    def test_manifest_generation_command_creates_new_manifest(self) -> None:
        generated = self.root / "generated.json"
        completed = subprocess.run([
            sys.executable, str(VLM_ROOT / "runtime" / "verify_minicpm_identity.py"),
            "--model-path", str(self.model), "--write-manifest", str(generated),
        ], check=False, capture_output=True, text=True)
        self.assertEqual(completed.returncode, 0, completed.stderr)
        identity.verify(self.model, generated)
        repeated = subprocess.run([
            sys.executable, str(VLM_ROOT / "runtime" / "verify_minicpm_identity.py"),
            "--model-path", str(self.model), "--write-manifest", str(generated),
        ], check=False, capture_output=True, text=True)
        self.assertEqual(repeated.returncode, 2)

    def test_rejects_changed_model_after_manifest(self) -> None:
        (self.model / "model-00001.safetensors").write_bytes(b"other-weight")
        with self.assertRaisesRegex(ValueError, "model-tree digest"):
            identity.verify(self.model, self.manifest)

    def test_rejects_manifest_destination_inside_model_tree(self) -> None:
        destination = self.model / "identity.json"
        with self.assertRaisesRegex(ValueError, "outside the MiniCPM model tree"):
            identity.write_manifest(self.model, destination)
        self.assertFalse(destination.exists())

    def test_invalid_model_does_not_create_manifest(self) -> None:
        invalid_model = self.root / "invalid" / identity.MODEL_DIRECTORY
        invalid_model.mkdir(parents=True)
        destination = self.root / "invalid-model.json"
        with self.assertRaisesRegex(ValueError, "regular config.json"):
            identity.write_manifest(invalid_model, destination)
        self.assertFalse(destination.exists())

    def test_rejects_stale_manifest_after_helper_change(self) -> None:
        copied_root = self.root / "vlm"
        for relative in identity.REQUIRED_SOURCE_FILES:
            destination = copied_root / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(VLM_ROOT / relative, destination)
        with patch.object(identity, "ROOT", copied_root):
            self.manifest.unlink()
            identity.write_manifest(self.model, self.manifest)
            identity.verify(self.model, self.manifest)
        (copied_root / "runtime/common.sh").write_text("changed\n", encoding="utf-8")
        with patch.object(identity, "ROOT", copied_root):
            with self.assertRaisesRegex(ValueError, "wrapper identity differs"):
                identity.verify(self.model, self.manifest)


if __name__ == "__main__":
    unittest.main()
