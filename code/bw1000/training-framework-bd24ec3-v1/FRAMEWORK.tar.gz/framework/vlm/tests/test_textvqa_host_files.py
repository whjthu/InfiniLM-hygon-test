"""File-backed host verification fixtures; no device execution."""

from datetime import datetime, timedelta
from pathlib import Path
from types import SimpleNamespace
import json
import os
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "runtime"))
import textvqa_contract as c
import textvqa_host as host
import textvqa_runner as approval
import test_textvqa as fixtures


class HostFileBindings(unittest.TestCase):
    def setUp(self):
        self.fixture = fixtures.TextVQAContracts(methodName="test_input_real_schema_strict_types_and_answer_free")
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        f = self.fixture
        self.root = f.root / "generative-mlu/mlu-10000/test-run"
        self.prep = f.root / "preparation"
        self.prep.mkdir()
        self.model = f.models / "gemma-3-4b-it"
        self.model.mkdir()
        (self.model / "config.json").write_text('{"fixture":true}')
        package = f.root / "controller/genmlu"
        package.mkdir(parents=True)
        source = Path(__file__).resolve().parents[2] / "generation/src/genmlu"
        for name in approval.RELEASE_FILES:
            (package / name).write_bytes((source / name).read_bytes())
        self.runner = package / "benchctl.py"
        deployment = self.prep / "deployment.json"
        approval.freeze_deployment(self.runner, deployment)
        self.identity = dict(f.identity, source_tree_sha256=c.tree_sha256(c.ROOT),
                             model_tree_sha256=c.tree_sha256(self.model))
        identity_file = self.prep / "identity.json"
        c.write_json(identity_file, self.identity)
        flags = {"model": self.model, "model-alias": "gemma3", "model-type": "gemma3_vision",
                 "questions": f.questions, "manifest": f.manifest, "manifest-sha256": f.manifest_sha,
                 "images-root": f.images, "api-evidence": f.api_file,
                 "runtime-image": self.identity["runtime_image"], "out": self.root / "generation",
                 "identity": identity_file, "identity-sha256": c.sha256_file(identity_file),
                 "container-name": "genmlu-test-run", "physical-card": 0, "uid": 1001, "gid": 1002,
                 "lease-root": self.root, "host-label": "mlu-10000", "runner-source": self.runner,
                 "runner-sha256": c.sha256_file(self.runner), "runner-deployment": deployment,
                 "runner-deployment-sha256": c.sha256_file(deployment)}
        argv = ["docker"]
        for key, value in flags.items():
            argv.extend(["--" + key, str(value)])
        arguments = self.prep / "arguments.json"
        c.write_json(arguments, argv)
        self.plan_file = self.prep / "plan.json"
        with patch.object(host.socket, "gethostname", return_value="node1"), \
             patch.object(host.os, "getuid", return_value=1001, create=True):
            host.prepare(SimpleNamespace(launcher_arguments=arguments,
                                         launcher_arguments_sha256=c.sha256_file(arguments), out=self.plan_file))
        self.plan = c.read_json(self.plan_file)
        self.plan_sha = c.sha256_file(self.plan_file)
        self.root.mkdir(parents=True)
        generation_root = self.root / "generation"
        generation_root.mkdir()
        created = datetime.fromisoformat(self.plan["created_at_utc"])
        sample = {"host": "node1", "cards": [0], "foreign_accelerator_processes": [],
                  "card_states": [{"index": 0, "used_mib": 0, "utilization_percent": 0}]}
        self.lease = {**self.plan, "schema_version": 2, "pid": 99, "lease_id": "a" * 32,
                      "state": "completed", "returncode": 0,
                      "command": self.plan["child_command"], "requested_command": self.plan["child_command"],
                      "container_names": [self.plan["container_name"]], "container_lease_label_required": True,
                      "containers": [{"name": self.plan["container_name"], "container_id": "b" * 64,
                                      "last_pid": 100, "state": "exited"}],
                      "timeout_seconds": 3600, "watch_interval_seconds": 15,
                      "started_at_utc": (created + timedelta(seconds=1)).isoformat(),
                      "finished_at_utc": (created + timedelta(seconds=302)).isoformat(),
                      "preflight": {key: {**sample, "checked_at_utc": (created + timedelta(seconds=delta)).isoformat()}
                                    for key, delta in (("first", 1), ("second", 301))}}
        c.write_json(self.root / "lease.json", self.lease)
        receipt = {"run_id": self.root.name, "host": "node1", "host_label": "mlu-10000",
                   "card": 0, "uid": 1001, "lease_id": "a" * 32,
                   "lease_sha256": c.sha256_file(self.root / "lease.json"),
                   "runner_sha256": c.sha256_file(self.runner),
                   "command_sha256": c.digest(self.plan["child_command"])}
        c.write_json(generation_root / "execution.json", receipt)
        predictions = generation_root / "predictions.jsonl"
        records = f.records()
        predictions.write_text("\n".join(json.dumps(value) for value in records) + "\n")
        _, inputs = f.validate()
        allocator = {"requested_fraction": 0.75, "actual_fraction": 0.75,
                     "total_memory": 100_000_000_000, "peak_reserved": 100}
        run = {"schema": "vlm-textvqa-generation-v2", "status": "diagnostic_completed",
               "identity": self.identity, "identity_sha256": c.sha256_file(identity_file),
               "inputs": inputs, "api": f.api, "predictions_sha256": c.sha256_file(predictions),
               "question_ids": [row["question_id"] for row in f.rows], "question_count": 64,
               "parameter_devices": ["mlu:0"], "adapter_active": False,
               "allocator_before": dict(allocator, peak_reserved=0), "allocator_after": allocator,
               "claims": c.FALSE_CLAIMS, "execution": receipt,
               "execution_sha256": c.sha256_file(generation_root / "execution.json"),
               "owned_execution_accepted": False}
        c.write_json(generation_root / "generation.json", run)
        self.args = SimpleNamespace(plan=self.plan_file, plan_sha256=self.plan_sha,
                                    output=self.prep / "result.json")

    def finalize(self):
        with patch.object(host.subprocess, "run", return_value=SimpleNamespace(
                returncode=0, stdout=self.plan["image"], stderr="")), patch.object(host, "confirm_absent"):
            return host.finalize(self.args)

    def test_complete_file_bindings_keep_quality_claims_false(self):
        result = self.finalize()
        self.assertTrue(result["owned_execution_accepted"])
        self.assertEqual(result["question_count"], 64)
        for key in ("quality_accepted", "performance_accepted", "recovery_accepted"):
            self.assertIs(result[key], False)
        self.assertEqual(result["container_id"], "b" * 64)

    def test_modified_receipt_or_predictions_cannot_be_attested(self):
        for name in ("execution.json", "predictions.jsonl", "generation.json"):
            path = self.root / "generation" / name
            original = path.read_bytes()
            if name == "generation.json":
                path.write_text(json.dumps({**json.loads(original), "question_count": 63}))
            else:
                path.write_bytes(original + b" ")
            with self.subTest(name=name), self.assertRaises((ValueError, RuntimeError)):
                self.finalize()
            self.assertFalse(Path(self.args.output).exists())
            path.write_bytes(original)

    def test_changed_model_or_api_rejected(self):
        for path in (self.model / "config.json", self.fixture.api_file):
            original = path.read_bytes()
            path.write_bytes(original + b" ")
            with self.subTest(path=path), self.assertRaises((ValueError, RuntimeError)):
                self.finalize()
            path.write_bytes(original)
        self.assertFalse(Path(self.args.output).exists())

    def test_retained_active_lease_rejected(self):
        active = self.root.parent / ".leases"
        active.mkdir()
        (active / "cards-0.json").write_text("{}")
        with self.assertRaisesRegex(RuntimeError, "active lease"):
            self.finalize()

    def test_existing_run_is_not_relaunched(self):
        with patch.object(host.subprocess, "run") as launch:
            with self.assertRaises(RuntimeError):
                host.run_plan(SimpleNamespace(plan=self.plan_file, plan_sha256=self.plan_sha))
            launch.assert_not_called()
