"""POSIX host signal forwarding and single-delivery regression tests."""

import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

RUNTIME = Path(__file__).resolve().parents[1] / "runtime"
sys.path.insert(0, str(RUNTIME))
import textvqa_host as host


class SignalDelivery(unittest.TestCase):
    def test_pending_and_running_signals_are_forwarded_once(self):
        for pending in (True, False):
            handlers, sent = {}, []
            child = SimpleNamespace(poll=lambda: None)
            def send(number):
                sent.append(number)
                handlers[signal.SIGTERM](signal.SIGTERM, None)
            child.send_signal = send
            def wait():
                if not pending:
                    handlers[signal.SIGTERM](signal.SIGTERM, None)
                return 0
            child.wait = wait
            def spawn(*args, **kwargs):
                if pending:
                    handlers[signal.SIGTERM](signal.SIGTERM, None)
                return child
            def install(number, handler):
                handlers[number] = handler
            with self.subTest(pending=pending), patch.object(host.signal, "getsignal", return_value="original"), \
                 patch.object(host.signal, "signal", side_effect=install), patch.object(host.subprocess, "Popen", side_effect=spawn):
                with self.assertRaisesRegex(RuntimeError, "host interrupted"):
                    host.wait_controller(["fixture"], "/fixture", {})
            self.assertEqual(sent, [signal.SIGTERM])
            self.assertEqual(set(handlers.values()), {"original"})

    def test_spawn_failure_restores_handlers(self):
        restored = []
        with patch.object(host.signal, "getsignal", return_value="original"), \
             patch.object(host.signal, "signal", side_effect=lambda n, v: restored.append((n, v))), \
             patch.object(host.subprocess, "Popen", side_effect=OSError("spawn failed")):
            with self.assertRaisesRegex(OSError, "spawn failed"):
                host.wait_controller(["fixture"], "/fixture", {})
        self.assertEqual(restored[-2:], [(signal.SIGINT, "original"), (signal.SIGTERM, "original")])


@unittest.skipUnless(os.name == "posix" and Path("/proc").exists(), "real process signals require Linux")
class RealHostSignal(unittest.TestCase):
    def test_sigterm_to_only_host_pid_waits_for_owned_grandchild_cleanup(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            controller = root / "controller.py"
            ready, cleaned = root / "ready.json", root / "cleaned"
            controller.write_text(
                "import os,signal,subprocess,sys,time,json\n"
                "from pathlib import Path\n"
                "child=subprocess.Popen([sys.executable,'-B','-c','import time;time.sleep(3600)'],start_new_session=True)\n"
                "def stop(number,frame):\n"
                " os.killpg(child.pid,signal.SIGTERM)\n"
                " child.wait()\n"
                " Path(sys.argv[2]).write_text('cleanup-completed')\n"
                " raise SystemExit(143)\n"
                "signal.signal(signal.SIGTERM,stop)\n"
                "signal.signal(signal.SIGINT,stop)\n"
                "Path(sys.argv[1]).write_text(json.dumps({'controller':os.getpid(),'grandchild':child.pid}))\n"
                "while True:time.sleep(0.05)\n")
            code = ("import sys,os;sys.path.insert(0," + repr(str(RUNTIME)) + ");"
                    "from textvqa_host import wait_controller;"
                    "wait_controller(" + repr([sys.executable, "-B", str(controller), str(ready), str(cleaned)])
                    + "," + repr(str(root)) + ",dict(os.environ))")
            process = subprocess.Popen([sys.executable, "-B", "-c", code], cwd=root,
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True)
            try:
                deadline = time.monotonic() + 10
                while not ready.exists() and process.poll() is None and time.monotonic() < deadline:
                    time.sleep(0.05)
                self.assertTrue(ready.exists(), "owned work did not start")
                pids = json.loads(ready.read_text())
                os.kill(process.pid, signal.SIGTERM)
                stdout, stderr = process.communicate(timeout=10)
                self.assertNotEqual(process.returncode, 0)
                self.assertIn("host interrupted", stderr)
                self.assertEqual(cleaned.read_text(), "cleanup-completed")
                for pid in pids.values():
                    self.assertFalse(Path("/proc", str(pid)).exists(), "owned process remains")
                self.assertFalse((root / "result.json").exists())
            finally:
                if process.poll() is None:
                    process.send_signal(signal.SIGTERM)
                    process.communicate(timeout=10)
