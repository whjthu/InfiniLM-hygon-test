"""Verify the pinned ms-swift parser accepts the qualified MiniCPM preset."""

from dataclasses import fields
from enum import Enum
from unittest.mock import patch

import swift
from transformers import HfArgumentParser
from swift import SftArguments


PRESET_ARGUMENTS = [
    "--model", "/contract/MiniCPM-V-4.6",
    "--model_type", "minicpmv4_6",
    "--template", "minicpmv4_6",
    "--dataset", "/contract/dataset.jsonl",
    "--output_dir", "/contract/output",
    "--add_version", "false",
    "--no_check_model",
    "--torch_dtype", "bfloat16",
    "--max_length", "4096",
    "--max_pixels", "262144",
    "--tuner_type", "lora",
    "--target_modules", "all-linear",
    "--lora_rank", "16",
    "--lora_alpha", "32",
    "--lora_dropout", "0.05",
    "--per_device_train_batch_size", "1",
    "--gradient_accumulation_steps", "4",
    "--learning_rate", "0.0001",
    "--max_grad_norm", "1.0",
    "--warmup_steps", "5",
    "--lr_scheduler_type", "cosine",
    "--optim", "adamw_torch",
    "--adam_beta1", "0.9",
    "--adam_beta2", "0.95",
    "--adam_epsilon", "1e-08",
    "--weight_decay", "0.1",
    "--gradient_checkpointing", "false",
    "--freeze_vit", "true",
    "--freeze_aligner", "true",
    "--freeze_llm", "false",
    "--vit_gradient_checkpointing", "false",
    "--dataloader_num_workers", "4",
    "--split_dataset_ratio", "0.0",
    "--dataset_shuffle", "true",
    "--dataloader_drop_last", "false",
    "--packing", "false",
    "--padding_free", "false",
    "--padding_side", "right",
    "--seed", "42",
    "--data_seed", "42",
    "--max_steps", "25",
    "--save_strategy", "steps",
    "--save_steps", "10",
    "--save_total_limit", "3",
    "--logging_steps", "1",
    "--report_to", "none",
]


def _plain(value):
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, list) and len(value) == 1:
        return value[0]
    return value


def main() -> None:
    assert swift.__version__ == "4.4.2"
    assert "resume_from_checkpoint" in {field.name for field in fields(SftArguments)}
    parser = HfArgumentParser(SftArguments)
    assert "--resume_from_checkpoint" in parser._option_string_actions
    # This is a parser contract test. Model and runtime validation is exercised
    # by the real wrapper run, so do not make a fake model tree pass post-init.
    with patch.object(SftArguments, "__post_init__", autospec=True):
        parsed = parser.parse_args_into_dataclasses(args=PRESET_ARGUMENTS)[0]
    expected = {
        "model": "/contract/MiniCPM-V-4.6", "dataset": "/contract/dataset.jsonl",
        "output_dir": "/contract/output", "add_version": False, "check_model": False,
        "model_type": "minicpmv4_6", "template": "minicpmv4_6",
        "torch_dtype": "bfloat16", "max_length": 4096, "max_pixels": 262144,
        "tuner_type": "lora", "target_modules": "all-linear", "lora_rank": 16,
        "lora_alpha": 32, "lora_dropout": 0.05, "per_device_train_batch_size": 1,
        "gradient_accumulation_steps": 4, "learning_rate": 0.0001,
        "max_grad_norm": 1.0, "warmup_steps": 5, "lr_scheduler_type": "cosine",
        "optim": "adamw_torch", "adam_beta1": 0.9, "adam_beta2": 0.95,
        "adam_epsilon": 1e-8, "weight_decay": 0.1, "gradient_checkpointing": False,
        "freeze_vit": True, "freeze_aligner": True, "freeze_llm": False,
        "vit_gradient_checkpointing": False, "dataloader_num_workers": 4,
        "split_dataset_ratio": 0.0, "dataset_shuffle": True,
        "dataloader_drop_last": False, "packing": False, "padding_free": False,
        "padding_side": "right", "seed": 42, "data_seed": 42, "max_steps": 25,
        "save_strategy": "steps", "save_steps": 10, "save_total_limit": 3,
        "logging_steps": 1, "report_to": "none",
    }
    for name, value in expected.items():
        assert _plain(getattr(parsed, name)) == value, name
    assert parsed.resume_from_checkpoint is None


if __name__ == "__main__":
    main()
