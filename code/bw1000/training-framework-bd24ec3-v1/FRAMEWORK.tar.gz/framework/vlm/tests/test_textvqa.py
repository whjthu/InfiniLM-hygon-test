"""CPU contracts and official scorer fixtures, not accelerator qualification."""

from __future__ import annotations

import copy
import ast
import importlib.util
import inspect
import json
import os
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace
import unittest
from unittest.mock import patch

from PIL import Image

RUNTIME = Path(__file__).resolve().parents[1] / "runtime"
sys.path.insert(0, str(RUNTIME))
import textvqa_contract as contract
import textvqa_docker as docker
import textvqa_generate as generate
import textvqa_score as scorer
from textvqa_runner import controller_bootstrap


class TextVQAContracts(unittest.TestCase):
    def test_physical_receipt_is_separate_from_isolated_logical_visibility(self):
        execution = {"run_id": "fixture", "host": "node1", "host_label": "mlu-10000", "card": 1,
                     "uid": 1001, "lease_id": "fixture-lease", "lease_sha256": "4" * 64,
                     "runner_sha256": "5" * 64, "command_sha256": "6" * 64}
        environment = {"MLU_VISIBLE_DEVICES": "0", "CNRT_VISIBLE_DEVICES": "0"}
        original = copy.deepcopy(execution)
        generate.validate_isolated_environment(execution, environment, 1001)
        self.assertEqual(execution, original)
        for card in (0, 7):
            generate.validate_isolated_environment(dict(execution, card=card), environment, 1001)
        for environment in ({}, {"MLU_VISIBLE_DEVICES": "1", "CNRT_VISIBLE_DEVICES": "1"},
                            {"MLU_VISIBLE_DEVICES": "0", "CNRT_VISIBLE_DEVICES": "1"}):
            with self.subTest(environment=environment), self.assertRaises(ValueError):
                generate.validate_isolated_environment(execution, environment, 1001)
        for card in (-1, 8, True):
            with self.subTest(card=card), self.assertRaises(ValueError):
                generate.validate_isolated_environment(dict(execution, card=card),
                                                      {"MLU_VISIBLE_DEVICES": "0",
                                                       "CNRT_VISIBLE_DEVICES": "0"}, 1001)
        with self.assertRaises(ValueError):
            generate.validate_isolated_environment(execution,
                                                  {"MLU_VISIBLE_DEVICES": "0",
                                                   "CNRT_VISIBLE_DEVICES": "0"}, 1002)

    def test_empty_thinking_prefix_is_explicit_and_preserves_raw_answers(self):
        raw = [{"answer": scorer.EMPTY_THINK_PREFIX + "yes"},
               {"answer": scorer.EMPTY_THINK_PREFIX + "two"}]
        original = copy.deepcopy(raw)
        self.assertEqual(scorer.extracted_answers(raw, "minicpmv4_6", "raw"),
                         [record["answer"] for record in raw])
        self.assertEqual(scorer.extracted_answers(raw, "minicpmv4_6", "empty-think-prefix-v1"), ["yes", "two"])
        self.assertEqual(raw, original)
        for alias in ("qwen3-vl", "gemma3", "internvl3_5", "llava-onevision1_5"):
            with self.assertRaises(ValueError):
                scorer.extracted_answers(raw, alias, "empty-think-prefix-v1")
        for answer in ("yes", "<think>reason</think>yes", "<think></think>yes",
                       "<think> \n</think>\n\nyes", "<think>\r\n\r\n</think>\r\n\r\nyes",
                       "<think>\n\nyes", "prefix" + scorer.EMPTY_THINK_PREFIX + "yes",
                       scorer.EMPTY_THINK_PREFIX, scorer.EMPTY_THINK_PREFIX + " ",
                       scorer.EMPTY_THINK_PREFIX + "<think>nested</think>yes",
                       scorer.EMPTY_THINK_PREFIX + "yes</think>"):
            with self.assertRaises(ValueError):
                scorer.extracted_answers([{"answer": answer}], "minicpmv4_6", "empty-think-prefix-v1")
        with self.assertRaises(ValueError):
            scorer.extracted_answers(raw, "minicpmv4_6", "automatic")

    def test_native_model_kwargs_do_not_alias_frozen_identity(self):
        tree = ast.parse(inspect.getsource(generate.generate))
        call = next(node for node in ast.walk(tree) if isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Name) and node.func.id == "TransformersEngine")
        expression = next(keyword.value for keyword in call.keywords if keyword.arg == "model_kwargs")
        code = compile(ast.Expression(expression), "<native-model-kwargs>", "eval")
        for options in ({}, {"trust_remote_code": True}):
            identity = {"model_type": "llava_onevision1_5", "model_kwargs": dict(options)}
            before = copy.deepcopy(identity)
            register = ModuleType("swift.model.register")
            register.MODEL_MAPPING = {"llava_onevision1_5": SimpleNamespace(
                loader=SimpleNamespace(default_trust_remote_code=True))}
            with patch.dict(sys.modules, {"swift.model.register": register}):
                actual = eval(code, {"identity": identity,
                                     "native_model_kwargs": generate.native_model_kwargs})
            self.assertEqual(actual, {k: v for k, v in options.items() if k != "trust_remote_code"})
            self.assertIsNot(actual, identity["model_kwargs"])
            actual.update(dtype="bfloat16", device_map={"": "mlu:0"}, trust_remote_code=False)
            actual.pop("trust_remote_code")
            self.assertEqual(identity, before)

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.models = self.root / "models"
        self.models.mkdir()
        self.environment = patch.dict(os.environ, MODELS_DIR=str(self.models))
        self.environment.start()
        self.addCleanup(self.environment.stop)
        self.images = self.root / "images"
        self.images.mkdir()
        self.rows = []
        for i in range(64):
            path = self.images / (str(i) + ".png")
            Image.new("RGB", (3, 2), (i, 7, 21)).save(path)
            self.rows.append({"question_id": 100 + i, "question": "What is written?",
                              "image_id": str(i), "image_path": path.name, "image_sha256": contract.sha256_file(path),
                              "image_bytes": path.stat().st_size, "width": 3, "height": 2})
        self.questions = self.root / "questions.json"
        self.manifest = self.root / "manifest.json"
        self.questions_value = {"schema": "vlm-textvqa-questions-v1", "dataset": "TextVQA",
                                "version": "0.5.1", "split": "val", "scope": "validation-subset", "data": self.rows}
        contract.write_json(self.questions, self.questions_value)
        self.manifest_value = {"schema": "vlm-textvqa-input-manifest-v1",
                               "questions_sha256": contract.sha256_file(self.questions),
                               "question_ids": [r["question_id"] for r in self.rows], "question_count": 64,
                               "source_annotations_sha256": contract.ANNOTATIONS_SHA,
                               "source_subset_sha256": contract.SUBSET_SHA}
        contract.write_json(self.manifest, self.manifest_value)
        self.manifest_sha = contract.sha256_file(self.manifest)
        from verify_environment import EXPECTED_DISTRIBUTIONS, EXPECTED_TORCH
        self.api = {"schema": "vlm-textvqa-api-v2", "status": "verified-cpu-import", "fixture": True,
                    "runtime_image": "sha256:" + "3" * 64,
                    "versions": {**EXPECTED_DISTRIBUTIONS, "torch": EXPECTED_TORCH},
                    "engine_parameters": sorted(contract.ENGINE_PARAMETERS),
                    "registry_templates": {alias: ("gemma" if alias == "gemma3" else alias)
                                           for alias in contract.REGISTRY}}
        self.api_file = self.root / "api.json"
        contract.write_json(self.api_file, self.api)
        self.identity = {"schema": "vlm-textvqa-identity-v2", "model_alias": "gemma3",
                         "model_type": "gemma3_vision", "template": "gemma",
                         "model_tree_sha256": "1" * 64, "adapter_tree_sha256": None,
                         "training_manifest_sha256": None, "training_provenance_sha256": None,
                         "source_tree_sha256": "2" * 64,
                         "runtime_image": "sha256:" + "3" * 64,
                         "api_evidence_sha256": contract.sha256_file(self.api_file),
                         "input_manifest_sha256": self.manifest_sha, "generation": contract.GENERATION,
                         "processor_env": {}, "attn_impl": None, "model_kwargs": {}}

    def validate(self):
        return contract.validate_inputs(self.questions, self.manifest, self.manifest_sha, self.images)

    def test_input_real_schema_strict_types_and_answer_free(self):
        self.assertEqual(self.validate()[0], self.rows)
        for mutate in (
            lambda v: v["data"][0].update(answers=["secret"] * 10),
            lambda v: v["data"][0].update(question_id=True),
            lambda v: v["data"][0].update(width=False),
            lambda v: v["data"][0].update(question=""),
            lambda v: v["data"][1].update(question_id=100),
            lambda v: v.update(split="train"),
            lambda v: v.update(scope="full-benchmark"),
            lambda v: v.update(data=v["data"][:-1]),
        ):
            value = copy.deepcopy(self.questions_value)
            mutate(value)
            self.questions.write_text(json.dumps(value), encoding="utf-8")
            with self.assertRaises(ValueError):
                self.validate()
        for value in ('{"x":1,"x":2}', '{"x":NaN}', '{"x":Infinity}'):
            with self.assertRaises(ValueError):
                contract.loads(value)

    def test_image_bytes_dimensions_escape_and_extra_files_rejected(self):
        for field, value in (("image_path", "../secret.jpg"), ("image_path", "/secret.jpg"),
                             ("image_path", "a\\b.jpg"), ("image_path", "0/../0.png"),
                             ("image_bytes", 1), ("image_sha256", "f" * 64), ("height", 9)):
            questions = copy.deepcopy(self.questions_value)
            questions["data"][0][field] = value
            self.questions.write_text(json.dumps(questions), encoding="utf-8")
            with self.assertRaises(ValueError):
                self.validate()
        self.questions.write_text(json.dumps(self.questions_value), encoding="utf-8")
        (self.images / "answers.json").write_text("{}", encoding="utf-8")
        with self.assertRaises(ValueError):
            self.validate()

    def test_manifest_order_and_source_pins(self):
        for field, value in (("source_subset_sha256", "f" * 64), ("question_count", True),
                             ("question_ids", list(reversed(self.manifest_value["question_ids"]))),
                             ("questions_sha256", "f" * 64)):
            manifest = copy.deepcopy(self.manifest_value)
            manifest[field] = value
            self.manifest.write_text(json.dumps(manifest), encoding="utf-8")
            self.manifest_sha = contract.sha256_file(self.manifest)
            with self.assertRaises(ValueError):
                self.validate()

    def records(self):
        return [{"question_id": r["question_id"], "image_id": r["image_id"], "answer": "yes",
                 "request_sha256": contract.digest({"prompt": contract.prompt(r), "image_sha256": r["image_sha256"]}),
                 "completion_tokens": 1, "prompt_tokens": 50, "finish_reason": "stop",
                 "forward": {"calls": 2, "input_devices": ["mlu:0"], "output_devices": ["mlu:0"], "finite": True}}
                for r in self.rows]

    def test_predictions_missing_duplicate_order_empty_device_finite_and_request(self):
        records = self.records()
        contract.validate_predictions(self.rows, records)
        with self.assertRaises(ValueError):
            contract.validate_predictions(self.rows, records[:-1])
        for key, value in (("question_id", 101), ("answer", ""), ("completion_tokens", 0),
                           ("completion_tokens", 33), ("request_sha256", "e" * 64), ("finish_reason", None)):
            bad = copy.deepcopy(records)
            bad[0][key] = value
            with self.assertRaises(ValueError):
                contract.validate_predictions(self.rows, bad)
        for key, value in (("calls", 0), ("input_devices", ["cpu"]), ("output_devices", []), ("finite", False)):
            bad = copy.deepcopy(records)
            bad[0]["forward"][key] = value
            with self.assertRaises(ValueError):
                contract.validate_predictions(self.rows, bad)
        with self.assertRaises(ValueError):
            contract.validate_predictions(self.rows, list(reversed(records)))

    def test_identity_and_allocator_safe_rounding(self):
        contract.validate_identity(self.identity)
        for key, value in (("runtime_image", "b6"), ("model_tree_sha256", None),
                           ("adapter_tree_sha256", "f" * 64), ("generation", {})):
            bad = copy.deepcopy(self.identity)
            bad[key] = value
            with self.assertRaises(ValueError):
                contract.validate_identity(bad)
        valid = {"requested_fraction": 0.74999, "actual_fraction": 0.75,
                 "total_memory": 100_000_000_000, "peak_reserved": 1}
        contract.validate_allocator(valid, peak=True)
        for key, value in (("actual_fraction", 0.750001), ("actual_fraction", float("nan")),
                           ("actual_fraction", "nan"), ("total_memory", 0), ("peak_reserved", 75_000_000_001)):
            bad = dict(valid, **{key: value})
            with self.assertRaises(ValueError):
                contract.validate_allocator(bad, peak=True)

    def test_official_soft_accuracy_and_pinned_bytes(self):
        evaluator = scorer.official_evaluator()
        for matches, expected in ((0, 0.0), (1, 0.3), (2, 0.6), (3, 0.9), (4, 1.0), (10, 1.0)):
            value = evaluator.eval_pred_list([{"pred_answer": "YES!", "gt_answers": ["yes"] * matches
                                               + ["no"] * (10 - matches)}])
            self.assertAlmostEqual(value, expected)
        self.assertEqual(evaluator.answer_processor("The TWO."), "2")

    def test_training_overlap_uses_actual_image_bytes(self):
        training_root = self.root / "training"
        training_root.mkdir()
        Image.new("RGB", (3, 2), (0, 255, 40)).save(training_root / "new.png")
        data = self.root / "train.jsonl"
        data.write_text(json.dumps({"images": ["new.png"], "messages": []}) + "\n", encoding="utf-8")
        result = scorer.held_out(data, contract.sha256_file(data), training_root, self.rows)
        self.assertTrue(result["held_out_from_supplied_sft_inputs"])
        (training_root / "new.png").write_bytes((self.images / "0.png").read_bytes())
        with self.assertRaises(ValueError):
            scorer.held_out(data, contract.sha256_file(data), training_root, self.rows)
        data.write_text(json.dumps({"images": ["../images/0.png"]}) + "\n", encoding="utf-8")
        with self.assertRaises(ValueError):
            scorer.held_out(data, contract.sha256_file(data), training_root, self.rows)

    def test_docker_exact_mounts_never_gt_parent(self):
        model = self.models / "gemma-3-4b-it"
        model.mkdir()
        identity_file = self.root / "identity.json"
        contract.write_json(identity_file, self.identity)
        args = SimpleNamespace(identity=str(identity_file), identity_sha256=contract.sha256_file(identity_file),
                               runtime_image=self.identity["runtime_image"], container_name="textvqa-fixture",
                               physical_card=0, uid=1001, gid=1002, model=str(model), adapter=None,
                               questions=str(self.questions), manifest=str(self.manifest), images_root=str(self.images),
                               api_evidence=str(self.api_file), out=str(self.root / "out"), model_alias="gemma3",
                               model_type="gemma3_vision", manifest_sha256=self.manifest_sha,
                               attn_impl=None, model_kwargs="{}", external_plugins=None,
                               lease_root=str(self.root / "textvqa-fixture"),
                               training_manifest=None, training_manifest_sha256=None)
        command = docker.command(args, "a" * 32)
        self.assertIn("genmlu.lease_id=" + "a" * 32, command)
        mounts = [command[i + 1] for i, word in enumerate(command) if word == "--mount"]
        self.assertIn("type=bind,source=" + str(self.questions) + ",target=" + str(self.questions) + ",readonly", mounts)
        self.assertFalse(any("source=" + str(self.root) + ",target=" in value for value in mounts))
        self.assertFalse((self.root / "out").exists())
        self.assertIn("none", command)
        self.assertIn("MLU_VISIBLE_DEVICES=0", command)
        self.assertIn("CNRT_VISIBLE_DEVICES=0", command)
        self.assertEqual(command[command.index("--cpus") + 1], "4")
        self.assertEqual(command[command.index("--pids-limit") + 1], "512")
        self.assertEqual(command[command.index("--memory-swap") + 1], "80g")
        self.assertEqual(command[command.index("--tmpfs") + 1], "/tmp:rw,exec,nosuid,nodev,size=2g")
        for value in ("OMP_NUM_THREADS=1", "MKL_NUM_THREADS=1", "OPENBLAS_NUM_THREADS=1",
                      "TRITON_CACHE_DIR=/tmp/triton", "TORCH_DEVICE_BACKEND_AUTOLOAD=0"):
            self.assertIn(value, command)
        for card in (1, 7):
            with self.subTest(physical_card=card):
                args.physical_card = card
                isolated = docker.command(args, "a" * 32)
                self.assertIn("MLU_VISIBLE_DEVICES=0", isolated)
                self.assertIn("CNRT_VISIBLE_DEVICES=0", isolated)
                devices = [isolated[i + 1] for i, item in enumerate(isolated) if item == "--device"]
                self.assertEqual(set(devices), {f"/dev/cambricon_dev{card}", "/dev/cambricon_ctl",
                                               f"/dev/cambricon_ipcm{card}", "/dev/cambricon_gdr"})
                self.assertNotIn(f"MLU_VISIBLE_DEVICES={card}", isolated)
                self.assertNotIn(f"CNRT_VISIBLE_DEVICES={card}", isolated)
        for card in (-1, 8, True):
            args.physical_card = card
            with self.subTest(invalid_card=card), self.assertRaises(ValueError):
                docker.command(args, "a" * 32)
        args.physical_card = 0
        args.out = str(model / "out")
        with self.assertRaises(ValueError):
            docker.command(args, "a" * 32)

    def test_all_five_shared_registry_routes_and_override_rejection(self):
        import os
        import shutil
        import subprocess
        bash = Path("C:/Program Files/Git/bin/bash.exe") if os.name == "nt" else Path(shutil.which("bash") or "/missing")
        if not bash.is_file():
            self.skipTest("Bash unavailable; registry shell route not exercised")
        models = self.root / "shell-models"
        binaries = self.root / "bin"
        models.mkdir()
        binaries.mkdir()
        executable = binaries / "python3"
        executable.write_text('#!/usr/bin/env bash\nprintf "%s\\n" "$@"\n', encoding="utf-8", newline="\n")
        executable.chmod(0o755)
        names = {"qwen": ("Qwen3-VL-8B-Instruct", "qwen3_vl"),
                 "gemma": ("gemma-3-4b-it", "gemma3_vision"),
                 "internvl": ("InternVL3_5-8B-HF", "internvl"),
                 "llava": ("LLaVA-OneVision-1.5-8B-Instruct", "llava_onevision1_5"),
                 "minicpm": ("MiniCPM-V-4.6", "minicpmv4_6")}
        environment = dict(os.environ, MODELS_DIR=models.as_posix(),
                           PATH=binaries.as_posix() + os.pathsep + os.environ["PATH"])
        script = RUNTIME.parent / "scripts/eval_textvqa.sh"
        for key, (folder, model_type) in names.items():
            (models / folder).mkdir()
            run = subprocess.run([str(bash), str(script), key, "freeze", "--out", "/fixture"],
                                 env=environment, text=True, encoding="utf-8", capture_output=True, timeout=30)
            self.assertEqual(run.returncode, 0, run.stderr)
            argv = run.stdout.splitlines()
            self.assertEqual(argv[argv.index("--model-type") + 1], model_type)
            self.assertEqual(argv[argv.index("--model") + 1], (models / folder).as_posix())
            alias = argv[argv.index("--model-alias") + 1]
            self.assertEqual(contract.REGISTRY[alias], (folder, model_type))
            self.assertEqual("--external_plugins" in argv, key == "llava")
        run = subprocess.run([str(bash), str(script), "gemma", "freeze", "--model=/foreign"],
                             env=environment, text=True, encoding="utf-8", capture_output=True, timeout=30)
        self.assertNotEqual(run.returncode, 0)
        self.assertIn("cannot be overridden", run.stderr)

    def test_freeze_explicit_base_and_adapter_metadata_not_directory_labels(self):
        model = self.models / "gemma-3-4b-it"
        model.mkdir()
        (model / "config.json").write_text("{}")
        (model / "model.safetensors").write_bytes(b"fixture only")
        args = SimpleNamespace(questions=self.questions, manifest=self.manifest, manifest_sha256=self.manifest_sha,
                               images_root=self.images, api_evidence=self.api_file, api_sha256=contract.sha256_file(self.api_file),
                               adapter=None, training_manifest=None, training_manifest_sha256=None,
                               model_alias="gemma3", model_type="gemma3_vision",
                               template="gemma", model=model, runtime_image=self.identity["runtime_image"],
                               processor_env="{}", attn_impl=None, model_kwargs="{}", external_plugins=None,
                               out=self.root / "base-identity")
        generate.freeze(args)
        base = contract.read_json(args.out / "identity.json")
        self.assertIsNone(base["adapter_tree_sha256"])
        self.assertEqual(base["model_tree_sha256"], contract.tree_sha256(model))
        adapter = self.root / "checkpoint-200"
        adapter.mkdir()
        config = {"base_model_name_or_path": str(model), "peft_type": "LORA", "r": 16,
                  "lora_alpha": 32, "target_modules": ["q_proj"]}
        contract.write_json(adapter / "adapter_config.json", config)
        (adapter / "adapter_model.safetensors").write_bytes(b"fixture only")
        args.adapter, args.training_manifest_sha256 = adapter, "7" * 64
        args.out = self.root / "missing-args"
        with self.assertRaises(ValueError):
            generate.freeze(args)
        saved = {"model": str(model), "model_type": "gemma3_vision", "template": "gemma",
                 "dataset": ["/pinned/training.jsonl"]}
        contract.write_json(adapter / "args.json", saved)
        provenance = {"schema": "vlm-textvqa-training-provenance-v1", "status": "accepted-qualified-training",
                      "model_alias": "gemma3", "model_type": "gemma3_vision", "template": "gemma",
                      "model_tree_sha256": contract.tree_sha256(model), "adapter_tree_sha256": contract.tree_sha256(adapter),
                      "checkpoint_args_sha256": contract.sha256_file(adapter / "args.json"),
                      "adapter_config_sha256": contract.sha256_file(adapter / "adapter_config.json"),
                      "base_model_name_or_path": str(model), "training_dataset": saved["dataset"],
                      "training_dataset_sha256": "7" * 64, "training_source_tree_sha256": "8" * 64,
                      "runtime_image": args.runtime_image,
                      "accepted_run": {"run_id": "accepted-fixture", "host_label": "mlu-10000", "global_step": 200,
                                       "report_sha256": "9" * 64, "identity_sha256": "a" * 64, "source_commit": "b" * 40}}
        args.training_manifest = self.root / "provenance.json"
        contract.write_json(args.training_manifest, provenance)
        args.training_manifest_sha256 = contract.sha256_file(args.training_manifest)
        args.out = self.root / "adapter-identity"
        generate.freeze(args)
        frozen = contract.read_json(args.out / "identity.json")
        self.assertEqual(frozen["adapter_tree_sha256"], contract.tree_sha256(adapter))
        self.assertEqual(frozen["training_provenance_sha256"], args.training_manifest_sha256)
        self.assertEqual(frozen["training_manifest_sha256"], "7" * 64)
        self.assertEqual(generate.bound_training(args, frozen), provenance)
        admitted = SimpleNamespace(**vars(args))
        admitted.identity = args.out / "identity.json"
        admitted.identity_sha256 = contract.sha256_file(admitted.identity)
        admitted.container_name, admitted.physical_card = "adapter-fixture", 0
        admitted.uid, admitted.gid = 1001, 1002
        admitted.lease_root, admitted.out = self.root / "lease", self.root / "generation"
        command = docker.command(admitted, "a" * 32)
        self.assertIn("type=bind,source=" + str(args.training_manifest) + ",target=" + str(args.training_manifest) + ",readonly",
                      command)
        self.assertIn("--training-manifest", command)
        actual_args = adapter / "args.json"
        original_args = actual_args.read_bytes()
        actual_args.unlink()
        args.out = self.root / "missing-original-args"
        with self.assertRaises(ValueError):
            generate.freeze(args)
        actual_args.write_bytes(original_args)
        original_manifest_sha = args.training_manifest_sha256
        args.training_manifest_sha256 = "f" * 64
        args.out = self.root / "wrong-provenance-file-sha"
        with self.assertRaises(ValueError):
            generate.freeze(args)
        args.training_manifest_sha256 = original_manifest_sha
        for field, value in (("status", "planned"), ("model_tree_sha256", "f" * 64),
                             ("adapter_tree_sha256", "f" * 64), ("checkpoint_args_sha256", "f" * 64),
                             ("adapter_config_sha256", "f" * 64), ("training_dataset", ["/wrong/data"]),
                             ("training_dataset_sha256", None), ("training_source_tree_sha256", None),
                             ("accepted_run", {}), ("base_model_name_or_path", "/wrong/model")):
            args.training_manifest.write_text(json.dumps(dict(provenance, **{field: value})), encoding="utf-8")
            args.training_manifest_sha256 = contract.sha256_file(args.training_manifest)
            args.out = self.root / ("wrong-provenance-" + field)
            with self.assertRaises(ValueError):
                generate.freeze(args)
            self.assertFalse(args.out.exists())

        args.training_manifest.write_text(json.dumps(provenance), encoding="utf-8")
        args.training_manifest_sha256 = contract.sha256_file(args.training_manifest)
        (adapter / "adapter_config.json").write_text("{}")
        empty = dict(provenance, adapter_config_sha256=contract.sha256_file(adapter / "adapter_config.json"),
                     adapter_tree_sha256=contract.tree_sha256(adapter))
        args.training_manifest.write_text(json.dumps(empty), encoding="utf-8")
        args.training_manifest_sha256 = contract.sha256_file(args.training_manifest)
        args.out = self.root / "empty-peft-config"
        with self.assertRaises(ValueError):
            generate.freeze(args)
        (adapter / "adapter_config.json").write_text(json.dumps(config), encoding="utf-8")
        provenance.update(adapter_config_sha256=contract.sha256_file(adapter / "adapter_config.json"),
                          adapter_tree_sha256=contract.tree_sha256(adapter))
        args.training_manifest.write_text(json.dumps(provenance), encoding="utf-8")
        args.training_manifest_sha256 = contract.sha256_file(args.training_manifest)
        wrong_config = dict(config, base_model_name_or_path="/foreign/gemma-3-4b-it")
        (adapter / "adapter_config.json").write_text(json.dumps(wrong_config), encoding="utf-8")
        wrong_base = dict(provenance, adapter_config_sha256=contract.sha256_file(adapter / "adapter_config.json"),
                          adapter_tree_sha256=contract.tree_sha256(adapter))
        args.training_manifest.write_text(json.dumps(wrong_base), encoding="utf-8")
        args.training_manifest_sha256 = contract.sha256_file(args.training_manifest)
        args.out = self.root / "wrong-config-base"
        with self.assertRaisesRegex(ValueError, "base model"):
            generate.freeze(args)
        (adapter / "adapter_config.json").write_text(json.dumps(config), encoding="utf-8")
        args.training_manifest.write_text(json.dumps(provenance), encoding="utf-8")
        args.training_manifest_sha256 = contract.sha256_file(args.training_manifest)
        for key, value in (("model_type", "wrong"), ("template", "wrong")):
            (adapter / "args.json").write_text(json.dumps(dict(saved, **{key: value})), encoding="utf-8")
            args.out = self.root / ("wrong-" + key)
            with self.assertRaises(ValueError):
                generate.freeze(args)
            self.assertFalse(args.out.exists())

    def test_direct_python_registry_overrides_fail_before_admission(self):
        for alias, (folder, model_type) in contract.REGISTRY.items():
            llava = alias == "llava-onevision1_5"
            args = SimpleNamespace(model=self.models / folder, model_alias=alias, model_type=model_type,
                                   attn_impl="eager" if llava else None,
                                   model_kwargs=json.dumps({"trust_remote_code": True} if llava else {}),
                                   external_plugins=str(contract.ROOT / "plugins/llava_onevision.py") if llava else None)
            contract.registry_policy(args, self.api["registry_templates"][alias], self.api)
        args = SimpleNamespace(model=self.models / "gemma-3-4b-it", model_alias="gemma3", model_type="gemma3_vision",
                               attn_impl=None, model_kwargs="{}", external_plugins=None,
                               api_evidence=self.api_file, identity=self.root / "direct-identity.json",
                               out=self.root / "never-created", adapter=None,
                               training_manifest=None, training_manifest_sha256=None)
        contract.write_json(args.identity, self.identity)
        args.identity_sha256 = contract.sha256_file(args.identity)
        for key, value in (("model", self.root / "foreign" / "gemma-3-4b-it"),
                           ("model", self.models / "Qwen3-VL-8B-Instruct"), ("model_type", "qwen3_vl"),
                           ("model_alias", "qwen3-vl"), ("attn_impl", "sdpa"),
                           ("model_kwargs", '{"trust_remote_code":true}'),
                           ("external_plugins", str(contract.ROOT / "plugins/llava_onevision.py"))):
            bad = SimpleNamespace(**dict(vars(args), **{key: value}))
            with self.assertRaises(ValueError):
                generate.generate(bad)
            self.assertFalse(args.out.exists())
        wrong = dict(self.identity, template="generic-chat")
        args.identity.write_text(json.dumps(wrong), encoding="utf-8")
        args.identity_sha256 = contract.sha256_file(args.identity)
        with self.assertRaisesRegex(ValueError, "native template"):
            generate.generate(args)
        with self.assertRaises(ValueError):
            contract.registry_policy(SimpleNamespace(**dict(vars(args), model_alias="llava-onevision1_5",
                                     model_type="llava_onevision1_5", model=self.models / "LLaVA-OneVision-1.5-8B-Instruct",
                                     attn_impl="eager", model_kwargs='{"trust_remote_code":true}')),
                                     self.api["registry_templates"]["llava-onevision1_5"], self.api)

    def test_production_versions_and_batch_parameter_are_enforced(self):
        versions = self.api["versions"]
        with patch.object(generate.metadata, "version", side_effect=versions.__getitem__):
            self.assertEqual(generate.installed_versions(), versions)
        for name in versions:
            bad = dict(versions, **{name: "unqualified"})
            with patch.object(generate.metadata, "version", side_effect=bad.__getitem__), \
                 patch("verify_environment.main") as imported:
                with self.assertRaisesRegex(ValueError, "package versions"):
                    generate.api_inventory(self.api["runtime_image"])
                imported.assert_not_called()
            with self.assertRaises(ValueError):
                contract.validate_api(dict(self.api, versions=bad))
        def engine(model, adapters, torch_dtype, model_type, device_map, model_kwargs,
                   attn_impl, template_type, max_batch_size=1):
            pass
        self.assertIn("max_batch_size", generate.engine_parameters(engine))
        def missing_batch(model, adapters, torch_dtype, model_type, device_map, model_kwargs,
                          attn_impl, template_type, **kwargs):
            pass
        with self.assertRaisesRegex(ValueError, "engine API"):
            generate.engine_parameters(missing_batch)
        with self.assertRaises(ValueError):
            contract.validate_api(dict(self.api, engine_parameters=sorted(contract.ENGINE_PARAMETERS - {"max_batch_size"})))

    def test_own_lease_parent_host_card_command_and_runner_source(self):
        import os
        root = self.root / "generative-mlu" / "mlu-10000" / "leased-run"
        root.mkdir(parents=True)
        active_dir = root.parent / ".leases"
        active_dir.mkdir()
        parent = self.root / "proc" / "321"
        parent.mkdir(parents=True)
        runner = self.root / "runner" / "src" / "genmlu" / "benchctl.py"
        runner.parent.mkdir(parents=True)
        runner.write_text("# frozen runner fixture\n", encoding="utf-8")
        argv = [str(RUNTIME / "textvqa_generate.py"), "docker", "--out", str(root / "generation")]
        child = ["python3", "-B", *argv]
        lease = {"schema_version": 2, "lease_id": "a" * 32, "pid": 321, "host": "node1", "host_label": "mlu-10000",
                 "run_id": root.name, "cards": [0], "project": "generative-mlu", "state": "running",
                 "returncode": None, "child_pgid": 654, "command": child, "requested_command": child,
                 "container_lease_label_required": True}
        paths = [root / "lease.json", active_dir / "cards-0.json"]
        for path in paths:
            contract.write_json(path, lease)
        (parent / "status").write_text("Uid:\t1001 1001 1001 1001\nState:\tS (sleeping)\n")
        parent_argv = ["python3", "-I", "-S", "-B", "-c", controller_bootstrap(str(runner.parents[1])),
                       "--output-root", str(self.root),
                       "--project", "generative-mlu", "run", "--host-label", "mlu-10000", "--cards", "0",
                       "--run-id", root.name, "--container-name", root.name,
                       "--sample-interval", "300", "--watch-interval", "15",
                       "--timeout-seconds", "3600", "--", *child]
        (parent / "cmdline").write_bytes(("\0".join(parent_argv) + "\0").encode())
        (parent / "environ").write_bytes(("PYTHONPATH=" + str(runner.parents[1]) + "\0").encode())
        args = SimpleNamespace(lease_root=str(root), physical_card=0, uid=1001, host_label="mlu-10000",
                               container_name=root.name, runner_source=str(runner),
                               runner_sha256=contract.sha256_file(runner), out=str(root / "generation"),
                               runner_deployment="fixture-deployment", runner_deployment_sha256="b" * 64)
        original_stat = Path.stat
        def owned_stat(path, *a, **kw):
            stat = list(original_stat(path, *a, **kw))
            stat[4] = 1001
            return os.stat_result(stat)
        with patch("textvqa_runner.validate_deployment", return_value={"import_root": str(runner.parents[1])}), \
             patch.object(docker.os, "readlink", return_value=str(runner.parents[1])), \
             patch.dict(os.environ, GENMLU_RUN_ID=root.name, GENMLU_LEASE_ID="a" * 32), \
             patch.object(Path, "stat", owned_stat), patch.object(docker.os, "getuid", return_value=1001, create=True), \
             patch.object(docker.os, "getppid", return_value=321), \
             patch.object(docker.os, "getpid", return_value=654), \
             patch.object(docker.os, "getpgid", return_value=654, create=True), \
             patch.object(docker.os, "kill"), patch.object(docker.socket, "gethostname", return_value="node1"), \
             patch.object(docker.sys, "argv", argv):
            receipt = docker.own_lease(args, self.root / "proc")
            self.assertEqual(receipt["host_label"], "mlu-10000")
            self.assertFalse((root / "generation").exists())
            for key in ("GENMLU_RUN_ID", "GENMLU_LEASE_ID"):
                with patch.dict(os.environ, {key: "wrong"}), self.assertRaises(ValueError):
                    docker.own_lease(args, self.root / "proc")
            for flag, value in (("--sample-interval", "0"), ("--watch-interval", "120"),
                                ("--timeout-seconds", "28801")):
                bad_argv = list(parent_argv)
                bad_argv[bad_argv.index(flag) + 1] = value
                (parent / "cmdline").write_bytes(("\0".join(bad_argv) + "\0").encode())
                with self.assertRaises(ValueError):
                    docker.own_lease(args, self.root / "proc")
            (parent / "cmdline").write_bytes(("\0".join(parent_argv) + "\0").encode())
            for key, value in (("state", "completed"), ("host", "node2"), ("host_label", "mlu-10001"),
                               ("cards", [1]), ("pid", 999), ("run_id", "foreign"),
                               ("command", ["python3", "foreign.py"]), ("child_pgid", 999),
                               ("lease_id", "b" * 32), ("container_lease_label_required", False)):
                bad = dict(lease, **{key: value})
                for path in paths:
                    path.write_text(json.dumps(bad), encoding="utf-8")
                with self.assertRaises(ValueError):
                    docker.own_lease(args, self.root / "proc")
            for path in paths:
                path.write_text(json.dumps(lease), encoding="utf-8")
            args.runner_sha256 = "f" * 64
            with self.assertRaises(ValueError):
                docker.own_lease(args, self.root / "proc")

    def test_existing_outputs_and_aliased_inputs_are_not_overwritten(self):
        existing = self.root / "existing"
        existing.mkdir()
        (existing / "marker").write_text("keep")
        with self.assertRaises(ValueError):
            contract.external_output(existing)
        self.assertEqual((existing / "marker").read_text(), "keep")
        with patch.object(Path, "is_symlink", return_value=True):
            with self.assertRaises(ValueError):
                self.validate()
        with self.assertRaises(ValueError):
            contract.external_output(self.images / "output", (self.images,))

    def test_full_score_fixture_and_tamper_rejected(self):
        annotations = {"dataset_type": "val", "dataset_version": "0.5.1", "data": []}
        for row in self.rows:
            native = dict(row, set_name="val", answers=["yes"] * 10)
            native["image_width"], native["image_height"] = native.pop("width"), native.pop("height")
            annotations["data"].append(native)
        annotations["data"] += [{"question_id": 10000 + i} for i in range(5000 - 64)]
        annotation_file, subset_file = self.root / "annotations.json", self.root / "subset.json"
        contract.write_json(annotation_file, annotations)
        selected = copy.deepcopy(annotations["data"][:64])
        for row in selected:
            row["image_path"] = "images/" + row["image_path"]
        contract.write_json(subset_file, {"data": selected})
        annotation_sha, subset_sha = contract.sha256_file(annotation_file), contract.sha256_file(subset_file)
        self.manifest_value.update(source_annotations_sha256=annotation_sha, source_subset_sha256=subset_sha)
        self.manifest.write_text(json.dumps(self.manifest_value), encoding="utf-8")
        self.manifest_sha = contract.sha256_file(self.manifest)
        self.identity["input_manifest_sha256"] = self.manifest_sha
        identity_file = self.root / "identity.json"
        contract.write_json(identity_file, self.identity)
        training_root = self.root / "training"
        training_root.mkdir()
        Image.new("RGB", (2, 2), (255, 255, 255)).save(training_root / "new.png")
        training_file = self.root / "training.jsonl"
        training_file.write_text('{"images":["new.png"]}\n', encoding="utf-8")
        run_root = self.root / "run"
        run_root.mkdir()
        records = self.records()
        predictions = run_root / "predictions.jsonl"
        predictions.write_text("\n".join(json.dumps(r) for r in records) + "\n", encoding="utf-8")
        with patch.multiple(contract, ANNOTATIONS_SHA=annotation_sha, SUBSET_SHA=subset_sha), \
             patch.multiple(scorer, ANNOTATIONS_SHA=annotation_sha, SUBSET_SHA=subset_sha):
            _, inputs = self.validate()
            run = {"schema": "vlm-textvqa-generation-v2", "status": "diagnostic_completed", "identity": self.identity,
                   "owned_execution_accepted": False,
                   "identity_sha256": contract.sha256_file(identity_file), "inputs": inputs, "api": self.api,
                   "predictions_sha256": contract.sha256_file(predictions), "question_ids": [r["question_id"] for r in self.rows],
                   "question_count": 64, "parameter_devices": ["mlu:0"], "adapter_active": False,
                   "allocator_before": {"requested_fraction": 0.75, "actual_fraction": 0.75,
                                        "total_memory": 100_000_000_000, "peak_reserved": 0},
                   "allocator_after": {"requested_fraction": 0.75, "actual_fraction": 0.75,
                                       "total_memory": 100_000_000_000, "peak_reserved": 100},
                   "claims": contract.FALSE_CLAIMS}
            execution = {"run_id": "fixture", "host": "node2", "host_label": "mlu-10001", "card": 0,
                         "uid": 1001, "lease_id": "fixture-lease", "lease_sha256": "4" * 64,
                         "runner_sha256": "5" * 64, "command_sha256": "6" * 64}
            contract.write_json(run_root / "execution.json", execution)
            run.update(execution=execution, execution_sha256=contract.sha256_file(run_root / "execution.json"))
            contract.write_json(run_root / "generation.json", run)
            args = SimpleNamespace(questions=self.questions, manifest=self.manifest, manifest_sha256=self.manifest_sha,
                                   images_root=self.images, identity=identity_file, identity_sha256=contract.sha256_file(identity_file),
                                   api_evidence=self.api_file, run_root=run_root, run_sha256=contract.sha256_file(run_root / "generation.json"),
                                   annotations=annotation_file, subset=subset_file, training_data=training_file,
                                   training_data_sha256=contract.sha256_file(training_file),
                                   training_images_root=training_root, out=self.root / "score",
                                   training_manifest=None, training_manifest_sha256=None)
            scorer.score(args)
            result = contract.read_json(args.out / "score.json")
            self.assertEqual(result["accuracy"], 1)
            self.assertEqual(result["question_count"], 64)
            self.assertFalse(result["claims"]["quality_accepted"])

            self.assertFalse(result["owned_execution_accepted"])
            self.assertEqual(result["status"], "diagnostic_completed")
            run_file = run_root / "generation.json"
            for key, value in (("schema", "planned"), ("status", "planned"),
                               ("status", "completed"),
                               ("question_count", 0), ("parameter_devices", ["cpu"]),
                               ("owned_execution_accepted", True),
                               ("claims", dict(contract.FALSE_CLAIMS, quality_accepted=True))):
                run_file.write_text(json.dumps(dict(run, **{key: value})), encoding="utf-8")
                args.run_sha256 = contract.sha256_file(run_file)
                args.out = self.root / ("reject-" + key)
                with self.assertRaises(ValueError):
                    scorer.score(args)
                self.assertFalse(args.out.exists())
            run_file.write_text(json.dumps(run), encoding="utf-8")
            args.run_sha256 = contract.sha256_file(run_file)
            predictions.write_text(predictions.read_text(encoding="utf-8").replace('"yes"', '"no"', 1), encoding="utf-8")
            args.out = self.root / "second"
            with self.assertRaises(ValueError):
                scorer.score(args)
            self.assertFalse(args.out.exists())


    def test_ground_truth_native_dimensions_and_aliases_are_strict(self):
        data = []
        for row in self.rows:
            native = dict(row, set_name="val", answers=["yes"] * 10)
            native["image_width"], native["image_height"] = native.pop("width"), native.pop("height")
            data.append(native)
        annotation = self.root / "native-annotations.json"
        subset = self.root / "native-subset.json"
        contract.write_json(annotation, {"dataset_type": "val", "dataset_version": "0.5.1",
                            "data": data + [{"question_id": 10000 + i} for i in range(4936)]})
        for change in ({}, {"image_width": 4}, {"image_height": False}, {"set_name": "train"}, {"width": 3}):
            selected = copy.deepcopy(data)
            selected[0].update(change)
            subset.write_text(json.dumps({"data": selected}), encoding="utf-8")
            with patch.multiple(scorer, ANNOTATIONS_SHA=contract.sha256_file(annotation),
                                SUBSET_SHA=contract.sha256_file(subset)):
                if change:
                    with self.assertRaises(ValueError):
                        scorer.ground_truth(annotation, subset, self.rows)
                else:
                    self.assertEqual(scorer.ground_truth(annotation, subset, self.rows), [["yes"] * 10] * 64)


class ForwardHooks(unittest.TestCase):
    def test_actual_hook_flow_and_restoration_on_error(self):
        class Tensor:
            device = "mlu:0"
            def is_floating_point(self):
                return True
        class Handle:
            removed = False
            def remove(self):
                self.removed = True
        class Module:
            def __init__(self):
                self.handles = []
            def generate(self):
                pass
            def modules(self):
                return [self]
            def register_forward_pre_hook(self, hook, with_kwargs=False):
                self.before = hook
                handle = Handle()
                self.handles.append(handle)
                return handle
            def register_forward_hook(self, hook):
                self.after = hook
                handle = Handle()
                self.handles.append(handle)
                return handle
        module = Module()
        torch = SimpleNamespace(Tensor=Tensor, isfinite=lambda t: SimpleNamespace(
            all=lambda: SimpleNamespace(item=lambda: True)))
        witness = generate.ForwardWitness(module, torch)
        try:
            module.before(module, (), {"input_ids": Tensor()})
            module.after(module, (), {"logits": Tensor()})
            self.assertEqual(witness.record(), {"calls": 1, "input_devices": ["mlu:0"],
                                               "output_devices": ["mlu:0"], "finite": True})
            raise RuntimeError("injected")
        except RuntimeError:
            pass
        finally:
            witness.close()
        self.assertTrue(all(h.removed for h in module.handles))


class InstalledSwiftAPI(unittest.TestCase):
    @unittest.skipUnless(all(importlib.util.find_spec(name) for name in ("swift", "torch", "torch_mlu")),
                         "actual pinned Swift/Torch MLU stack unavailable locally; not API-qualified")
    def test_installed_cpu_import_and_request_construction(self):
        inventory = generate.api_inventory("sha256:" + "3" * 64)
        self.assertEqual(inventory["versions"]["ms-swift"], "4.4.2")
        self.assertEqual(inventory["status"], "verified-cpu-import")
        self.assertIn("engine", inventory["sources"])
        self.assertIn("max_batch_size", inventory["engine_parameters"])
        self.assertEqual(set(inventory["registry_templates"]), set(contract.REGISTRY))


if __name__ == "__main__":
    unittest.main()
