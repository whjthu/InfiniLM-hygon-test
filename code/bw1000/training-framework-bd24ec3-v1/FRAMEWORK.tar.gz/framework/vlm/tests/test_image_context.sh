#!/usr/bin/env bash
set -euo pipefail

root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
temporary=$(mktemp -d)
image_id=
container_id=
cleanup() {
  status=$?
  [[ -z "$container_id" ]] || docker rm "$container_id" >/dev/null 2>&1 || true
  [[ -z "$image_id" ]] || docker image rm "$image_id" >/dev/null 2>&1 || true
  rm -rf -- "$temporary" || true
  exit "$status"
}
trap cleanup EXIT
mkdir -p "$temporary/context"/{runtime/reports,plugins/results,scripts,tests/models,outputs}
cp "$root/.dockerignore" "$temporary/context/.dockerignore"
printf 'FROM scratch\n' > "$temporary/context/Dockerfile"
awk '$1 == "WORKDIR" || $1 == "COPY"' "$root/Dockerfile" >> "$temporary/context/Dockerfile"
workdir=$(awk '$1 == "WORKDIR" { value = $2 } END { print value }' "$root/Dockerfile")
if [[ "$workdir" != /* ]]; then
  echo 'Dockerfile must declare an absolute WORKDIR' >&2
  exit 1
fi
image_path=${workdir#/}
printf 'usage\n' > "$temporary/context/README.md"
printf 'dependency\n' > "$temporary/context/requirements-mlu.txt"
printf 'pass\n' > "$temporary/context/runtime/verify_environment.py"
printf 'pass\n' > "$temporary/context/plugins/example.py"
printf 'true\n' > "$temporary/context/scripts/example.sh"
printf 'pass\n' > "$temporary/context/tests/test_example.py"
printf 'true\n' > "$temporary/context/tests/test_example.sh"
printf 'DUMMY=forbidden\n' > "$temporary/context/.env"
printf 'DUMMY=forbidden\n' > "$temporary/context/runtime/.env.private"
printf 'report\n' > "$temporary/context/runtime/reports/report.md"
printf 'result\n' > "$temporary/context/plugins/results/results.csv"
printf 'DUMMY=forbidden\n' > "$temporary/context/scripts/.env.private"
printf 'model\n' > "$temporary/context/tests/models/model.safetensors"
printf 'result\n' > "$temporary/context/tests/perf.json"
printf 'result\n' > "$temporary/context/outputs/result.csv"
printf 'weights\n' > "$temporary/context/model.safetensors"
printf 'report\n' > "$temporary/context/report.md"
image_id=$(docker build --network=none --quiet "$temporary/context")
container_id=$(docker create "$image_id" /bin/true)
docker export "$container_id" -o "$temporary/files.tar"
tar -tf "$temporary/files.tar" > "$temporary/files.txt"
grep -q "${image_path}/runtime/verify_environment.py$" "$temporary/files.txt"
grep -q "${image_path}/plugins/example.py$" "$temporary/files.txt"
grep -q "${image_path}/scripts/example.sh$" "$temporary/files.txt"
grep -q "${image_path}/tests/test_example.py$" "$temporary/files.txt"
grep -q "${image_path}/tests/test_example.sh$" "$temporary/files.txt"
if grep -Eq '(^|/)(\.env[^/]*|[^/]+\.(csv|json|safetensors)|report\.md)$' "$temporary/files.txt"; then
  echo 'Unapproved file reached the image' >&2
  exit 1
fi
printf 'Docker context sentinel test passed\n'
