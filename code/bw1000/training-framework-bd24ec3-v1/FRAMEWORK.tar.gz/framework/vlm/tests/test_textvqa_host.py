"""Host workflow contracts; no model or accelerator qualification."""

from types import SimpleNamespace
from pathlib import Path
import unittest
import tempfile
import json
import sys
import copy
import subprocess
import os
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "runtime"))
import textvqa_contract as c
import textvqa_runner as approval


from textvqa_host import bind_launcher, completed_lease, confirm_absent, recheck_inputs


class HostFinalizerTest(unittest.TestCase):
    def setUp(self):
        self.plan = {"run_id": "run", "host": "node1", "host_label": "mlu-10000",
                     "project": "generative-mlu", "cards": [0], "container_name": "genmlu-run",
                     "child_command": ["python3", "-B", "launcher.py"],
                     "created_at_utc": "2026-10-11T00:00:00+00:00"}
        self.lease = {**self.plan, "command": self.plan["child_command"],
                      "requested_command": self.plan["child_command"], "pid": 42, "lease_id": "a" * 32, "container_lease_label_required": True,
                      "containers": [{"name": "genmlu-run", "container_id": "b" * 64, "state": "exited", "last_pid": 77}],
                      "state": "completed", "returncode": 0, "container_names": ["genmlu-run"],
                      "started_at_utc": "2026-10-11T00:00:01+00:00",
                      "finished_at_utc": "2026-10-11T00:05:02+00:00",
                      "schema_version": 2, "timeout_seconds": 3600, "watch_interval_seconds": 15,
                      "preflight": {key: {"host": "node1", "cards": [0], "foreign_accelerator_processes": [],
                                          "card_states": [{"index": 0, "used_mib": 0, "utilization_percent": 0}],
                                          "checked_at_utc": stamp}
                                    for key, stamp in (("first", "2026-10-11T00:00:01+00:00"),
                                                       ("second", "2026-10-11T00:05:01+00:00"))}}

    def test_completed(self):
        completed_lease(self.plan, self.lease)

    def test_failed_running_and_boolean_returncode(self):
        for change in ({"state": "running"}, {"returncode": 1}, {"returncode": False}):
            with self.subTest(change=change), self.assertRaises(RuntimeError):
                completed_lease(self.plan, {**self.lease, **change})

    def test_command_and_replay(self):
        for change in ({"command": ["forged"]}, {"run_id": "older"}, {"cards": [1]},
                       {"host": "node2"}, {"container_names": ["other"]}):
            with self.subTest(change=change), self.assertRaises(RuntimeError):
                completed_lease(self.plan, {**self.lease, **change})

    def test_post_run_and_naive_descriptor(self):
        for created in ("2026-10-11T00:00:03+00:00", "2026-10-11T00:00:00"):
            with self.subTest(created=created), self.assertRaises(RuntimeError):
                completed_lease({**self.plan, "created_at_utc": created}, self.lease)

    def test_cleanup_unknown_or_present(self):
        for code, stderr in ((0, ""), (1, "permission denied"), (1, "daemon unavailable")):
            with self.subTest(stderr=stderr), self.assertRaises(RuntimeError):
                confirm_absent("container", "run", lambda *a, **kw: SimpleNamespace(
                    returncode=code, stdout="", stderr=stderr))

    def test_other_owned_container(self):
        calls = iter([SimpleNamespace(returncode=1, stdout="", stderr="error: no such object: container"),
                      SimpleNamespace(returncode=0, stdout="still-owned", stderr="")])
        with self.assertRaises(RuntimeError):
            confirm_absent("container", "run", lambda *a, **kw: next(calls))

    def test_absent(self):
        calls = iter([SimpleNamespace(returncode=1, stdout="", stderr="Error: No Such Object: container"),
                      SimpleNamespace(returncode=0, stdout="", stderr="")])
        confirm_absent("container", "run", lambda *a, **kw: next(calls))

    def test_docker_inspect_empty_array_is_absent(self):
        calls = iter([SimpleNamespace(returncode=1, stdout="[]\n",
                                     stderr="error: no such object: container"),
                      SimpleNamespace(returncode=0, stdout="", stderr="")])
        confirm_absent("container", "run", lambda *a, **kw: next(calls))
        with self.assertRaises(RuntimeError):
            confirm_absent("container", "run", lambda *a, **kw: SimpleNamespace(
                returncode=1, stdout="[{}]", stderr="error: no such object: container"))

    def test_mixed_or_other_object_error(self):
        for error in ("error: no such object: container\ndaemon unavailable",
                      "error: no such object: other"):
            with self.subTest(error=error), self.assertRaises(RuntimeError):
                confirm_absent("container", "run", lambda *a, **kw: SimpleNamespace(
                    returncode=1, stdout="", stderr=error))

    def test_boolean_card_rejected(self):
        with self.assertRaises(RuntimeError):
            completed_lease(self.plan, {**self.lease, "cards": [False]})

    def test_launcher_binding(self):
        fields = ("model", "identity", "identity_sha256", "questions", "manifest", "manifest_sha256",
                  "images_root", "api_evidence", "run_root", "container_name", "uid", "gid",
                  "host_label", "runner_source", "runner_sha256", "runner_deployment", "runner_deployment_sha256", "image")
        plan = {**self.plan, **{key: key for key in fields}}
        args = {key: plan[key] for key in fields if key not in ("run_root", "image")}
        args.update(command="docker", runtime_image=plan["image"], lease_root=plan["run_root"],
                    physical_card=0, out=str(Path("run_root") / "generation"), adapter=None,
                    training_manifest=None, training_manifest_sha256=None)
        bind_launcher(plan, SimpleNamespace(**args))
        for key in ("questions", "out", "uid", "runtime_image", "lease_root", "command"):
            with self.subTest(key=key), self.assertRaises(RuntimeError):
                bind_launcher(plan, SimpleNamespace(**{**args, key: "changed"}))

    def test_input_change_is_rejected(self):
        plan = {"identity": "identity", "identity_sha256": "pin", "api_evidence": "api",
                "model": "model", "questions": "questions", "manifest": "manifest",
                "manifest_sha256": "pin", "images_root": "images"}
        identity = {"api_evidence_sha256": "api-pin", "model_tree_sha256": "model-pin"}
        for changed in ("model", "images"):
            c = SimpleNamespace(read_json=lambda path, pin: identity if path == "identity" else {},
                                tree_sha256=lambda path: "changed" if changed == "model" else "model-pin",
                                validate_inputs=lambda *a: ([], {"pin": "changed" if changed == "images" else "ok"}))
            with self.subTest(changed=changed), self.assertRaises(RuntimeError):
                recheck_inputs(c, plan, identity, {}, {"pin": "ok"})

    def test_missing_nonce_or_registered_container_is_rejected(self):
        for change in ({"container_lease_label_required": False}, {"lease_id": "old"},
                       {"containers": []}, {"containers": [{"name": "genmlu-run", "state": "declared"}]},
                       {"containers": [{"name": "other", "container_id": "b" * 64,
                                        "state": "exited", "last_pid": 77}]}):
            with self.subTest(change=change), self.assertRaises(RuntimeError):
                completed_lease(self.plan, {**self.lease, **change})

    def test_idle_interval_resource_policy_and_old_schema_rejected(self):
        for change in ({"schema_version": 1}, {"schema_version": True}, {"preflight": {}},
                       {"timeout_seconds": False}, {"watch_interval_seconds": 120}):
            with self.subTest(change=change), self.assertRaises(RuntimeError):
                completed_lease(self.plan, {**self.lease, **change})
        for field, value in (("checked_at_utc", "2026-10-11T00:00:02+00:00"),
                             ("foreign_accelerator_processes", [{"pid": 9}]), ("cards", [False])):
            changed = copy.deepcopy(self.lease)
            changed["preflight"]["second"][field] = value
            with self.subTest(field=field), self.assertRaises(RuntimeError):
                completed_lease(self.plan, changed)


class RunnerApprovalTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.package = self.root / "source/genmlu"
        self.package.mkdir(parents=True)
        actual = Path(__file__).resolve().parents[2] / "generation/src/genmlu"
        for name in approval.RELEASE_FILES:
            (self.package / name).write_bytes((actual / name).read_bytes())
        self.runner = self.package / "benchctl.py"
        self.manifest = self.root / "deployment.json"
        approval.freeze_deployment(self.runner, self.manifest)
        self.pin = c.sha256_file(self.manifest)

    def test_actual_reviewed_controller_inventory(self):
        value = approval.validate_deployment(self.manifest, self.pin, self.runner)
        self.assertEqual(value["release_commit"], approval.RELEASE_COMMIT)
        self.assertEqual(value["files"], approval.RELEASE_FILES)

    @unittest.skipUnless(os.name == "posix", "isolated POSIX host bootstrap requires Linux")
    def test_bootstrap_ignores_shadow_cwd_and_pythonpath(self):
        shadow = self.root / "shadow"
        (shadow / "genmlu").mkdir(parents=True)
        (shadow / "genmlu/__init__.py").write_text("raise RuntimeError('shadow imported')")
        (shadow / "sitecustomize.py").write_text("raise RuntimeError('site imported')")
        run = subprocess.run([sys.executable, "-I", "-S", "-B", "-c",
                              approval.controller_bootstrap(self.runner.parents[1]), "--help"],
                             cwd=shadow, env={**os.environ, "PYTHONPATH": str(shadow)},
                             text=True, capture_output=True, timeout=30)
        self.assertEqual(run.returncode, 0, run.stderr)
        self.assertIn("preflight", run.stdout)
        self.assertNotIn("shadow imported", run.stderr)

    @unittest.skipUnless(os.name == "posix", "isolated POSIX host bootstrap requires Linux")
    def test_bootstrap_rejects_unapproved_file_before_import(self):
        marker = self.root / "executed"
        self.runner.write_text("from pathlib import Path\nPath(" + repr(str(marker)) + ").touch()\n")
        run = subprocess.run([sys.executable, "-I", "-S", "-B", "-c",
                              approval.controller_bootstrap(self.runner.parents[1]), "--help"],
                             text=True, capture_output=True, timeout=30)
        self.assertNotEqual(run.returncode, 0)
        self.assertIn("controller source differs", run.stderr)
        self.assertFalse(marker.exists())

    def test_unknown_source_cannot_approve_itself(self):
        self.runner.write_text("# unrelated runner\n")
        value = c.read_json(self.manifest)
        value["files"]["benchctl.py"] = c.sha256_file(self.runner)
        self.manifest.write_text(json.dumps(value))
        with self.assertRaisesRegex(ValueError, "reviewed release"):
            approval.validate_deployment(self.manifest, c.sha256_file(self.manifest), self.runner)

    def test_manifest_replacement_and_missing_source_rejected(self):
        value = c.read_json(self.manifest)
        for key, changed in (("release_commit", "0" * 40), ("runner_source", "/foreign/benchctl.py"),
                             ("import_root", "/foreign"), ("schema", "planned")):
            with self.subTest(key=key):
                self.manifest.write_text(json.dumps({**value, key: changed}))
                with self.assertRaises(ValueError):
                    approval.validate_deployment(self.manifest, c.sha256_file(self.manifest), self.runner)
        self.manifest.write_text(json.dumps(value))
        with self.assertRaises(ValueError):
            approval.validate_deployment(self.manifest, self.pin, self.runner)
        (self.package / "lease.py").unlink()
        with self.assertRaises(ValueError):
            approval.validate_deployment(self.manifest, c.sha256_file(self.manifest), self.runner)


if __name__ == "__main__":
    unittest.main()
