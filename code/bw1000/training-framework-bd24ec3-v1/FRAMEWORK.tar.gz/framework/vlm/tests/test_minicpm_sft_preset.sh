#!/usr/bin/env bash

set -euo pipefail

root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
tmp=$(mktemp -d)
trap 'rm -rf "${tmp}"' EXIT

case_root="${tmp}/case with spaces"
models="${case_root}/models"
outputs="${case_root}/outputs"
mkdir -p "${models}/MiniCPM-V-4.6" "${models}/Qwen3-VL-8B-Instruct" "${outputs}" "${tmp}/bin" "${case_root}/data"
printf '%s\n' '{"architectures":["MiniCPMV"]}' > "${models}/MiniCPM-V-4.6/config.json"
printf '%s\n' 'test-weight' > "${models}/MiniCPM-V-4.6/model.safetensors"
printf '%s\n' '{}' > "${case_root}/data/dataset.jsonl"
manifest="${tmp}/minicpm-identity.json"
python3 "${root}/runtime/verify_minicpm_identity.py" \
  --model-path "${models}/MiniCPM-V-4.6" --write-manifest "${manifest}"

printf '%s\n' '#!/usr/bin/env bash' \
  'printf '\''%s\0'\'' "$@" > "${FAKE_SWIFT_ARGS:?}"' \
  'printf '\''%s\n'\'' "${NPROC_PER_NODE-}" "${NNODES-}" "${NODE_RANK-}" > "${FAKE_SWIFT_DISTRIBUTED_ENV:?}"' \
  > "${tmp}/bin/swift"
printf '%s\n' '#!/usr/bin/env bash' 'env | LC_ALL=C sort > "${FAKE_DOCKER_ENV:?}"' 'printf '\''%s\n'\'' "$@" > "${FAKE_DOCKER_ARGS:?}"' > "${tmp}/bin/docker"
printf '%s\n' '#!/usr/bin/env bash' 'case "$1" in -u) echo 1001 ;; -g) echo 1002 ;; -G) echo "1002 1234" ;; *) exit 2 ;; esac' > "${tmp}/bin/id"
chmod +x "${tmp}/bin/swift" "${tmp}/bin/docker" "${tmp}/bin/id"

export PATH="${tmp}/bin:${PATH}"
export MODELS_DIR="${models}"
export FAKE_SWIFT_ARGS="${tmp}/swift.args"
export FAKE_SWIFT_DISTRIBUTED_ENV="${tmp}/swift.distributed.env"
export FAKE_DOCKER_ARGS="${tmp}/docker.args"
export FAKE_DOCKER_ENV="${tmp}/docker.env"

run_preset() {
  local output=${1:?output is required}
  shift
  env -u MINICPM_PRESET_GRADIENT_CHECKPOINTING \
    MINICPM_SFT_PRESET=qualified-gc-25 \
    MINICPM_STRICT_IDENTITY=true MINICPM_IDENTITY_MANIFEST="${manifest}" \
    DATASET="${case_root}/data/dataset.jsonl" OUTPUT_DIR="${outputs}/${output}" \
    "$@" bash "${root}/scripts/train_sft.sh" minicpm
}

assert_exact_argv() {
  local expected_gc=${1:?expected gradient checkpointing value is required}
  python3 - "${FAKE_SWIFT_ARGS}" "${models}/MiniCPM-V-4.6" \
    "${case_root}/data/dataset.jsonl" "${2}" "${expected_gc}" <<'PY'
from pathlib import Path
import sys

actual = [item.decode() for item in Path(sys.argv[1]).read_bytes().split(b"\0") if item]
expected = [
    "sft", "--model", sys.argv[2], "--model_type", "minicpmv4_6",
    "--template", "minicpmv4_6", "--dataset", sys.argv[3],
    "--output_dir", sys.argv[4], "--add_version", "false", "--no_check_model",
    "--torch_dtype", "bfloat16", "--max_length", "4096", "--max_pixels", "262144",
    "--tuner_type", "lora", "--target_modules", "all-linear", "--lora_rank", "16",
    "--lora_alpha", "32", "--lora_dropout", "0.05",
    "--per_device_train_batch_size", "1", "--gradient_accumulation_steps", "4",
    "--learning_rate", "0.0001", "--max_grad_norm", "1.0", "--warmup_steps", "5",
    "--lr_scheduler_type", "cosine", "--optim", "adamw_torch", "--adam_beta1", "0.9",
    "--adam_beta2", "0.95", "--adam_epsilon", "1e-08", "--weight_decay", "0.1",
    "--gradient_checkpointing", sys.argv[5], "--freeze_vit", "true",
    "--freeze_aligner", "true", "--freeze_llm", "false",
    "--vit_gradient_checkpointing", "false", "--dataloader_num_workers", "4",
    "--split_dataset_ratio", "0.0", "--dataset_shuffle", "true",
    "--dataloader_drop_last", "false", "--packing", "false", "--padding_free", "false",
    "--padding_side", "right", "--seed", "42", "--data_seed", "42",
    "--max_steps", "25", "--save_strategy", "steps", "--save_steps", "10",
    "--save_total_limit", "3", "--logging_steps", "1", "--report_to", "none",
]
assert actual == expected, (actual, expected)
PY
  mapfile -t distributed < "${FAKE_SWIFT_DISTRIBUTED_ENV}"
  [[ "${distributed[*]}" == "8 1 0" ]] || {
    echo "Swift distributed environment differs from the single-host preset" >&2
    exit 1
  }
}

run_preset default-off env
assert_exact_argv false "${outputs}/default-off"
run_preset explicit-on env MINICPM_PRESET_GRADIENT_CHECKPOINTING=true
assert_exact_argv true "${outputs}/explicit-on"
run_preset explicit-single-node env NNODES=1 NODE_RANK=0
assert_exact_argv false "${outputs}/explicit-single-node"

env -u DATASET MINICPM_SFT_PRESET=qualified-gc-25 MINICPM_STRICT_IDENTITY=true \
  MINICPM_IDENTITY_MANIFEST="${manifest}" OUTPUT_DIR="${outputs}/positional-dataset" \
  bash "${root}/scripts/train_sft.sh" minicpm "${case_root}/data/dataset.jsonl"
assert_exact_argv false "${outputs}/positional-dataset"

env -u MINICPM_STRICT_IDENTITY -u MINICPM_IDENTITY_MANIFEST \
  MINICPM_SFT_PRESET=qualified-gc-25 DATASET="${case_root}/data/dataset.jsonl" \
  OUTPUT_DIR="${outputs}/identity-opt-in" bash "${root}/scripts/train_sft.sh" minicpm
assert_exact_argv false "${outputs}/identity-opt-in"

env -u MINICPM_SFT_PRESET -u MINICPM_PRESET_GRADIENT_CHECKPOINTING \
  MINICPM_STRICT_IDENTITY=true MINICPM_IDENTITY_MANIFEST="${manifest}" \
  DATASET="${case_root}/data/dataset.jsonl" OUTPUT_DIR="${outputs}/generic-unset" \
  bash "${root}/scripts/train_sft.sh" minicpm
[[ -s "${FAKE_SWIFT_ARGS}" ]] || { echo "Generic MiniCPM path did not run when preset was unset" >&2; exit 1; }

reject_train() {
  rm -f "${FAKE_SWIFT_ARGS}"
  if "$@" >/dev/null 2>&1; then
    echo "rejected preset invocation unexpectedly succeeded" >&2
    exit 1
  fi
  [[ ! -e "${FAKE_SWIFT_ARGS}" ]] || { echo "Swift ran after preset rejection" >&2; exit 1; }
}

common=(env MINICPM_SFT_PRESET=qualified-gc-25 MINICPM_STRICT_IDENTITY=true
  MINICPM_IDENTITY_MANIFEST="${manifest}" DATASET="${case_root}/data/dataset.jsonl")
reject_train "${common[@]}" OUTPUT_DIR="${outputs}/wrong-model" bash "${root}/scripts/train_sft.sh" qwen
reject_train env MINICPM_SFT_PRESET=unknown MINICPM_STRICT_IDENTITY=true \
  MINICPM_IDENTITY_MANIFEST="${manifest}" DATASET=x OUTPUT_DIR="${outputs}/unknown" \
  bash "${root}/scripts/train_sft.sh" minicpm
reject_train env MINICPM_SFT_PRESET= MINICPM_STRICT_IDENTITY=true \
  MINICPM_IDENTITY_MANIFEST="${manifest}" DATASET=x OUTPUT_DIR="${outputs}/empty-preset" \
  bash "${root}/scripts/train_sft.sh" minicpm
reject_train "${common[@]}" OUTPUT_DIR="${outputs}/extra" \
  bash "${root}/scripts/train_sft.sh" minicpm --learning_rate 2e-4
for extra in --callbacks --external_plugins --config-file --max_step; do
  reject_train "${common[@]}" OUTPUT_DIR="${outputs}/extra-${extra#--}" \
    bash "${root}/scripts/train_sft.sh" minicpm "${extra}" value
done
for extra in --resume_from_checkpoint --resume_only_model --adapters --load_args; do
  reject_train "${common[@]}" OUTPUT_DIR="${outputs}/resume-argument-${extra#--}" \
    bash "${root}/scripts/train_sft.sh" minicpm "${extra}" value
done
reject_train "${common[@]}" MAX_STEPS=26 OUTPUT_DIR="${outputs}/override" \
  bash "${root}/scripts/train_sft.sh" minicpm
reject_train "${common[@]}" GRADIENT_CHECKPOINTING=true OUTPUT_DIR="${outputs}/generic-gc" \
  bash "${root}/scripts/train_sft.sh" minicpm
reject_train "${common[@]}" RESUME_FROM_CHECKPOINT=/checkpoint-10 OUTPUT_DIR="${outputs}/resume" \
  bash "${root}/scripts/train_sft.sh" minicpm
reject_train "${common[@]}" MINICPM_PRESET_GRADIENT_CHECKPOINTING=yes OUTPUT_DIR="${outputs}/bad-gc" \
  bash "${root}/scripts/train_sft.sh" minicpm
reject_train "${common[@]}" MINICPM_PRESET_GRADIENT_CHECKPOINTING= OUTPUT_DIR="${outputs}/empty-gc" \
  bash "${root}/scripts/train_sft.sh" minicpm
for specification in NNODES=2 NNODES=1:2 NODE_RANK=1 WORLD_SIZE=8 RANK=0 LOCAL_RANK=0 LOCAL_WORLD_SIZE=8; do
  reject_train "${common[@]}" "${specification}" OUTPUT_DIR="${outputs}/distributed-${specification%%=*}" \
    bash "${root}/scripts/train_sft.sh" minicpm
done

fixed=(
  MAX_STEPS=25 SAVE_STEPS=10 SAVE_TOTAL_LIMIT=3 LOGGING_STEPS=1 REPORT_TO=none
  MAX_LENGTH=4096 MAX_PIXELS=262144 PER_DEVICE_TRAIN_BATCH_SIZE=1
  GRADIENT_ACCUMULATION_STEPS=4 LEARNING_RATE=0.0001 WARMUP_STEPS=5 MAX_GRAD_NORM=1.0
  FREEZE_VIT=true FREEZE_ALIGNER=true FREEZE_LLM=false VIT_GRADIENT_CHECKPOINTING=false
  DATALOADER_NUM_WORKERS=4 TUNER_TYPE=lora TARGET_MODULES=all-linear LORA_RANK=16
  LORA_ALPHA=32 LORA_DROPOUT=0.05 TORCH_DTYPE=bfloat16 SPLIT_DATASET_RATIO=0.0
  DATA_SEED=42 LR_SCHEDULER_TYPE=cosine OPTIM=adamw_torch ADAM_BETA1=0.9 ADAM_BETA2=0.95
  ADAM_EPSILON=1e-08 WEIGHT_DECAY=0.1 SEED=42 DATASET_SHUFFLE=true
  DATALOADER_DROP_LAST=false PACKING=false PADDING_FREE=false PADDING_SIDE=right
  TEMPLATE=minicpmv4_6 ADD_VERSION=false SAVE_STRATEGY=steps
)
run_preset exact-fixed env "${fixed[@]}"
assert_exact_argv false "${outputs}/exact-fixed"
for specification in "${fixed[@]}"; do
  name=${specification%%=*}
  reject_train "${common[@]}" "${name}=__conflict__" OUTPUT_DIR="${outputs}/conflict-${name}" \
    bash "${root}/scripts/train_sft.sh" minicpm
done
reject_train "${common[@]}" MAX_STEPS= OUTPUT_DIR="${outputs}/empty-fixed" \
  bash "${root}/scripts/train_sft.sh" minicpm
for name in VAL_DATASET NUM_TRAIN_EPOCHS WARMUP_RATIO AVERAGE_TOKENS_ACROSS_DEVICES \
  RAY_SWIFT_ARGS SWIFT_ARGS SWIFT_SFT_ARGS; do
  reject_train "${common[@]}" "${name}=value" OUTPUT_DIR="${outputs}/forbidden-${name}" \
    bash "${root}/scripts/train_sft.sh" minicpm
done
reject_train "${common[@]}" NPROC_PER_NODE=7 OUTPUT_DIR="${outputs}/seven-ranks" \
  bash "${root}/scripts/train_sft.sh" minicpm
reject_train "${common[@]}" MLU_VISIBLE_DEVICES=0,1,2,3,4,5,6 OUTPUT_DIR="${outputs}/seven-devices" \
  bash "${root}/scripts/train_sft.sh" minicpm
reject_train "${common[@]}" MLU_VISIBLE_DEVICES=0,1,2,3,4,5,6,6 OUTPUT_DIR="${outputs}/duplicate-devices" \
  bash "${root}/scripts/train_sft.sh" minicpm

rm -f "${FAKE_DOCKER_ARGS}"
MINICPM_SFT_PRESET=qualified-gc-25 MINICPM_PRESET_GRADIENT_CHECKPOINTING=true \
MINICPM_STRICT_IDENTITY=true MINICPM_IDENTITY_MANIFEST="${manifest}" \
IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 DATASET="${case_root}/data/dataset.jsonl" \
DATA_MOUNT_ROOT="${case_root}/data" MODELS_DIR="${models}" OUTPUT_DIR="${outputs}/docker" \
bash "${root}/scripts/docker_run.sh" bash scripts/train_sft.sh minicpm
for name in MINICPM_SFT_PRESET MINICPM_PRESET_GRADIENT_CHECKPOINTING MINICPM_STRICT_IDENTITY MINICPM_IDENTITY_MANIFEST; do
  grep -qx "${name}" "${FAKE_DOCKER_ARGS}"
done
grep -qx 'MINICPM_SFT_PRESET=qualified-gc-25' "${FAKE_DOCKER_ENV}"
grep -qx 'MINICPM_PRESET_GRADIENT_CHECKPOINTING=true' "${FAKE_DOCKER_ENV}"

for specification in WARMUP_STEPS=6 MAX_GRAD_NORM=2.0 FREEZE_ALIGNER=false \
  FREEZE_LLM=true VIT_GRADIENT_CHECKPOINTING=true SAVE_STRATEGY=epoch NNODES=2 \
  MINICPM_SFT_PRESET= MINICPM_PRESET_GRADIENT_CHECKPOINTING=; do
  rm -f "${FAKE_DOCKER_ARGS}"
  if env MINICPM_SFT_PRESET=qualified-gc-25 MINICPM_STRICT_IDENTITY=true \
    MINICPM_IDENTITY_MANIFEST="${manifest}" "${specification}" IMAGE=test-image \
    MLU_DOCKER_SKIP_DEVICE_CHECK=1 MODELS_DIR="${models}" \
    bash "${root}/scripts/docker_run.sh" bash -lc true >/dev/null 2>&1; then
    echo "Docker accepted preset override ${specification}" >&2
    exit 1
  fi
  [[ ! -e "${FAKE_DOCKER_ARGS}" ]] || { echo "Docker ran after preset rejection" >&2; exit 1; }
done

echo "MiniCPM SFT preset tests passed"
