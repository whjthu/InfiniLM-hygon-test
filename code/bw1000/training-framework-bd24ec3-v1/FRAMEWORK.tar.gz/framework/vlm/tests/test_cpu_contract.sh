#!/usr/bin/env bash

set -euo pipefail

root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
source "${root}/runtime/common.sh"
tmp=$(mktemp -d)
trap 'rm -rf "${tmp}"' EXIT
grep -qx 'CMD \["bash"\]' "${root}/Dockerfile"
if grep -q '^ENTRYPOINT' "${root}/Dockerfile"; then
  echo "Dockerfile must not wrap user commands with an ENTRYPOINT" >&2
  exit 1
fi
for requirement in ms-swift==4.4.2 transformers==5.12.1 peft==0.19.1 accelerate==1.14.0 tokenizers==0.22.2 qwen-vl-utils[decord]==0.0.14 safetensors==0.8.0 av==17.1.0 timm==1.0.28; do
  grep -qxF "${requirement}" "${root}/requirements-mlu.txt"
done
grep -q -- '--no-deps' "${root}/Dockerfile"
grep -q 'verify_environment.py' "${root}/Dockerfile"
grep -qx 'EXPECTED_TORCH = "2.6.0+cpu"' "${root}/runtime/verify_environment.py"
grep -q 'from swift import SftArguments' "${root}/runtime/verify_environment.py"
grep -q 'HfArgumentParser(SftArguments)' "${root}/runtime/verify_environment.py"
python3 - <<'PY'
from dataclasses import dataclass

from transformers import HfArgumentParser


@dataclass
class Arguments:
    output_dir: str
    resume_from_checkpoint: str | None = None


parser = HfArgumentParser(Arguments)
for option in ("--output_dir", "--output-dir", "--output_d", "--output-d"):
    parsed, = parser.parse_args_into_dataclasses([option, "/unsafe"])
    assert parsed.output_dir == "/unsafe", option
parsed, = parser.parse_args_into_dataclasses(
    ["--output_dir", "/new-output", "--resume_from_checkpoint", "/checkpoint-100"]
)
assert parsed.resume_from_checkpoint == "/checkpoint-100"
PY
models="${tmp}/models"
outputs="${tmp}/outputs"
mkdir -p "${models}" "${outputs}" "${tmp}/bin"

for directory in Qwen3-VL-8B-Instruct gemma-3-4b-it InternVL3_5-8B-HF LLaVA-OneVision-1.5-8B-Instruct MiniCPM-V-4.6; do
  mkdir -p "${models}/${directory}"
done
printf '%s\n' '{"architectures":["MiniCPMV"]}' > "${models}/MiniCPM-V-4.6/config.json"
printf '%s\n' 'test-weight' > "${models}/MiniCPM-V-4.6/model-00001.safetensors"
minicpm_identity_manifest="${tmp}/minicpm-identity.json"
python3 - "${root}" "${models}/MiniCPM-V-4.6" "${minicpm_identity_manifest}" <<'PY'
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
model = Path(sys.argv[2])
sys.path.insert(0, str(root / "runtime"))
import verify_minicpm_identity as identity

Path(sys.argv[3]).write_text(json.dumps({
    "schema_version": 1,
    "scope": "minicpm_wrapper_and_model_weights_only",
    "wrapper_files": identity.wrapper_file_hashes(root),
    "model": {
        "directory": model.name,
        "config_sha256": identity.sha256_file(model / "config.json"),
        "tree_sha256": identity.tree_sha256(model),
    },
}), encoding="utf-8")
PY

printf '%s\n' '#!/usr/bin/env bash' 'printf '\''%s\0'\'' "$@" > "${FAKE_SWIFT_ARGS:?}"' 'printf '\''%s\n'\'' "${PYTHONHASHSEED:-}" > "${FAKE_SWIFT_HASH_SEED:?}"' > "${tmp}/bin/swift"
printf '%s\n' '#!/usr/bin/env bash' 'env | LC_ALL=C sort > "${FAKE_DOCKER_ENV:?}"' 'printf '\''%s\n'\'' "$@" > "${FAKE_DOCKER_ARGS:?}"' > "${tmp}/bin/docker"
printf '%s\n' '#!/usr/bin/env bash' 'case "$1" in -u) echo 1001 ;; -g) echo 1002 ;; -G) echo "1002 1234 4567" ;; *) exit 2 ;; esac' > "${tmp}/bin/id"
chmod +x "${tmp}/bin/swift" "${tmp}/bin/docker" "${tmp}/bin/id"

export PATH="${tmp}/bin:${PATH}"
export MODELS_DIR="${models}"
export FAKE_SWIFT_ARGS="${tmp}/swift.args"
export FAKE_SWIFT_HASH_SEED="${tmp}/swift.hash-seed"
export FAKE_DOCKER_ENV="${tmp}/docker.env"
export FAKE_DOCKER_ARGS="${tmp}/docker.args"

checkpoint="${tmp}/resume-source/checkpoint-100"
mkdir -p "${checkpoint}"
: > "${checkpoint}/trainer_state.json"
: > "${checkpoint}/adapter_model.safetensors"
: > "${checkpoint}/optimizer.pt"
: > "${checkpoint}/scheduler.pt"
for rank in {0..7}; do
  : > "${checkpoint}/rng_state_${rank}.pth"
done

assert_gradient_checkpointing() {
  local expected=${1:?expected gradient checkpointing value}
  local -a arguments=()
  local index
  mapfile -d '' -t arguments < "${FAKE_SWIFT_ARGS}"
  for index in "${!arguments[@]}"; do
    [[ "${arguments[${index}]}" == --gradient_checkpointing ]] || continue
    [[ "${arguments[$((index + 1))]}" == "${expected}" ]] || {
      echo "unexpected gradient checkpointing value: ${arguments[$((index + 1))]}" >&2
      exit 1
    }
    return
  done
  echo "missing gradient checkpointing option" >&2
  exit 1
}

for model in qwen gemma internvl llava minicpm; do
  output="${outputs}/${model}"
  if [[ "${model}" == minicpm ]]; then
    PYTHONHASHSEED=37 MINICPM_STRICT_IDENTITY=true MINICPM_IDENTITY_MANIFEST="${minicpm_identity_manifest}" \
      DATASET="${tmp}/dataset.jsonl" OUTPUT_DIR="${output}" bash "${root}/scripts/train_sft.sh" "${model}"
  else
    PYTHONHASHSEED=37 DATASET="${tmp}/dataset.jsonl" OUTPUT_DIR="${output}" bash "${root}/scripts/train_sft.sh" "${model}"
  fi
  [[ -s "${FAKE_SWIFT_ARGS}" ]] || { echo "missing fake swift invocation for ${model}" >&2; exit 1; }
  [[ "$(tr '\0' '\n' < "${FAKE_SWIFT_ARGS}")" == *"--model_type"* ]] || exit 1
  if [[ "${model}" == gemma ]]; then
    grep -qx 0 "${FAKE_SWIFT_HASH_SEED}"
  else
    grep -qx 37 "${FAKE_SWIFT_HASH_SEED}"
  fi
  if [[ "${model}" == llava ]]; then
    assert_gradient_checkpointing false
  else
    assert_gradient_checkpointing true
  fi
done

env -u MINICPM_STRICT_IDENTITY -u MINICPM_IDENTITY_MANIFEST \
  DATASET="${tmp}/dataset.jsonl" OUTPUT_DIR="${outputs}/minicpm-unrecorded" \
  bash "${root}/scripts/train_sft.sh" minicpm
if env -u MINICPM_IDENTITY_MANIFEST MINICPM_STRICT_IDENTITY=true \
  DATASET="${tmp}/dataset.jsonl" OUTPUT_DIR="${outputs}/minicpm-missing-manifest" \
  bash "${root}/scripts/train_sft.sh" minicpm >/dev/null 2>&1; then
  echo "strict MiniCPM training unexpectedly accepted a missing identity manifest" >&2; exit 1
fi

env -u PYTHONHASHSEED DATASET="${tmp}/dataset.jsonl" OUTPUT_DIR="${outputs}/gemma-unset" \
  bash "${root}/scripts/train_sft.sh" gemma
grep -qx 0 "${FAKE_SWIFT_HASH_SEED}"
for model in gemma3 gemma3-vl; do
  PYTHONHASHSEED=37 DATASET="${tmp}/dataset.jsonl" OUTPUT_DIR="${outputs}/${model}" \
    bash "${root}/scripts/train_sft.sh" "${model}"
  grep -qx 0 "${FAKE_SWIFT_HASH_SEED}"
  assert_gradient_checkpointing true
done

gemma_qualified() {
  MAX_LENGTH=512 MAX_PIXELS=262144 GRADIENT_ACCUMULATION_STEPS=4 "$@"
}
gemma_qualified env DATASET="${tmp}/dataset.jsonl" OUTPUT_DIR="${outputs}/gemma-qualified" \
  bash "${root}/scripts/train_sft.sh" gemma
assert_gradient_checkpointing false
gemma_qualified env DATASET="${tmp}/dataset.jsonl" OUTPUT_DIR="${outputs}/gemma-extra-length" \
  bash "${root}/scripts/train_sft.sh" gemma --max_length 4096
assert_gradient_checkpointing true
gemma_qualified env LORA_RANK=32 DATASET="${tmp}/dataset.jsonl" \
  OUTPUT_DIR="${outputs}/gemma-rank" bash "${root}/scripts/train_sft.sh" gemma
assert_gradient_checkpointing true
gemma_qualified env PACKING=true DATASET="${tmp}/dataset.jsonl" \
  OUTPUT_DIR="${outputs}/gemma-packing" bash "${root}/scripts/train_sft.sh" gemma
assert_gradient_checkpointing true
MAX_LENGTH=4096 MAX_PIXELS=262144 GRADIENT_ACCUMULATION_STEPS=4 \
  DATASET="${tmp}/dataset.jsonl" OUTPUT_DIR="${outputs}/gemma-long" \
  bash "${root}/scripts/train_sft.sh" gemma
assert_gradient_checkpointing true
gemma_qualified env GRADIENT_CHECKPOINTING=true DATASET="${tmp}/dataset.jsonl" \
  OUTPUT_DIR="${outputs}/gemma-qualified-override" bash "${root}/scripts/train_sft.sh" gemma
assert_gradient_checkpointing true

GRADIENT_CHECKPOINTING=true DATASET="${tmp}/dataset.jsonl" OUTPUT_DIR="${outputs}/gemma-gc-true" \
  bash "${root}/scripts/train_sft.sh" gemma
assert_gradient_checkpointing true
GRADIENT_CHECKPOINTING=true DATASET="${tmp}/dataset.jsonl" OUTPUT_DIR="${outputs}/llava-gc-true" \
  bash "${root}/scripts/train_sft.sh" llava
assert_gradient_checkpointing true
GRADIENT_CHECKPOINTING=false DATASET="${tmp}/dataset.jsonl" OUTPUT_DIR="${outputs}/llava-gc-false" \
  bash "${root}/scripts/train_sft.sh" llava
assert_gradient_checkpointing false

python3 - "${FAKE_SWIFT_ARGS}" <<'PY'
from pathlib import Path
import sys

arguments = Path(sys.argv[1]).read_bytes().split(b"\0")
optional = {
    b"--split_dataset_ratio", b"--data_seed", b"--lr_scheduler_type", b"--optim",
    b"--adam_beta1", b"--adam_beta2", b"--adam_epsilon", b"--weight_decay",
    b"--seed", b"--dataset_shuffle", b"--dataloader_drop_last", b"--packing",
    b"--padding_free", b"--padding_side", b"--template",
    b"--average_tokens_across_devices", b"--add_version",
}
assert optional.isdisjoint(arguments), arguments
PY

SPLIT_DATASET_RATIO=0 DATA_SEED=17 LR_SCHEDULER_TYPE=cosine OPTIM=adamw_torch \
ADAM_BETA1=0.9 ADAM_BETA2=0.95 ADAM_EPSILON=1e-8 WEIGHT_DECAY=0.1 SEED=42 \
DATASET_SHUFFLE=true DATALOADER_DROP_LAST=false PACKING=false PADDING_FREE=false \
PADDING_SIDE=right TEMPLATE=internvl AVERAGE_TOKENS_ACROSS_DEVICES=true \
ADD_VERSION=false \
DATASET=x OUTPUT_DIR="${outputs}/frozen-options" bash "${root}/scripts/train_sft.sh" internvl
python3 - "${FAKE_SWIFT_ARGS}" <<'PY'
from pathlib import Path
import sys

arguments = [item.decode() for item in Path(sys.argv[1]).read_bytes().split(b"\0") if item]
expected = {
    "--split_dataset_ratio": "0",
    "--data_seed": "17",
    "--lr_scheduler_type": "cosine",
    "--optim": "adamw_torch",
    "--adam_beta1": "0.9",
    "--adam_beta2": "0.95",
    "--adam_epsilon": "1e-8",
    "--weight_decay": "0.1",
    "--seed": "42",
    "--dataset_shuffle": "true",
    "--dataloader_drop_last": "false",
    "--packing": "false",
    "--padding_free": "false",
    "--padding_side": "right",
    "--template": "internvl",
    "--average_tokens_across_devices": "true",
    "--add_version": "false",
}
for option, value in expected.items():
    assert arguments.count(option) == 1, (option, arguments)
    index = arguments.index(option)
    assert arguments[index + 1] == value, (option, arguments[index + 1])
PY

rm -f "${FAKE_SWIFT_ARGS}"
reject_override() {
  rm -f "${FAKE_SWIFT_ARGS}"
  if DATASET=x OUTPUT_DIR="${outputs}/override-${RANDOM}" bash "${root}/scripts/train_sft.sh" qwen "$@" >/dev/null 2>&1; then
    echo "output/config override unexpectedly succeeded: $*" >&2; exit 1
  fi
  [[ ! -e "${FAKE_SWIFT_ARGS}" ]] || { echo "swift ran despite rejected override" >&2; exit 1; }
}
reject_override --output_dir "${root}"
reject_override "--output_dir=${root}"
reject_override --output-dir "${root}"
reject_override "--output-dir=${root}"
reject_override --output_d "${root}"
reject_override --output-d "${root}"
reject_override --config-file=settings.yaml
reject_override --learning-r 2e-5
reject_override --split_dataset_ratio 0
if RAY_SWIFT_ARGS="--output-dir=${root}" DATASET=x OUTPUT_DIR="${outputs}/ray-override" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "RAY_SWIFT_ARGS override unexpectedly succeeded" >&2; exit 1
fi
[[ ! -e "${FAKE_SWIFT_ARGS}" ]] || { echo "swift ran despite rejected environment override" >&2; exit 1; }
DATASET=x OUTPUT_DIR="${outputs}/extra-ok" bash "${root}/scripts/train_sft.sh" qwen --learning_rate 2e-5
grep -zqx -- '--learning_rate' "${FAKE_SWIFT_ARGS}"
grep -zqx '2e-5' "${FAKE_SWIFT_ARGS}"
DATASET=x OUTPUT_DIR="${outputs}/extra-equals" bash "${root}/scripts/train_sft.sh" qwen --learning_rate=2e-5
grep -zqx -- '--learning_rate=2e-5' "${FAKE_SWIFT_ARGS}"
for invalid in \
  'DATASET_SHUFFLE=yes' 'DATALOADER_DROP_LAST=0' 'PACKING=TRUE' \
  'PADDING_FREE=' 'AVERAGE_TOKENS_ACROSS_DEVICES=no' 'ADD_VERSION=0' 'DATA_SEED=-1' \
  'SEED=seed' 'SEED=4294967296' 'DATA_SEED=99999999999999999999' \
  'SPLIT_DATASET_RATIO=1' 'ADAM_BETA1=1' 'ADAM_BETA2=-0.1' \
  'ADAM_EPSILON=0' 'ADAM_EPSILON=--bad' 'ADAM_EPSILON=1e309' \
  'WEIGHT_DECAY=-0.1' 'WEIGHT_DECAY=1e309' \
  'LR_SCHEDULER_TYPE=cosine schedule' 'PADDING_SIDE=right,left'; do
  name=${invalid%%=*}
  value=${invalid#*=}
  rm -f "${FAKE_SWIFT_ARGS}"
  if env "${name}=${value}" DATASET=x OUTPUT_DIR="${outputs}/invalid-env-${RANDOM}" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
    echo "invalid controlled environment value unexpectedly succeeded: ${invalid}" >&2
    exit 1
  fi
  [[ ! -e "${FAKE_SWIFT_ARGS}" ]] || { echo "swift ran despite invalid controlled environment value" >&2; exit 1; }
done
rm -f "${FAKE_SWIFT_ARGS}"
if WEIGHT_DECAY=0.1 DATASET=x OUTPUT_DIR="${outputs}/duplicate-weight-decay" bash "${root}/scripts/train_sft.sh" qwen --weight_decay 0.2 >/dev/null 2>&1; then
  echo "environment and argv weight decay conflict unexpectedly succeeded" >&2
  exit 1
fi
[[ ! -e "${FAKE_SWIFT_ARGS}" ]] || { echo "swift ran despite conflicting controlled option" >&2; exit 1; }
if SEED=42 DATASET=x OUTPUT_DIR="${outputs}/duplicate-seed" bash "${root}/scripts/train_sft.sh" qwen --seed=7 >/dev/null 2>&1; then
  echo "environment and argv seed conflict unexpectedly succeeded" >&2
  exit 1
fi
[[ ! -e "${FAKE_SWIFT_ARGS}" ]] || { echo "swift ran despite conflicting controlled option" >&2; exit 1; }
reject_override --resume_from_checkpoint "${checkpoint}"

RESUME_FROM_CHECKPOINT="${checkpoint}" DATASET=x OUTPUT_DIR="${outputs}/resume-train" bash "${root}/scripts/train_sft.sh" qwen
grep -zqx -- '--resume_from_checkpoint' "${FAKE_SWIFT_ARGS}"
grep -zqx "${checkpoint}" "${FAKE_SWIFT_ARGS}"
for invalid_resume in "${tmp}/missing-checkpoint" "relative/checkpoint-100"; do
  if RESUME_FROM_CHECKPOINT="${invalid_resume}" DATASET=x OUTPUT_DIR="${outputs}/invalid-resume-${RANDOM}" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
    echo "invalid resume checkpoint unexpectedly succeeded: ${invalid_resume}" >&2; exit 1
  fi
done
mkdir -p "${tmp}/resume-source/checkpoint-101"
if RESUME_FROM_CHECKPOINT="${tmp}/resume-source/checkpoint-101" DATASET=x OUTPUT_DIR="${outputs}/missing-resume-state" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "resume checkpoint missing state unexpectedly succeeded" >&2; exit 1
fi
weights_only_checkpoint="${tmp}/resume-source/checkpoint-102"
mkdir -p "${weights_only_checkpoint}"
: > "${weights_only_checkpoint}/trainer_state.json"
: > "${weights_only_checkpoint}/adapter_model.safetensors"
if RESUME_FROM_CHECKPOINT="${weights_only_checkpoint}" DATASET=x OUTPUT_DIR="${outputs}/weights-only-resume" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "weights-only resume checkpoint unexpectedly succeeded" >&2; exit 1
fi
missing_scheduler_checkpoint="${tmp}/resume-source/checkpoint-105"
mkdir -p "${missing_scheduler_checkpoint}"
for state_file in trainer_state.json adapter_model.safetensors optimizer.pt; do
  : > "${missing_scheduler_checkpoint}/${state_file}"
done
for rank in {0..7}; do
  : > "${missing_scheduler_checkpoint}/rng_state_${rank}.pth"
done
if RESUME_FROM_CHECKPOINT="${missing_scheduler_checkpoint}" DATASET=x OUTPUT_DIR="${outputs}/missing-scheduler-resume" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "resume checkpoint missing scheduler unexpectedly succeeded" >&2; exit 1
fi
incomplete_rng_checkpoint="${tmp}/resume-source/checkpoint-103"
mkdir -p "${incomplete_rng_checkpoint}"
for state_file in trainer_state.json adapter_model.safetensors optimizer.pt scheduler.pt; do
  : > "${incomplete_rng_checkpoint}/${state_file}"
done
for rank in {0..6}; do
  : > "${incomplete_rng_checkpoint}/rng_state_${rank}.pth"
done
if RESUME_FROM_CHECKPOINT="${incomplete_rng_checkpoint}" DATASET=x OUTPUT_DIR="${outputs}/incomplete-rng-resume" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "incomplete DDP RNG resume checkpoint unexpectedly succeeded" >&2; exit 1
fi
single_rng_checkpoint="${tmp}/resume-source/checkpoint-104"
mkdir -p "${single_rng_checkpoint}"
for state_file in trainer_state.json adapter_model.safetensors optimizer.pt scheduler.pt rng_state.pth; do
  : > "${single_rng_checkpoint}/${state_file}"
done
MLU_VISIBLE_DEVICES=0 NPROC_PER_NODE=1 RESUME_FROM_CHECKPOINT="${single_rng_checkpoint}" DATASET=x OUTPUT_DIR="${outputs}/single-rng-resume" bash "${root}/scripts/train_sft.sh" qwen
grep -zqx -- '--resume_from_checkpoint' "${FAKE_SWIFT_ARGS}"
if RESUME_FROM_CHECKPOINT="${single_rng_checkpoint}" DATASET=x OUTPUT_DIR="${outputs}/single-rng-on-ddp" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "single-process RNG resume checkpoint unexpectedly succeeded for DDP" >&2; exit 1
fi
indexed_single_rng_checkpoint="${tmp}/resume-source/checkpoint-106"
mkdir -p "${indexed_single_rng_checkpoint}"
for state_file in trainer_state.json adapter_model.safetensors optimizer.pt scheduler.pt rng_state_0.pth; do
  : > "${indexed_single_rng_checkpoint}/${state_file}"
done
if MLU_VISIBLE_DEVICES=0 NPROC_PER_NODE=1 RESUME_FROM_CHECKPOINT="${indexed_single_rng_checkpoint}" DATASET=x OUTPUT_DIR="${outputs}/indexed-single-rng" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "indexed-only RNG resume checkpoint unexpectedly succeeded for one process" >&2; exit 1
fi
if RESUME_FROM_CHECKPOINT="${checkpoint}" DATASET=x OUTPUT_DIR="${checkpoint}/new-run" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "resume checkpoint/output overlap unexpectedly succeeded" >&2; exit 1
fi
ln -s "${checkpoint}" "${tmp}/resume-alias"
if RESUME_FROM_CHECKPOINT="${tmp}/resume-alias" DATASET=x OUTPUT_DIR="${tmp}/resume-alias/new-run" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "resume checkpoint alias/output overlap unexpectedly succeeded" >&2; exit 1
fi
mkdir -p "${outputs}/resume-existing-empty"
RESUME_FROM_CHECKPOINT="${checkpoint}" DATASET=x OUTPUT_DIR="${outputs}/resume-existing-empty" bash "${root}/scripts/train_sft.sh" qwen
grep -zqx -- '--resume_from_checkpoint' "${FAKE_SWIFT_ARGS}"
checkpoint_parent=$(dirname "${tmp}")
checkpoint_relative=${checkpoint#"${checkpoint_parent}/"}
dot_dot_output="${tmp}/missing/../../${checkpoint_relative}/new-run"
[[ "$(resolve_resume_output_path "${dot_dot_output}")" == "${checkpoint}/new-run" ]] || {
  echo "dot-dot resume output fixture did not resolve to the checkpoint" >&2
  exit 1
}
if RESUME_FROM_CHECKPOINT="${checkpoint}" DATASET=x OUTPUT_DIR="${dot_dot_output}" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "resume checkpoint/output dot-dot overlap unexpectedly succeeded" >&2; exit 1
fi

if MODELS_DIR="${tmp}/missing" DATASET=x OUTPUT_DIR="${outputs}/missing" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "missing model path unexpectedly succeeded" >&2; exit 1
fi
mkdir -p "${outputs}/occupied"; : > "${outputs}/occupied/existing"
if DATASET=x OUTPUT_DIR="${outputs}/occupied" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "occupied output directory unexpectedly succeeded" >&2; exit 1
fi
if DATASET=x OUTPUT_DIR="${outputs}/occupied/existing" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "file output path unexpectedly succeeded" >&2; exit 1
fi
if DATASET=x OUTPUT_DIR="${root}/../generation/forbidden" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "monorepo output path unexpectedly succeeded" >&2; exit 1
fi
if MLU_VISIBLE_DEVICES=0,,1 DATASET=x OUTPUT_DIR="${outputs}/empty-device" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "empty MLU device item unexpectedly succeeded" >&2; exit 1
fi
if MLU_VISIBLE_DEVICES=0,0 DATASET=x OUTPUT_DIR="${outputs}/duplicate-device" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "duplicate MLU device item unexpectedly succeeded" >&2; exit 1
fi
if MLU_VISIBLE_DEVICES=0,1 NPROC_PER_NODE=3 DATASET=x OUTPUT_DIR="${outputs}/oversubscribed" bash "${root}/scripts/train_sft.sh" qwen >/dev/null 2>&1; then
  echo "oversubscribed NPROC_PER_NODE unexpectedly succeeded" >&2; exit 1
fi

mkdir -p "${tmp}/data"; : > "${tmp}/data/dataset.jsonl"
minicpm_docker_manifest="${tmp}/minicpm-docker-identity.json"
printf '%s\n' '{"scope":"minicpm_wrapper_and_model_weights_only"}' > "${minicpm_docker_manifest}"
rm -f "${FAKE_DOCKER_ARGS}"
ln -s "${root}" "${tmp}/source-alias"
for blocked_output in "${root}/run" "${root}/../generation/run" "${tmp}/source-alias/run"; do
  if IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 DATASET="${tmp}/data/dataset.jsonl" DATA_MOUNT_ROOT="${tmp}/data" MODELS_DIR="${models}" OUTPUT_DIR="${blocked_output}" bash "${root}/scripts/docker_run.sh" bash -lc true >/dev/null 2>&1; then
    echo "unsafe Docker output unexpectedly succeeded: ${blocked_output}" >&2; exit 1
  fi
  [[ ! -e "${FAKE_DOCKER_ARGS}" ]] || { echo "docker ran despite rejected output" >&2; exit 1; }
done
rm -f "${FAKE_DOCKER_ARGS}"
if IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 DATASET="${tmp}/data/dataset.jsonl" DATA_MOUNT_ROOT="${tmp}/data" MODELS_DIR="${models}" RESUME_FROM_CHECKPOINT="${checkpoint}" bash "${root}/scripts/docker_run.sh" bash -lc true >/dev/null 2>&1; then
  echo "Docker resume without a new output unexpectedly succeeded" >&2; exit 1
fi
[[ ! -e "${FAKE_DOCKER_ARGS}" ]] || { echo "docker ran without required resume output" >&2; exit 1; }
if IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 DATASET="${tmp}/data/dataset.jsonl" DATA_MOUNT_ROOT="${tmp}/data" MODELS_DIR="${models}" RESUME_FROM_CHECKPOINT="${tmp}/missing-checkpoint" OUTPUT_DIR="${outputs}/docker-invalid-resume" bash "${root}/scripts/docker_run.sh" bash -lc true >/dev/null 2>&1; then
  echo "Docker invalid resume checkpoint unexpectedly succeeded" >&2; exit 1
fi
[[ ! -e "${FAKE_DOCKER_ARGS}" ]] || { echo "docker ran despite invalid resume checkpoint" >&2; exit 1; }
if IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 DATASET="${tmp}/data/dataset.jsonl" DATA_MOUNT_ROOT="${tmp}/data" MODELS_DIR="${models}" RESUME_FROM_CHECKPOINT="${checkpoint}" OUTPUT_DIR="${checkpoint}/new-run" bash "${root}/scripts/docker_run.sh" bash -lc true >/dev/null 2>&1; then
  echo "Docker resume checkpoint/output overlap unexpectedly succeeded" >&2; exit 1
fi
[[ ! -e "${FAKE_DOCKER_ARGS}" ]] || { echo "docker ran despite resume/output conflict" >&2; exit 1; }
rm -f "${FAKE_DOCKER_ARGS}"
MINICPM_STRICT_IDENTITY=true MINICPM_IDENTITY_MANIFEST="${minicpm_docker_manifest}" \
  IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 DATASET="${tmp}/data/dataset.jsonl" \
  DATA_MOUNT_ROOT="${tmp}/data" MODELS_DIR="${models}" OUTPUT_DIR="${outputs}/docker-minicpm-strict" \
  bash "${root}/scripts/docker_run.sh" bash -lc true
grep -qx 'MINICPM_STRICT_IDENTITY=true' "${FAKE_DOCKER_ENV}"
grep -qx "MINICPM_IDENTITY_MANIFEST=${minicpm_docker_manifest}" "${FAKE_DOCKER_ENV}"
grep -qx "${minicpm_docker_manifest}:${minicpm_docker_manifest}:ro" "${FAKE_DOCKER_ARGS}"
python3 - "${FAKE_DOCKER_ARGS}" <<'PY'
from pathlib import Path
import sys

arguments = Path(sys.argv[1]).read_text(encoding="utf-8").splitlines()
for name in ("MINICPM_STRICT_IDENTITY", "MINICPM_IDENTITY_MANIFEST"):
    positions = [index for index, value in enumerate(arguments) if value == name]
    assert len(positions) == 1, (name, arguments)
    assert positions[0] > 0 and arguments[positions[0] - 1] == "--env", (name, arguments)
PY
rm -f "${FAKE_DOCKER_ARGS}"
if MINICPM_STRICT_IDENTITY=true IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 \
  DATASET="${tmp}/data/dataset.jsonl" DATA_MOUNT_ROOT="${tmp}/data" MODELS_DIR="${models}" \
  OUTPUT_DIR="${outputs}/docker-minicpm-missing-manifest" \
  bash "${root}/scripts/docker_run.sh" bash -lc true >/dev/null 2>&1; then
  echo "Docker accepted strict MiniCPM mode without a manifest" >&2; exit 1
fi
[[ ! -e "${FAKE_DOCKER_ARGS}" ]] || { echo "Docker ran without a strict MiniCPM manifest" >&2; exit 1; }
if MINICPM_STRICT_IDENTITY=true MINICPM_IDENTITY_MANIFEST="${root}/README.md" \
  IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 DATASET="${tmp}/data/dataset.jsonl" \
  DATA_MOUNT_ROOT="${tmp}/data" MODELS_DIR="${models}" OUTPUT_DIR="${outputs}/docker-minicpm-workspace-manifest" \
  bash "${root}/scripts/docker_run.sh" bash -lc true >/dev/null 2>&1; then
  echo "Docker accepted a workspace MiniCPM manifest" >&2; exit 1
fi
[[ ! -e "${FAKE_DOCKER_ARGS}" ]] || { echo "Docker mounted a rejected MiniCPM manifest" >&2; exit 1; }
rm -f "${FAKE_DOCKER_ARGS}"
MINICPM_STRICT_IDENTITY=false MINICPM_IDENTITY_MANIFEST="${root}/README.md" \
  IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 DATASET="${tmp}/data/dataset.jsonl" \
  DATA_MOUNT_ROOT="${tmp}/data" MODELS_DIR="${models}" OUTPUT_DIR="${outputs}/docker-minicpm-nonstrict" \
  bash "${root}/scripts/docker_run.sh" bash -lc true
if grep -qx 'MINICPM_IDENTITY_MANIFEST' "${FAKE_DOCKER_ARGS}" \
  || grep -qx "${root}/README.md:${root}/README.md:ro" "${FAKE_DOCKER_ARGS}"; then
  echo "Docker forwarded a MiniCPM manifest while strict mode was disabled" >&2; exit 1
fi
IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 MLU_DOCKER_CONTROL_DEVICES=/dev/cambricon_ctl,/dev/cambricon_ipcm MLU_DOCKER_RUNTIME=mlu-site MLU_RUNTIME_MOUNTS="${tmp}/data" MLU_VISIBLE_DEVICES=2,5 CUDA_VISIBLE_DEVICES=7 DATASET="${tmp}/data/dataset.jsonl" DATA_MOUNT_ROOT="${tmp}/data" MODELS_DIR="${models}" OUTPUT_DIR="${outputs}/docker" bash "${root}/scripts/docker_run.sh" bash -lc true
grep -qx 'MLU_VISIBLE_DEVICES=2,5' "${FAKE_DOCKER_ENV}"
grep -qx 'CUDA_VISIBLE_DEVICES=7' "${FAKE_DOCKER_ENV}"
grep -qx -- '--env' "${FAKE_DOCKER_ARGS}"
grep -qx -- '--user' "${FAKE_DOCKER_ARGS}"
grep -qx "$(id -u):$(id -g)" "${FAKE_DOCKER_ARGS}"
grep -qx -- '--entrypoint' "${FAKE_DOCKER_ARGS}"
grep -qx '/usr/bin/env' "${FAKE_DOCKER_ARGS}"
grep -qx 'HOME=/tmp/genmlu-home' "${FAKE_DOCKER_ARGS}"
grep -qx 'XDG_CACHE_HOME=/tmp/genmlu-cache' "${FAKE_DOCKER_ARGS}"
grep -qx 'HF_HOME=/tmp/genmlu-cache/huggingface' "${FAKE_DOCKER_ARGS}"
grep -qx 'TRANSFORMERS_CACHE=/tmp/genmlu-cache/transformers' "${FAKE_DOCKER_ARGS}"
mapfile -t group_args < <(awk 'pending { print; pending = 0; next } $0 == "--group-add" { pending = 1 }' "${FAKE_DOCKER_ARGS}")
[[ "${group_args[*]}" == '1234 4567' ]] || {
  echo "Docker did not preserve host supplementary groups exactly" >&2
  exit 1
}
grep -qx -- '--runtime' "${FAKE_DOCKER_ARGS}"
grep -qx 'mlu-site' "${FAKE_DOCKER_ARGS}"
grep -qx '/dev/cambricon_dev2' "${FAKE_DOCKER_ARGS}"
grep -qx '/dev/cambricon_dev5' "${FAKE_DOCKER_ARGS}"
grep -qx '/dev/cambricon_ctl' "${FAKE_DOCKER_ARGS}"
grep -qx '/dev/cambricon_ipcm' "${FAKE_DOCKER_ARGS}"
grep -qx "${outputs}/docker:${outputs}/docker:rw" "${FAKE_DOCKER_ARGS}"
mapfile -t rw_mounts < <(grep ':rw$' "${FAKE_DOCKER_ARGS}" || true)
[[ ${#rw_mounts[@]} -eq 1 && "${rw_mounts[0]}" == "${outputs}/docker:${outputs}/docker:rw" ]] || {
  echo "Docker must mount only the dedicated output run directory read-write" >&2
  exit 1
}
mapfile -t docker_argv < "${FAKE_DOCKER_ARGS}"
image_index=-1
for index in "${!docker_argv[@]}"; do
  if [[ "${docker_argv[${index}]}" == test-image ]]; then
    image_index=${index}
    break
  fi
done
((image_index >= 0)) || { echo "container image was not passed to Docker" >&2; exit 1; }
[[ "${docker_argv[$((image_index + 1))]}" == bash && "${docker_argv[$((image_index + 2))]}" == -lc && "${docker_argv[$((image_index + 3))]}" == true ]] || {
  echo "container command argv is not exactly: bash -lc true" >&2
  exit 1
}
[[ ${#docker_argv[@]} -eq $((image_index + 4)) ]] || { echo "container command has unexpected extra argv" >&2; exit 1; }

rm -f "${FAKE_DOCKER_ARGS}"
IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 MLU_DOCKER_IPCM_PREFIX="${tmp}/ipcm" \
  MLU_VISIBLE_DEVICES=2,5 MODELS_DIR="${models}" \
  bash "${root}/scripts/docker_run.sh" bash -lc true
grep -qx "${tmp}/ipcm2" "${FAKE_DOCKER_ARGS}"
grep -qx "${tmp}/ipcm5" "${FAKE_DOCKER_ARGS}"
mapfile -t numbered_devices < <(awk 'pending { print; pending = 0; next } $0 == "--device" { pending = 1 }' "${FAKE_DOCKER_ARGS}")
[[ "${numbered_devices[*]}" == "/dev/cambricon_dev2 /dev/cambricon_dev5 /dev/cambricon_ctl ${tmp}/ipcm2 ${tmp}/ipcm5" ]] || {
  echo "Docker did not mount exactly the selected numbered IPCM nodes" >&2; exit 1
}
touch "${tmp}/ipcm"
IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 MLU_DOCKER_IPCM_PREFIX="${tmp}/ipcm" \
  MLU_VISIBLE_DEVICES=2,5 MODELS_DIR="${models}" \
  bash "${root}/scripts/docker_run.sh" bash -lc true
grep -qx "${tmp}/ipcm" "${FAKE_DOCKER_ARGS}"
mapfile -t shared_devices < <(awk 'pending { print; pending = 0; next } $0 == "--device" { pending = 1 }' "${FAKE_DOCKER_ARGS}")
[[ "${shared_devices[*]}" == "/dev/cambricon_dev2 /dev/cambricon_dev5 /dev/cambricon_ctl ${tmp}/ipcm" ]] || {
  echo "Docker did not prefer the shared IPCM node" >&2; exit 1
}
rm -f "${tmp}/ipcm"
IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 MLU_DOCKER_CONTROL_DEVICES="${tmp}/custom-ctl,${tmp}/custom-ipcm" \
  MLU_VISIBLE_DEVICES=2,5 MODELS_DIR="${models}" \
  bash "${root}/scripts/docker_run.sh" bash -lc true
grep -qx "${tmp}/custom-ctl" "${FAKE_DOCKER_ARGS}"
grep -qx "${tmp}/custom-ipcm" "${FAKE_DOCKER_ARGS}"
mapfile -t custom_devices < <(awk 'pending { print; pending = 0; next } $0 == "--device" { pending = 1 }' "${FAKE_DOCKER_ARGS}")
[[ "${custom_devices[*]}" == "/dev/cambricon_dev2 /dev/cambricon_dev5 ${tmp}/custom-ctl ${tmp}/custom-ipcm" ]] || {
  echo "Docker ignored or supplemented the explicit control-device override" >&2; exit 1
}
if MLU_DOCKER_CONTROL_DEVICES= IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 \
  MODELS_DIR="${models}" bash "${root}/scripts/docker_run.sh" bash -lc true >/dev/null 2>&1; then
  echo "Docker accepted an empty control-device override" >&2; exit 1
fi
if [[ -e /dev/cambricon_ctl ]]; then
  touch "${tmp}/cambricon_dev2" "${tmp}/cambricon_dev5" "${tmp}/ipcm2"
  rm -f "${FAKE_DOCKER_ARGS}"
  if IMAGE=test-image MLU_DOCKER_DEVICE_PREFIX="${tmp}/cambricon_dev" MLU_DOCKER_IPCM_PREFIX="${tmp}/ipcm" \
    MLU_VISIBLE_DEVICES=2,5 MODELS_DIR="${models}" \
    bash "${root}/scripts/docker_run.sh" bash -lc true >/dev/null 2>&1; then
    echo "Docker accepted a missing selected IPCM node" >&2; exit 1
  fi
  [[ ! -e "${FAKE_DOCKER_ARGS}" ]] || { echo "Docker ran despite a missing IPCM node" >&2; exit 1; }
  touch "${tmp}/ipcm5"
  IMAGE=test-image MLU_DOCKER_DEVICE_PREFIX="${tmp}/cambricon_dev" MLU_DOCKER_IPCM_PREFIX="${tmp}/ipcm" \
    MLU_VISIBLE_DEVICES=2,5 MODELS_DIR="${models}" \
    bash "${root}/scripts/docker_run.sh" bash -lc true
  mapfile -t checked_devices < <(awk 'pending { print; pending = 0; next } $0 == "--device" { pending = 1 }' "${FAKE_DOCKER_ARGS}")
  [[ "${checked_devices[*]}" == "${tmp}/cambricon_dev2 ${tmp}/cambricon_dev5 /dev/cambricon_ctl ${tmp}/ipcm2 ${tmp}/ipcm5" ]] || {
    echo "Docker did not validate exactly the selected device nodes" >&2; exit 1
  }
fi

rm -f "${FAKE_DOCKER_ARGS}"
IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 MODELS_DIR="${models}" \
  bash "${root}/scripts/docker_run.sh"
mapfile -t default_argv < "${FAKE_DOCKER_ARGS}"
default_image_index=-1
for index in "${!default_argv[@]}"; do
  if [[ "${default_argv[${index}]}" == test-image ]]; then
    default_image_index=${index}
    break
  fi
done
((default_image_index >= 0)) || { echo "default container image was not passed to Docker" >&2; exit 1; }
[[ ${#default_argv[@]} -eq $((default_image_index + 2)) && "${default_argv[$((default_image_index + 1))]}" == bash ]] || {
  echo "default container command is not bash" >&2
  exit 1
}

rm -f "${FAKE_DOCKER_ARGS}"
MLU_DOCKER_NAME=genmlu-x MLU_DOCKER_RUN_ID=x \
  IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 \
  DATASET="${tmp}/data/dataset.jsonl" DATA_MOUNT_ROOT="${tmp}/data" MODELS_DIR="${models}" \
  OUTPUT_DIR="${outputs}/docker-named" bash "${root}/scripts/docker_run.sh" bash -lc true
mapfile -t named_argv < "${FAKE_DOCKER_ARGS}"
name_count=0
label_count=0
named_image_index=
for index in "${!named_argv[@]}"; do
  [[ "${named_argv[${index}]}" != test-image ]] || named_image_index=${index}
  if [[ "${named_argv[${index}]}" == --name ]]; then
    name_count=$((name_count + 1))
    [[ "${named_argv[$((index + 1))]}" == genmlu-x ]] || {
      echo "Docker received the wrong container name" >&2
      exit 1
    }
  fi
  if [[ "${named_argv[${index}]}" == --label ]]; then
    label_count=$((label_count + 1))
    [[ "${named_argv[$((index + 1))]}" == genmlu.run_id=x ]] || {
      echo "Docker received the wrong run identity label" >&2
      exit 1
    }
  fi
  if [[ "${named_argv[${index}]}" == --env ]]; then
    [[ "${named_argv[$((index + 1))]}" != MLU_DOCKER_NAME \
      && "${named_argv[$((index + 1))]}" != MLU_DOCKER_RUN_ID ]] || {
      echo "Docker identity controls leaked into the container environment" >&2
      exit 1
    }
  fi
  [[ "${named_argv[${index}]}" != --env=MLU_DOCKER_NAME \
    && "${named_argv[${index}]}" != --env=MLU_DOCKER_RUN_ID ]] || {
    echo "Docker identity controls leaked into the container environment" >&2
    exit 1
  }
done
[[ ${name_count} -eq 1 ]] || { echo "Docker container name must be passed exactly once" >&2; exit 1; }
[[ ${label_count} -eq 1 ]] || { echo "Docker run identity label must be passed exactly once" >&2; exit 1; }
[[ -n "${named_image_index}" ]] || { echo "named Docker invocation is missing its image" >&2; exit 1; }
for index in "${!named_argv[@]}"; do
  if [[ "${named_argv[${index}]}" == --name || "${named_argv[${index}]}" == --label ]]; then
    ((index < named_image_index)) || { echo "Docker identity option follows the image" >&2; exit 1; }
  fi
done
[[ "${named_argv[$((named_image_index + 1))]}" == bash \
  && "${named_argv[$((named_image_index + 2))]}" == -lc \
  && "${named_argv[$((named_image_index + 3))]}" == true ]] || {
  echo "named Docker invocation changed the container command" >&2
  exit 1
}

for invalid_name in x 'bad/name' '--escape' 'bad name'; do
  rm -f "${FAKE_DOCKER_ARGS}"
  if MLU_DOCKER_NAME="${invalid_name}" IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 \
    DATASET="${tmp}/data/dataset.jsonl" DATA_MOUNT_ROOT="${tmp}/data" MODELS_DIR="${models}" \
    OUTPUT_DIR="${outputs}/docker-invalid-name-${RANDOM}" bash "${root}/scripts/docker_run.sh" \
    bash -lc true >/dev/null 2>&1; then
    echo "invalid MLU_DOCKER_NAME unexpectedly succeeded: ${invalid_name}" >&2
    exit 1
  fi
  [[ ! -e "${FAKE_DOCKER_ARGS}" ]] || { echo "Docker ran with an invalid container name" >&2; exit 1; }
done

for invalid_run_id in 'bad/run' '--escape' 'bad run' 'bad=value' $'bad\nvalue' $'bad\rvalue' '$(touch injected)'; do
  rm -f "${FAKE_DOCKER_ARGS}"
  if MLU_DOCKER_RUN_ID="${invalid_run_id}" IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 \
    DATASET="${tmp}/data/dataset.jsonl" DATA_MOUNT_ROOT="${tmp}/data" MODELS_DIR="${models}" \
    OUTPUT_DIR="${outputs}/docker-invalid-run-id-${RANDOM}" bash "${root}/scripts/docker_run.sh" \
    bash -lc true >/dev/null 2>&1; then
    echo "invalid MLU_DOCKER_RUN_ID unexpectedly succeeded: ${invalid_run_id}" >&2
    exit 1
  fi
  [[ ! -e "${FAKE_DOCKER_ARGS}" ]] || { echo "Docker ran with an invalid run identifier" >&2; exit 1; }
done

for identity_mode in name-only label-only; do
  rm -f "${FAKE_DOCKER_ARGS}"
  if [[ "${identity_mode}" == name-only ]]; then
    MLU_DOCKER_NAME=genmlu-name-only IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 \
      DATASET="${tmp}/data/dataset.jsonl" DATA_MOUNT_ROOT="${tmp}/data" MODELS_DIR="${models}" \
      OUTPUT_DIR="${outputs}/docker-name-only" bash "${root}/scripts/docker_run.sh" bash -lc true
  else
    MLU_DOCKER_RUN_ID=label-only IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 \
      DATASET="${tmp}/data/dataset.jsonl" DATA_MOUNT_ROOT="${tmp}/data" MODELS_DIR="${models}" \
      OUTPUT_DIR="${outputs}/docker-label-only" bash "${root}/scripts/docker_run.sh" bash -lc true
  fi
  mapfile -t identity_argv < "${FAKE_DOCKER_ARGS}"
  if [[ "${identity_mode}" == name-only ]]; then
    [[ " ${identity_argv[*]} " == *' --name genmlu-name-only '* \
      && " ${identity_argv[*]} " != *' --label '* ]] || exit 1
  else
    [[ " ${identity_argv[*]} " == *' --label genmlu.run_id=label-only '* \
      && " ${identity_argv[*]} " != *' --name '* ]] || exit 1
  fi
done

rm -f "${FAKE_DOCKER_ARGS}"
SPLIT_DATASET_RATIO=0 DATA_SEED=17 LR_SCHEDULER_TYPE=cosine OPTIM=adamw_torch \
ADAM_BETA1=0.9 ADAM_BETA2=0.95 ADAM_EPSILON=1e-8 WEIGHT_DECAY=0.1 SEED=42 \
DATASET_SHUFFLE=true DATALOADER_DROP_LAST=false PACKING=false PADDING_FREE=false \
PADDING_SIDE=right TEMPLATE=internvl_hf AVERAGE_TOKENS_ACROSS_DEVICES=true ADD_VERSION=false \
IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 DATASET="${tmp}/data/dataset.jsonl" \
DATA_MOUNT_ROOT="${tmp}/data" MODELS_DIR="${models}" OUTPUT_DIR="${outputs}/docker-frozen" \
bash "${root}/scripts/docker_run.sh" bash -lc true
python3 - "${FAKE_DOCKER_ARGS}" <<'PY'
from pathlib import Path
import sys

arguments = Path(sys.argv[1]).read_text(encoding="utf-8").splitlines()
expected = {
    "SPLIT_DATASET_RATIO", "DATA_SEED", "LR_SCHEDULER_TYPE", "OPTIM",
    "ADAM_BETA1", "ADAM_BETA2", "ADAM_EPSILON", "WEIGHT_DECAY", "SEED",
    "DATASET_SHUFFLE", "DATALOADER_DROP_LAST", "PACKING", "PADDING_FREE",
    "PADDING_SIDE", "TEMPLATE", "AVERAGE_TOKENS_ACROSS_DEVICES", "ADD_VERSION",
}
for name in expected:
    positions = [index for index, value in enumerate(arguments) if value == name]
    assert len(positions) == 1, (name, arguments)
    assert positions[0] > 0 and arguments[positions[0] - 1] == "--env", (name, arguments)
PY

rm -f "${FAKE_DOCKER_ARGS}"
IMAGE=test-image MLU_DOCKER_SKIP_DEVICE_CHECK=1 DATASET="${tmp}/data/dataset.jsonl" DATA_MOUNT_ROOT="${tmp}/data" MODELS_DIR="${models}" RESUME_FROM_CHECKPOINT="${checkpoint}" OUTPUT_DIR="${outputs}/docker-resume" bash "${root}/scripts/docker_run.sh" bash -lc true
grep -qx "RESUME_FROM_CHECKPOINT=${checkpoint}" "${FAKE_DOCKER_ENV}"
grep -qx "${checkpoint}:${checkpoint}:ro" "${FAKE_DOCKER_ARGS}"
grep -qx "${outputs}/docker-resume:${outputs}/docker-resume:rw" "${FAKE_DOCKER_ARGS}"
mapfile -t resume_mounts < <(grep "${checkpoint}" "${FAKE_DOCKER_ARGS}" || true)
[[ ${#resume_mounts[@]} -eq 1 && "${resume_mounts[0]}" == "${checkpoint}:${checkpoint}:ro" ]] || {
  echo "Docker must mount only the exact resume checkpoint read-only" >&2
  exit 1
}
RESUME_FROM_CHECKPOINT="${checkpoint}" DATASET=x OUTPUT_DIR="${outputs}/docker-resume" bash "${root}/scripts/train_sft.sh" qwen
grep -zqx -- '--resume_from_checkpoint' "${FAKE_SWIFT_ARGS}"
grep -zqx "${checkpoint}" "${FAKE_SWIFT_ARGS}"

VLM_PLUGIN_DISABLE_AUTO_INSTALL=1 python3 - "${root}/plugins/llava_onevision.py" <<'PY'
import importlib.util
import sys
spec = importlib.util.spec_from_file_location("llava_onevision", sys.argv[1])
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert module.LOAD_KEY_MAPPING["^visual"] == "model.visual"
PY

echo "CPU contract tests passed"
