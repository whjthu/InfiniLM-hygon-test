#!/usr/bin/env bash
set -euo pipefail
script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "${script_dir}/../runtime/model_registry.sh"
model=${1:?model key required: qwen, gemma, internvl, llava, minicpm}
command=${2:?command required: freeze, generate, docker}
shift 2
case "${command}" in freeze|generate|docker) ;; *) echo "Unsupported TextVQA command" >&2; exit 2 ;; esac
load_model "${model}"
# Registry-selected loader arguments cannot be overridden by user arguments.
for option in "$@"; do
  case "${option}" in
    --model|--model=*|--model-alias*|--model-type*|--attn_impl*|--model_kwargs*|--external_plugins*)
      echo "Registry loader option cannot be overridden: ${option}" >&2; exit 2 ;;
  esac
done
extra=("${MODEL_EXTRA_ARGS[@]}")
exec python3 -B "${script_dir}/../runtime/textvqa_generate.py" "${command}" \
  --model "${MODEL_PATH}" --model-alias "${MODEL_ALIAS}" --model-type "${MODEL_TYPE}" \
  "${extra[@]}" "$@"
