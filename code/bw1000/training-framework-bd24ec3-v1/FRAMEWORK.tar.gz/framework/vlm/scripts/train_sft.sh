#!/usr/bin/env bash

set -euo pipefail

script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "${script_dir}/../runtime/common.sh"
source "${script_dir}/../runtime/model_registry.sh"
source "${script_dir}/../runtime/minicpm_sft_preset.sh"

model_key=${1:?Usage: train_sft.sh <qwen|gemma|internvl|llava|minicpm> [dataset] [extra swift arguments...]}
shift
if [[ -z "${DATASET:-}" && $# -gt 0 ]]; then
  DATASET=$1
  shift
fi
[[ -n "${DATASET:-}" ]] || { echo "DATASET is required." >&2; exit 2; }
[[ -n "${OUTPUT_DIR:-}" ]] || { echo "OUTPUT_DIR is required and must be external." >&2; exit 2; }
require_external_output_dir "${OUTPUT_DIR}"
validate_sft_tuning_args "$@"
load_model "${model_key}"
if [[ "${MODEL_ALIAS}" == minicpmv4_6 ]]; then
  if [[ "${MINICPM_STRICT_IDENTITY:-false}" != true && "${MINICPM_STRICT_IDENTITY:-false}" != false ]]; then
    echo "MINICPM_STRICT_IDENTITY must be exactly true or false." >&2
    exit 2
  fi
  if [[ "${MINICPM_STRICT_IDENTITY:-false}" == true ]]; then
    : "${MINICPM_IDENTITY_MANIFEST:?MINICPM_IDENTITY_MANIFEST is required when MINICPM_STRICT_IDENTITY=true.}"
    python3 "${script_dir}/../runtime/verify_minicpm_identity.py" \
      --model-path "${MODEL_PATH}" --manifest "${MINICPM_IDENTITY_MANIFEST}"
  fi
fi
if [[ "${MODEL_ALIAS}" == gemma3 ]]; then
  # Gemma3 registers RoPE buffers from a set; DDP ranks must share that order.
  export PYTHONHASHSEED=0
fi
gemma_qualified_shape=true
for argument in "$@"; do
  case "${argument%%=*}" in
    --max_length|--max_pixels|--torch_dtype|--tuner_type|--per_device_train_batch_size|--gradient_accumulation_steps|--freeze_vit|--target_modules|--lora_rank|--lora_alpha|--lora_dropout)
      gemma_qualified_shape=false
      ;;
  esac
done

gradient_checkpointing_default=true
if [[ "${MODEL_TYPE}" == llava_onevision1_5 ]]; then
  gradient_checkpointing_default=false
elif [[ "${MODEL_ALIAS}" == gemma3 && "${gemma_qualified_shape}" == true &&
        "${MLU_VISIBLE_DEVICES:-0,1,2,3,4,5,6,7}" == 0,1,2,3,4,5,6,7 &&
        "${NPROC_PER_NODE:-8}" == 8 && "${MAX_LENGTH:-4096}" == 512 &&
        "${MAX_PIXELS:-1003520}" == 262144 && "${TORCH_DTYPE:-bfloat16}" == bfloat16 &&
        "${TUNER_TYPE:-lora}" == lora && "${PER_DEVICE_TRAIN_BATCH_SIZE:-1}" == 1 &&
        "${GRADIENT_ACCUMULATION_STEPS:-16}" == 4 && "${FREEZE_VIT:-true}" == true &&
        "${TARGET_MODULES:-all-linear}" == all-linear && "${LORA_RANK:-16}" == 16 &&
        "${LORA_ALPHA:-32}" == 32 && "${LORA_DROPOUT:-0.05}" == 0.05 &&
        "${PACKING:-false}" == false && "${PADDING_FREE:-false}" == false &&
        "${PADDING_SIDE:-right}" == right ]]; then
  gradient_checkpointing_default=false
fi

: "${MLU_VISIBLE_DEVICES:=0,1,2,3,4,5,6,7}"
export MLU_VISIBLE_DEVICES
visible_device_count=$(count_visible_devices "${MLU_VISIBLE_DEVICES}")
: "${NPROC_PER_NODE:=${visible_device_count}}"
[[ "${NPROC_PER_NODE}" =~ ^[1-9][0-9]*$ ]] || { echo "NPROC_PER_NODE must be a positive integer." >&2; exit 2; }
((NPROC_PER_NODE <= visible_device_count)) || { echo "NPROC_PER_NODE (${NPROC_PER_NODE}) exceeds selected MLU devices (${visible_device_count})." >&2; exit 2; }
export NPROC_PER_NODE
resume_checkpoint=
if [[ -n "${RESUME_FROM_CHECKPOINT:-}" ]]; then
  resume_checkpoint=$(resolve_resume_checkpoint "${RESUME_FROM_CHECKPOINT}" "${NPROC_PER_NODE}")
  require_separate_resume_output_dir "${OUTPUT_DIR}" "${resume_checkpoint}"
fi
export WANDB_MODE=${WANDB_MODE:-offline}
export TOKENIZERS_PARALLELISM=${TOKENIZERS_PARALLELISM:-false}

if minicpm_sft_preset_enabled; then
  validate_minicpm_sft_preset "${MODEL_ALIAS}" "${visible_device_count}" "${NPROC_PER_NODE}" "$@"
  build_minicpm_sft_preset_command
  printf 'Running:'; printf ' %q' "${cmd[@]}"; printf '\n'
  exec "${cmd[@]}"
fi

validate_optional_scalar() {
  local name=${1:?environment variable name is required}
  local value=${!name}
  [[ -n "${value}" && "${value}" != --* && "${value}" != *$'\n'* && "${value}" != *$'\r'* ]] || {
    echo "${name} must be a non-empty scalar value." >&2
    return 2
  }
}

validate_optional_boolean() {
  local name=${1:?environment variable name is required}
  validate_optional_scalar "${name}" || return
  [[ "${!name}" == true || "${!name}" == false ]] || {
    echo "${name} must be exactly true or false." >&2
    return 2
  }
}

validate_optional_integer() {
  local name=${1:?environment variable name is required}
  validate_optional_scalar "${name}" || return
  [[ "${!name}" =~ ^[0-9]+$ ]] || {
    echo "${name} must be a non-negative integer." >&2
    return 2
  }
  python3 - "${!name}" <<'PY' || {
import sys
value = int(sys.argv[1])
raise SystemExit(0 if 0 <= value <= 2**32 - 1 else 1)
PY
    echo "${name} must be within the unsigned 32-bit seed range." >&2
    return 2
  }
}

validate_optional_number() {
  local name=${1:?environment variable name is required}
  validate_optional_scalar "${name}" || return
  [[ "${!name}" =~ ^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)([eE][+-]?[0-9]+)?$ ]] || {
    echo "${name} must be a finite number." >&2
    return 2
  }
  python3 - "${!name}" <<'PY' || {
import math
import sys
raise SystemExit(0 if math.isfinite(float(sys.argv[1])) else 1)
PY
    echo "${name} must be a finite number." >&2
    return 2
  }
}

validate_optional_fraction() {
  local name=${1:?environment variable name is required}
  validate_optional_number "${name}" || return
  awk -v value="${!name}" 'BEGIN { exit !(value >= 0 && value < 1) }' || {
    echo "${name} must be at least zero and less than one." >&2
    return 2
  }
}

validate_optional_positive_number() {
  local name=${1:?environment variable name is required}
  validate_optional_number "${name}" || return
  awk -v value="${!name}" 'BEGIN { exit !(value > 0) }' || {
    echo "${name} must be greater than zero." >&2
    return 2
  }
}

validate_optional_nonnegative_number() {
  local name=${1:?environment variable name is required}
  validate_optional_number "${name}" || return
  awk -v value="${!name}" 'BEGIN { exit !(value >= 0) }' || {
    echo "${name} must be at least zero." >&2
    return 2
  }
}

validate_optional_identifier() {
  local name=${1:?environment variable name is required}
  validate_optional_scalar "${name}" || return
  [[ "${!name}" =~ ^[A-Za-z0-9_./+:-]+$ ]] || {
    echo "${name} contains unsupported characters." >&2
    return 2
  }
}

validate_optional_padding_side() {
  local name=${1:?environment variable name is required}
  validate_optional_scalar "${name}" || return
  [[ "${!name}" == left || "${!name}" == right ]] || {
    echo "${name} must be exactly left or right." >&2
    return 2
  }
}

reject_optional_arg_conflicts() {
  local specification name option argument
  for specification in \
    SPLIT_DATASET_RATIO:--split_dataset_ratio DATA_SEED:--data_seed \
    LR_SCHEDULER_TYPE:--lr_scheduler_type OPTIM:--optim \
    ADAM_BETA1:--adam_beta1 ADAM_BETA2:--adam_beta2 ADAM_EPSILON:--adam_epsilon \
    WEIGHT_DECAY:--weight_decay SEED:--seed DATASET_SHUFFLE:--dataset_shuffle \
    DATALOADER_DROP_LAST:--dataloader_drop_last PACKING:--packing \
    PADDING_FREE:--padding_free PADDING_SIDE:--padding_side TEMPLATE:--template \
    AVERAGE_TOKENS_ACROSS_DEVICES:--average_tokens_across_devices ADD_VERSION:--add_version; do
    name=${specification%%:*}
    option=${specification#*:}
    [[ -v "${name}" ]] || continue
    for argument in "$@"; do
      if [[ "${argument}" == "${option}" || "${argument}" == "${option}="* ]]; then
        echo "${option} cannot be set by both ${name} and extra arguments." >&2
        return 2
      fi
    done
  done
}

append_optional_arg() {
  local name=${1:?environment variable name is required}
  local option=${2:?option name is required}
  local validator=${3:?validator is required}
  [[ -v "${name}" ]] || return 0
  "${validator}" "${name}"
  cmd+=("${option}" "${!name}")
}

cmd=(
  swift sft
  --model "${MODEL_PATH}"
  --model_type "${MODEL_TYPE}"
  --dataset "${DATASET}"
  --output_dir "${OUTPUT_DIR}"
  --no_check_model
  --torch_dtype "${TORCH_DTYPE:-bfloat16}"
  --max_length "${MAX_LENGTH:-4096}"
  --max_pixels "${MAX_PIXELS:-1003520}"
  --tuner_type "${TUNER_TYPE:-lora}"
  --per_device_train_batch_size "${PER_DEVICE_TRAIN_BATCH_SIZE:-1}"
  --gradient_accumulation_steps "${GRADIENT_ACCUMULATION_STEPS:-16}"
  --learning_rate "${LEARNING_RATE:-1e-4}"
  --warmup_ratio "${WARMUP_RATIO:-0.03}"
  --gradient_checkpointing "${GRADIENT_CHECKPOINTING:-${gradient_checkpointing_default}}"
  --freeze_vit "${FREEZE_VIT:-true}"
  --logging_steps "${LOGGING_STEPS:-1}"
  --save_steps "${SAVE_STEPS:-100}"
  --save_total_limit "${SAVE_TOTAL_LIMIT:-3}"
  --dataloader_num_workers "${DATALOADER_NUM_WORKERS:-4}"
  --report_to "${REPORT_TO:-tensorboard}"
)

reject_optional_arg_conflicts "$@"
append_optional_arg SPLIT_DATASET_RATIO --split_dataset_ratio validate_optional_fraction
append_optional_arg DATA_SEED --data_seed validate_optional_integer
append_optional_arg LR_SCHEDULER_TYPE --lr_scheduler_type validate_optional_identifier
append_optional_arg OPTIM --optim validate_optional_identifier
append_optional_arg ADAM_BETA1 --adam_beta1 validate_optional_fraction
append_optional_arg ADAM_BETA2 --adam_beta2 validate_optional_fraction
append_optional_arg ADAM_EPSILON --adam_epsilon validate_optional_positive_number
append_optional_arg WEIGHT_DECAY --weight_decay validate_optional_nonnegative_number
append_optional_arg SEED --seed validate_optional_integer
append_optional_arg DATASET_SHUFFLE --dataset_shuffle validate_optional_boolean
append_optional_arg DATALOADER_DROP_LAST --dataloader_drop_last validate_optional_boolean
append_optional_arg PACKING --packing validate_optional_boolean
append_optional_arg PADDING_FREE --padding_free validate_optional_boolean
append_optional_arg PADDING_SIDE --padding_side validate_optional_padding_side
append_optional_arg TEMPLATE --template validate_optional_identifier
append_optional_arg AVERAGE_TOKENS_ACROSS_DEVICES --average_tokens_across_devices validate_optional_boolean
append_optional_arg ADD_VERSION --add_version validate_optional_boolean

if [[ "${TUNER_TYPE:-lora}" == lora* ]]; then
  cmd+=(--target_modules "${TARGET_MODULES:-all-linear}" --lora_rank "${LORA_RANK:-16}" --lora_alpha "${LORA_ALPHA:-32}" --lora_dropout "${LORA_DROPOUT:-0.05}")
fi
if [[ -n "${MAX_STEPS:-}" ]]; then
  cmd+=(--max_steps "${MAX_STEPS}")
else
  cmd+=(--num_train_epochs "${NUM_TRAIN_EPOCHS:-1}")
fi
[[ -z "${VAL_DATASET:-}" ]] || cmd+=(--val_dataset "${VAL_DATASET}")
[[ -z "${resume_checkpoint}" ]] || cmd+=(--resume_from_checkpoint "${resume_checkpoint}")
cmd+=("${MODEL_EXTRA_ARGS[@]}" "$@")

printf 'Running:'; printf ' %q' "${cmd[@]}"; printf '\n'
exec "${cmd[@]}"
