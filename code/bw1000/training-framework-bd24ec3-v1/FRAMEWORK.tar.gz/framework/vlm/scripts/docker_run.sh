#!/usr/bin/env bash

set -euo pipefail

script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "${script_dir}/../runtime/common.sh"
source "${script_dir}/../runtime/minicpm_sft_preset.sh"

: "${MLU_VISIBLE_DEVICES:=0,1,2,3,4,5,6,7}"
export MLU_VISIBLE_DEVICES
validate_visible_devices "${MLU_VISIBLE_DEVICES}"
visible_device_count=$(count_visible_devices "${MLU_VISIBLE_DEVICES}")
: "${NPROC_PER_NODE:=${visible_device_count}}"
[[ "${NPROC_PER_NODE}" =~ ^[1-9][0-9]*$ ]] || { echo "NPROC_PER_NODE must be a positive integer." >&2; exit 2; }
((NPROC_PER_NODE <= visible_device_count)) || { echo "NPROC_PER_NODE (${NPROC_PER_NODE}) exceeds selected MLU devices (${visible_device_count})." >&2; exit 2; }
export NPROC_PER_NODE
if minicpm_sft_preset_enabled; then
  validate_minicpm_sft_preset_environment
  [[ "${visible_device_count}" == 8 && "${NPROC_PER_NODE}" == 8 ]] || {
    echo "${MINICPM_SFT_PRESET_NAME} requires exactly eight visible devices and eight processes." >&2
    exit 2
  }
fi
image=${IMAGE:?Set IMAGE to the built VLM SFT container image.}
workspace=$(realpath -e "${WORKSPACE:-$(repo_root)}")
[[ -d "${workspace}" ]] || { echo "WORKSPACE does not exist: ${workspace}" >&2; exit 2; }
source_root=$(realpath -e "$(monorepo_root)")
container_workdir=${CONTAINER_WORKDIR:-/workspace/vlm}
host_uid=$(id -u)
host_gid=$(id -g)
host_groups=$(id -G)
[[ "${host_uid}" =~ ^[0-9]+$ && "${host_gid}" =~ ^[0-9]+$ && "${host_groups}" =~ ^[0-9]+(\ [0-9]+)*$ ]] || {
  echo "host UID, GID, and supplementary groups must be numeric for Docker ownership mapping." >&2
  exit 2
}
models_dir=$(realpath -e "${MODELS_DIR:-/mnt/models}")
[[ -d "${models_dir}" ]] || { echo "MODELS_DIR does not exist: ${models_dir}" >&2; exit 2; }

docker_args=(
  run --rm --ipc=host --user "${host_uid}:${host_gid}"
  --entrypoint /usr/bin/env
  --env HOME=/tmp/genmlu-home
  --env XDG_CACHE_HOME=/tmp/genmlu-cache
  --env HF_HOME=/tmp/genmlu-cache/huggingface
  --env TRANSFORMERS_CACHE=/tmp/genmlu-cache/transformers
  -w "${container_workdir}"
  -v "${workspace}:${container_workdir}:ro"
  -v "${models_dir}:${models_dir}:ro"
)
for group_id in ${host_groups}; do
  [[ "${group_id}" == "${host_gid}" ]] || docker_args+=(--group-add "${group_id}")
done

if [[ -n "${MLU_DOCKER_NAME:-}" ]]; then
  [[ "${MLU_DOCKER_NAME}" =~ ^[A-Za-z0-9][A-Za-z0-9_.-]+$ ]] || {
    echo "MLU_DOCKER_NAME is not a valid Docker container name." >&2
    exit 2
  }
  docker_args+=(--name "${MLU_DOCKER_NAME}")
fi

if [[ -n "${MLU_DOCKER_RUN_ID:-}" ]]; then
  [[ "${MLU_DOCKER_RUN_ID}" =~ ^[A-Za-z0-9][A-Za-z0-9_.-]*$ ]] || {
    echo "MLU_DOCKER_RUN_ID is not a valid run identifier." >&2
    exit 2
  }
  docker_args+=(--label "genmlu.run_id=${MLU_DOCKER_RUN_ID}")
fi

resume_checkpoint=
if [[ -n "${RESUME_FROM_CHECKPOINT:-}" ]]; then
  [[ -n "${OUTPUT_DIR:-}" ]] || { echo "OUTPUT_DIR is required when RESUME_FROM_CHECKPOINT is set." >&2; exit 2; }
  resume_checkpoint=$(resolve_resume_checkpoint "${RESUME_FROM_CHECKPOINT}" "${NPROC_PER_NODE}")
  RESUME_FROM_CHECKPOINT=${resume_checkpoint}
  export RESUME_FROM_CHECKPOINT
  docker_args+=(-v "${resume_checkpoint}:${resume_checkpoint}:ro")
fi

minicpm_identity_manifest=
minicpm_strict_identity=${MINICPM_STRICT_IDENTITY:-false}
if [[ "${minicpm_strict_identity}" != true && "${minicpm_strict_identity}" != false ]]; then
  echo "MINICPM_STRICT_IDENTITY must be exactly true or false." >&2
  exit 2
fi
if [[ "${minicpm_strict_identity}" == true ]]; then
  : "${MINICPM_IDENTITY_MANIFEST:?MINICPM_IDENTITY_MANIFEST is required when MINICPM_STRICT_IDENTITY=true.}"
  [[ "${MINICPM_IDENTITY_MANIFEST}" == /* ]] || {
    echo "MINICPM_IDENTITY_MANIFEST must be an absolute path." >&2
    exit 2
  }
  [[ -f "${MINICPM_IDENTITY_MANIFEST}" && ! -L "${MINICPM_IDENTITY_MANIFEST}" ]] || {
    echo "MINICPM_IDENTITY_MANIFEST must be a regular, non-symlink file." >&2
    exit 2
  }
  minicpm_identity_manifest=$(realpath -e "${MINICPM_IDENTITY_MANIFEST}")
  if paths_overlap "${minicpm_identity_manifest}" "${source_root}"; then
    echo "MINICPM_IDENTITY_MANIFEST must be outside the source tree." >&2
    exit 2
  fi
  if paths_overlap "${minicpm_identity_manifest}" "${models_dir}"; then
    echo "MINICPM_IDENTITY_MANIFEST must be outside MODELS_DIR." >&2
    exit 2
  fi
  MINICPM_IDENTITY_MANIFEST=${minicpm_identity_manifest}
  export MINICPM_IDENTITY_MANIFEST
  docker_args+=(-v "${minicpm_identity_manifest}:${minicpm_identity_manifest}:ro")
else
  unset MINICPM_IDENTITY_MANIFEST
fi

if [[ -n "${DATASET:-}" ]]; then
  data_mount_root=$(realpath -e "${DATA_MOUNT_ROOT:-$(dirname "${DATASET}")}")
  [[ -d "${data_mount_root}" ]] || { echo "DATA_MOUNT_ROOT does not exist: ${data_mount_root}" >&2; exit 2; }
  docker_args+=(-v "${data_mount_root}:${data_mount_root}:ro")
fi
if [[ -n "${OUTPUT_DIR:-}" ]]; then
  readonly_paths=("${workspace}" "${models_dir}")
  [[ -z "${DATASET:-}" ]] || readonly_paths+=("${data_mount_root}")
  [[ -z "${resume_checkpoint}" ]] || readonly_paths+=("${resume_checkpoint}")
  [[ -z "${minicpm_identity_manifest}" ]] || readonly_paths+=("${minicpm_identity_manifest}")
  output_run_dir=$(prepare_external_run_dir "${OUTPUT_DIR}" "${readonly_paths[@]}")
  OUTPUT_DIR=${output_run_dir}
  export OUTPUT_DIR
  docker_args+=(-v "${output_run_dir}:${output_run_dir}:rw")
fi

if [[ -n "${MLU_DOCKER_RUNTIME:-}" ]]; then
  docker_args+=(--runtime "${MLU_DOCKER_RUNTIME}")
fi
if [[ -n "${MLU_RUNTIME_MOUNTS:-}" ]]; then
  IFS=',' read -r -a runtime_mounts <<< "${MLU_RUNTIME_MOUNTS}"
  for runtime_mount in "${runtime_mounts[@]}"; do
    [[ -n "${runtime_mount}" && -d "${runtime_mount}" ]] || { echo "Invalid MLU runtime mount: ${runtime_mount:-<empty>}" >&2; exit 2; }
    docker_args+=(-v "${runtime_mount}:${runtime_mount}:ro")
  done
fi

compact_devices=${MLU_VISIBLE_DEVICES//[[:space:]]/}
IFS=',' read -r -a selected_devices <<< "${compact_devices}"
device_prefix=${MLU_DOCKER_DEVICE_PREFIX:-/dev/cambricon_dev}
skip_device_check=${MLU_DOCKER_SKIP_DEVICE_CHECK:-0}
if [[ -v MLU_DOCKER_CONTROL_DEVICES ]]; then
  control_devices=${MLU_DOCKER_CONTROL_DEVICES}
  [[ -n "${control_devices}" ]] || { echo "MLU_DOCKER_CONTROL_DEVICES must not be empty." >&2; exit 2; }
else
  ipcm_prefix=${MLU_DOCKER_IPCM_PREFIX:-/dev/cambricon_ipcm}
  control_devices=/dev/cambricon_ctl
  if [[ -e "${ipcm_prefix}" ]]; then
    control_devices+=",${ipcm_prefix}"
  else
    for device_id in "${selected_devices[@]}"; do
      control_devices+=",${ipcm_prefix}${device_id}"
    done
  fi
fi
for device_id in "${selected_devices[@]}"; do
  device_path="${device_prefix}${device_id}"
  if [[ "${skip_device_check}" != 1 && ! -e "${device_path}" ]]; then
    echo "MLU device node is unavailable: ${device_path}" >&2
    exit 2
  fi
  docker_args+=(--device "${device_path}")
done
IFS=',' read -r -a control_device_list <<< "${control_devices}"
for device_path in "${control_device_list[@]}"; do
  [[ -n "${device_path}" ]] || continue
  if [[ "${skip_device_check}" != 1 && ! -e "${device_path}" ]]; then
    echo "MLU control device node is unavailable: ${device_path}" >&2
    exit 2
  fi
  docker_args+=(--device "${device_path}")
done

for name in MLU_VISIBLE_DEVICES CUDA_VISIBLE_DEVICES DATASET VAL_DATASET OUTPUT_DIR MODELS_DIR RESUME_FROM_CHECKPOINT NPROC_PER_NODE WANDB_MODE TOKENIZERS_PARALLELISM MINICPM_STRICT_IDENTITY MINICPM_IDENTITY_MANIFEST MINICPM_SFT_PRESET MINICPM_PRESET_GRADIENT_CHECKPOINTING MAX_STEPS NUM_TRAIN_EPOCHS SAVE_STEPS SAVE_TOTAL_LIMIT LOGGING_STEPS REPORT_TO MAX_LENGTH MAX_PIXELS PER_DEVICE_TRAIN_BATCH_SIZE GRADIENT_ACCUMULATION_STEPS LEARNING_RATE WARMUP_RATIO GRADIENT_CHECKPOINTING FREEZE_VIT DATALOADER_NUM_WORKERS TUNER_TYPE TARGET_MODULES LORA_RANK LORA_ALPHA LORA_DROPOUT TORCH_DTYPE SPLIT_DATASET_RATIO DATA_SEED LR_SCHEDULER_TYPE OPTIM ADAM_BETA1 ADAM_BETA2 ADAM_EPSILON WEIGHT_DECAY SEED DATASET_SHUFFLE DATALOADER_DROP_LAST PACKING PADDING_FREE PADDING_SIDE TEMPLATE AVERAGE_TOKENS_ACROSS_DEVICES ADD_VERSION; do
  [[ -v "${name}" ]] && docker_args+=(--env "${name}")
done

if (($# == 0)); then
  set -- bash
fi
exec docker "${docker_args[@]}" "${image}" "$@"
