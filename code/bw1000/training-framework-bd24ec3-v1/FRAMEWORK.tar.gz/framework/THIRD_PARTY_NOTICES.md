# Third-party Source Inventory

The patches in this repository target the source revisions below. The license
names and SHA-256 values identify files read from those Git revisions, not from
a later branch tip. Upstream sources, model weights, datasets and vendor runtimes
are separate inputs and are not bundled in this source delivery.

| Patch target | Revision | Upstream license file | File SHA-256 |
| --- | --- | --- | --- |
| Diffusers | `a3608b512ed7248499a44c61d954965ed9bdae4d` | [Apache License 2.0](https://github.com/huggingface/diffusers/blob/a3608b512ed7248499a44c61d954965ed9bdae4d/LICENSE) | `f9e2070c247517b1ddf65f7b11b393484a18da91a958fd18a97bd0f241c3125c` |
| DiffSynth-Studio-GRPO | `e9dd628299267ff30d8cff44c8be431ee4bc9e51` | [Apache License 2.0](https://github.com/Jayce-Ping/DiffSynth-Studio-GRPO/blob/e9dd628299267ff30d8cff44c8be431ee4bc9e51/LICENSE) | `d43b96112d60d83595395649e61c6bc215f568052a979320489556c6c1262eb1` |
| Stable Fast 3D | `ff21fc491b4dc5314bf6734c7c0dabd86b5f5bb2` | [Stability AI Community License Agreement](https://github.com/Stability-AI/stable-fast-3d/blob/ff21fc491b4dc5314bf6734c7c0dabd86b5f5bb2/LICENSE.md) | `a0f992849ce25def8e531884edd7adf3c00cb8d2d4c59e49f0cb02597c29066e` |
| HunyuanVideo 1.5 | `60783e704160023913bee78f0b47036d393d4dfa` | [Tencent Hunyuan Community License Agreement](https://github.com/Tencent-Hunyuan/HunyuanVideo-1.5/blob/60783e704160023913bee78f0b47036d393d4dfa/LICENSE) | `c38236952096107a4adbc164f44cd1768745b0a20090ea858e0954c96a6b8391` |
| HY-Motion 1.0 | `4e426f5a1021cbcf7f375458c37b840ee7225229` | [Tencent HY-Motion 1.0 Community License Agreement](https://github.com/Tencent-Hunyuan/HY-Motion-1.0/blob/4e426f5a1021cbcf7f375458c37b840ee7225229/License.txt) | `03e846e8bcaae503dbb878cb5b125b9810d8cac8bfc38b0275c4886759afd81b` |
| TRELLIS.2 | `75fbf0183001ed9876c8dbb35de6b68552ee08bd` | [MIT License, Microsoft Corporation](https://github.com/microsoft/TRELLIS.2/blob/75fbf0183001ed9876c8dbb35de6b68552ee08bd/LICENSE) | `d9a1b1e30d633d5732ea18e3cba9538d293ebc53e1a9e4e96ab739e0c5c4f1cb` |

HunyuanVideo also supplies an upstream [NOTICE](https://github.com/Tencent-Hunyuan/HunyuanVideo-1.5/blob/60783e704160023913bee78f0b47036d393d4dfa/NOTICE),
SHA-256 `534cc588b18839005089731fd3907af266386d18288b4349be4d75a7705bbfdf`.
Keep upstream copyright and notice files with deployed source checkouts.
The two HY-Motion patch files share the same upstream revision and license.

This inventory does not relicense third-party code, grant rights to model
weights, or establish that a particular deployment or redistribution is allowed.
Package dependencies and their bundled notices must also be reviewed when
distributing a runtime image. The original adapter code has no open-source
license grant in this delivery; its owner must approve an outbound license
before it is published as an open-source project.

## CPU Sparse Material Sampling

`generation/src/genmlu/trellis_cpu_texture_export.py::SparseSampler` adapts the
forward neighbor/weight mathematics of FlexGEMM's
`flex_gemm/kernels/cuda/grid_sample/grid_sample.cu` at
`6dd94a859c26ee8246888502eada3dd8ad85532e`, with NumPy sparse lookup instead of CUDA.
The reference is not a required installed package or a deployed CUDA parity
claim. Its [MIT license](https://github.com/JeffreyXiang/FlexGEMM/blob/6dd94a859c26ee8246888502eada3dd8ad85532e/LICENSE)
and copyright notice are reproduced in the sampler's module, so they also ship
with the Python package.

CPU UV unwrap and texture rasterization call externally provided Stable Fast 3D
modules; no SF3D source or native binaries are bundled here. The source reference
and Community License above still apply to those separately supplied components.
Deployment must preserve their notices and satisfy the upstream license terms.
Expected hashes identify the supplied build, not permission to redistribute it.
