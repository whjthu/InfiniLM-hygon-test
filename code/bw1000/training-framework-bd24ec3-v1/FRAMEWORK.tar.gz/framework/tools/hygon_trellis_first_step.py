"""Bind the original TRELLIS Shape Flow cache and replay one frozen A100 update on HIP."""

from __future__ import annotations

import argparse
from dataclasses import asdict
import json
import os
from pathlib import Path
import random
import sys

REFERENCE = "c164b02f2bd4edea0d266daebf7d93adef17e753589d95fb530f81b1fba9e612"
POLICY = "6c89ab647541db1ba2e762c15308cfaad1a71b8b954bb7bcda7e8ca314016064"
LAUNCH = "d5b23154d64af63332e54e079d6b0fda0a2904f53bdd0e6a0541fa265fad29fa"
BOUNDARY = "trellis-shape-flow-frozen-first-update"


def inputs_and_reference(torch, args):
    from gencuda.backends.trellis2_training import realize_flow_inputs
    from gencuda.trellis_training_contract import (
        CONFIG_SHA, PIPELINE_SHA, PREFIX, adapter_shapes, file_sha, load_cache, require, resolve_config,
    )

    ref = args.reference / "reference.pt"
    policy = args.reference / "policy.json"
    launch = args.reference / "a100-launch.json"
    for path, pin in ((ref, REFERENCE), (policy, POLICY), (launch, LAUNCH)):
        require(file_sha(path) == pin, f"TRELLIS first-step binding differs: {path.name}")
    require(json.loads(policy.read_bytes())["reference_payload_sha256"] == REFERENCE,
            "TRELLIS policy refers to a different reference")
    config = json.loads(launch.read_bytes())["config"]
    config["training_cache"] = str(args.cache)
    if args.source:
        config["source_root"] = str(args.source)
    config = resolve_config(config)
    require(config["max_tokens"] == 1024 and config["max_condition_tokens"] == 2048,
            "original Shape Flow limits differ")

    component = args.weights / "ckpts" / (PREFIX + ".json")
    pipeline = args.weights / "pipeline.json"
    require(file_sha(component) == CONFIG_SHA and file_sha(pipeline) == PIPELINE_SHA,
            "TRELLIS component or pipeline configuration differs")
    normalization = json.loads(pipeline.read_bytes())["args"]["shape_slat_normalization"]
    arrays, cache = load_cache(config, normalization)
    reference = torch.load(ref, map_location="cpu", weights_only=True)
    inputs = reference["inputs"]
    shapes = {
        "coords": ((1024, 4), torch.int32),
        "clean": ((1024, 32), torch.bfloat16),
        "condition": ((1, 1029, 1024), torch.bfloat16),
        "noise": ((1024, 32), torch.bfloat16),
        "fraction": ((1,), torch.float32),
        "noised": ((1024, 32), torch.bfloat16),
        "target": ((1024, 32), torch.bfloat16),
    }
    require(set(inputs) == set(shapes), "TRELLIS first-step input inventory differs")
    for name, (shape, dtype) in shapes.items():
        tensor = inputs[name]
        require(isinstance(tensor, torch.Tensor) and tensor.shape == shape and tensor.dtype == dtype
                and bool(torch.isfinite(tensor).all()), f"TRELLIS realized tensor differs: {name}")
    require(0 <= inputs["fraction"].item() <= 1, "TRELLIS invalid sampled timestep fraction")
    for key, array in (("coords", "coords"), ("clean", "shape_latent"), ("condition", "condition")):
        require(torch.equal(torch.from_numpy(arrays[array]).to(inputs[key].dtype), inputs[key]),
                f"normalized original cache differs from A100 tensor: {key}")
    require(torch.equal(reference["prediction_coords"], inputs["coords"]),
            "A100 prediction coordinate ordering differs")
    noised, target = realize_flow_inputs(inputs["clean"], inputs["fraction"], inputs["noise"])
    arithmetic = {
        "noised_bitwise_on_cpu": torch.equal(noised, inputs["noised"]),
        "target_bitwise_on_cpu": torch.equal(target, inputs["target"]),
    }
    initial = reference["initial_adapter"]
    layout = adapter_shapes()
    require(list(initial) == list(layout) and sum(t.numel() for t in initial.values()) == 96256,
            "TRELLIS original adapter inventory differs")
    for name, tensor in initial.items():
        require(tuple(tensor.shape) == layout[name] and tensor.dtype == torch.float32
                and bool(torch.isfinite(tensor).all()), f"invalid original adapter tensor: {name}")
    optimizer = reference["initial_optimizer"]
    group, = optimizer["param_groups"]
    require(optimizer["state"] == {} and group["params"] == list(range(len(layout))) and
            group["lr"] == config["learning_rate"] and group["weight_decay"] == config["weight_decay"],
            "TRELLIS original first AdamW groups differ")
    return config, reference, cache, arithmetic



EXCLUDED_SOURCE = "trellis2/pipelines/rembg/BiRefNet.py"


def verify_shape_flow_source(config, expected_path):
    from gencuda.trellis_training_contract import file_sha, json_sha, require, verify_source

    if expected_path is None:
        return verify_source(config)
    baseline = json.loads(expected_path.read_bytes())
    require(len(baseline) == 93 and EXCLUDED_SOURCE in baseline
            and json_sha(baseline) == config["source_inventory_sha256"], "TRELLIS original source inventory differs")
    root = Path(config["source_root"]).resolve(strict=True)
    require((root / "trellis2").is_dir() and not (root / "trellis2").is_symlink(), "invalid TRELLIS source directory")
    entries = list((root / "trellis2").rglob("*"))
    require(all(not item.is_symlink() for item in entries), "symlink in TRELLIS Shape Flow source")
    actual = {item.relative_to(root).as_posix(): file_sha(item) for item in entries if item.is_file()}
    expected = {name: digest for name, digest in baseline.items() if name != EXCLUDED_SOURCE}
    require(actual == expected, "TRELLIS Shape Flow source differs from the original 92-file closure")
    return {"path": str(root), "python_inventory_sha256": json_sha(actual),
            "original_inventory_sha256": config["source_inventory_sha256"],
            "excluded_source": EXCLUDED_SOURCE, "source_files": len(actual)}


def executed_source(config):
    from gencuda.backends.trellis2_training import validate_module_origin
    from gencuda.trellis_training_contract import file_sha, require

    root = Path(config["source_root"]).resolve()
    modules = {}
    for name, module in sorted(sys.modules.copy().items()):
        if name != "trellis2" and not name.startswith("trellis2."):
            continue
        validate_module_origin(module, root, name)
        if getattr(module, "__file__", None):
            path = Path(module.__file__).resolve()
            rel = path.relative_to(root).as_posix()
            require(rel != EXCLUDED_SOURCE, "TRELLIS background-removal module was executed")
            modules[rel] = file_sha(path)
    require("trellis2/models/structured_latent_flow.py" in modules, "TRELLIS Shape Flow did not load")
    return modules


def prepare_model(torch, args, config, reference, device):
    from gencuda.backends.trellis2_training import _import_model, inject_lora, load_base_weights, trainable_parameters
    from gencuda.hy_resume_checkpoint import cpu_tree
    from gencuda.trellis_training_contract import inspect_weights, require
    from gencuda.trellis_training_resume_checkpoint import make_optimizer

    model_config, _, weights = inspect_weights(args.weights)
    require(model_config["name"] == "SLatFlowModel", "TRELLIS component model class differs")
    model_class, sparse = _import_model(config)
    model = model_class(**model_config["args"])
    load_base_weights(model, weights)
    inject_lora(model)
    for block in model.blocks:
        block.use_checkpoint = config["gradient_checkpointing"]
    model.to(device).train()
    named = trainable_parameters(model)
    initial = reference["initial_adapter"]
    require(list(named) == list(initial), "TRELLIS device adapter names or order differ")
    with torch.no_grad():
        for name, parameter in named.items():
            parameter.copy_(initial[name])
            require(parameter.device == device and torch.equal(parameter.cpu(), initial[name]),
                    f"TRELLIS initial adapter copy differs: {name}")
    optimizer = make_optimizer(list(named.values()), config)
    optimizer.load_state_dict(reference["initial_optimizer"])
    return model, sparse, named, optimizer, cpu_tree(named), cpu_tree(optimizer.state_dict()), weights


def construct(torch, args, config, reference):
    source = verify_shape_flow_source(config, args.source_inventory)
    torch.manual_seed(config["seed"])
    model, _, named, _, _, _, weights = prepare_model(torch, args, config, reference, torch.device("cpu"))
    modules = executed_source(config)
    from gencuda.trellis_training_contract import require
    require(not torch.cuda.is_initialized(), "CPU construction initialized a GPU")
    require(verify_shape_flow_source(config, args.source_inventory) == source, "TRELLIS source changed")
    return {"scope":"native CPU construction from the exact original checkpoint",
            "source":source,"executed_source":modules,"model_type":type(model).__name__,
            "weights_SHA256":weights["sha256"],"weight_tensors":len(weights["header"]),
            "trainable_tensors":len(named),"trainable_elements":sum(p.numel() for p in named.values()),
            "gpu_initialized":False,"forward_executed":False}

def replay(torch, args, config, reference, cache, arithmetic):
    import numpy as np
    from gencuda.backends.trellis2_training import checked_memory, flow_prediction_and_loss, observe_sdpa
    from gencuda.hy_resume_checkpoint import cpu_tree
    from gencuda.runtime import MEMORY_LIMIT_BYTES, inspect_runtime, validate_accelerator
    from gencuda.trellis_training_contract import require, file_sha

    runtime = inspect_runtime()
    validate_accelerator(runtime, "hip", 1)
    source = verify_shape_flow_source(config, args.source_inventory)
    device = torch.device("cuda", 0)
    torch.cuda.set_device(device)
    total = torch.cuda.get_device_properties(device).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1.0, MEMORY_LIMIT_BYTES / total), device)
    torch.cuda.reset_peak_memory_stats(device)
    seed = config["seed"]
    random.seed(seed)
    np.random.seed(seed % 2**32)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    model, sparse, named, optimizer, initial_adapter, initial_optimizer, weights = prepare_model(
        torch, args, config, reference, device,
    )
    initial = reference["initial_adapter"]
    inputs = {name: t.to(device) for name, t in reference["inputs"].items()}
    optimizer.zero_grad(set_to_none=True)
    with observe_sdpa(torch) as sdpa:
        prediction, loss = flow_prediction_and_loss(
            torch, model, sparse, inputs["coords"], inputs["noised"],
            inputs["fraction"], inputs["condition"], inputs["target"],
        )
        require(bool(torch.isfinite(prediction.feats).all()) and bool(torch.isfinite(loss)),
                "nonfinite TRELLIS prediction")
        loss.backward()
    require(sdpa["forward_and_recompute_calls"] > 0, "no actual BF16 SDPA calls observed")
    before = {name: cpu_tree(p.grad) for name, p in named.items()}
    require(all(t is not None and bool(torch.isfinite(t).all()) for t in before.values()), "invalid TRELLIS gradient")
    norm = torch.nn.utils.clip_grad_norm_(list(named.values()), config["max_grad_norm"])
    require(bool(torch.isfinite(norm)) and float(norm) > 0, "invalid TRELLIS gradient norm")
    after = {name: cpu_tree(p.grad) for name, p in named.items()}
    optimizer.step()
    torch.cuda.synchronize(device)
    final = cpu_tree(named)
    require(any(not torch.equal(initial[name], final[name]) for name in named), "TRELLIS zero adapter update")
    modules = executed_source(config)
    require(verify_shape_flow_source(config, args.source_inventory) == source, "TRELLIS source changed during the replay")
    args.output.mkdir()
    observed = args.output / "observed.pt"
    torch.save({
        "initial_adapter": initial_adapter, "initial_optimizer": initial_optimizer, "inputs": cpu_tree(inputs),
        "prediction": cpu_tree(prediction.feats), "prediction_coords": cpu_tree(prediction.coords),
        "loss": cpu_tree(loss), "gradients_before_clip": before, "gradients_after_clip": after,
        "preclip_norm": cpu_tree(norm), "final_adapter": final, "final_optimizer": cpu_tree(optimizer.state_dict()),
    }, observed)
    summary = {"stage_id": "trellis-shape", "boundary": BOUNDARY,
               "reference_sha256": REFERENCE, "policy_sha256": POLICY, "launch_sha256": LAUNCH,
               "runtime": asdict(runtime), "observed_sha256": file_sha(observed),
               "replay_source_sha256": file_sha(Path(__file__)),
               "weight_sha256": weights["sha256"], "upstream_inventory_sha256": source["python_inventory_sha256"],
               "cache_sha256": cache["file_sha256"], "cpu_arithmetic": arithmetic,
               "source_binding": {k: v for k, v in source.items() if k != "files"}, "executed_source": modules,
               "memory": checked_memory(), "sdpa": sdpa, "numerical_acceptance": "pending"}
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("reference", "weights", "cache"):
        parser.add_argument(f"--{name}", required=True, type=Path)
    for name in ("source", "source_inventory", "output"):
        parser.add_argument("--" + name.replace("_", "-"), type=Path)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--validate-only", action="store_true")
    mode.add_argument("--construct-only", action="store_true")
    args = parser.parse_args()
    if not args.validate_only and args.source is None:
        parser.error("--source is required for model construction or replay")
    if not (args.validate_only or args.construct_only) and (args.output is None or args.output.exists()):
        parser.error("a fresh --output is required for HIP replay")
    os.environ["HF_HUB_OFFLINE"] = "1"
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "generation" / "src"))
    from gencuda.runtime import get_torch

    torch = get_torch()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    config, reference, cache, arithmetic = inputs_and_reference(torch, args)
    if args.validate_only:
        print(json.dumps({"stage_id": "trellis-shape", "cache": {k: cache[k] for k in (
            "file_sha256", "semantic_sha256", "normalized_sha256", "tokens", "condition_tokens",
        )}, "cpu_arithmetic": arithmetic, "reference_loss": float(reference["loss"]),
            "original_cache_tensors_bitwise": True, "adapter_tensors": len(reference["initial_adapter"]),
            "adapter_elements": 96256, "weight_values_loaded": False, "gpu_initialized": torch.cuda.is_initialized()}))
    elif args.construct_only:
        print(json.dumps(construct(torch, args, config, reference)))
    else:
        print(json.dumps(replay(torch, args, config, reference, cache, arithmetic)))


if __name__ == "__main__":
    main()
