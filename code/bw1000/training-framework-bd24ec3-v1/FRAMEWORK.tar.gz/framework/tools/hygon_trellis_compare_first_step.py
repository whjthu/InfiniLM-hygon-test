"""Independently check a HIP TRELLIS first update against the frozen A100 policy."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from pickle import UnpicklingError

from hygon_sdxl_compare_first_step import check_tensor, exact, relative, require, sha, vector_metrics
from hygon_trellis_first_step import BOUNDARY, EXCLUDED_SOURCE, LAUNCH, POLICY, REFERENCE

REPLAY = Path(__file__).with_name("hygon_trellis_first_step.py")
FIELDS = {
    "initial_adapter", "initial_optimizer", "inputs", "prediction", "prediction_coords", "loss",
    "gradients_before_clip", "gradients_after_clip", "preclip_norm", "final_adapter", "final_optimizer",
}


def compare(torch, actual, reference, policy):
    require(set(actual) == FIELDS, "TRELLIS observed field inventory differs")
    limits = policy["metrics"]
    for key in ("initial_adapter", "initial_optimizer", "inputs", "prediction_coords"):
        exact(torch, actual[key], reference[key], key)
    initial = reference["initial_adapter"]
    expected = reference["final_optimizer"]
    observed = actual["final_optimizer"]
    require(set(observed) == {"param_groups", "state"}, "TRELLIS optimizer schema differs")
    exact(torch, observed["param_groups"], expected["param_groups"], "final optimizer groups")
    state, ref_state = observed["state"], expected["state"]
    moments = tuple(policy["optimizer_state_tensor_keys"])
    require(moments == ("exp_avg", "exp_avg_sq"), "TRELLIS AdamW moment policy differs")
    names = list(initial)
    require(list(state) == list(ref_state) == list(range(len(names))), "TRELLIS optimizer state IDs or order differ")
    for i, fields in ref_state.items():
        require(list(state[i]) == list(fields), f"TRELLIS optimizer fields differ: {names[i]}")
        for key in fields.keys() - set(moments):
            exact(torch, state[i][key], fields[key], f"optimizer/{names[i]}/{key}")

    checks = {"exact_inputs_and_state_schema": True}
    metrics = {}
    for key, limit in (
        ("loss", "loss_relative_error_max"), ("preclip_norm", "gradient_preclip_norm_relative_error_max"),
    ):
        left, right = actual[key], reference[key]
        check_tensor(torch, left, right, key)
        require(right.is_floating_point() and right.numel() == 1, f"{key}: expected a scalar")
        a, b = float(left), float(right)
        error = relative(abs(a - b), abs(b))
        metrics[key] = {"observed": a, "reference": b, "relative_error": error}
        checks[key] = error is not None and error <= limits[limit]

    def vectors(key, left, right, limit, start=None):
        metrics[key] = vector_metrics(torch, left, right, key, start)
        error = metrics[key]["relative_l2"]
        checks[key] = error is not None and error <= limits[limit]

    vectors("prediction", {"output": actual["prediction"]}, {"output": reference["prediction"]},
            "prediction_relative_l2_max")
    for key, limit in (
        ("gradients_before_clip", "gradient_preclip_relative_l2_max"),
        ("gradients_after_clip", "gradient_postclip_relative_l2_max"),
    ):
        require(list(reference[key]) == names, f"{key}: initial trainable order differs")
        vectors(key, actual[key], reference[key], limit)
    cosine = metrics["gradients_before_clip"]["cosine"]
    checks["gradient_direction"] = cosine is not None and cosine >= limits["gradient_preclip_cosine_min"]
    require(list(reference["final_adapter"]) == names, "TRELLIS final trainable order differs")
    vectors("parameter_update", actual["final_adapter"], reference["final_adapter"],
            "parameter_update_relative_l2_max", initial)
    for key in moments:
        vectors("optimizer_" + key, {names[i]: state[i][key] for i in ref_state},
                {names[i]: ref_state[i][key] for i in ref_state}, "optimizer_moment_relative_l2_max")
    checks["all_required_floating_values_finite"] = True
    checks["nonzero_gradient_and_update"] = all(
        metrics[key][side] > 0 for key in ("gradients_before_clip", "parameter_update")
        for side in ("reference_l2", "observed_l2")
    )
    return {"passed": all(checks.values()), "checks": checks, "metrics": metrics}


def verify_receipt(receipt, observed_sha, replay_sha, inventory):
    required = {
        "stage_id": "trellis-shape", "boundary": BOUNDARY,
        "reference_sha256": REFERENCE, "policy_sha256": POLICY, "launch_sha256": LAUNCH,
        "observed_sha256": observed_sha, "replay_source_sha256": replay_sha,
        "weight_sha256": "ec5e0917ef9b7e25ad51dffc7d19687a42019871f94239f2fa7f86264c55b70f",
        "cache_sha256": "d6c6370b340a21aca16568a1c9ed56e1ca6e26c1ecb458386c8ee9b905ee1a88",
    }
    require(all(receipt.get(key) == value for key, value in required.items()),
            "TRELLIS observed file or replay receipt differs from the frozen binding")
    runtime = receipt["runtime"]
    require(runtime["accelerator"] == "hip" and runtime["cuda_available"] is True
            and type(runtime["cuda_count"]) is int and runtime["cuda_count"] == 1,
            "TRELLIS receipt must record one HIP device")
    calls = receipt["sdpa"]["forward_and_recompute_calls"]
    require(type(calls) is int and calls > 0, "TRELLIS BF16 SDPA execution evidence is missing")
    executed = receipt["executed_source"]
    require("trellis2/models/structured_latent_flow.py" in executed and EXCLUDED_SOURCE not in executed
            and all(inventory.get(path) == digest for path, digest in executed.items()),
            "TRELLIS executed source differs from the A100 inventory")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("reference", "observed", "receipt", "output"):
        parser.add_argument(f"--{name}", required=True, type=Path)
    parser.add_argument("--source-inventory", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("--output must not already exist")
    import torch
    reference_path = args.reference / "reference.pt"
    policy_path = args.reference / "policy.json"
    launch_path = args.reference / "a100-launch.json"
    for path, expected in ((reference_path, REFERENCE), (policy_path, POLICY), (launch_path, LAUNCH)):
        require(sha(path) == expected, "TRELLIS A100 evidence file differs")
    require(sha(args.source_inventory) == "48669721adaee4162ee2dc7b232e7779d14c687b8e00e90319612505c45151cf",
            "TRELLIS A100 source inventory differs")
    inventory = json.loads(args.source_inventory.read_bytes())
    reference = torch.load(reference_path, map_location="cpu", weights_only=True)
    policy = json.loads(policy_path.read_bytes())
    observed_sha = sha(args.observed)
    receipt_sha = sha(args.receipt)
    replay_sha = sha(REPLAY)
    try:
        verify_receipt(json.loads(args.receipt.read_bytes()), observed_sha, replay_sha, inventory)
        actual = torch.load(args.observed, map_location="cpu", weights_only=True)
        result = compare(torch, actual, reference, policy)
    except (KeyError, TypeError, AttributeError, ValueError, RuntimeError, EOFError, UnpicklingError) as error:
        result = {"passed": False, "evidence_error": f"{type(error).__name__}: {error}"}
    result.update(stage_id="trellis-shape", boundary=BOUNDARY, reference_sha256=REFERENCE, policy_sha256=POLICY,
                  launch_sha256=LAUNCH, observed_sha256=observed_sha, replay_receipt_sha256=receipt_sha,
                  replay_source_sha256=replay_sha, comparator_sha256=sha(Path(__file__)))
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"passed": result["passed"], "failed_checks": [k for k, ok in result.get("checks", {}).items() if not ok],
                      "evidence_error": result.get("evidence_error")}))
    return int(not result["passed"])


if __name__ == "__main__":
    raise SystemExit(main())
