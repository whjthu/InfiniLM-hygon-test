"""Validate release commit identities, messages and tracked file types."""

from __future__ import annotations

import argparse
import subprocess

from check_repository import RESIDUE, ROOT, check_file


def git(*arguments: str) -> str:
    return subprocess.run(
        ["git", "-C", str(ROOT), *arguments], check=True,
        stdout=subprocess.PIPE, encoding="utf-8",
    ).stdout


def read_blob(object_id: str) -> bytes:
    return subprocess.run(
        ["git", "-C", str(ROOT), "cat-file", "blob", object_id],
        check=True, stdout=subprocess.PIPE,
    ).stdout


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--revision", default="HEAD")
    parser.add_argument("--name", default="whjthu")
    parser.add_argument("--email", default="haojie0429@gmail.com")
    args = parser.parse_args()
    failures = []
    checked_blobs = set()
    commits = git("rev-list", args.revision).splitlines()
    for commit in commits:
        fields = git("show", "-s", "--format=%an%x00%ae%x00%cn%x00%ce%x00%B", commit).split("\0", 4)
        if fields[:4] != [args.name, args.email, args.name, args.email]:
            failures.append(f"{commit}: unexpected author or committer")
        message = fields[4].strip()
        if len(message.splitlines()) != 1 or not message:
            failures.append(f"{commit}: commit message must contain exactly one nonempty line")
        if RESIDUE.search(message):
            failures.append(f"{commit}: generated-message residue in commit message")
        for entry in git("ls-tree", "-rz", commit).split("\0"):
            if not entry:
                continue
            metadata, name = entry.split("\t", 1)
            mode, _, object_id = metadata.split()
            if mode not in {"100644", "100755"}:
                failures.append(f"{commit}: non-source file mode for {name}")
                continue
            key = (name, object_id)
            if key not in checked_blobs:
                checked_blobs.add(key)
                failures.extend(
                    f"{commit}: {name}: {error}"
                    for error in check_file(name, read_blob(object_id))
                )
    if failures:
        print("\n".join(failures))
        return 1
    print(f"Checked {len(commits)} commits and {len(checked_blobs)} source revisions.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
