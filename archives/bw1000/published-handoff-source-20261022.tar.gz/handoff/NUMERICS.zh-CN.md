# 数据问题与修复方案

## 最新用户验收要求（优先于下文历史 raw gate）

用户明确要求：**不需要所有数值逐位一致，保证最终输出的 token 一致即可。** 完整生成 token ID 序列（含 EOS）与同输入冻结参考一致是数值验收标准；logits 在重复行、rank、重复运行或精度变体间的逐位差异仅作诊断。仍验证有限值、CPU argmax 与实际所选 GPU token 一致、EOS、同配置重复、owner/设备/stream、正常退出和 Slurm 终态。raw SHA 用于文件完整性，不能据此要求模型数值逐位相同。

原生 BF16/FP32 为优先性能路径，F64 仅作参考和对照。F64 相对 BF16 的通信负载字节数为 4 倍，整模型慢多少必须实测。历史 raw-only 失败保留并标注旧规则；仅 raw 不同不再淘汰候选。完整 token ID 不同（包括空格 token）仍是失败，不做文本归一化放宽。

Kimi 已安排原生 BF16、FP32 两组完整模型试验，对冻结 F64 序列检查完整 token，并用相同 round-feedback 调度作 F64/候选/候选/F64 同进程对照。Deep 原生与匹配同步模式也按 token 标准重测。新精度路径尚无审计后的性能数字。具体代码见 `drivers/*r3560*`、`drivers/audit_kimi_token_r3562.py`、`drivers/*r3564*`，规则见 `evidence/token-acceptance-policy.json`。

## Kimi-K3

当前复现的数值问题是：相同输入的 batch 行在原始 logits 中出现差异。第一层 KDA 的输入、局部 QKV、状态和归一化检查一致；实际 `o_proj` 局部 GEMM 在 8 个 rank 上重复、重复行也一致，随后 BF16 SUM 可以复现输出行差异。将该局部归约升为 FP32 可恢复 CPU FP64 累加后舍入到 BF16 的结果。

FP32 方案并未修复整模型。`r3266` 在 B1 的 OFF/ON 共 44 项 QA、B8 前两项各两次 QA 通过后，仍在 retrieval 的 decode step 2 失败。行 2、6 相对行 0 有 89,005 个 BF16 word 不同，最大绝对差 0.0625，relative L2 约 0.003755；8 行 argmax 仍相同。这是旧 raw 规则下的失败证据。根据最新用户要求，raw 差异只作诊断；该候选须按完整 token 序列、EOS 和重复生成重新验收。

### 当前修复候选

`r3393` Common 增加 policy 2：仅对实际多请求的 BF16 和 FP32 SUM 使用 F64 scratch、原生 F64 SUM，再转换回原 dtype。B1 即使 prefill 打包 M 很大也不升精度，避免把矩阵行数误当请求数。policy 0 为基线，policy 1 保留 BF16→FP32。

Hygon Cast 原本缺少 F64；`r3314/r3315` 加入转换，并在三个模型的私有 SDK 上通过 3,840 个新 Cast 案例、2,160 个旧九种转换回归及 CPU 精确舍入审计。F64 TP8 组件 `r3385/r3388` 的 192 项样例通过 CPU FP64 oracle、重复及 8 个通信域正常关闭。该合成样例的 F32 控制出现重复行差异，但没有 BF16 可见差异，因此不能据此宣称已解释整模型失败。

Common `r3395` 已构建、默认关闭和非法输入检查通过。真实权重投影回放 `r3409/r3410` 已运行结束；其独立 CPU 审计 `r3411` 已通过 48 项、384 个 raw 文件及 8 个正常关闭。整模型 Mode2 在本次观察时已完成 57 项 QA、经过此前 retrieval step2 失败窗口，仍未完成全部测试。最终整模型结果以 `evidence/recheck-status.json` 为准。

### 验证与收敛顺序

1. 先审计真实权重投影的每个 rank 局部输出、完整归约结果、FP64 oracle、输入只读、B1 不升精度、忙状态和正常关闭。
2. 保留 `Model r3261` 的私有 CommunicationGroup 构造与布局，只把自由函数 `allreduce_` 解析到新的 Common。曾删除整个私有 group 对象导致 ABI 不匹配并崩溃，不能重复这个做法。
3. 整模型先验证冻结 B1 OFF/ON，再测试 B8 retrieval 失败窗口，之后完成全部 batch QA、重复行、全量 raw、EOS、计数及退出检查。按模型实际出现的 dtype 读取 F64 调用计数，不臆测每次前向都含 F32 SUM；两种 dtype 的转换与通信另有组件覆盖。B1 升精度次数必须为零。
4. 若 F64 仍失败，保存未插桩的首个差异窗口；对照局部计算、归约前 partial、归约后结果、残差和状态更新，逐步缩小到最早层与张量。同步式 tracing 会改变执行，必须用未追踪重放确认。
5. 只有完整模型通过后测 B2/B4/B8，再做流水线 G32/G64 和连续批处理。性能路径优先原生 BF16/FP32；按最新完整 token 标准验收，仅在确有 token 错误且定位边界后考虑选择性升精度。

目前不能将差异归因于硬件故障或某个厂商库的实现缺陷；现有证据定位到了特定边界及条件，没有完成全部因果隔离。

## DeepSeek-v4-Flash

当前默认关闭的 `r2904` 多请求 attention BF16→FP32 归约在 B2 仍失败。固定 160 次重放中，OFF 的重复行差异为 16/80、跨重复差异为 64/80；ON 分别为 48/80 和 64/80。最大 L2 差异变小不构成修复。

长 tracing 的 24 组最终 raw 均未与对应未追踪运行一致，说明观察方式扰动了失败窗口。应先用未追踪原始运行确定差异，再以最小张量保存缩小边界。Deep 专用 Cast64 SDK 已通过算子检查，但没有已验收的 Deep F64 整模型修复。

新增 `r3443` 隔离候选将 mode0 原始执行、mode1 原始数学加相同同步、mode2 attention F64、mode3 再加 FFN F64、mode4 再加 indexer F64 分开测试。实际 B1 不升精度，scratch 在释放前排空。先对 Deep 专用 SDK/Common 做 F64 组件和独立 CPU oracle，再测原始 B2；Deep 专用 F64 组件 `r3445/r3449` 已通过 192 项、1,728 个 raw 文件和 8 个正常通信关闭，独立 CPU oracle 通过；整模型短输入和长输入 `r3457/r3458` 已并行提交。该候选目前没有整模型修复或性能结论。

## GLM-5.3

现有有效吞吐基线已通过完整 batch、raw、QA 和退出审计。优先在该基线上做吞吐优化，避免同时引入数值变化。

专家排序 `r3328/r3348` 按 expert 分桶，保留原 dot tree 和输出位置。组件在 M512/4096 的部分真实 shape 有约 1.08–1.14 倍收益，M8 无收益，单 expert 部分 shape 退步。整模型 ABBA 正在运行，不能将组件收益当作整模型收益。

Prefill plan cache 的已观察整体改善约 0.6%，不足以解释主要瓶颈。已通过审计的 timeline 指向 prefill FFN 和 decode attention/indexer，后续先做相同形状与数学路径下的缓存、排序、调度和通信优化。BF16 scaled GEMM 的 21 个误差超限及 compensated GEMM 的一次重复性失败保留为否定结果，不得直接进入稳定模型。

## 10 月 20 日晚：故障窗口更新（优先于前文进行中状态）

Kimi 整模型 F64 `r3419` 最终在 B2 sort 的冻结答案 ID 检查失败。`r3486` 保存了完整输出：两行一致，较冻结 B1 答案少三个经过历史词表验证的独立空格 token 220。原严格 literal-ID 失败仍保留，不能因排序文本相同直接把完整模型改成通过。下一步分开检查语义答案、同 batch raw 重复、B1 前后不变和数值变体质量；不得抹去原失败或将 token 一致当 raw 一致。B4/B8 分别跑完整前后 QA 与性能，结果尚未验收。

Deep `r3443` mode2 已通过 B4 完整测试并获得实际吞吐；B2 在 retrieval 首步重复行 raw gate 失败。五种模式诊断提示升精度并非通用修复，且原诊断遗漏 affinity 环境变量导致末尾失败，不能把其收集到的矩阵当完整合格运行。B8 当前入口报 Native Engine CAPI input differs，应先检查输入宽度和 4096 元素上限、prefill 分块及协议约束，再分析数学路径；不是已证明的硬件错误。

最新上游 SDK 三个变体已编译/安装，但 CPU-only 加载检查 abort，尚待读取完整首个错误区分 Torch 注册与库依赖问题。`c3deba4` 不得直接继承旧版数值或吞吐验收。

更新至本轮末：新上游三个 SDK 已在健康节点通过 GPU 可见加载（每节点8卡小计算检查）；原 CPU-only 加载失败是无可见 ROCm 设备，保留负例。新 Common/Model、算子与吞吐仍须验收。旧版 Kimi 长文已独立审计 68.53–68.70/59.89–60.10 tok/s；当前 GLM G128/M32、最多128输出的组合优化已审计 60.51/20.83 tok/s（decode/含prefill），详见性能末表。Deep B8 分块 prefill 已重新测试；Kimi 流水线 producer 已结束，独立审计待完成。
